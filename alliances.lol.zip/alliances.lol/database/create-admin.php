<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    exit('Run this script from the terminal.');
}

require dirname(__DIR__) . '/src/database.php';

function prompt(string $label): string
{
    echo $label;

    $input = fgets(STDIN);

    if ($input === false) {
        throw new RuntimeException('No input received.');
    }

    return rtrim($input, "\r\n");
}

$displayName = trim(prompt('Display name: '));
$email = strtolower(trim(prompt('Email: ')));
$workspaceName = trim(prompt('Team/workspace name: '));
$password = prompt('Password (visible while typing): ');

if ($displayName === '' || $workspaceName === '') {
    exit("Display name and workspace name are required.\n");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("Enter a valid email address.\n");
}

if (strlen($password) < 12 || strlen($password) > 72) {
    exit("Use a password between 12 and 72 bytes long.\n");
}

$connection = db();

try {
    $connection->beginTransaction();

    $statement = $connection->prepare(
        'INSERT INTO users (display_name, email, password_hash)
         VALUES (?, ?, ?)'
    );

    $statement->execute([
        $displayName,
        $email,
        password_hash($password, PASSWORD_DEFAULT),
    ]);

    $userId = (int) $connection->lastInsertId();

    $statement = $connection->prepare(
        'INSERT INTO workspaces (name, timezone) VALUES (?, ?)'
    );

    $statement->execute([$workspaceName, 'Europe/Oslo']);

    $workspaceId = (int) $connection->lastInsertId();

    $statement = $connection->prepare(
        'INSERT INTO workspace_members (workspace_id, user_id, role)
         VALUES (?, ?, ?)'
    );

    $statement->execute([$workspaceId, $userId, 'admin']);

    $connection->commit();

    echo "Administrator account and workspace created successfully.\n";
} catch (Throwable $error) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    fwrite(STDERR, "Creation failed: {$error->getMessage()}\n");
    exit(1);
}