<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    exit('Run this script from the terminal.');
}

require_once dirname(__DIR__) . '/src/database.php';

function prompt(string $label): string
{
    echo $label;

    $input = fgets(STDIN);

    if ($input === false) {
        throw new RuntimeException('No input received.');
    }

    return trim($input);
}

$displayName = prompt('Display name: ');
$email = strtolower(prompt('Email: '));
$password = prompt('Password: ');

if ($displayName === '') {
    exit("Display name is required.\n");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit("Enter a valid email address.\n");
}

if (strlen($password) < 12 || strlen($password) > 72) {
    exit("Use a password between 12 and 72 characters.\n");
}

$connection = db();

$workspaces = $connection
    ->query(
        'SELECT id, name
         FROM workspaces
         ORDER BY name ASC'
    )
    ->fetchAll();

if ($workspaces === []) {
    exit("No workspaces exist yet.\n");
}

echo PHP_EOL . "Available workspaces:" . PHP_EOL;

foreach ($workspaces as $workspace) {
    echo $workspace['id'] . ': ' . $workspace['name'] . PHP_EOL;
}

$workspaceId = (int) prompt('Workspace ID: ');

$validWorkspace = false;

foreach ($workspaces as $workspace) {
    if ((int) $workspace['id'] === $workspaceId) {
        $validWorkspace = true;
        break;
    }
}

if (!$validWorkspace) {
    exit("Invalid workspace ID.\n");
}

try {
    $connection->beginTransaction();

    $existingUserStatement = $connection->prepare(
        'SELECT id
         FROM users
         WHERE email = ?'
    );

    $existingUserStatement->execute([$email]);

    if ($existingUserStatement->fetchColumn() !== false) {
        throw new RuntimeException(
            'A user with this email already exists.'
        );
    }

    $userStatement = $connection->prepare(
        'INSERT INTO users
            (display_name, email, password_hash)
         VALUES (?, ?, ?)'
    );

    $userStatement->execute([
        $displayName,
        $email,
        password_hash($password, PASSWORD_DEFAULT),
    ]);

    $userId = (int) $connection->lastInsertId();

    $memberStatement = $connection->prepare(
        'INSERT INTO workspace_members
            (workspace_id, user_id, role)
         VALUES (?, ?, ?)'
    );

    $memberStatement->execute([
        $workspaceId,
        $userId,
        'member',
    ]);

    $connection->commit();

    echo PHP_EOL;
    echo "Test user created successfully." . PHP_EOL;
    echo "Workspace ID: {$workspaceId}" . PHP_EOL;
} catch (Throwable $error) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    fwrite(
        STDERR,
        "Could not create user: " . $error->getMessage() . PHP_EOL
    );

    exit(1);
}