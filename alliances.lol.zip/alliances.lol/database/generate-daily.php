<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/database.php';

$connection = db();

$date = (new DateTimeImmutable('today'))
    ->format('Y-m-d');

/*
|--------------------------------------------------------------------------
| Load active personal daily templates
|--------------------------------------------------------------------------
|
| Each template belongs to the user who created it.
|
| We intentionally do not assume that there is only one workspace.
|
*/

$templatesStatement = $connection->query(
    'SELECT
        dtt.id,
        dtt.workspace_id,
        dtt.created_by,
        dtt.assigned_to,
        dtt.name,
        dtt.description,
        dtt.deadline_time

     FROM daily_task_templates dtt

     INNER JOIN workspace_members wm
         ON wm.workspace_id = dtt.workspace_id
        AND wm.user_id = dtt.created_by

     WHERE dtt.active = 1

     ORDER BY
        dtt.workspace_id ASC,
        dtt.created_by ASC,
        dtt.id ASC'
);

$templates = $templatesStatement->fetchAll();

if ($templates === []) {
    return;
}

/*
|--------------------------------------------------------------------------
| Prepared statements
|--------------------------------------------------------------------------
*/

$findList = $connection->prepare(
    'SELECT tl.id

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     WHERE tl.workspace_id = ?
       AND tl.created_by = ?
       AND tl.name = ?

     LIMIT 1'
);

$createList = $connection->prepare(
    'INSERT INTO task_lists
        (
            workspace_id,
            created_by,
            name,
            start_date
        )
     VALUES (?, ?, ?, ?)'
);

$addListMember = $connection->prepare(
    'INSERT OR IGNORE INTO task_list_members
        (
            task_list_id,
            user_id
        )
     VALUES (?, ?)'
);

$occurrenceCheck = $connection->prepare(
    'SELECT id
     FROM daily_task_occurrences
     WHERE template_id = ?
       AND occurrence_date = ?
     LIMIT 1'
);

$createTask = $connection->prepare(
    'INSERT INTO tasks
        (
            task_list_id,
            assigned_to,
            name,
            description
        )
     VALUES (?, ?, ?, ?)'
);

$createOccurrence = $connection->prepare(
    'INSERT INTO daily_task_occurrences
        (
            template_id,
            task_list_id,
            task_id,
            occurrence_date
        )
     VALUES (?, ?, ?, ?)'
);

/*
|--------------------------------------------------------------------------
| Group templates by workspace + user
|--------------------------------------------------------------------------
*/

$templatesByUser = [];

foreach ($templates as $template) {
    $workspaceId =
        (int) $template['workspace_id'];

    $userId =
        (int) $template['created_by'];

    $key =
        $workspaceId
        . ':'
        . $userId;

    if (!isset($templatesByUser[$key])) {
        $templatesByUser[$key] = [
            'workspace_id' => $workspaceId,
            'user_id' => $userId,
            'templates' => [],
        ];
    }

    $templatesByUser[$key]['templates'][] =
        $template;
}

/*
|--------------------------------------------------------------------------
| Generate each user's personal daily list
|--------------------------------------------------------------------------
*/

foreach ($templatesByUser as $group) {
    $workspaceId =
        (int) $group['workspace_id'];

    $userId =
        (int) $group['user_id'];

    $userTemplates =
        $group['templates'];

    /*
    |--------------------------------------------------------------------------
    | Personal list name
    |--------------------------------------------------------------------------
    |
    | We can use the same visible name for everyone because created_by and
    | membership distinguish each user's list.
    |
    */

    $listName =
        'Daily Tasks ' . $date;

    /*
    |--------------------------------------------------------------------------
    | Find today's personal list
    |--------------------------------------------------------------------------
    */

    $findList->execute([
        $userId,
        $workspaceId,
        $userId,
        $listName,
    ]);

    $listId = $findList->fetchColumn();

    /*
    |--------------------------------------------------------------------------
    | Create list if needed
    |--------------------------------------------------------------------------
    */

    if ($listId === false) {
        $createList->execute([
            $workspaceId,
            $userId,
            $listName,
            $date,
        ]);

        $listId =
            (int) $connection->lastInsertId();

        /*
        |--------------------------------------------------------------------------
        | Only the owner is a member
        |--------------------------------------------------------------------------
        */

        $addListMember->execute([
            $listId,
            $userId,
        ]);
    } else {
        $listId = (int) $listId;

        /*
        |--------------------------------------------------------------------------
        | Make sure owner membership exists
        |--------------------------------------------------------------------------
        */

        $addListMember->execute([
            $listId,
            $userId,
        ]);
    }

    /*
    |--------------------------------------------------------------------------
    | Generate today's occurrences
    |--------------------------------------------------------------------------
    */

    foreach ($userTemplates as $template) {
        $templateId =
            (int) $template['id'];

        /*
        |--------------------------------------------------------------------------
        | Prevent duplicate occurrence
        |--------------------------------------------------------------------------
        */

        $occurrenceCheck->execute([
            $templateId,
            $date,
        ]);

        if (
            $occurrenceCheck->fetchColumn()
            !== false
        ) {
            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | Daily tasks are assigned to their owner
        |--------------------------------------------------------------------------
        |
        | We deliberately use the template creator rather than trusting an old
        | assigned_to value. Daily tasks are personal.
        |
        */

try {
    $connection->beginTransaction();

    $createTask->execute([
        $listId,
        $userId,
        $template['name'],
        $template['description'],
    ]);

    $taskId =
        (int) $connection->lastInsertId();

    /*
    |--------------------------------------------------------------------------
    | Record occurrence
    |--------------------------------------------------------------------------
    */

    $createOccurrence->execute([
        $templateId,
        $listId,
        $taskId,
        $date,
    ]);

    $connection->commit();
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    throw $exception;
        }
    }
}