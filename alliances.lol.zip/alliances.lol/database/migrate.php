<?php

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    exit('Run this script from the terminal.');
}

require dirname(__DIR__) . '/src/database.php';

$connection = db();

$connection->exec(
    'CREATE TABLE IF NOT EXISTS schema_migrations (
        filename TEXT PRIMARY KEY,
        applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )'
);

$files = glob(__DIR__ . '/migrations/*.sql') ?: [];
sort($files);

$check = $connection->prepare(
    'SELECT filename FROM schema_migrations WHERE filename = ?'
);

$record = $connection->prepare(
    'INSERT INTO schema_migrations (filename) VALUES (?)'
);

foreach ($files as $file) {
    $filename = basename($file);

    $check->execute([$filename]);

    if ($check->fetchColumn() !== false) {
        echo "Already applied: {$filename}" . PHP_EOL;
        continue;
    }

    try {
        $sql = file_get_contents($file);

        if ($sql === false) {
            throw new RuntimeException("Cannot read {$filename}");
        }

        $connection->beginTransaction();
        $connection->exec($sql);
        $record->execute([$filename]);
        $connection->commit();

        echo "Applied: {$filename}" . PHP_EOL;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        fwrite(STDERR, $error->getMessage() . PHP_EOL);
        exit(1);
    }
}