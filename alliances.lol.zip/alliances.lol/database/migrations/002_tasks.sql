CREATE TABLE task_lists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'completed')),
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE TABLE task_list_members (
    task_list_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (task_list_id, user_id),
    FOREIGN KEY (task_list_id)
        REFERENCES task_lists(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_list_id INTEGER NOT NULL,
    assigned_to INTEGER,
    name TEXT NOT NULL,
    description TEXT,
    start_date TEXT,
    deadline TEXT,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'completed')),
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (task_list_id)
        REFERENCES task_lists(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to)
        REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE daily_task_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    assigned_to INTEGER,
    name TEXT NOT NULL,
    description TEXT,
    deadline_time TEXT,
    active INTEGER NOT NULL DEFAULT 1
        CHECK (active IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)
        REFERENCES users(id) ON DELETE RESTRICT,
    FOREIGN KEY (assigned_to)
        REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE daily_task_occurrences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id INTEGER NOT NULL,
    task_list_id INTEGER NOT NULL,
    occurrence_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'completed')),
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (template_id, occurrence_date),
    FOREIGN KEY (template_id)
        REFERENCES daily_task_templates(id) ON DELETE CASCADE,
    FOREIGN KEY (task_list_id)
        REFERENCES task_lists(id) ON DELETE CASCADE
);

CREATE INDEX idx_tasks_assigned_status
    ON tasks (assigned_to, status);

CREATE INDEX idx_tasks_dates
    ON tasks (start_date, deadline);

CREATE INDEX idx_daily_occurrences_date
    ON daily_task_occurrences (occurrence_date);