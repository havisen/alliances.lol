ALTER TABLE task_lists ADD COLUMN start_date TEXT;
ALTER TABLE task_lists ADD COLUMN deadline TEXT;