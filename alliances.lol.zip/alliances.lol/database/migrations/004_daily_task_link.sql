ALTER TABLE daily_task_occurrences
ADD COLUMN task_id INTEGER
REFERENCES tasks(id) ON DELETE CASCADE;