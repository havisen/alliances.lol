ALTER TABLE task_lists
ADD COLUMN members_can_edit INTEGER NOT NULL DEFAULT 1
CHECK (members_can_edit IN (0, 1));