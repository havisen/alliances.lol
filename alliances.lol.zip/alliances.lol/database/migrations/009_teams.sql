CREATE TABLE teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    team_lead_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (workspace_id, name),

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id) ON DELETE CASCADE,

    FOREIGN KEY (team_lead_id)
        REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE team_members (
    team_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (team_id, user_id),

    FOREIGN KEY (team_id)
        REFERENCES teams(id) ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE
);

ALTER TABLE task_lists ADD COLUMN team_id INTEGER;

CREATE INDEX idx_team_members_user
    ON team_members(user_id);

CREATE INDEX idx_task_lists_team
    ON task_lists(team_id);