/* Additive: per-Workspace Drive storage quota (1 GiB default ceiling). */

CREATE TABLE workspace_quotas (
    workspace_id INTEGER PRIMARY KEY,
    storage_limit_bytes INTEGER NOT NULL DEFAULT 1073741824,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE
);

/* Give every existing Workspace the standard 1 GiB ceiling. */
INSERT INTO workspace_quotas (workspace_id, storage_limit_bytes)
SELECT id, 1073741824
FROM workspaces;