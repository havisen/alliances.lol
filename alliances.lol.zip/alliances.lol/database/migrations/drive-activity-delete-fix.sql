/*
 * ==========================================================================
 * Alliances — Drive activity permanent-delete fix
 * ==========================================================================
 *
 * Activity history should survive permanent deletion of a Drive file/folder.
 *
 * The original drive_file_activity table required either file_id or
 * folder_id to remain non-NULL. That conflicts with ON DELETE SET NULL.
 *
 * Rebuild the table without that CHECK constraint.
 */


ALTER TABLE drive_file_activity
    RENAME TO drive_file_activity_old;


/*
 * ==========================================================================
 * Recreate activity table
 * ==========================================================================
 */

CREATE TABLE drive_file_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    workspace_id INTEGER NOT NULL,

    file_id INTEGER NULL,
    folder_id INTEGER NULL,

    actor_user_id INTEGER NULL,

    action TEXT NOT NULL,

    details_json TEXT NULL,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE,

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE SET NULL,

    FOREIGN KEY (folder_id)
        REFERENCES drive_folders(id)
        ON DELETE SET NULL,

    FOREIGN KEY (actor_user_id)
        REFERENCES users(id)
        ON DELETE SET NULL
);


/*
 * ==========================================================================
 * Preserve existing activity
 * ==========================================================================
 */

INSERT INTO drive_file_activity (
    id,
    workspace_id,
    file_id,
    folder_id,
    actor_user_id,
    action,
    details_json,
    created_at
)
SELECT
    id,
    workspace_id,
    file_id,
    folder_id,
    actor_user_id,
    action,
    details_json,
    created_at
FROM drive_file_activity_old;


/*
 * ==========================================================================
 * Remove old table
 * ==========================================================================
 */

DROP TABLE drive_file_activity_old;


/*
 * ==========================================================================
 * Recreate indexes
 * ==========================================================================
 */

CREATE INDEX idx_drive_file_activity_file
    ON drive_file_activity (
        file_id,
        created_at
    );


CREATE INDEX idx_drive_file_activity_folder
    ON drive_file_activity (
        folder_id,
        created_at
    );


CREATE INDEX idx_drive_file_activity_workspace
    ON drive_file_activity (
        workspace_id,
        created_at
    );