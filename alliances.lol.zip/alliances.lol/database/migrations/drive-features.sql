/*
 * ==========================================================================
 * Alliances — Extended Drive features
 * ==========================================================================
 *
 * Adds the shared database foundation for:
 *
 * - Trash / restore
 * - Favorites
 * - Recent files
 * - File activity
 * - Expiring file access
 * - Team sharing
 * - Version conflict detection
 *
 * IMPORTANT:
 * This migration does not contain BEGIN / COMMIT because migrate.php
 * already runs migrations inside a transaction.
 */


/*
 * ==========================================================================
 * Trash
 * ==========================================================================
 *
 * Files and folders are soft-deleted first.
 *
 * Their encrypted file contents remain untouched in private storage until
 * permanent deletion is explicitly requested.
 */

ALTER TABLE drive_files
    ADD COLUMN trashed_at TEXT NULL;

ALTER TABLE drive_files
    ADD COLUMN trashed_by INTEGER NULL
        REFERENCES users(id);

ALTER TABLE drive_folders
    ADD COLUMN trashed_at TEXT NULL;

ALTER TABLE drive_folders
    ADD COLUMN trashed_by INTEGER NULL
        REFERENCES users(id);


CREATE INDEX idx_drive_files_workspace_trash
    ON drive_files (
        workspace_id,
        trashed_at
    );

CREATE INDEX idx_drive_folders_workspace_trash
    ON drive_folders (
        workspace_id,
        trashed_at
    );


/*
 * ==========================================================================
 * Expiring individual access
 * ==========================================================================
 *
 * NULL = access does not automatically expire.
 */

ALTER TABLE drive_file_access
    ADD COLUMN expires_at TEXT NULL;


CREATE INDEX idx_drive_file_access_expiry
    ON drive_file_access (
        expires_at
    );


/*
 * ==========================================================================
 * Favorites
 * ==========================================================================
 *
 * A favorite can point to either a file or a folder.
 *
 * item_type determines which ID column is populated.
 */

CREATE TABLE drive_favorites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    workspace_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    item_type TEXT NOT NULL
        CHECK (
            item_type IN (
                'file',
                'folder'
            )
        ),

    file_id INTEGER NULL,
    folder_id INTEGER NULL,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE CASCADE,

    FOREIGN KEY (folder_id)
        REFERENCES drive_folders(id)
        ON DELETE CASCADE,

    CHECK (
        (
            item_type = 'file'
            AND file_id IS NOT NULL
            AND folder_id IS NULL
        )
        OR
        (
            item_type = 'folder'
            AND folder_id IS NOT NULL
            AND file_id IS NULL
        )
    )
);


CREATE UNIQUE INDEX idx_drive_favorites_unique_file
    ON drive_favorites (
        user_id,
        file_id
    )
    WHERE file_id IS NOT NULL;


CREATE UNIQUE INDEX idx_drive_favorites_unique_folder
    ON drive_favorites (
        user_id,
        folder_id
    )
    WHERE folder_id IS NOT NULL;


CREATE INDEX idx_drive_favorites_user
    ON drive_favorites (
        workspace_id,
        user_id,
        created_at
    );


/*
 * ==========================================================================
 * Recent files
 * ==========================================================================
 *
 * One record per user/file.
 *
 * Opening the file updates last_opened_at instead of creating endless rows.
 */

CREATE TABLE drive_recent_files (
    user_id INTEGER NOT NULL,
    file_id INTEGER NOT NULL,

    last_opened_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (
        user_id,
        file_id
    ),

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE CASCADE
);


CREATE INDEX idx_drive_recent_files_user_date
    ON drive_recent_files (
        user_id,
        last_opened_at
    );


/*
 * ==========================================================================
 * Team sharing
 * ==========================================================================
 *
 * This records the fact that a file is shared with a team.
 *
 * IMPORTANT:
 * The actual AES file key must still be wrapped individually for authorized
 * users. This table must never contain the raw AES key.
 */

CREATE TABLE drive_file_team_access (
    file_id INTEGER NOT NULL,
    team_id INTEGER NOT NULL,

    granted_by INTEGER NOT NULL,

    can_edit INTEGER NOT NULL DEFAULT 0
        CHECK (
            can_edit IN (0, 1)
        ),

    expires_at TEXT NULL,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (
        file_id,
        team_id
    ),

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE CASCADE,

    FOREIGN KEY (team_id)
        REFERENCES teams(id)
        ON DELETE CASCADE,

    FOREIGN KEY (granted_by)
        REFERENCES users(id)
        ON DELETE RESTRICT
);


CREATE INDEX idx_drive_file_team_access_team
    ON drive_file_team_access (
        team_id
    );


CREATE INDEX idx_drive_file_team_access_expiry
    ON drive_file_team_access (
        expires_at
    );


/*
 * ==========================================================================
 * File activity
 * ==========================================================================
 *
 * This is user-facing Drive history.
 *
 * Never put:
 * - decrypted file contents
 * - passwords
 * - raw AES keys
 * - OpenPGP private keys
 * - other secrets
 *
 * into details_json.
 */

CREATE TABLE drive_file_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    workspace_id INTEGER NOT NULL,

    file_id INTEGER NULL,
    folder_id INTEGER NULL,

    actor_user_id INTEGER NULL,

    action TEXT NOT NULL,

    details_json TEXT NULL,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE,

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE SET NULL,

    FOREIGN KEY (folder_id)
        REFERENCES drive_folders(id)
        ON DELETE SET NULL,

    FOREIGN KEY (actor_user_id)
        REFERENCES users(id)
        ON DELETE SET NULL,

    CHECK (
        file_id IS NOT NULL
        OR folder_id IS NOT NULL
    )
);


CREATE INDEX idx_drive_file_activity_file
    ON drive_file_activity (
        file_id,
        created_at
    );


CREATE INDEX idx_drive_file_activity_folder
    ON drive_file_activity (
        folder_id,
        created_at
    );


CREATE INDEX idx_drive_file_activity_workspace
    ON drive_file_activity (
        workspace_id,
        created_at
    );


/*
 * ==========================================================================
 * Version conflict detection
 * ==========================================================================
 *
 * drive_file_versions already contains version_number.
 *
 * current_version makes it inexpensive to compare:
 *
 *     version user opened
 *
 * against:
 *
 *     version currently stored
 *
 * before accepting an edited version.
 *
 * This prevents one editor from silently overwriting another user's newer
 * work.
 */

ALTER TABLE drive_files
    ADD COLUMN current_version INTEGER NOT NULL
        DEFAULT 1;


CREATE INDEX idx_drive_files_current_version
    ON drive_files (
        id,
        current_version
    );