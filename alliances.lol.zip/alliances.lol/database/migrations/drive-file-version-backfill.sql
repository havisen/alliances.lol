/*
 * ==========================================================================
 * Alliances — Drive file version backfill
 * ==========================================================================
 *
 * Files uploaded before Drive version history was introduced do not yet
 * have an entry in drive_file_versions.
 *
 * Their currently stored encrypted blob becomes Version 1.
 *
 * This migration does NOT copy, decrypt, or modify the encrypted file.
 * It only records the existing encrypted storage blob in version history.
 */

INSERT INTO drive_file_versions (
    file_id,
    version_number,
    created_by,
    storage_id,
    encrypted_size,
    encryption_version,
    key_version,
    created_at
)
SELECT
    f.id,
    1,
    f.uploaded_by,
    f.storage_id,
    f.encrypted_size,
    f.encryption_version,
    f.key_version,
    f.created_at
FROM drive_files AS f
WHERE NOT EXISTS (
    SELECT 1
    FROM drive_file_versions AS v
    WHERE v.file_id = f.id
);