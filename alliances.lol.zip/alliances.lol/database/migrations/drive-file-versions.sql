CREATE TABLE IF NOT EXISTS drive_file_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    file_id INTEGER NOT NULL,

    version_number INTEGER NOT NULL,

    created_by INTEGER NOT NULL,

    storage_id TEXT NOT NULL,

    encrypted_size INTEGER NOT NULL DEFAULT 0,

    encryption_version INTEGER NOT NULL DEFAULT 1,

    key_version INTEGER NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
        ON DELETE RESTRICT,

    UNIQUE (
        file_id,
        version_number
    ),

    UNIQUE (
        storage_id
    )
);


CREATE INDEX IF NOT EXISTS
    idx_drive_file_versions_file
ON drive_file_versions (
    file_id,
    version_number
);


CREATE INDEX IF NOT EXISTS
    idx_drive_file_versions_creator
ON drive_file_versions (
    created_by
);