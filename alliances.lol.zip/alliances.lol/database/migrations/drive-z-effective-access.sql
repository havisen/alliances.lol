/* Effective Drive authorization: individual + team grants, with expiry. */
DROP VIEW IF EXISTS drive_effective_access;
CREATE VIEW drive_effective_access AS
SELECT file_id, user_id, MAX(can_edit) AS can_edit
FROM (
    SELECT a.file_id, a.user_id, a.can_edit
    FROM drive_file_access AS a
    WHERE a.expires_at IS NULL OR datetime(a.expires_at) > CURRENT_TIMESTAMP

    UNION ALL

    SELECT ta.file_id, tm.user_id, ta.can_edit
    FROM drive_file_team_access AS ta
    INNER JOIN team_members AS tm ON tm.team_id = ta.team_id
    WHERE ta.expires_at IS NULL OR datetime(ta.expires_at) > CURRENT_TIMESTAMP
) AS grants
GROUP BY file_id, user_id;
