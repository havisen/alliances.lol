CREATE TABLE drive_folders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    parent_id INTEGER NULL,
    created_by INTEGER NOT NULL,

    name TEXT NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE,

    FOREIGN KEY (parent_id)
        REFERENCES drive_folders(id)
        ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
        ON DELETE RESTRICT
);

CREATE INDEX idx_drive_folders_workspace_parent
    ON drive_folders(workspace_id, parent_id);

CREATE INDEX idx_drive_folders_created_by
    ON drive_folders(created_by);


CREATE TABLE drive_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    folder_id INTEGER NULL,
    uploaded_by INTEGER NOT NULL,

    storage_id TEXT NOT NULL UNIQUE,

    original_name TEXT NOT NULL,
    mime_type TEXT NULL,

    encrypted_size INTEGER NOT NULL DEFAULT 0,

    encryption_version INTEGER NOT NULL DEFAULT 1,
    key_version INTEGER NOT NULL DEFAULT 1,

    sharing_mode TEXT NOT NULL DEFAULT 'selected'
        CHECK (sharing_mode IN ('selected', 'workspace')),

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE,

    FOREIGN KEY (folder_id)
        REFERENCES drive_folders(id)
        ON DELETE SET NULL,

    FOREIGN KEY (uploaded_by)
        REFERENCES users(id)
        ON DELETE RESTRICT
);

CREATE INDEX idx_drive_files_workspace_folder
    ON drive_files(workspace_id, folder_id);

CREATE INDEX idx_drive_files_uploaded_by
    ON drive_files(uploaded_by);

CREATE INDEX idx_drive_files_storage_id
    ON drive_files(storage_id);


CREATE TABLE drive_file_access (
    file_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    granted_by INTEGER NOT NULL,

    can_edit INTEGER NOT NULL DEFAULT 0
        CHECK (can_edit IN (0, 1)),

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (file_id, user_id),

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    FOREIGN KEY (granted_by)
        REFERENCES users(id)
        ON DELETE RESTRICT
);

CREATE INDEX idx_drive_file_access_user
    ON drive_file_access(user_id);


CREATE TABLE drive_file_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    file_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,

    key_version INTEGER NOT NULL,
    encrypted_key TEXT NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (file_id)
        REFERENCES drive_files(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    UNIQUE (file_id, user_id, key_version)
);

CREATE INDEX idx_drive_file_keys_user
    ON drive_file_keys(user_id);

CREATE INDEX idx_drive_file_keys_file_version
    ON drive_file_keys(file_id, key_version);