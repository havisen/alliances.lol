/*
|--------------------------------------------------------------------------
| Messaging direct messages
|--------------------------------------------------------------------------
|
| Adds "direct" as a supported conversation type.
|
| SQLite cannot alter an existing CHECK constraint directly, so we
| recreate the conversations table while preserving its data.
|
*/




/*
|--------------------------------------------------------------------------
| Rename existing table
|--------------------------------------------------------------------------
*/

ALTER TABLE conversations
RENAME TO conversations_old;


/*
|--------------------------------------------------------------------------
| Recreate conversations
|--------------------------------------------------------------------------
*/

CREATE TABLE conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    workspace_id INTEGER NOT NULL,

    created_by INTEGER NOT NULL,

    type TEXT NOT NULL
        CHECK (
            type IN (
                'group',
                'channel',
                'direct'
            )
        ),

    name TEXT NOT NULL,

    description TEXT,

    key_version INTEGER NOT NULL
        DEFAULT 1,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    updated_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id)
        ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
        ON DELETE CASCADE
);


/*
|--------------------------------------------------------------------------
| Copy existing conversations
|--------------------------------------------------------------------------
*/

INSERT INTO conversations (
    id,
    workspace_id,
    created_by,
    type,
    name,
    description,
    key_version,
    created_at,
    updated_at
)
SELECT
    id,
    workspace_id,
    created_by,
    type,
    name,
    description,
    key_version,
    created_at,
    updated_at
FROM conversations_old;


/*
|--------------------------------------------------------------------------
| Remove old table
|--------------------------------------------------------------------------
*/

DROP TABLE conversations_old;


/*
|--------------------------------------------------------------------------
| Recreate indexes
|--------------------------------------------------------------------------
*/

CREATE INDEX IF NOT EXISTS
    idx_conversations_workspace
ON conversations (
    workspace_id
);

CREATE INDEX IF NOT EXISTS
    idx_conversations_updated
ON conversations (
    workspace_id,
    updated_at
);


/*
|--------------------------------------------------------------------------
| Prevent duplicate DMs
|--------------------------------------------------------------------------
|
| dm_pair_key will contain the two user IDs in ascending order:
|
|     4:17
|
| It is NULL for groups and channels.
|
*/

ALTER TABLE conversations
ADD COLUMN dm_pair_key TEXT NULL;


CREATE UNIQUE INDEX IF NOT EXISTS
    idx_conversations_unique_dm
ON conversations (
    workspace_id,
    dm_pair_key
)
WHERE
    type = 'direct'
    AND dm_pair_key IS NOT NULL;



