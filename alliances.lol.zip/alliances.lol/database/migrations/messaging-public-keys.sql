CREATE TABLE user_public_keys (
    user_id INTEGER PRIMARY KEY,

    key_type TEXT NOT NULL
        CHECK (key_type IN ('openpgp')),

    format_version INTEGER NOT NULL DEFAULT 1,

    public_key TEXT NOT NULL,
    fingerprint TEXT NOT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

CREATE UNIQUE INDEX idx_user_public_keys_fingerprint
    ON user_public_keys(fingerprint);