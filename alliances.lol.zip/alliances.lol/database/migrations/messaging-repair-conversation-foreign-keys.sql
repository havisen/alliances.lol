/*
|--------------------------------------------------------------------------
| Repair Messaging conversation foreign keys
|--------------------------------------------------------------------------
|
| The direct-message migration renamed "conversations" to
| "conversations_old".
|
| SQLite consequently updated foreign-key references in the Messaging
| child tables to point to "conversations_old".
|
| That old table no longer exists.
|
| Rebuild the affected child tables so their foreign keys once again
| reference "conversations".
|
| Existing rows are copied where possible.
|
*/


/*
|--------------------------------------------------------------------------
| conversation_members
|--------------------------------------------------------------------------
*/

ALTER TABLE conversation_members
RENAME TO conversation_members_broken;

CREATE TABLE conversation_members (
    conversation_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL DEFAULT 'member'
        CHECK (role IN ('owner', 'admin', 'member')),
    joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (
        conversation_id,
        user_id
    ),

    FOREIGN KEY (conversation_id)
        REFERENCES conversations(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
);

INSERT INTO conversation_members (
    conversation_id,
    user_id,
    role,
    joined_at
)
SELECT
    conversation_id,
    user_id,
    role,
    joined_at
FROM conversation_members_broken;

DROP TABLE conversation_members_broken;

CREATE INDEX IF NOT EXISTS idx_conversation_members_user
    ON conversation_members(user_id);


/*
|--------------------------------------------------------------------------
| conversation_keys
|--------------------------------------------------------------------------
*/

ALTER TABLE conversation_keys
RENAME TO conversation_keys_broken;

CREATE TABLE conversation_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    key_version INTEGER NOT NULL,
    encrypted_key TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (conversation_id)
        REFERENCES conversations(id)
        ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE,

    UNIQUE (
        conversation_id,
        user_id,
        key_version
    )
);

INSERT INTO conversation_keys (
    id,
    conversation_id,
    user_id,
    key_version,
    encrypted_key,
    created_at
)
SELECT
    id,
    conversation_id,
    user_id,
    key_version,
    encrypted_key,
    created_at
FROM conversation_keys_broken;

DROP TABLE conversation_keys_broken;

CREATE INDEX IF NOT EXISTS idx_conversation_keys_user
    ON conversation_keys(
        user_id,
        conversation_id
    );


/*
|--------------------------------------------------------------------------
| messages
|--------------------------------------------------------------------------
*/

ALTER TABLE messages
RENAME TO messages_broken;

CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    sender_id INTEGER NOT NULL,
    key_version INTEGER NOT NULL,
    ciphertext TEXT NOT NULL,
    iv TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    edited_at TEXT,

    FOREIGN KEY (conversation_id)
        REFERENCES conversations(id)
        ON DELETE CASCADE,

    FOREIGN KEY (sender_id)
        REFERENCES users(id)
        ON DELETE RESTRICT
);

INSERT INTO messages (
    id,
    conversation_id,
    sender_id,
    key_version,
    ciphertext,
    iv,
    created_at,
    edited_at
)
SELECT
    id,
    conversation_id,
    sender_id,
    key_version,
    ciphertext,
    iv,
    created_at,
    edited_at
FROM messages_broken;

DROP TABLE messages_broken;

CREATE INDEX IF NOT EXISTS idx_messages_conversation
    ON messages(
        conversation_id,
        id
    );