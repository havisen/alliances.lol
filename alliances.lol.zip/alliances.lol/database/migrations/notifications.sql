CREATE TABLE notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    actor_user_id INTEGER,
    type TEXT NOT NULL,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    target_type TEXT,
    target_id INTEGER,
    target_url TEXT,
    is_read INTEGER NOT NULL DEFAULT 0
        CHECK (is_read IN (0, 1)),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    read_at TEXT,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id) ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE,

    FOREIGN KEY (actor_user_id)
        REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_notifications_user_unread
    ON notifications(user_id, is_read, created_at);

CREATE INDEX idx_notifications_workspace_user_created
    ON notifications(workspace_id, user_id, created_at);
