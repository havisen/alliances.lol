ALTER TABLE users ADD COLUMN time_zone TEXT;
ALTER TABLE users ADD COLUMN working_hours TEXT;
ALTER TABLE users ADD COLUMN current_status TEXT NOT NULL DEFAULT 'available';
ALTER TABLE users ADD COLUMN out_of_office INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN out_of_office_until TEXT;

ALTER TABLE teams ADD COLUMN description TEXT;
