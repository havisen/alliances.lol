CREATE TABLE projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'planning'
        CHECK (status IN ('planning', 'active', 'on_hold', 'completed', 'archived')),
    start_date TEXT,
    target_date TEXT,
    completed_at TEXT,
    archived_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id) ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX idx_projects_workspace_status
    ON projects(workspace_id, status);

CREATE INDEX idx_projects_created_by
    ON projects(created_by);

CREATE TABLE project_members (
    project_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL DEFAULT 'member'
        CHECK (role IN ('member', 'lead')),
    added_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, user_id),

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (user_id)
        REFERENCES users(id) ON DELETE CASCADE,

    FOREIGN KEY (added_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX idx_project_members_user
    ON project_members(user_id);

CREATE INDEX idx_project_members_project_role
    ON project_members(project_id, role);

CREATE TABLE project_teams (
    project_id INTEGER NOT NULL,
    team_id INTEGER NOT NULL,
    membership_mode TEXT NOT NULL DEFAULT 'synchronized'
        CHECK (membership_mode IN ('synchronized', 'snapshot')),
    added_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, team_id),

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (team_id)
        REFERENCES teams(id) ON DELETE CASCADE,

    FOREIGN KEY (added_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX idx_project_teams_team
    ON project_teams(team_id);