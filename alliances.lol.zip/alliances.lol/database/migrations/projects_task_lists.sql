-- Add optional Project context to Task Lists.
--
-- A Task List may belong to zero or one Project:
--   project_id NULL     -> workspace-level list (existing behavior)
--   project_id non-NULL -> the list is anchored to that Project
--
-- Projects are not normally deleted, so when one is removed we detach
-- (SET NULL) rather than destroy work. Attaching/detaching only changes
-- context; tasks, members, team assignment, and template configuration
-- are never touched.

ALTER TABLE task_lists
ADD COLUMN project_id INTEGER
REFERENCES projects(id) ON DELETE SET NULL;

CREATE INDEX idx_task_lists_project
    ON task_lists(project_id);