/*
 |--------------------------------------------------------------------------
 | Project Overview system
 |--------------------------------------------------------------------------
 |
 | Additive, workspace-scoped schema for the Project Overview surface
 | (public/projects/project.php). This migration is independent of the
 | unapplied work-templates_zadvanced.sql migration. Adds optional Project
 | context to Calendar; leaves Drive and Messaging storage/encryption intact.
 |
 | Every table is workspace-scoped through the projects table it references.
 */

PRAGMA foreign_keys = ON;

/* Project header metadata. These columns are intentionally added here while
 | this migration is still pending, so no compensating migration is needed. */
ALTER TABLE projects ADD COLUMN icon TEXT;
ALTER TABLE projects ADD COLUMN color TEXT CHECK (color IS NULL OR (length(color) = 7 AND color GLOB '#[0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f][0-9A-Fa-f]'));
ALTER TABLE projects ADD COLUMN health TEXT NOT NULL DEFAULT 'unknown'
    CHECK (health IN ('unknown', 'on_track', 'at_risk', 'off_track'));

ALTER TABLE calendar_events ADD COLUMN project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL;
CREATE INDEX idx_calendar_events_project ON calendar_events(project_id, starts_at);

/* Pages (tabs) shown on the Project Overview surface. */
CREATE TABLE IF NOT EXISTS project_overview_pages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    page_key TEXT NOT NULL,
    title TEXT NOT NULL,
    position INTEGER NOT NULL DEFAULT 0,
    is_visible INTEGER NOT NULL DEFAULT 1 CHECK (is_visible IN (0, 1)),
    is_default INTEGER NOT NULL DEFAULT 0 CHECK (is_default IN (0, 1)),
    archived_at TEXT,
    config_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (project_id, page_key),
    UNIQUE (id, project_id),

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_overview_pages_project
    ON project_overview_pages(project_id, archived_at, position);

/* At most one non-archived default page per Project. Application code owns
 | promotion when the current default is archived. */
CREATE UNIQUE INDEX IF NOT EXISTS idx_overview_pages_one_active_default
    ON project_overview_pages(project_id)
    WHERE is_default = 1 AND archived_at IS NULL;

/* Keep the database-side active-page ceiling aligned with the manager UI. */
CREATE TRIGGER IF NOT EXISTS project_overview_pages_max_eight_insert
BEFORE INSERT ON project_overview_pages
WHEN NEW.archived_at IS NULL
 AND (SELECT COUNT(*) FROM project_overview_pages
      WHERE project_id = NEW.project_id AND archived_at IS NULL) >= 8
BEGIN
    SELECT RAISE(ABORT, 'A project may have at most 8 active overview pages');
END;

CREATE TRIGGER IF NOT EXISTS project_overview_pages_max_eight_restore
BEFORE UPDATE OF archived_at ON project_overview_pages
WHEN OLD.archived_at IS NOT NULL AND NEW.archived_at IS NULL
 AND (SELECT COUNT(*) FROM project_overview_pages
      WHERE project_id = NEW.project_id AND archived_at IS NULL AND id <> OLD.id) >= 8
BEGIN
    SELECT RAISE(ABORT, 'A project may have at most 8 active overview pages');
END;

/* A Project must retain at least one active Overview page. */
CREATE TRIGGER IF NOT EXISTS project_overview_pages_keep_one_active
BEFORE UPDATE OF archived_at ON project_overview_pages
WHEN OLD.archived_at IS NULL AND NEW.archived_at IS NOT NULL
 AND (SELECT COUNT(*) FROM project_overview_pages
      WHERE project_id = OLD.project_id AND archived_at IS NULL AND id <> OLD.id) = 0
BEGIN
    SELECT RAISE(ABORT, 'A project must retain at least one active overview page');
END;

/* Module instances assigned to a page. module_key maps to the registry. */
CREATE TABLE IF NOT EXISTS project_overview_modules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    page_id INTEGER NOT NULL,
    module_key TEXT NOT NULL CHECK (module_key IN ('status', 'progress', 'tasks', 'members',
        'milestones', 'calendar', 'channel', 'group_chat', 'files', 'document', 'spreadsheet',
        'activity', 'announcements', 'metrics', 'links', 'notes', 'custom_content')),
    title TEXT,
    position INTEGER NOT NULL DEFAULT 0,
    is_enabled INTEGER NOT NULL DEFAULT 1,
    config TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    col_span INTEGER NOT NULL DEFAULT 1 CHECK (col_span BETWEEN 1 AND 3),
    visibility TEXT NOT NULL DEFAULT 'all' CHECK (visibility IN ('all', 'leads')),
    seed_key TEXT,
    UNIQUE (project_id, seed_key),

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (page_id)
        REFERENCES project_overview_pages(id) ON DELETE CASCADE,
    FOREIGN KEY (page_id, project_id)
        REFERENCES project_overview_pages(id, project_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_overview_modules_project
    ON project_overview_modules(project_id, position);

CREATE INDEX IF NOT EXISTS idx_overview_modules_page
    ON project_overview_modules(page_id, position);

/* Resource attachments. Only the reference is persisted; metadata shown to
 | a viewer is re-fetched from the source subsystem at read time. */
CREATE TABLE IF NOT EXISTS project_drive_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    resource_id INTEGER NOT NULL,
    added_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (project_id, resource_id),
    FOREIGN KEY (resource_id) REFERENCES drive_files(id) ON DELETE CASCADE,

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (added_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE TABLE IF NOT EXISTS project_drive_folders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    resource_id INTEGER NOT NULL REFERENCES drive_folders(id) ON DELETE CASCADE,
    added_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (project_id, resource_id)
);

CREATE TABLE IF NOT EXISTS project_conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    resource_id INTEGER NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    added_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (project_id, resource_id)
);

/* Milestones with due dates and completion state. */
CREATE TABLE IF NOT EXISTS project_milestones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    due_date TEXT,
    status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'completed')),
    position INTEGER NOT NULL DEFAULT 0,
    created_by INTEGER NOT NULL,
    completed_by INTEGER,
    completed_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id) ON DELETE RESTRICT,

    FOREIGN KEY (completed_by)
        REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_project_milestones_project_due
    ON project_milestones(project_id, status, due_date, position);

/* Announcements shown on the Overview surface. */
CREATE TABLE IF NOT EXISTS project_announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    author_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    is_pinned INTEGER NOT NULL DEFAULT 0 CHECK (is_pinned IN (0, 1)),
    archived_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (author_id)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_project_announcements_project
    ON project_announcements(project_id, archived_at, is_pinned, created_at);

/* Links collected on the Overview surface. */
CREATE TABLE IF NOT EXISTS project_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT 'link',
    added_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (added_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_project_links_project
    ON project_links(project_id, created_at);

/* Append-only activity feed of important project changes. */
CREATE TABLE IF NOT EXISTS project_activity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    actor_user_id INTEGER NOT NULL,
    activity_type TEXT NOT NULL,
    summary TEXT NOT NULL,
    target_type TEXT,
    target_id INTEGER,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (project_id)
        REFERENCES projects(id) ON DELETE CASCADE,

    FOREIGN KEY (actor_user_id)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_project_activity_project
    ON project_activity(project_id, created_at);

-- Seed once in migration, never on a GET. Module type is intentionally not unique.
INSERT INTO project_overview_pages (project_id, page_key, title, position, is_default)
SELECT id, 'overview', 'Overview', 0, 1 FROM projects;
INSERT INTO project_overview_modules (project_id, page_id, module_key, title, position, seed_key)
SELECT p.project_id, p.id, m.module_key, m.title, m.position, 'starter_' || m.module_key
FROM project_overview_pages p CROSS JOIN (
    SELECT 'status' AS module_key, 'Status' AS title, 0 AS position
    UNION ALL SELECT 'progress', 'Progress', 1
    UNION ALL SELECT 'tasks', 'Tasks', 2
    UNION ALL SELECT 'members', 'Members', 3
    UNION ALL SELECT 'activity', 'Activity', 4
) m WHERE p.page_key = 'overview';
