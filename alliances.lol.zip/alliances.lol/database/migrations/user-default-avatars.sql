/*
|--------------------------------------------------------------------------
| Permanent default avatars
|--------------------------------------------------------------------------
|
| Give every existing user without a profile image one of the
| eight built-in avatars.
|
| The selected avatar is written permanently to users.avatar_path.
| Existing/custom profile pictures are never changed.
|
*/

UPDATE users
SET avatar_path =
    '/profile/profile-image.php?file=basic%2F'
    || (
        1 + (
            abs(random()) % 8
        )
    )
    || '.png'
WHERE avatar_path IS NULL
   OR TRIM(avatar_path) = '';