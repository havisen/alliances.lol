-- Work Template System — Phase 1 foundation.
--
-- Template identity + immutable versioned definitions.
--
-- Lifecycle:
--   template identity: active <-> archived
--   version:          draft -> published -> retired
--
-- Draft definitions are authoritative in the relational rows below.
-- Publishing snapshots a normalized definition_json into the version,
-- after which the relational rows for that version are immutable.

CREATE TABLE work_templates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    workspace_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'archived')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (workspace_id)
        REFERENCES workspaces(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

CREATE INDEX idx_work_templates_workspace
    ON work_templates(workspace_id, status);

CREATE TABLE work_template_versions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    template_id INTEGER NOT NULL,
    version_number INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft', 'published', 'retired')),
    definition_json TEXT,
    created_by INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    published_at TEXT,
    retired_at TEXT,

    UNIQUE (template_id, version_number),
    FOREIGN KEY (template_id)
        REFERENCES work_templates(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)
        REFERENCES users(id) ON DELETE RESTRICT
);

-- At most one published version per template.
CREATE UNIQUE INDEX idx_work_template_versions_published
    ON work_template_versions(template_id)
    WHERE status = 'published';

CREATE INDEX idx_work_template_versions_template
    ON work_template_versions(template_id, version_number);

CREATE TABLE work_template_sections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    version_id INTEGER NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    name TEXT NOT NULL,
    description TEXT,

    FOREIGN KEY (version_id)
        REFERENCES work_template_versions(id) ON DELETE CASCADE
);

CREATE INDEX idx_work_template_sections_version
    ON work_template_sections(version_id, sort_order);

CREATE TABLE work_template_fields (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    section_id INTEGER NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    name TEXT NOT NULL,
    description TEXT,
    field_type TEXT NOT NULL,
    is_required INTEGER NOT NULL DEFAULT 0
        CHECK (is_required IN (0, 1)),
    options_json TEXT,
    number_unit TEXT,
    config_json TEXT,

    FOREIGN KEY (section_id)
        REFERENCES work_template_sections(id) ON DELETE CASCADE
);

CREATE INDEX idx_work_template_fields_section
    ON work_template_fields(section_id, sort_order);