-- Work Template System — Phase 1 task binding + typed values.

-- Existing tasks remain Basic Tasks (template_version_id NULL).
ALTER TABLE tasks
ADD COLUMN template_version_id INTEGER
REFERENCES work_template_versions(id) ON DELETE RESTRICT;

CREATE INDEX idx_tasks_template_version
    ON tasks(template_version_id);

ALTER TABLE task_lists
ADD COLUMN default_template_id INTEGER
REFERENCES work_templates(id) ON DELETE SET NULL;

CREATE INDEX idx_task_lists_default_template
    ON task_lists(default_template_id);

CREATE TABLE task_list_allowed_templates (
    task_list_id INTEGER NOT NULL,
    template_id INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (task_list_id, template_id),
    FOREIGN KEY (task_list_id)
        REFERENCES task_lists(id) ON DELETE CASCADE,
    FOREIGN KEY (template_id)
        REFERENCES work_templates(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_list_allowed_templates_template
    ON task_list_allowed_templates(template_id);

CREATE TABLE task_values (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_id INTEGER NOT NULL,
    value_text TEXT,
    value_integer INTEGER,
    value_real REAL,
    value_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (task_id, field_id),
    FOREIGN KEY (task_id)
        REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY (field_id)
        REFERENCES work_template_fields(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_values_field
    ON task_values(field_id);