-- Work Template System — Advanced field types.
-- PRE-MIGRATION revision: task_id pins the immutable template version;
-- field_key identifies the field inside that version's definition_json.
-- There is intentionally NO FK to work_template_fields or work_template_sections.
-- Only deleting the owning Task deletes normalized state. This file must not
-- be reapplied to an installation that already ran an older revision.
--
-- 1) Stable field identity.
--    field_key is generated as lower(hex(randomblob(8))) (16 hex chars) and is
--    unique WITHIN ONE Template Version / immutable definition. It is
--    intentionally reusable across versions of the same logical field, so
--    there is NO global unique index on field_key. Per-version uniqueness is
--    enforced in server-side draft normalization/publish validation.
--
--    Only draft rows are backfilled below. Published rows and historical
--    snapshots are never rewritten; at read time they fall back to 'f'||id.

ALTER TABLE work_template_fields ADD COLUMN field_key TEXT;

UPDATE work_template_fields
SET field_key = lower(hex(randomblob(8)))
WHERE field_key IS NULL
  AND section_id IN (
      SELECT s.id
      FROM work_template_sections s
      INNER JOIN work_template_versions v ON v.id = s.version_id
      WHERE v.status = 'draft'
  );

CREATE INDEX idx_work_template_fields_field_key
    ON work_template_fields(field_key);

-- 2) Relations (relation, task_relation, project_relation, file_relation,
--    record_relation). asset_relation is registered but unavailable because
--    there is no Assets module, so 'asset' is intentionally NOT a permitted
--    target kind. The submitted target_id is always re-resolved server-side.
CREATE TABLE task_value_relations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    target_type TEXT NOT NULL
        CHECK (target_type IN ('task', 'project', 'file', 'record')),
    target_id INTEGER NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_relations_task_field
    ON task_value_relations(task_id, field_key, sort_order);

CREATE INDEX idx_task_value_relations_target
    ON task_value_relations(target_type, target_id);

-- 3) Drive evidence (file, files, photo, photos). A Task evidence row NEVER
--    grants Drive access. Only the Drive file id and an immutable MIME snapshot
--    are stored; access is re-checked on every render. No storage id, path, or
--    wrapped-key information is ever copied into Task storage.
CREATE TABLE task_value_evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    drive_file_id INTEGER NOT NULL,
    mime_type TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_evidence_task_field
    ON task_value_evidence(task_id, field_key, sort_order);

-- 4) Signature / drawing artifacts. Signature is lightweight evidence, not a
--    legal e-signature. signer identity is preserved as a nullable reference
--    plus a name snapshot so history stays meaningful if the user is removed.
CREATE TABLE task_value_artifacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    kind TEXT NOT NULL CHECK (kind IN ('signature', 'drawing')),
    signer_id INTEGER,
    signer_name TEXT,
    signed_at TEXT,
    typed_name TEXT,
    mime_type TEXT NOT NULL DEFAULT 'image/png',
    width INTEGER,
    height INTEGER,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY (signer_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_task_value_artifacts_task_field
    ON task_value_artifacts(task_id, field_key, id);

-- 5) Checklist / structured checklist. Stable step keys come from the
--    immutable definition; only per-task state (checked/result/notes) lives
--    here. Labels are resolved from the definition at render time.
CREATE TABLE task_value_checklist_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    step_key TEXT NOT NULL,
    checked INTEGER NOT NULL DEFAULT 0 CHECK (checked IN (0, 1)),
    result TEXT,
    notes TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (task_id, field_key, step_key),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_checklist_task_field
    ON task_value_checklist_items(task_id, field_key, sort_order);

-- 6) Table. Stable column keys from the definition; typed cells per row.
CREATE TABLE task_value_table_rows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    row_key TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (task_id, field_key, row_key),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_table_rows_task_field
    ON task_value_table_rows(task_id, field_key, sort_order);

CREATE TABLE task_value_table_cells (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    row_key TEXT NOT NULL,
    column_key TEXT NOT NULL,
    value_text TEXT,
    value_integer INTEGER,
    value_real REAL,
    value_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (task_id, field_key, row_key, column_key),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_table_cells_task_field
    ON task_value_table_cells(task_id, field_key, row_key);

-- 7) Repeater. Stable child keys from the definition; typed values per instance.
CREATE TABLE task_value_repeater_instances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    instance_key TEXT NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (task_id, field_key, instance_key),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_repeater_instances_task
    ON task_value_repeater_instances(task_id, field_key, sort_order);

CREATE TABLE task_value_repeater_values (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    instance_key TEXT NOT NULL,
    child_key TEXT NOT NULL,
    value_text TEXT,
    value_integer INTEGER,
    value_real REAL,
    value_json TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE (task_id, field_key, instance_key, child_key),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

CREATE INDEX idx_task_value_repeater_values_task
    ON task_value_repeater_values(task_id, field_key, instance_key);

-- 8) Approval. Append-only decision history; a later decision supersedes an
--    earlier one for the same field. Approval adds only narrowly-defined
--    decision eligibility and grants no generic RBAC.
CREATE TABLE task_value_approvals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id INTEGER NOT NULL,
    field_key TEXT NOT NULL CHECK (length(field_key) BETWEEN 1 AND 64),
    cycle INTEGER NOT NULL CHECK (cycle >= 1),
    event_type TEXT NOT NULL CHECK (event_type IN ('requested', 'decision')),
    decided_by INTEGER,
    decided_by_name TEXT NOT NULL DEFAULT '',
    decision TEXT NOT NULL
        CHECK (decision IN ('approved', 'rejected', 'changes_requested', 'pending')),
    comment TEXT,
    decided_at TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CHECK ((event_type = 'requested' AND decision = 'pending')
        OR (event_type = 'decision' AND decision != 'pending')),

    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
    FOREIGN KEY (decided_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_task_value_approvals_task_field
    ON task_value_approvals(task_id, field_key, id);

-- Published Task context cannot be repointed to a later definition.
CREATE TRIGGER task_template_context_immutable
BEFORE UPDATE OF template_version_id ON tasks
WHEN OLD.template_version_id IS NOT NULL AND NEW.template_version_id IS NOT OLD.template_version_id
BEGIN
    SELECT RAISE(ABORT, 'Task template version is immutable');
END;

CREATE TRIGGER published_template_snapshot_immutable
BEFORE UPDATE OF definition_json ON work_template_versions
WHEN OLD.status IN ('published', 'retired') AND NEW.definition_json IS NOT OLD.definition_json
BEGIN
    SELECT RAISE(ABORT, 'Published template snapshot is immutable');
END;

CREATE UNIQUE INDEX idx_approval_one_request_per_cycle
    ON task_value_approvals(task_id, field_key, cycle) WHERE event_type = 'requested';
CREATE UNIQUE INDEX idx_approval_one_decision_per_cycle
    ON task_value_approvals(task_id, field_key, cycle) WHERE event_type = 'decision';
