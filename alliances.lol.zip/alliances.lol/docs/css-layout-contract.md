# Alliances CSS Layout Contract

The shared application stylesheet is `public/assets/css/app.css`. Use it first for normal application pages. Keep specialized stylesheets only for genuinely unique interfaces such as Drive, Messaging, Key Vault, editors, or the command palette.

## Standard Page

Use one centered page wrapper:

```html
<main class="app-main">
    <div class="page-container">
        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">Title</h1>
                <p class="page-description">Short description.</p>
            </div>

            <div class="page-header-actions">...</div>
        </header>
    </div>
</main>
```

Use `page--wide` only for data-heavy views that truly need more horizontal room.

## Sections

Ordinary panels use `section`, `section-header`, `section-title`, and `section-actions`.

```html
<section class="section">
    <header class="section-header">
        <h2 class="section-title">Section</h2>
        <div class="section-actions">...</div>
    </header>

    ...
</section>
```

Do not invent another card or section component for normal CRUD pages.

## Forms

Use `form`, `form-group`, `form-row`, and `form-actions`.

```html
<form class="form" method="post">
    <div class="form-group">
        <label class="form-label" for="name">Name</label>
        <input id="name" name="name">
    </div>

    <div class="form-row">
        <div class="form-group">...</div>
        <div class="form-group">...</div>
    </div>

    <div class="form-actions">...</div>
</form>
```

Labels stay directly above controls. Inputs fill their form group. Form rows collapse on narrow screens.

## Lists And Tables

Use `record-list`, `record`, `record-title`, `record-description`, `record-meta`, and `record-meta-item` for simple records such as projects, templates, teams, people, and task-like objects.

Use `table-wrapper` for real tables or wide data. Do not force dense data tables into record cards.

Use `empty-state` for empty content.

## Shared Primitives

Available shared primitives include:

- `page-container`, `page--wide`
- `page-header`, `page-header-content`, `page-header-actions`, `page-title`, `page-description`
- `section`, `section-header`, `section-title`, `section-actions`
- `form`, `form-group`, `form-row`, `form-actions`, `form-label`
- `record-list`, `record`, `record-title`, `record-description`, `record-meta`, `record-meta-item`
- `badge`, `badge--success`, `badge--warning`, `badge--danger`
- `primary-action`, `secondary-action`, `icon-button`
- `stack`, `cluster`, `grid`, `grid--2`
- `table-wrapper`, `empty-state`, `muted`, `sr-only`

## Responsive Expectations

Normal pages should work without page-specific breakpoints. Shared rules reduce page padding, wrap header/actions, collapse form rows and two-column grids, and prevent horizontal overflow. Add a page-specific breakpoint only for a genuinely unique interface.

## When Page-Specific CSS Is Allowed

Page-specific CSS is allowed for unique behavior or dense interfaces: messaging panes, calendar grids, Drive browser/editor surfaces, Key Vault flows, complex task workspaces, and JavaScript-driven modals. Even there, reuse shared headers, buttons, badges, forms, empty states, and semantic theme variables where practical.

## Do Not

- Do not create page-specific layout CSS for ordinary pages.
- Do not invent another card or section component.
- Do not invent another form layout.
- Do not use fixed heights for ordinary sections.
- Do not use absolute positioning for ordinary page layout.
- Do not invent arbitrary page widths.
- Do not duplicate theme colors; use semantic variables from `app.css`.
- Do not add a CSS framework.
- Do not add utility-class explosions such as spacing scales in markup.
- Do not override obsolete CSS forever; prefer deleting or consolidating it.

Before adding a class, search `public/assets/css/app.css` and the repository for an existing shared primitive.
