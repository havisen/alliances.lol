# Projects navigation and Universal Search

Projects already had a Work sidebar link to `/projects/` with an active state
covering every `/projects/` page. That navigation and all Project pages remain
unchanged. The command palette now includes a Projects navigation shortcut and
renders `project` results from the existing `/actions/search.php` endpoint.

## Search and authorization

- Searches name and description with the same parameterized, case-insensitive
  LIKE convention as other Universal Search categories.
- Returns at most 20 matching Projects, ordered by name and ID. Results contain
  only type, ID, name, status/short description, and a fixed numeric Project URL.
- Uses `projects_for_workspace` for workspace administrators and
  `projects_for_user` for everyone else, just like the Project list. Those helpers
  now accept optional query/limit arguments; their existing defaults and access
  predicates are unchanged.
- Every query is workspace-scoped. Non-admins require either a direct
  `project_members` row (member or lead) or membership in a same-workspace Team
  attached through `project_teams.membership_mode = synchronized`.
- Team Lead status, same-workspace status, and Task List membership alone do not
  grant Project visibility. Snapshot Team attachment alone grants no live Team
  access; any existing direct memberships from a prior snapshot retain their
  normal direct-member behavior.
- Search excludes archived Projects, matching the default Projects list. Visible
  planning, active, on_hold, and completed Projects are searchable. Historical
  Projects remain available through **Projects → Show archived** and authorized
  direct links.
- The destination still loads with `project_by_id` and checks
  `project_user_can_view`; a search result never grants access.
- Project search adds one database query, regardless of result count. Workspace,
  membership, text filtering, ordering, and limit are applied in SQL. Existing
  membership/workspace indexes remain in use; no schema changes were needed.
- The shared result renderer assigns names/descriptions with `textContent`.
  Project metadata cannot construct URLs or introduce HTML into the result UI.

## Automated checks

```text
php tests/project-search.php
php tests/task-page-render.php
node --check public/assets/js/command-palette.js
```

The Project checks capture generated SQL without executing it. They compare its
entire effective-membership predicate against the existing detail-page helper,
check actor/workspace bindings, admin behavior, archive filtering, query limits,
result formatting, absence of per-result queries, and command-palette links.
The Task checks are the existing Task 1 regressions. Neither test opens a database
or creates a temporary database. Live SQL execution and authenticated browser
behavior still require the following manual tests.

## Exact manual tests

Use existing test accounts and Projects where possible. For visibility checks,
choose a distinctive Project name or description keyword, and verify both the
palette and the JSON response from `/actions/search.php?q=YOUR_KEYWORD` while
signed in as each account. Check result objects whose `type` is `project`.

1. **Sidebar:** As a normal workspace user, click **Work → Projects**. Confirm
   the list loads and Projects is active. Open an accessible Project, its People
   page, and its Task Lists page; Projects must stay active. Visit Tasks and
   confirm Projects is no longer active. Repeat as a workspace administrator;
   only one Projects entry should be present.
2. **Palette navigation:** Press Ctrl+K (Cmd+K on macOS) with the input empty.
   Select **Projects** with the arrow keys and Enter. Confirm `/projects/` opens.
   Reopen the palette and verify the search placeholder mentions Projects.
3. **Name and description:** Search a distinctive partial Project name, then a
   word appearing only in its description. Try mixed case for ASCII text. Verify
   the Project badge, name, readable status, and short description. Click it and
   confirm `/projects/project.php?id=ID` opens the correct Project. Test keyboard
   selection and Enter as well. Null/empty descriptions should show only status;
   multiline/long descriptions should remain compact.
4. **Direct member/lead:** Search as a direct Project member, then as a direct
   Project Lead. Both must receive that Project. Their other management controls
   must behave exactly as before this change.
5. **Synchronized Team:** Use a user with no direct Project membership who belongs
   to an attached synchronized Team. Confirm the Project appears. With an
   authorized manager, remove that membership or detach the Team, then search
   again; the Project must disappear unless another valid membership remains.
   A user with both direct and synchronized membership should see one result.
6. **Denied membership cases:** As a same-workspace non-member, search the exact
   name and a description-only keyword; neither response may contain that
   Project's metadata. Repeat for a Team Lead who is neither a direct member nor
   a member of an attached synchronized Team. Also test a Task List member whose
   list is linked to the Project but who has no Project membership. Neither role
   alone grants search visibility. For snapshot Teams, test a newly joined Team
   member with no direct Project row; snapshot attachment alone must not grant
   search visibility.
7. **Workspace administrator:** Search as an administrator who has no direct or
   Team-derived membership in the Project. Non-archived Projects in that
   administrator's workspace must appear. Projects from another workspace must
   not appear, even when names or description keywords match.
8. **Cross-workspace user:** Sign in as a user from another workspace. Search the
   exact name/description of the original workspace's Project. Confirm it is
   absent. Open its direct numeric URL; the destination must reject it. Adding a
   workspace_id/is_admin/user_id parameter to the search URL must not change
   authorization, because the endpoint derives these from the logged-in user.
9. **Lifecycle:** Check visible planning, active, on_hold, and completed Projects;
   all should be returned with the correct status. Search an archived Project's
   exact name as both member and administrator; neither should receive it. Use
   **Projects → Show archived**, open that Project, and confirm historical access
   still works under the existing permissions.
10. **Access changes and destination checks:** Obtain a result, then remove the
    user's last effective Project membership in another session. Follow the old
    result URL; the destination must deny access. Search again; it must be absent.
    Confirm search itself does not add members or change Team attachments.
11. **Bounded/safe results:** If more than 20 accessible Projects match, count
    Project results in the JSON response: at most 20, ordered by name and ID.
    Inaccessible matches must never appear or consume the Project result limit.
    Search quotes, `%`, and `_`; they may follow the existing LIKE wildcard
    behavior but must never bypass membership/workspace filtering. Names or
    descriptions containing markup must display as text, not execute markup.
12. **Other categories and Task 1:** Search known People, Teams, Tasks, Task Lists,
    Calendar events, and accessible Drive metadata. Confirm their existing links,
    badges, and access behavior remain unchanged. Open an individual Task and
    confirm the Task 1 details/work/status controls remain intact.

No Project-specific CSS, new framework, generic RBAC, membership materialization,
Project modules, or resources were added. No migration was created or run.
