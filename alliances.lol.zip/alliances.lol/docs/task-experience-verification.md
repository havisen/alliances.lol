# Individual Task verification

Run from the repository root:

```text
php tests/task-page-render.php
```

This covers all 41 existing field types, storage encoding/decoding, validation,
safe rendering, permission decisions, and the actual page markup for editors,
viewers, archived templates, invalid historical values, and Project context.
It does not open a database. It does not replace authenticated browser testing
of persistence, notifications, or transactions. No migration is needed.

## Manual click-through

Use existing test Tasks and accounts where possible. Perform mutations only on
Tasks you intend to change. The implementation agent did not run these live
database tests.

1. **Basic Task:** From a Task List, click a pending Task's checkmark or name.
   Confirm name, Task List, assignee, Pending badge, description, and creation
   timestamp. Confirm there is no Work Template section. Click **Back to Task
   List**, then reopen the Task.
2. **Normal details:** As the list creator, open **Edit task details**. Change
   the name and multiline description, then click **Save task details**.
   Confirm the success message, header name, and description. Reload and verify
   persistence. Try a blank name; confirm validation and that other entries are
   retained. Clear an optional description, save, and confirm **No description**.
3. **Reassignment:** Select another active member of this Task List and save.
   Confirm the header changes. With that recipient's Tasks notifications enabled,
   verify one assignment notification whose link opens the individual Task.
   Save unchanged details again and verify no second notification. Assign to
   yourself or Everyone and verify no assignment notification. Repeat with the
   recipient's Tasks notifications disabled; no notification should be created.
4. **Unavailable assignee:** Open an existing Task assigned to an inactive or
   removed list member. Confirm the unavailable/inactive label. Edit only its
   description with **Keep: ...** selected; its assignment must remain unchanged.
   Then reassign to an active list member. The historical assignee must not be
   available as a new assignment.
5. **Complete:** As the list creator or the assignee, click **Complete task**.
   Stay on the Task page and verify Completed, completion time, and **Reopen task**.
   Reload. When this was the last pending Task, check the Task List is completed.
   Repeat the same completion POST and verify the timestamp does not change.
6. **Reopen:** Click **Reopen task**. Confirm Pending and no completion timestamp;
   the parent Task List must be active again. Repeated reopen requests must not
   change other Tasks or create notifications.
7. **Permission matrix:** Use a list with members_can_edit disabled and a Task
   assigned to one member. The creator can edit and complete/reopen. The assignee
   can complete/reopen but cannot edit details or template values. Another member
   has neither control. For an Everyone Task, any list member can complete/reopen.
   Enable members_can_edit: another member can edit details and values, but still
   cannot complete a Task assigned to someone else. A workspace administrator
   who belongs to the list retains the existing delete permission; administrator
   status alone must not grant detail editing or completion.
8. **All 41 fields:** Open an existing all-fields template Task as an editor.
   Fill every field, including compound ranges, coordinates, person/team,
   radio/multi-select/checkbox choices, and multiline values. Click **Save work**
   and reload. Verify every value. Include number/currency/unit values of 100,
   numeric zero, checkbox false, No, Fail, and N/A. Use both sliders and numeric
   inputs; use both color text and picker. Clear optional fields (especially
   range/scale/color), save another field, and verify blanks remain blank.
9. **Validation recovery:** Fill a required field, change several other fields,
   then clear the required field. For server validation, submit an out-of-range
   value using browser developer tools. Confirm no work values are saved, the
   errors identify their fields, and the other submitted entries remain. Fix the
   error and save. Verify success and persistence after reload.
10. **Independent saves:** Change both normal details and work values without
    saving. Submit either form. Confirm the unsaved-changes prompt explains that
    the other section will be discarded. Cancel and verify both drafts remain.
    Test the same warning before completion, deletion, and navigating away.
11. **Template viewer:** Open the template Task as a member without edit rights.
    Confirm all fields render as values, including compound values and false/zero,
    with no work-value inputs or Save work button. Read-only completion permissions
    remain as described in step 7.
12. **Exact historical version:** Open a Task created from version 1 after version
    2 has been published. Verify Version 1 and only version 1's field definitions.
    Save and reload; it must still use version 1. Remove the template from the
    Task List's allowed/default templates and archive it: the old Task must still
    show the archived template, its version, and saved values, and remain editable
    under the normal Task permissions.
13. **Historical errors:** If existing historical records contain an invalid
    value or an unavailable person/team, open them as both editor and viewer.
    Confirm a useful warning and the original stored value without PHP warnings.
    Correct the value as an editor and save. If an existing Task references an
    unavailable version, confirm its explanation and that no work save form is
    offered. Do not create corrupt records in the live database for this test.
14. **Project context:** For a linked Task List, use a Task List member who can
    view the Project. Confirm its name and **Project** link; follow it and return.
    Repeat as a Task List member who cannot view that Project: show only restricted
    context and no Project link. A detached Task List has no Project context.
15. **Missing/access errors:** Open an invalid/missing Task ID, an ID in another
    workspace, and a Task whose list you do not belong to. Each must be unavailable
    without exposing Task data. Project membership, team membership, and admin
    status without Task List membership must not bypass this check.
16. **Forged requests:** In developer tools, resend a captured save, complete,
    reopen, or delete request without/with an invalid CSRF token; expect rejection.
    Repeat detail/value POSTs as a read-only member. Try assignment to a workspace
    user outside this list, an inactive member, and another workspace's user;
    expect rejection and unchanged data. Change task_id or the page ID to an
    inaccessible Task; expect rejection. Add field_type/template_version_id and
    unknown field IDs to a work save; they must not change its stored definition
    or permit writing another version's fields. Submit nested arrays for scalar
    fields; expect validation errors without PHP warnings.
17. **Layout:** At desktop and narrow mobile widths, verify header actions wrap,
    long names/descriptions are readable, forms fit the page, and all controls are
    keyboard usable. Check compound field labels and visible validation messages.
18. **Separation:** Verify Task List browsing, **Add task**, and **Configure
    templates** still navigate to their separate existing pages. No creation or
    template-configuration UI has moved onto the Task List or individual Task.

The page uses the shared stylesheet without new CSS. There is no Task updated_at
column, so it shows existing creation/completion timestamps without inventing one.

## Database observation during implementation

The agent did not connect to, migrate, or write the database, and the test runner
asserts that the application's database connection was never initialized.
However, file hashes observed at the beginning and end differ, so the file cannot
be certified unchanged across the entire session:

- Initial SHA-256: `4C3887613112B09982D3FCFC0306B49392EB5D4D8AF537328FB07E6A7E2F6F38`
- Later SHA-256: `1742640246D97A638A9D5B1A7FAD95365F1F3C43534EE7B14FB2BE45A538D839`

The source of that change was not established. No attempt was made to restore or
alter the database. Browser preview was also attempted using static fixture HTML,
but the browser-control tool failed to initialize before a page could be checked.
