<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();
$connection = db();

$access = require_administration_access($user);

if (!$access['is_admin']) {
    http_response_code(403);
    exit('Only workspace administrators can create teams.');
}

$workspaceId = (int) $access['workspace_id'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$name = trim($_POST['name'] ?? '');

$teamLeadId = filter_input(
    INPUT_POST,
    'team_lead_id',
    FILTER_VALIDATE_INT
);

$memberIds = $_POST['member_ids'] ?? [];

if ($name === '') {
    http_response_code(400);
    exit('Team name is required.');
}

if (strlen($name) > 120) {
    http_response_code(400);
    exit('Team name must be 120 characters or fewer.');
}

if (!$teamLeadId) {
    http_response_code(400);
    exit('A Team Lead is required.');
}

if (!is_array($memberIds)) {
    $memberIds = [];
}

/*
|--------------------------------------------------------------------------
| Verify Team Lead
|--------------------------------------------------------------------------
*/

$leadStatement = $connection->prepare(
    'SELECT 1
     FROM workspace_members wm
     INNER JOIN users u
         ON u.id = wm.user_id
     WHERE wm.workspace_id = ?
       AND wm.user_id = ?
       AND u.account_status = "active"
     LIMIT 1'
);

$leadStatement->execute([
    $workspaceId,
    $teamLeadId,
]);

if (!$leadStatement->fetchColumn()) {
    http_response_code(400);
    exit('The selected Team Lead is not a workspace member.');
}

/*
|--------------------------------------------------------------------------
| Normalize submitted members
|--------------------------------------------------------------------------
*/

$normalizedMemberIds = [];

foreach ($memberIds as $memberId) {
    $memberId = filter_var($memberId, FILTER_VALIDATE_INT);

    if ($memberId) {
        $normalizedMemberIds[] = (int) $memberId;
    }
}

$normalizedMemberIds[] = (int) $teamLeadId;

$normalizedMemberIds = array_values(
    array_unique($normalizedMemberIds)
);

/*
|--------------------------------------------------------------------------
| Keep only users belonging to this workspace
|--------------------------------------------------------------------------
*/

$validMemberIds = [];

if ($normalizedMemberIds !== []) {
    $placeholders = implode(
        ',',
        array_fill(0, count($normalizedMemberIds), '?')
    );

    $parameters = [$workspaceId];

    foreach ($normalizedMemberIds as $memberId) {
        $parameters[] = $memberId;
    }

    $membersStatement = $connection->prepare(
        'SELECT wm.user_id
         FROM workspace_members wm
         INNER JOIN users u
             ON u.id = wm.user_id
         WHERE wm.workspace_id = ?
           AND wm.user_id IN (' . $placeholders . ')
           AND u.account_status = "active"'
    );

    $membersStatement->execute($parameters);

    $validMemberIds = array_map(
        'intval',
        $membersStatement->fetchAll(PDO::FETCH_COLUMN)
    );
}

if (!in_array($teamLeadId, $validMemberIds, true)) {
    http_response_code(400);
    exit('Invalid Team Lead.');
}

/*
|--------------------------------------------------------------------------
| Create team
|--------------------------------------------------------------------------
*/

try {
    $connection->beginTransaction();

    $teamStatement = $connection->prepare(
        'INSERT INTO teams (
            workspace_id,
            name,
            team_lead_id
         )
         VALUES (?, ?, ?)'
    );

    $teamStatement->execute([
        $workspaceId,
        $name,
        $teamLeadId,
    ]);

    $newTeamId = (int) $connection->lastInsertId();

    $memberStatement = $connection->prepare(
        'INSERT OR IGNORE INTO team_members (
            team_id,
            user_id
         )
         VALUES (?, ?)'
    );

    foreach ($validMemberIds as $memberId) {
        $memberStatement->execute([
            $newTeamId,
            $memberId,
        ]);
    }

    $connection->commit();

    admin_audit_log(
        $workspaceId,
        (int) $user['id'],
        'team_created',
        'team',
        $newTeamId
    );

    create_notifications_for_users($validMemberIds, [
        'workspace_id' => $workspaceId,
        'actor_user_id' => (int) $user['id'],
        'type' => 'team_added',
        'category' => 'teams',
        'title' => 'You were added to a team',
        'body' => $name,
        'target_type' => 'team',
        'target_id' => $newTeamId,
        'target_url' => '/team.php?id=' . $newTeamId,
    ]);

    create_notification([
        'workspace_id' => $workspaceId,
        'user_id' => (int) $teamLeadId,
        'actor_user_id' => (int) $user['id'],
        'type' => 'team_lead_assigned',
        'category' => 'teams',
        'title' => 'You were made Team Lead',
        'body' => $name,
        'target_type' => 'team',
        'target_id' => $newTeamId,
        'target_url' => '/team.php?id=' . $newTeamId,
    ]);
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    throw $exception;
}

header(
    'Location: /admin/admin-team.php?id='
    . $newTeamId
);

exit;
