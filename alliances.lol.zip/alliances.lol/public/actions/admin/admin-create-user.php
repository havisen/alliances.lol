<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

$user = require_login();
$connection = db();

/*
|--------------------------------------------------------------------------
| Administrator only
|--------------------------------------------------------------------------
|
| Team Leads can manage members of their teams, but they cannot create
| new workspace users.
|
*/

$access = workspace_access((int) $user['id']);

if (
    $access === null
    || !$access['is_admin']
) {
    http_response_code(403);
    exit('Administrator access required.');
}

$workspaceId =
    (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| POST only
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

/*
|--------------------------------------------------------------------------
| Input
|--------------------------------------------------------------------------
*/

$displayName =
    trim((string) ($_POST['display_name'] ?? ''));

$email =
    strtolower(
        trim((string) ($_POST['email'] ?? ''))
    );

$password =
    (string) ($_POST['password'] ?? '');

$jobTitle =
    trim((string) ($_POST['job_title'] ?? ''));

/*
|--------------------------------------------------------------------------
| Validation
|--------------------------------------------------------------------------
*/

if ($displayName === '') {
    http_response_code(400);
    exit('Enter a display name.');
}

if (strlen($displayName) > 200) {
    http_response_code(400);
    exit('Display name is too long.');
}

if (
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {
    http_response_code(400);
    exit('Enter a valid email address.');
}

if (strlen($email) > 320) {
    http_response_code(400);
    exit('Email address is too long.');
}

if (strlen($password) < 12) {
    http_response_code(400);
    exit(
        'Password must be at least 12 characters.'
    );
}

if (strlen($password) > 4096) {
    http_response_code(400);
    exit('Password is too long.');
}

if (strlen($jobTitle) > 200) {
    http_response_code(400);
    exit('Job title is too long.');
}

/*
|--------------------------------------------------------------------------
| Existing email
|--------------------------------------------------------------------------
*/

$existing = $connection->prepare(
    'SELECT id
     FROM users
     WHERE email = ?
     LIMIT 1'
);

$existing->execute([
    $email,
]);

if ($existing->fetchColumn() !== false) {
    http_response_code(409);
    exit(
        'A user with that email already exists.'
    );
}

/*
|--------------------------------------------------------------------------
| Create user
|--------------------------------------------------------------------------
*/

try {
    $connection->beginTransaction();

    $userStatement = $connection->prepare(
        'INSERT INTO users
            (
                display_name,
                email,
                password_hash,
                job_title
            )
         VALUES (?, ?, ?, ?)'
    );

    $userStatement->execute([
        $displayName,
        $email,
        password_hash(
            $password,
            PASSWORD_DEFAULT
        ),
        $jobTitle !== ''
            ? $jobTitle
            : null,
    ]);

    $newUserId =
        (int) $connection->lastInsertId();

    /*
    |--------------------------------------------------------------------------
    | Add to workspace
    |--------------------------------------------------------------------------
    |
    | New users start as ordinary members.
    |
    */

    $memberStatement = $connection->prepare(
        'INSERT INTO workspace_members
            (
                workspace_id,
                user_id,
                role
            )
         VALUES (?, ?, ?)'
    );

    $memberStatement->execute([
        $workspaceId,
        $newUserId,
        'member',
    ]);

    $connection->commit();

    admin_audit_log(
        $workspaceId,
        (int) $user['id'],
        'user_created',
        'user',
        $newUserId
    );

    header(
        'Location: /admin/admin.php?created=1'
    );

    exit;
} catch (Throwable $error) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    http_response_code(500);
    exit('Could not create user.');
}
