<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();
$connection = db();

$access = require_administration_access($user);

$workspaceId = (int) $access['workspace_id'];
$isAdmin = (bool) $access['is_admin'];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$teamId = filter_input(INPUT_POST, 'team_id', FILTER_VALIDATE_INT);
$action = (string) ($_POST['action'] ?? 'update');
$name = trim($_POST['name'] ?? '');
$teamLeadId = filter_input(
    INPUT_POST,
    'team_lead_id',
    FILTER_VALIDATE_INT
);

$memberIds = $_POST['member_ids'] ?? [];

if (!$teamId) {
    http_response_code(400);
    exit('Invalid team.');
}

if ($action === 'archive') {
    if (!$isAdmin) {
        http_response_code(403);
        exit('Only workspace administrators can archive teams.');
    }

    $teamStatement = $connection->prepare(
        'SELECT id
         FROM teams
         WHERE id = ?
           AND workspace_id = ?
         LIMIT 1'
    );

    $teamStatement->execute([$teamId, $workspaceId]);

    if (!$teamStatement->fetch()) {
        http_response_code(404);
        exit('Team not found.');
    }

    $archiveStatement = $connection->prepare(
        'UPDATE teams
         SET status = ?
         WHERE id = ?
           AND workspace_id = ?'
    );

    $archiveStatement->execute(['archived', $teamId, $workspaceId]);

    admin_audit_log(
        $workspaceId,
        (int) $user['id'],
        'team_archived',
        'team',
        $teamId
    );

    header('Location: /admin/admin.php?updated=1');
    exit;
}

if (!is_array($memberIds)) {
    $memberIds = [];
}

/*
|--------------------------------------------------------------------------
| Verify team belongs to this workspace
|--------------------------------------------------------------------------
*/

$teamStatement = $connection->prepare(
    'SELECT id, name, team_lead_id, status
     FROM teams
     WHERE id = ?
       AND workspace_id = ?
     LIMIT 1'
);

$teamStatement->execute([
    $teamId,
    $workspaceId,
]);

$existingTeam = $teamStatement->fetch();

if (!$existingTeam) {
    http_response_code(404);
    exit('Team not found.');
}

if ((string) ($existingTeam['status'] ?? 'active') === 'archived') {
    http_response_code(400);
    exit('Archived teams cannot be updated.');
}

if (!$isAdmin && !can_manage_team($access, (int) $existingTeam['id'])) {
    http_response_code(403);
    exit('You cannot update this team.');
}

if (!$isAdmin) {
    $name = (string) $existingTeam['name'];
    $teamLeadId = (int) $existingTeam['team_lead_id'];
}

if ($name === '') {
    http_response_code(400);
    exit('Team name is required.');
}

if (strlen($name) > 120) {
    http_response_code(400);
    exit('Team name must be 120 characters or fewer.');
}

if (!$teamLeadId) {
    http_response_code(400);
    exit('A Team Lead is required.');
}

/*
|--------------------------------------------------------------------------
| Verify Team Lead belongs to this workspace
|--------------------------------------------------------------------------
*/

$leadStatement = $connection->prepare(
    'SELECT 1
     FROM workspace_members wm
     INNER JOIN users u
         ON u.id = wm.user_id
     WHERE wm.workspace_id = ?
       AND wm.user_id = ?
       AND u.account_status = "active"
     LIMIT 1'
);

$leadStatement->execute([
    $workspaceId,
    $teamLeadId,
]);

if (!$leadStatement->fetchColumn()) {
    http_response_code(400);
    exit('The selected Team Lead is not a workspace member.');
}

/*
|--------------------------------------------------------------------------
| Normalize member IDs
|--------------------------------------------------------------------------
*/

$normalizedMemberIds = [];

foreach ($memberIds as $memberId) {
    $memberId = filter_var($memberId, FILTER_VALIDATE_INT);

    if ($memberId) {
        $normalizedMemberIds[] = (int) $memberId;
    }
}

/*
 * The Team Lead must always be a member of their own team.
 */
$normalizedMemberIds[] = (int) $teamLeadId;

$normalizedMemberIds = array_values(
    array_unique($normalizedMemberIds)
);

/*
|--------------------------------------------------------------------------
| Validate submitted members
|--------------------------------------------------------------------------
|
| Do not trust IDs sent by the browser.
|
*/

$validMemberIds = [];

if ($normalizedMemberIds !== []) {
    $placeholders = implode(
        ',',
        array_fill(0, count($normalizedMemberIds), '?')
    );

    $parameters = [$workspaceId];

    foreach ($normalizedMemberIds as $memberId) {
        $parameters[] = $memberId;
    }

    $membersStatement = $connection->prepare(
        'SELECT wm.user_id
         FROM workspace_members wm
         INNER JOIN users u
             ON u.id = wm.user_id
         WHERE wm.workspace_id = ?
           AND wm.user_id IN (' . $placeholders . ')
           AND u.account_status = "active"'
    );

    $membersStatement->execute($parameters);

    $validMemberIds = array_map(
        'intval',
        $membersStatement->fetchAll(PDO::FETCH_COLUMN)
    );
}

if (!in_array($teamLeadId, $validMemberIds, true)) {
    http_response_code(400);
    exit('Invalid Team Lead.');
}

/*
|--------------------------------------------------------------------------
| Update team
|--------------------------------------------------------------------------
*/

try {
    $previousMembersStatement = $connection->prepare(
        'SELECT tm.user_id
         FROM team_members tm
         INNER JOIN users u
             ON u.id = tm.user_id
         WHERE tm.team_id = ?
           AND u.account_status = "active"'
    );

    $previousMembersStatement->execute([$teamId]);

    $previousMemberIds = array_map(
        'intval',
        $previousMembersStatement->fetchAll(PDO::FETCH_COLUMN)
    );

    $connection->beginTransaction();

    $updateStatement = $connection->prepare(
        'UPDATE teams
         SET name = ?,
             team_lead_id = ?
         WHERE id = ?
           AND workspace_id = ?'
    );

    $updateStatement->execute([
        $name,
        $teamLeadId,
        $teamId,
        $workspaceId,
    ]);

    $deleteStatement = $connection->prepare(
        'DELETE FROM team_members
         WHERE team_id = ?'
    );

    $deleteStatement->execute([$teamId]);

    $insertStatement = $connection->prepare(
        'INSERT OR IGNORE INTO team_members (
            team_id,
            user_id
         )
         VALUES (?, ?)'
    );

    foreach ($validMemberIds as $memberId) {
        $insertStatement->execute([
            $teamId,
            $memberId,
        ]);
    }

    $connection->commit();

    admin_audit_log(
        $workspaceId,
        (int) $user['id'],
        'team_updated',
        'team',
        $teamId,
        $isAdmin
            ? 'Team details and membership updated.'
            : 'Team membership updated by Team Lead.'
    );

    $addedMemberIds = array_values(
        array_diff($validMemberIds, $previousMemberIds)
    );

    create_notifications_for_users($addedMemberIds, [
        'workspace_id' => $workspaceId,
        'actor_user_id' => (int) $user['id'],
        'type' => 'team_added',
        'category' => 'teams',
        'title' => 'You were added to a team',
        'body' => $name,
        'target_type' => 'team',
        'target_id' => $teamId,
        'target_url' => '/team.php?id=' . $teamId,
    ]);

    if ((int) $existingTeam['team_lead_id'] !== (int) $teamLeadId) {
        create_notification([
            'workspace_id' => $workspaceId,
            'user_id' => (int) $teamLeadId,
            'actor_user_id' => (int) $user['id'],
            'type' => 'team_lead_assigned',
            'category' => 'teams',
            'title' => 'You were made Team Lead',
            'body' => $name,
            'target_type' => 'team',
            'target_id' => $teamId,
            'target_url' => '/team.php?id=' . $teamId,
        ]);
    }
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    throw $exception;
}

header(
    'Location: /admin/admin-team.php?id='
    . $teamId
);

exit;
