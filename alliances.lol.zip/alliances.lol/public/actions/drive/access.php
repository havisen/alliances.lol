<?php
declare(strict_types=1);
require_once dirname(__DIR__,3).'/src/auth.php';
require_once dirname(__DIR__,3).'/src/database.php';
require_once dirname(__DIR__,3).'/src/drive/drive.php';
$user=require_login(); header('Content-Type: application/json; charset=utf-8');
$wa=workspace_access((int)$user['id']);
if($wa===null){http_response_code(403);echo json_encode(['success'=>false,'error'=>'You do not have access to a workspace.']);exit;}
if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);echo json_encode(['success'=>false,'error'=>'Method not allowed.']);exit;}
$fileId=filter_input(INPUT_GET,'file_id',FILTER_VALIDATE_INT); if(!$fileId||$fileId<1){http_response_code(400);echo json_encode(['success'=>false,'error'=>'A valid file ID is required.']);exit;}
$userId=(int)$user['id']; $workspaceId=(int)$wa['workspace_id'];
try{
 $pdo=db(); $effective=drive_effective_access($pdo,$workspaceId,(int)$fileId,$userId);
 if($effective===null){http_response_code(404);echo json_encode(['success'=>false,'error'=>'File not found or you do not have access.']);exit;}
 $fs=$pdo->prepare('SELECT id,uploaded_by,original_name,sharing_mode,key_version FROM drive_files WHERE id=? AND workspace_id=? LIMIT 1');$fs->execute([$fileId,$workspaceId]);$file=$fs->fetch(PDO::FETCH_ASSOC);
 if(!$file){http_response_code(404);echo json_encode(['success'=>false,'error'=>'File not found.']);exit;}
 $ms=$pdo->prepare("SELECT u.id,u.display_name,u.email,u.job_title,u.avatar_path,
   CASE WHEN dfa.user_id IS NULL THEN 0 ELSE 1 END individual_access,
   COALESCE(dfa.can_edit,0) individual_can_edit, dfa.expires_at,
   CASE WHEN ea.user_id IS NULL THEN 0 ELSE 1 END has_access, COALESCE(ea.can_edit,0) can_edit,
   CASE WHEN dfk.user_id IS NULL THEN 0 ELSE 1 END has_current_key
 FROM workspace_members wm JOIN users u ON u.id=wm.user_id
 LEFT JOIN drive_file_access dfa ON dfa.file_id=:fid1 AND dfa.user_id=u.id
 LEFT JOIN drive_effective_access ea ON ea.file_id=:fid2 AND ea.user_id=u.id
 LEFT JOIN drive_file_keys dfk ON dfk.file_id=:fid3 AND dfk.user_id=u.id AND dfk.key_version=:kv
 WHERE wm.workspace_id=:wid ORDER BY u.display_name COLLATE NOCASE,u.email COLLATE NOCASE");
 $ms->execute([':fid1'=>$fileId,':fid2'=>$fileId,':fid3'=>$fileId,':kv'=>(int)$file['key_version'],':wid'=>$workspaceId]);
 $members=[]; while($m=$ms->fetch(PDO::FETCH_ASSOC)){$id=(int)$m['id'];$members[]=['id'=>$id,'name'=>(string)$m['display_name'],'email'=>(string)$m['email'],'job_title'=>(string)($m['job_title']??''),'avatar_path'=>$m['avatar_path'],'has_access'=>(int)$m['has_access']===1,'individual_access'=>(int)$m['individual_access']===1,'can_edit'=>(int)$m['can_edit']===1,'individual_can_edit'=>(int)$m['individual_can_edit']===1,'expires_at'=>$m['expires_at'],'has_current_key'=>(int)$m['has_current_key']===1,'is_current_user'=>$id===$userId,'is_uploader'=>$id===(int)$file['uploaded_by']];}
 $ts=$pdo->prepare("SELECT t.id,t.name,ta.can_edit,ta.expires_at,CASE WHEN ta.team_id IS NULL THEN 0 ELSE 1 END has_access
 FROM teams t LEFT JOIN drive_file_team_access ta ON ta.team_id=t.id AND ta.file_id=:fid WHERE t.workspace_id=:wid ORDER BY t.name COLLATE NOCASE");
 $ts->execute([':fid'=>$fileId,':wid'=>$workspaceId]); $teams=[];
 $tms=$pdo->prepare("SELECT u.id,u.display_name,u.email FROM team_members tm JOIN users u ON u.id=tm.user_id WHERE tm.team_id=? ORDER BY u.display_name COLLATE NOCASE");
 while($t=$ts->fetch(PDO::FETCH_ASSOC)){$tms->execute([(int)$t['id']]);$tm=[];while($r=$tms->fetch(PDO::FETCH_ASSOC))$tm[]=['id'=>(int)$r['id'],'name'=>(string)$r['display_name'],'email'=>(string)$r['email']];$teams[]=['id'=>(int)$t['id'],'name'=>(string)$t['name'],'has_access'=>(int)$t['has_access']===1,'can_edit'=>(int)$t['can_edit']===1,'expires_at'=>$t['expires_at'],'members'=>$tm];}
 echo json_encode(['success'=>true,'file'=>['id'=>(int)$file['id'],'name'=>(string)$file['original_name'],'sharing_mode'=>(string)$file['sharing_mode'],'key_version'=>(int)$file['key_version'],'uploaded_by'=>(int)$file['uploaded_by'],'current_user_can_edit'=>$effective['can_edit']],'members'=>$members,'teams'=>$teams]);
}catch(Throwable $e){error_log('Drive access lookup error: '.$e->getMessage());http_response_code(500);echo json_encode(['success'=>false,'error'=>'Unable to load file access information.']);}
