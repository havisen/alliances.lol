<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'You do not have access to a workspace.']);
    exit;
}

$fileId = filter_input(INPUT_GET, 'file_id', FILTER_VALIDATE_INT);

if ($fileId === false || $fileId === null || $fileId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid Drive file.']);
    exit;
}

$userId = (int) $user['id'];
$workspaceId = (int) $access['workspace_id'];

try {
    $pdo = db();

    $accessStatement = $pdo->prepare(
        '
        SELECT f.id
        FROM drive_files AS f
        INNER JOIN drive_effective_access AS a
            ON a.file_id = f.id
           AND a.user_id = :user_id
        WHERE f.id = :file_id
          AND f.workspace_id = :workspace_id
        LIMIT 1
        '
    );

    $accessStatement->execute([
        ':user_id' => $userId,
        ':file_id' => $fileId,
        ':workspace_id' => $workspaceId,
    ]);

    if (!$accessStatement->fetchColumn()) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'File not found or access is unavailable.']);
        exit;
    }

    $activityStatement = $pdo->prepare(
        '
        SELECT
            a.id,
            a.action,
            a.details_json,
            a.created_at,
            u.display_name AS actor_name,
            u.avatar_path AS actor_avatar
        FROM drive_file_activity AS a
        LEFT JOIN users AS u
            ON u.id = a.actor_user_id
        WHERE a.workspace_id = :workspace_id
          AND a.file_id = :file_id
        ORDER BY a.created_at DESC, a.id DESC
        LIMIT 50
        '
    );

    $activityStatement->execute([
        ':workspace_id' => $workspaceId,
        ':file_id' => $fileId,
    ]);

    $items = [];

    while ($row = $activityStatement->fetch()) {
        $details = null;
        $detailsJson = (string) ($row['details_json'] ?? '');

        if ($detailsJson !== '') {
            $decoded = json_decode($detailsJson, true);
            $details = is_array($decoded) ? $decoded : null;
        }

        $items[] = [
            'id' => (int) $row['id'],
            'action' => (string) $row['action'],
            'details' => $details,
            'created_at' => (string) $row['created_at'],
            'actor_name' => (string) ($row['actor_name'] ?? 'Unknown user'),
            'actor_avatar' => $row['actor_avatar'] !== null ? (string) $row['actor_avatar'] : null,
        ];
    }

    echo json_encode([
        'success' => true,
        'activity' => $items,
    ]);
} catch (Throwable $exception) {
    error_log('Drive activity load failed: ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Unable to load file activity.']);
}
