<?php
declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();
$access = workspace_access((int) $user['id']);

if (!$access) {
    http_response_code(403);
    echo json_encode(['error' => 'Workspace access required.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

require_valid_csrf();

$pdo = db();

$userId = (int) $user['id'];
$workspaceId = (int) $access['workspace_id'];

$sourceFileId = (int) ($_POST['source_file_id'] ?? 0);
$folderIdRaw = trim((string) ($_POST['folder_id'] ?? ''));
$originalName = trim((string) ($_POST['original_name'] ?? ''));
$mimeType = trim((string) ($_POST['mime_type'] ?? ''));
$iv = trim((string) ($_POST['iv'] ?? ''));
$encryptedKeysJson = (string) ($_POST['encrypted_keys'] ?? '');

$folderId = $folderIdRaw === '' ? null : (int) $folderIdRaw;

if ($sourceFileId <= 0) {
    http_response_code(422);
    echo json_encode(['error' => 'Invalid source file.']);
    exit;
}

if ($originalName === '' || strlen($originalName) > 200) {
    http_response_code(422);
    echo json_encode(['error' => 'Invalid file name.']);
    exit;
}

if (
    $originalName === '.'
    || $originalName === '..'
    || str_contains($originalName, '/')
    || str_contains($originalName, '\\')
    || preg_match('/[\x00-\x1F\x7F]/', $originalName)
) {
    http_response_code(422);
    echo json_encode(['error' => 'Invalid file name.']);
    exit;
}

if ($iv === '') {
    http_response_code(422);
    echo json_encode(['error' => 'Missing encryption IV.']);
    exit;
}

$encryptedKeys = json_decode($encryptedKeysJson, true);

if (!is_array($encryptedKeys) || $encryptedKeys === []) {
    http_response_code(422);
    echo json_encode(['error' => 'Missing encrypted file keys.']);
    exit;
}

if (
    !isset($_FILES['encrypted_file'])
    || !is_array($_FILES['encrypted_file'])
    || ($_FILES['encrypted_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK
) {
    http_response_code(422);
    echo json_encode(['error' => 'Missing encrypted file data.']);
    exit;
}

$tmpPath = (string) ($_FILES['encrypted_file']['tmp_name'] ?? '');

if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
    http_response_code(422);
    echo json_encode(['error' => 'Invalid encrypted upload.']);
    exit;
}

/*
 * Confirm the user can currently access the source file and possesses
 * the current encrypted key envelope.
 */
$sourceStmt = $pdo->prepare(
    'SELECT
        f.id,
        f.original_name,
        f.mime_type,
        f.key_version,
        f.trashed_at
     FROM drive_files f
     INNER JOIN drive_effective_access a
        ON a.file_id = f.id
       AND a.user_id = :user_id
       AND (a.expires_at IS NULL OR a.expires_at > CURRENT_TIMESTAMP)
     INNER JOIN drive_file_keys k
        ON k.file_id = f.id
       AND k.user_id = :key_user_id
       AND k.key_version = f.key_version
     WHERE f.id = :file_id
       AND f.workspace_id = :workspace_id
       AND f.trashed_at IS NULL
     LIMIT 1'
);

$sourceStmt->execute([
    ':user_id' => $userId,
    ':key_user_id' => $userId,
    ':file_id' => $sourceFileId,
    ':workspace_id' => $workspaceId,
]);

$source = $sourceStmt->fetch();

if (!$source) {
    http_response_code(404);
    echo json_encode(['error' => 'Source file not found or access denied.']);
    exit;
}

/*
 * If a destination folder was supplied, make sure it belongs to the
 * workspace, is not trashed, and none of its ancestors are trashed.
 */
if ($folderId !== null) {
    if ($folderId <= 0) {
        http_response_code(422);
        echo json_encode(['error' => 'Invalid destination folder.']);
        exit;
    }

    $visited = [];
    $currentFolderId = $folderId;

    while ($currentFolderId !== null) {
        if (isset($visited[$currentFolderId])) {
            http_response_code(409);
            echo json_encode(['error' => 'Invalid folder hierarchy.']);
            exit;
        }

        $visited[$currentFolderId] = true;

        $folderStmt = $pdo->prepare(
            'SELECT id, parent_id, trashed_at
             FROM drive_folders
             WHERE id = :folder_id
               AND workspace_id = :workspace_id
             LIMIT 1'
        );

        $folderStmt->execute([
            ':folder_id' => $currentFolderId,
            ':workspace_id' => $workspaceId,
        ]);

        $folder = $folderStmt->fetch();

        if (!$folder || $folder['trashed_at'] !== null) {
            http_response_code(404);
            echo json_encode(['error' => 'Destination folder not found.']);
            exit;
        }

        $currentFolderId = $folder['parent_id'] !== null
            ? (int) $folder['parent_id']
            : null;
    }
}

/*
 * Validate the encrypted key envelopes before storing anything.
 *
 * Each entry must contain:
 * {
 *   "user_id": 123,
 *   "encrypted_key": "-----BEGIN PGP MESSAGE-----..."
 * }
 */
$normalizedKeys = [];

foreach ($encryptedKeys as $keyEntry) {
    if (!is_array($keyEntry)) {
        continue;
    }

    $recipientUserId = (int) ($keyEntry['user_id'] ?? 0);
    $encryptedKey = trim((string) ($keyEntry['encrypted_key'] ?? ''));

    if ($recipientUserId <= 0 || $encryptedKey === '') {
        continue;
    }

    $normalizedKeys[$recipientUserId] = $encryptedKey;
}

if ($normalizedKeys === []) {
    http_response_code(422);
    echo json_encode(['error' => 'No valid encrypted file keys were supplied.']);
    exit;
}

/*
 * The person creating the copy must always receive an envelope.
 */
if (!isset($normalizedKeys[$userId])) {
    http_response_code(422);
    echo json_encode(['error' => 'The copied file must include your encrypted key.']);
    exit;
}

/*
 * Only accept key recipients who currently belong to this workspace.
 */
$memberCheckStmt = $pdo->prepare(
    'SELECT 1
     FROM workspace_members
     WHERE workspace_id = :workspace_id
       AND user_id = :user_id
     LIMIT 1'
);

foreach (array_keys($normalizedKeys) as $recipientUserId) {
    $memberCheckStmt->execute([
        ':workspace_id' => $workspaceId,
        ':user_id' => $recipientUserId,
    ]);

    if (!$memberCheckStmt->fetchColumn()) {
        http_response_code(422);
        echo json_encode(['error' => 'One or more key recipients are not workspace members.']);
        exit;
    }
}

$encryptedSize = (int) ($_FILES['encrypted_file']['size'] ?? 0);

if ($encryptedSize <= 0) {
    http_response_code(422);
    echo json_encode(['error' => 'Encrypted file is empty.']);
    exit;
}

$storageId = drive_generate_storage_id();
$storagePath = drive_file_path($storageId);

drive_ensure_file_directory($storageId);

if (!move_uploaded_file($tmpPath, $storagePath)) {
    http_response_code(500);
    echo json_encode(['error' => 'Could not store the encrypted copy.']);
    exit;
}

try {
    $pdo->beginTransaction();

    /*
     * A copy is intentionally a completely new Drive file:
     * - new database ID
     * - new storage ID
     * - new AES key generated by the browser
     * - new AES-GCM IV generated by the browser
     * - new OpenPGP key envelopes
     */
    $insertFileStmt = $pdo->prepare(
        'INSERT INTO drive_files (
            workspace_id,
            folder_id,
            uploaded_by,
            storage_id,
            original_name,
            mime_type,
            encrypted_size,
            encryption_version,
            key_version,
            sharing_mode,
            current_version,
            created_at,
            updated_at
         ) VALUES (
            :workspace_id,
            :folder_id,
            :uploaded_by,
            :storage_id,
            :original_name,
            :mime_type,
            :encrypted_size,
            1,
            1,
            :sharing_mode,
            1,
            CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP
         )'
    );

    /*
     * A copied file starts private to the selected recipients supplied
     * by the browser. The browser is responsible for deciding which
     * recipients receive the new independent key.
     */
    $sharingMode = count($normalizedKeys) > 1 ? 'selected' : 'selected';

    $insertFileStmt->execute([
        ':workspace_id' => $workspaceId,
        ':folder_id' => $folderId,
        ':uploaded_by' => $userId,
        ':storage_id' => $storageId,
        ':original_name' => $originalName,
        ':mime_type' => $mimeType !== '' ? $mimeType : null,
        ':encrypted_size' => $encryptedSize,
        ':sharing_mode' => $sharingMode,
    ]);

    $newFileId = (int) $pdo->lastInsertId();

    /*
     * Store Version 1.
     *
     * Your Drive stores the encrypted payload in the file represented
     * by storage_id. The IV must therefore be retained with the version
     * metadata used by your existing editor/download flow.
     *
     * The current Drive schema may store the IV in a column added by
     * your existing upload/version implementation. Detect it before
     * inserting so this endpoint matches the installed schema.
     */
    $versionColumnsStmt = $pdo->query('PRAGMA table_info(drive_file_versions)');
    $versionColumns = [];

    foreach ($versionColumnsStmt->fetchAll() as $column) {
        $versionColumns[(string) $column['name']] = true;
    }

    if (isset($versionColumns['iv'])) {
        $versionStmt = $pdo->prepare(
            'INSERT INTO drive_file_versions (
                file_id,
                version_number,
                created_by,
                storage_id,
                encrypted_size,
                encryption_version,
                key_version,
                iv,
                created_at
             ) VALUES (
                :file_id,
                1,
                :created_by,
                :storage_id,
                :encrypted_size,
                1,
                1,
                :iv,
                CURRENT_TIMESTAMP
             )'
        );

        $versionStmt->execute([
            ':file_id' => $newFileId,
            ':created_by' => $userId,
            ':storage_id' => $storageId,
            ':encrypted_size' => $encryptedSize,
            ':iv' => $iv,
        ]);
    } else {
        /*
         * Some existing versions of the schema keep the IV on
         * drive_files instead. Update it there when available.
         */
        $fileColumnsStmt = $pdo->query('PRAGMA table_info(drive_files)');
        $fileColumns = [];

        foreach ($fileColumnsStmt->fetchAll() as $column) {
            $fileColumns[(string) $column['name']] = true;
        }

        if (isset($fileColumns['iv'])) {
            $ivStmt = $pdo->prepare(
                'UPDATE drive_files
                 SET iv = :iv
                 WHERE id = :file_id'
            );

            $ivStmt->execute([
                ':iv' => $iv,
                ':file_id' => $newFileId,
            ]);
        }

        $versionStmt = $pdo->prepare(
            'INSERT INTO drive_file_versions (
                file_id,
                version_number,
                created_by,
                storage_id,
                encrypted_size,
                encryption_version,
                key_version,
                created_at
             ) VALUES (
                :file_id,
                1,
                :created_by,
                :storage_id,
                :encrypted_size,
                1,
                1,
                CURRENT_TIMESTAMP
             )'
        );

        $versionStmt->execute([
            ':file_id' => $newFileId,
            ':created_by' => $userId,
            ':storage_id' => $storageId,
            ':encrypted_size' => $encryptedSize,
        ]);
    }

    $accessStmt = $pdo->prepare(
        'INSERT INTO drive_file_access (
            file_id,
            user_id,
            granted_by,
            can_edit,
            created_at
         ) VALUES (
            :file_id,
            :user_id,
            :granted_by,
            :can_edit,
            CURRENT_TIMESTAMP
         )'
    );

    $keyStmt = $pdo->prepare(
        'INSERT INTO drive_file_keys (
            file_id,
            user_id,
            key_version,
            encrypted_key,
            created_at
         ) VALUES (
            :file_id,
            :user_id,
            1,
            :encrypted_key,
            CURRENT_TIMESTAMP
         )'
    );

    foreach ($normalizedKeys as $recipientUserId => $encryptedKey) {
        $accessStmt->execute([
            ':file_id' => $newFileId,
            ':user_id' => $recipientUserId,
            ':granted_by' => $userId,
            ':can_edit' => $recipientUserId === $userId ? 1 : 0,
        ]);

        $keyStmt->execute([
            ':file_id' => $newFileId,
            ':user_id' => $recipientUserId,
            ':encrypted_key' => $encryptedKey,
        ]);
    }

    /*
     * Record the copy operation when the Drive activity table exists.
     */
    $activityTableStmt = $pdo->query(
        "SELECT name
         FROM sqlite_master
         WHERE type = 'table'
           AND name = 'drive_file_activity'
         LIMIT 1"
    );

    if ($activityTableStmt->fetchColumn()) {
        $activityStmt = $pdo->prepare(
            'INSERT INTO drive_file_activity (
                workspace_id,
                file_id,
                folder_id,
                actor_user_id,
                action,
                created_at
             ) VALUES (
                :workspace_id,
                :file_id,
                :folder_id,
                :actor_user_id,
                :action,
                CURRENT_TIMESTAMP
             )'
        );

        $activityStmt->execute([
            ':workspace_id' => $workspaceId,
            ':file_id' => $newFileId,
            ':folder_id' => $folderId,
            ':actor_user_id' => $userId,
            ':action' => 'file_copied',
        ]);
    }

    $pdo->commit();

echo json_encode([
    'success' => true,
    'file' => [
        'id' => $newFileId,
        'folder_id' => $folderId,
        'original_name' => $originalName,
        'mime_type' => $mimeType !== '' ? $mimeType : null,
        'encrypted_size' => $encryptedSize,
        'key_version' => 1,
        'current_version' => 1,
    ],
]);
} catch (Throwable $e) {
    if (
        isset($pdo) &&
        $pdo instanceof PDO &&
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    if (
        isset($storedPath) &&
        is_string($storedPath) &&
        $storedPath !== '' &&
        is_file($storedPath)
    ) {
        @unlink($storedPath);
    }

    error_log(
        'Drive copy failed: '
        . $e->getMessage()
        . ' in '
        . $e->getFile()
        . ':'
        . $e->getLine()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Copy failed: ' . $e->getMessage(),
    ]);
}