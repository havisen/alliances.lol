<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();
require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];
$currentUserId = (int) $user['id'];


/*
 * --------------------------------------------------------------------------
 * Folder name
 * --------------------------------------------------------------------------
 */

$name = trim((string) ($_POST['name'] ?? ''));

if ($name === '') {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Folder name is required.',
    ]);

    exit;
}

if (strlen($name) > 150) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Folder name is too long.',
    ]);

    exit;
}


/*
 * Do not allow control characters in folder names.
 */
if (preg_match('/[\x00-\x1F\x7F]/', $name)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Folder name contains invalid characters.',
    ]);

    exit;
}


/*
 * --------------------------------------------------------------------------
 * Parent folder
 * --------------------------------------------------------------------------
 */

$parentIdRaw = $_POST['parent_id'] ?? '';

$parentId = null;

if ($parentIdRaw !== '' && $parentIdRaw !== null) {
    $validatedParentId = filter_var(
        $parentIdRaw,
        FILTER_VALIDATE_INT,
        [
            'options' => [
                'min_range' => 1,
            ],
        ]
    );

    if ($validatedParentId === false) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid parent folder.',
        ]);

        exit;
    }

    $parentId = (int) $validatedParentId;
}


try {
    $pdo = db();


    /*
     * If this folder is being created inside another folder,
     * verify that the parent belongs to the same workspace.
     */
    if ($parentId !== null) {
        $parentStatement = $pdo->prepare(
            '
            SELECT id
            FROM drive_folders
            WHERE id = :parent_id
              AND workspace_id = :workspace_id
            LIMIT 1
            '
        );

        $parentStatement->execute([
            ':parent_id' => $parentId,
            ':workspace_id' => $workspaceId,
        ]);

        if ($parentStatement->fetch(PDO::FETCH_ASSOC) === false) {
            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' => 'Parent folder not found.',
            ]);

            exit;
        }
    }


    /*
     * Prevent two folders with the same name inside the same
     * parent folder.
     *
     * SQLite's COLLATE NOCASE makes this case-insensitive for
     * ordinary ASCII folder names.
     */
    if ($parentId === null) {
        $duplicateStatement = $pdo->prepare(
            '
            SELECT id
            FROM drive_folders
            WHERE workspace_id = :workspace_id
              AND parent_id IS NULL
              AND name = :name COLLATE NOCASE
            LIMIT 1
            '
        );

        $duplicateStatement->execute([
            ':workspace_id' => $workspaceId,
            ':name' => $name,
        ]);
    } else {
        $duplicateStatement = $pdo->prepare(
            '
            SELECT id
            FROM drive_folders
            WHERE workspace_id = :workspace_id
              AND parent_id = :parent_id
              AND name = :name COLLATE NOCASE
            LIMIT 1
            '
        );

        $duplicateStatement->execute([
            ':workspace_id' => $workspaceId,
            ':parent_id' => $parentId,
            ':name' => $name,
        ]);
    }


    if ($duplicateStatement->fetch(PDO::FETCH_ASSOC) !== false) {
        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'A folder with that name already exists here.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Create folder
     * ----------------------------------------------------------------------
     */

    $statement = $pdo->prepare(
        '
        INSERT INTO drive_folders (
            workspace_id,
            parent_id,
            created_by,
            name
        )
        VALUES (
            :workspace_id,
            :parent_id,
            :created_by,
            :name
        )
        '
    );

    $statement->execute([
        ':workspace_id' => $workspaceId,
        ':parent_id' => $parentId,
        ':created_by' => $currentUserId,
        ':name' => $name,
    ]);

    $folderId = (int) $pdo->lastInsertId();


    echo json_encode([
        'success' => true,

        'folder' => [
            'id' => $folderId,
            'parent_id' => $parentId,
            'name' => $name,
            'created_by' => $currentUserId,
            'owner_name' => (string) $user['display_name'],
        ],
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive create folder error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to create folder.',
    ]);
}