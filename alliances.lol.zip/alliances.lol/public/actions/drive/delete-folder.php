<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$folderId =
    filter_input(
        INPUT_POST,
        'folder_id',
        FILTER_VALIDATE_INT
    );

if (
    !$folderId ||
    $folderId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive folder.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Load folder
     * ----------------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    workspace_id,
                    parent_id,
                    created_by,
                    name,
                    trashed_at
                FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':folder_id' =>
            $folderId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $folder =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );

    if ($folder === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Drive folder not found.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Authorization
     * ----------------------------------------------------------------------
     *
     * Folder Trash permission:
     *
     * - folder creator
     * - workspace administrator
     */

    $isCreator =
        (int) $folder['created_by'] ===
        $userId;

    $isAdmin =
        !empty(
            $access['is_admin']
        );

    if (
        !$isCreator &&
        !$isAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to move this folder to Trash.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Already trashed
     * ----------------------------------------------------------------------
     */

    if (
        $folder['trashed_at'] !== null &&
        trim(
            (string) $folder['trashed_at']
        ) !== ''
    ) {
        echo json_encode([
            'success' => true,

            'folder_id' =>
                $folderId,

            'already_trashed' =>
                true,

            'message' =>
                'Folder is already in Trash.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Check whether an ancestor is already in Trash
     * ----------------------------------------------------------------------
     *
     * A folder inside a trashed parent is already effectively in Trash.
     *
     * We do not mark descendants individually because preserving the tree
     * makes restoration much cleaner.
     */

    $ancestorId =
        $folder['parent_id'] !== null
            ? (int) $folder['parent_id']
            : null;

    $visited = [];

    while ($ancestorId !== null) {
        if (isset($visited[$ancestorId])) {
            throw new RuntimeException(
                'Invalid Drive folder hierarchy.'
            );
        }

        $visited[$ancestorId] = true;

        $ancestorStatement =
            $pdo->prepare(
                '
                    SELECT
                        parent_id,
                        trashed_at
                    FROM drive_folders
                    WHERE id = :folder_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );

        $ancestorStatement->execute([
            ':folder_id' =>
                $ancestorId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $ancestor =
            $ancestorStatement->fetch(
                PDO::FETCH_ASSOC
            );

        if ($ancestor === false) {
            /*
             * Broken/missing parent.
             *
             * Stop walking instead of leaking information from another
             * workspace or following an invalid hierarchy.
             */
            break;
        }

        if (
            $ancestor['trashed_at'] !== null &&
            trim(
                (string) $ancestor['trashed_at']
            ) !== ''
        ) {
            echo json_encode([
                'success' =>
                    true,

                'folder_id' =>
                    $folderId,

                'already_trashed' =>
                    true,

                'in_trashed_parent' =>
                    true,

                'message' =>
                    'Folder is already inside Trash.',
            ]);

            exit;
        }

        $ancestorId =
            $ancestor['parent_id'] !== null
                ? (int) $ancestor['parent_id']
                : null;
    }


    /*
     * ----------------------------------------------------------------------
     * Move folder tree to Trash
     * ----------------------------------------------------------------------
     *
     * Only the selected folder receives trashed_at.
     *
     * Child folders and files retain their original parent/folder IDs.
     * This preserves the complete hierarchy for Restore.
     *
     * No encrypted file data is deleted or modified.
     */

    $pdo->beginTransaction();

    $trashStatement =
        $pdo->prepare(
            '
                UPDATE drive_folders
                SET
                    trashed_at = CURRENT_TIMESTAMP,
                    trashed_by = :trashed_by,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NULL
            '
        );

    $trashStatement->execute([
        ':trashed_by' =>
            $userId,

        ':folder_id' =>
            $folderId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    if (
        $trashStatement->rowCount() !== 1
    ) {
        throw new RuntimeException(
            'Unable to move the Drive folder to Trash.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Activity
     * ----------------------------------------------------------------------
     */

    $activityStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_file_activity (
                    workspace_id,
                    folder_id,
                    actor_user_id,
                    action,
                    details_json
                )
                VALUES (
                    :workspace_id,
                    :folder_id,
                    :actor_user_id,
                    :action,
                    :details_json
                )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':folder_id' =>
            $folderId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'folder_trashed',

        ':details_json' =>
            json_encode(
                [
                    'name' =>
                        (string) $folder['name'],

                    'parent_id' =>
                        $folder['parent_id'] !== null
                            ? (int) $folder['parent_id']
                            : null,
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    $pdo->commit();


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' =>
            true,

        'folder_id' =>
            $folderId,

        'trashed' =>
            true,

        'message' =>
            'Folder moved to Trash.',
    ]);
} catch (Throwable $error) {
    if (
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive folder trash failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to move the Drive folder to Trash.',
    ]);
}