<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$fileId =
    filter_input(
        INPUT_POST,
        'file_id',
        FILTER_VALIDATE_INT
    );

if (
    !$fileId ||
    $fileId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive file.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * --------------------------------------------------------------
     * Load file
     * --------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    workspace_id,
                    uploaded_by,
                    original_name,
                    trashed_at
                FROM drive_files
                WHERE id = :file_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $file =
        $statement->fetch();

    if (!$file) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Drive file not found.',
        ]);

        exit;
    }


    /*
     * --------------------------------------------------------------
     * Authorization
     * --------------------------------------------------------------
     *
     * Moving a file to Trash is currently restricted to:
     *
     * - the original uploader
     * - a workspace administrator
     *
     * can_edit alone does not grant deletion permission.
     */

    $isUploader =
        (int) $file['uploaded_by'] ===
        $userId;

    $isAdmin =
        !empty(
            $access['is_admin']
        );

    if (
        !$isUploader &&
        !$isAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to move this file to Trash.',
        ]);

        exit;
    }


    /*
     * --------------------------------------------------------------
     * Already in Trash
     * --------------------------------------------------------------
     */

    if (
        $file['trashed_at'] !== null &&
        trim(
            (string) $file['trashed_at']
        ) !== ''
    ) {
        echo json_encode([
            'success' => true,

            'file_id' =>
                $fileId,

            'already_trashed' =>
                true,

            'message' =>
                'File is already in Trash.',
        ]);

        exit;
    }


    /*
     * --------------------------------------------------------------
     * Move to Trash
     * --------------------------------------------------------------
     *
     * IMPORTANT:
     *
     * We do NOT delete:
     *
     * - drive_files
     * - drive_file_versions
     * - drive_file_keys
     * - drive_file_access
     * - encrypted storage blobs
     *
     * Trash must remain recoverable.
     */

    $pdo->beginTransaction();


    $statement =
        $pdo->prepare(
            '
                UPDATE drive_files
                SET
                    trashed_at = CURRENT_TIMESTAMP,
                    trashed_by = :trashed_by,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :file_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NULL
            '
        );

    $statement->execute([
        ':trashed_by' =>
            $userId,

        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    if (
        $statement->rowCount() !== 1
    ) {
        throw new RuntimeException(
            'Unable to move the Drive file to Trash.'
        );
    }


    /*
     * --------------------------------------------------------------
     * Record Drive activity
     * --------------------------------------------------------------
     *
     * Keep this metadata-only.
     * Never place decrypted file contents or encryption secrets here.
     */

    $activityStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_file_activity (
                    workspace_id,
                    file_id,
                    actor_user_id,
                    action,
                    details_json
                )
                VALUES (
                    :workspace_id,
                    :file_id,
                    :actor_user_id,
                    :action,
                    :details_json
                )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':file_id' =>
            $fileId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'file_trashed',

        ':details_json' =>
            json_encode(
                [
                    'name' =>
                        (string) $file['original_name'],
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    $pdo->commit();


    echo json_encode([
        'success' => true,

        'file_id' =>
            $fileId,

        'trashed' =>
            true,

        'message' =>
            'File moved to Trash.',
    ]);
} catch (Throwable $error) {
    if (
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive trash failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to move the Drive file to Trash.',
    ]);
}