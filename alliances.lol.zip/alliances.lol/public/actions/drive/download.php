<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}


$userId = (int) $user['id'];
$workspaceId = (int) $access['workspace_id'];

$fileId = filter_input(
    INPUT_GET,
    'file_id',
    FILTER_VALIDATE_INT
);

if (
    $fileId === false ||
    $fileId === null ||
    $fileId <= 0
) {
    http_response_code(400);

    header('Content-Type: application/json; charset=utf-8');

    echo json_encode([
        'success' => false,
        'error' => 'A valid file ID is required.',
    ]);

    exit;
}


try {
    $pdo = db();


    /*
     * Find the file, but only when this user currently has
     * access to it.
     *
     * The workspace check prevents IDs from another workspace
     * being used here.
     */
    $statement = $pdo->prepare(
        '
        SELECT
            f.id,
            f.storage_id,
            f.original_name,
            f.mime_type,
            f.encrypted_size,
            f.encryption_version,
            f.key_version,
            f.sharing_mode,
            f.updated_at,
            a.can_edit
        FROM drive_files AS f
        INNER JOIN drive_effective_access AS a
            ON a.file_id = f.id
        WHERE
            f.id = :file_id
            AND f.workspace_id = :workspace_id
            AND a.user_id = :user_id
        LIMIT 1
        '
    );

    $statement->execute([
        ':file_id' => $fileId,
        ':workspace_id' => $workspaceId,
        ':user_id' => $userId,
    ]);

    $file = $statement->fetch();


    if (!$file) {
        http_response_code(404);

        header('Content-Type: application/json; charset=utf-8');

        echo json_encode([
            'success' => false,
            'error' => 'File not found or you do not have access.',
        ]);

        exit;
    }


    /*
     * Retrieve ONLY this user's wrapped file key for the
     * file's current key version.
     */
    $keyStatement = $pdo->prepare(
        '
        SELECT
            encrypted_key,
            key_version
        FROM drive_file_keys
        WHERE
            file_id = :file_id
            AND user_id = :user_id
            AND key_version = :key_version
        LIMIT 1
        '
    );

    $keyStatement->execute([
        ':file_id' => $fileId,
        ':user_id' => $userId,
        ':key_version' => (int) $file['key_version'],
    ]);

    $keyRecord = $keyStatement->fetch();


    if (!$keyRecord) {
        http_response_code(403);

        header('Content-Type: application/json; charset=utf-8');

        echo json_encode([
            'success' => false,
            'error' => 'No decryption key is available for this file.',
        ]);

        exit;
    }


    $storageId = (string) $file['storage_id'];

    $filePath = drive_file_path(
        $storageId
    );


    /*
     * The physical storage path is never returned to the browser.
     */
    if (
        !is_file($filePath) ||
        !is_readable($filePath)
    ) {
        http_response_code(404);

        header('Content-Type: application/json; charset=utf-8');

        echo json_encode([
            'success' => false,
            'error' => 'The encrypted file data could not be found.',
        ]);

        exit;
    }


    $actualSize = filesize(
        $filePath
    );

    if ($actualSize === false) {
        throw new RuntimeException(
            'Unable to determine encrypted file size.'
        );
    }


    /*
     * Return the wrapped key in headers.
     *
     * The armored PGP message contains line breaks and therefore
     * cannot safely be placed directly into a normal HTTP header.
     * Base64 keeps the header transport-safe.
     *
     * This value is still encrypted to the current user's
     * OpenPGP public key.
     */
    $encryptedKeyBase64 =
        base64_encode(
            (string) $keyRecord['encrypted_key']
        );


    /*
     * Metadata values used by the browser after local decryption.
     *
     * Base64 avoids header encoding problems with filenames.
     */
    $nameBase64 =
        base64_encode(
            (string) $file['original_name']
        );

    $mimeBase64 =
        base64_encode(
            (string) (
                $file['mime_type']
                ?: 'application/octet-stream'
            )
        );


    /*
     * The response body contains encrypted bytes only.
     */
    header(
        'Content-Type: application/octet-stream'
    );

    header(
        'Content-Length: ' . $actualSize
    );

    header(
        'Cache-Control: no-store, private'
    );

    header(
        'Pragma: no-cache'
    );

    header(
        'X-Content-Type-Options: nosniff'
    );

    header(
        'X-Alliances-Drive-Name: '
        . $nameBase64
    );

    header(
        'X-Alliances-Drive-Mime: '
        . $mimeBase64
    );

    header(
        'X-Alliances-Drive-Key-Version: '
        . (int) $keyRecord['key_version']
    );

    header(
        'X-Alliances-Drive-Encryption-Version: '
        . (int) $file['encryption_version']
    );

    header(
        'X-Alliances-Drive-Can-Edit: '
        . ((int) $file['can_edit'] === 1 ? '1' : '0')
    );

    header(
        'X-Alliances-Drive-Key: '
        . $encryptedKeyBase64
    );


    /*
     * Stream the encrypted blob.
     *
     * PHP never decrypts it.
     */
    $handle = fopen(
        $filePath,
        'rb'
    );

    if ($handle === false) {
        throw new RuntimeException(
            'Unable to open encrypted file.'
        );
    }


    while (!feof($handle)) {
        $chunk = fread(
            $handle,
            1024 * 1024
        );

        if ($chunk === false) {
            fclose($handle);

            throw new RuntimeException(
                'Unable to read encrypted file.'
            );
        }

        echo $chunk;

        flush();
    }


    fclose($handle);

    exit;
} catch (Throwable $error) {
    /*
     * Do not expose internal paths, SQL errors or other server
     * details to the browser.
     */
    error_log(
        'Drive download error: '
        . $error->getMessage()
    );


    if (!headers_sent()) {
        http_response_code(500);

        header(
            'Content-Type: application/json; charset=utf-8'
        );

        echo json_encode([
            'success' => false,
            'error' => 'Unable to retrieve the encrypted file.',
        ]);
    }

    exit;
}