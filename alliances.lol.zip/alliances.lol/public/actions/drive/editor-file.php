<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

$user = require_login();

$workspaceAccess =
    workspace_access(
        (int) $user['id']
    );


if ($workspaceAccess === null) {
    http_response_code(403);

    header(
        'Content-Type: application/json; charset=utf-8'
    );

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}


if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    header(
        'Content-Type: application/json; charset=utf-8'
    );

    echo json_encode([
        'success' => false,
        'error' =>
            'Method not allowed.',
    ]);

    exit;
}


$userId =
    (int) $user['id'];

$workspaceId =
    (int) $workspaceAccess['workspace_id'];


$fileId =
    filter_input(
        INPUT_GET,
        'file_id',
        FILTER_VALIDATE_INT
    );


if (
    $fileId === false
    || $fileId === null
    || $fileId <= 0
) {
    http_response_code(400);

    header(
        'Content-Type: application/json; charset=utf-8'
    );

    echo json_encode([
        'success' => false,
        'error' =>
            'A valid file ID is required.',
    ]);

    exit;
}


try {
    $pdo = db();


    /*
     * ----------------------------------------------------------------------
     * Verify file access and retrieve the current user's key envelope
     * ----------------------------------------------------------------------
     *
     * PHP receives and returns only:
     *
     * - encrypted file bytes
     * - plaintext file metadata
     * - the current user's OpenPGP-encrypted AES key
     *
     * The raw AES file key and plaintext document remain browser-side.
     */

    $statement =
        $pdo->prepare(
            '
            SELECT
                f.id,
                f.original_name,
                f.mime_type,
                f.storage_id,
                f.encrypted_size,
                f.encryption_version,
                f.key_version,
                f.updated_at,
                a.can_edit,
                k.encrypted_key

            FROM drive_files AS f

            INNER JOIN drive_effective_access AS a
                ON a.file_id = f.id
                AND a.user_id = :access_user_id

            INNER JOIN drive_file_keys AS k
                ON k.file_id = f.id
                AND k.user_id = :key_user_id
                AND k.key_version = f.key_version

            WHERE
                f.id = :file_id
                AND f.workspace_id = :workspace_id

            LIMIT 1
            '
        );


    $statement->execute([
        ':access_user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    $file =
        $statement->fetch();


    if (!$file) {
        http_response_code(404);

        header(
            'Content-Type: application/json; charset=utf-8'
        );

        echo json_encode([
            'success' => false,
            'error' =>
                'File not found or access is unavailable.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Validate encrypted key envelope
     * ----------------------------------------------------------------------
     */

    $encryptedKey =
        (string) (
            $file['encrypted_key']
            ?? ''
        );


    if (
        $encryptedKey === ''
        || !str_starts_with(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
        || !str_contains(
            $encryptedKey,
            '-----END PGP MESSAGE-----'
        )
    ) {
        throw new RuntimeException(
            'Stored Drive key envelope is invalid.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Locate encrypted blob
     * ----------------------------------------------------------------------
     */

    $storageId =
        (string) (
            $file['storage_id']
            ?? ''
        );


    $filePath =
        drive_file_path(
            $storageId
        );


    if (
        !is_file($filePath)
        || !is_readable($filePath)
    ) {
        throw new RuntimeException(
            'Encrypted Drive blob is missing.'
        );
    }


    $actualSize =
        filesize(
            $filePath
        );


    if ($actualSize === false) {
        throw new RuntimeException(
            'Unable to determine encrypted Drive blob size.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Response metadata
     * ----------------------------------------------------------------------
     *
     * Metadata is Base64 encoded before being placed into headers so
     * filenames, MIME types and armored OpenPGP text cannot break the
     * HTTP header format.
     */

    $originalName =
        (string) (
            $file['original_name']
            ?? 'file'
        );


    $mimeType =
        (string) (
            $file['mime_type']
            ?? 'application/octet-stream'
        );


    header(
        'Content-Type: application/octet-stream'
    );

    header(
        'Content-Length: '
        . (string) $actualSize
    );

    header(
        'Cache-Control: no-store, private'
    );

    header(
        'Pragma: no-cache'
    );

    header(
        'X-Content-Type-Options: nosniff'
    );


    header(
        'X-Alliances-Drive-File-Id: '
        . (string) $fileId
    );


    header(
        'X-Alliances-Drive-Name: '
        . base64_encode(
            $originalName
        )
    );


    header(
        'X-Alliances-Drive-Mime: '
        . base64_encode(
            $mimeType
        )
    );


    header(
        'X-Alliances-Drive-Key: '
        . base64_encode(
            $encryptedKey
        )
    );


    header(
        'X-Alliances-Drive-Key-Version: '
        . (string) (
            (int) $file['key_version']
        )
    );


    header(
        'X-Alliances-Drive-Encryption-Version: '
        . (string) (
            (int) $file['encryption_version']
        )
    );


    header(
        'X-Alliances-Drive-Can-Edit: '
        . (
            (int) $file['can_edit'] === 1
                ? '1'
                : '0'
        )
    );


    /*
     * ----------------------------------------------------------------------
     * Stream encrypted bytes
     * ----------------------------------------------------------------------
     */

    $handle =
        fopen(
            $filePath,
            'rb'
        );


    if ($handle === false) {
        throw new RuntimeException(
            'Unable to open encrypted Drive blob.'
        );
    }


    try {
        while (!feof($handle)) {
            $chunk =
                fread(
                    $handle,
                    1024 * 1024
                );


            if ($chunk === false) {
                throw new RuntimeException(
                    'Unable to read encrypted Drive blob.'
                );
            }


            echo $chunk;


            /*
             * Allow PHP to release the output buffer while
             * streaming larger encrypted files.
             */
            if (
                function_exists(
                    'ob_flush'
                )
            ) {
                @ob_flush();
            }


            flush();
        }
    } finally {
        fclose(
            $handle
        );
    }


    exit;
} catch (Throwable $error) {
    error_log(
        'Drive editor file error: '
        . $error->getMessage()
    );


    /*
     * If headers have already been sent because streaming began,
     * we cannot safely replace the response with JSON.
     */
    if (!headers_sent()) {
        http_response_code(500);

        header(
            'Content-Type: application/json; charset=utf-8'
        );

        echo json_encode([
            'success' => false,
            'error' =>
                'Unable to load the encrypted file for editing.',
        ]);
    }


    exit;
}