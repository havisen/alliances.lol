<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Favorite folders
     * ----------------------------------------------------------------------
     *
     * A folder is shown only when:
     *
     * - it belongs to this workspace
     * - the current user favorited it
     * - it is not directly in Trash
     * - none of its ancestors are in Trash
     *
     * The recursive CTE builds the complete visible folder tree.
     */

    $folderStatement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    path
                ) AS (
                    SELECT
                        id,
                        parent_id,
                        \'/\' || id || \'/\'
                    FROM drive_folders
                    WHERE workspace_id = :workspace_id
                      AND parent_id IS NULL
                      AND trashed_at IS NULL

                    UNION ALL

                    SELECT
                        child.id,
                        child.parent_id,
                        visible_folders.path
                            || child.id
                            || \'/\'
                    FROM drive_folders child

                    INNER JOIN visible_folders
                        ON child.parent_id =
                            visible_folders.id

                    WHERE child.workspace_id =
                            :recursive_workspace_id
                      AND child.trashed_at IS NULL

                      AND instr(
                          visible_folders.path,
                          \'/\' || child.id || \'/\'
                      ) = 0
                )

                SELECT
                    df.id,
                    df.parent_id,
                    df.name,
                    df.created_by,
                    df.created_at,
                    df.updated_at,

                    u.display_name AS owner_name,

                    1 AS is_favorite

                FROM drive_favorites fav

                INNER JOIN drive_folders df
                    ON df.id = fav.folder_id

                INNER JOIN visible_folders vf
                    ON vf.id = df.id

                LEFT JOIN users u
                    ON u.id = df.created_by

                WHERE fav.user_id = :user_id
                  AND df.workspace_id =
                        :folder_workspace_id

                ORDER BY
                    df.updated_at DESC,
                    df.name COLLATE NOCASE ASC
            '
        );

    $folderStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':recursive_workspace_id' =>
            $workspaceId,

        ':user_id' =>
            $userId,

        ':folder_workspace_id' =>
            $workspaceId,
    ]);

    $folders =
        $folderStatement->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * ----------------------------------------------------------------------
     * Favorite files
     * ----------------------------------------------------------------------
     *
     * Files require:
     *
     * - a favorite belonging to this user
     * - workspace membership
     * - an active individual access row
     * - an unexpired share
     * - the current wrapped encryption key
     * - the file itself not being in Trash
     *
     * A file inside a folder is also shown only if the complete folder
     * path remains visible.
     *
     * Root files have folder_id = NULL and therefore do not require a
     * visible_folders match.
     */

    $fileStatement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    path
                ) AS (
                    SELECT
                        id,
                        parent_id,
                        \'/\' || id || \'/\'
                    FROM drive_folders
                    WHERE workspace_id = :workspace_id
                      AND parent_id IS NULL
                      AND trashed_at IS NULL

                    UNION ALL

                    SELECT
                        child.id,
                        child.parent_id,
                        visible_folders.path
                            || child.id
                            || \'/\'
                    FROM drive_folders child

                    INNER JOIN visible_folders
                        ON child.parent_id =
                            visible_folders.id

                    WHERE child.workspace_id =
                            :recursive_workspace_id
                      AND child.trashed_at IS NULL

                      AND instr(
                          visible_folders.path,
                          \'/\' || child.id || \'/\'
                      ) = 0
                )

                SELECT
                    df.id,
                    df.folder_id,

                    df.uploaded_by,

                    df.original_name AS name,
                    df.mime_type,
                    df.encrypted_size,
                    df.encryption_version,
                    df.key_version,
                    df.sharing_mode,
                    df.current_version,

                    df.created_at,
                    df.updated_at,

                    u.display_name AS owner_name,

                    dfa.can_edit,
                    NULL AS expires_at,

                    1 AS is_favorite

                FROM drive_favorites fav

                INNER JOIN drive_files df
                    ON df.id = fav.file_id

                INNER JOIN drive_effective_access dfa
                    ON dfa.file_id = df.id
                   AND dfa.user_id = :access_user_id

                INNER JOIN drive_file_keys dfk
                    ON dfk.file_id = df.id
                   AND dfk.user_id = :key_user_id
                   AND dfk.key_version =
                        df.key_version

                LEFT JOIN users u
                    ON u.id = df.uploaded_by

                LEFT JOIN visible_folders vf
                    ON vf.id = df.folder_id

                WHERE fav.user_id = :favorite_user_id

                  AND df.workspace_id =
                        :file_workspace_id

                  AND df.trashed_at IS NULL

                  AND (
                      df.folder_id IS NULL
                      OR vf.id IS NOT NULL
                  )


                ORDER BY
                    df.updated_at DESC,
                    df.original_name
                        COLLATE NOCASE ASC
            '
        );

    $fileStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':recursive_workspace_id' =>
            $workspaceId,

        ':access_user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':favorite_user_id' =>
            $userId,

        ':file_workspace_id' =>
            $workspaceId,
    ]);

    $files =
        $fileStatement->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * ----------------------------------------------------------------------
     * Normalize values for JSON
     * ----------------------------------------------------------------------
     */

    foreach ($folders as &$folder) {
        $folder['id'] =
            (int) $folder['id'];

        $folder['parent_id'] =
            $folder['parent_id'] !== null
                ? (int) $folder['parent_id']
                : null;

        $folder['created_by'] =
            (int) $folder['created_by'];

        $folder['is_favorite'] =
            true;
    }

    unset($folder);


    foreach ($files as &$file) {
        $file['id'] =
            (int) $file['id'];

        $file['folder_id'] =
            $file['folder_id'] !== null
                ? (int) $file['folder_id']
                : null;

        $file['uploaded_by'] =
            (int) $file['uploaded_by'];

        $file['encrypted_size'] =
            (int) $file['encrypted_size'];

        $file['encryption_version'] =
            (int) $file[
                'encryption_version'
            ];

        $file['key_version'] =
            (int) $file['key_version'];

        $file['current_version'] =
            (int) $file['current_version'];

        $file['can_edit'] =
            (bool) $file['can_edit'];

        $file['is_favorite'] =
            true;
    }

    unset($file);


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' => true,

        'folders' =>
            $folders,

        'files' =>
            $files,

        'counts' => [
            'folders' =>
                count($folders),

            'files' =>
                count($files),

            'total' =>
                count($folders) +
                count($files),
        ],
    ]);
} catch (Throwable $error) {
    error_log(
        'Alliances Drive favorites load failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to load Drive favorites.',
    ]);
}