<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

$user = require_login();

header(
    'Content-Type: application/json; charset=utf-8'
);

header(
    'Cache-Control: no-store, private'
);


if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}


$workspaceAccess =
    workspace_access(
        (int) $user['id']
    );


if ($workspaceAccess === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}


$userId =
    (int) $user['id'];

$workspaceId =
    (int) $workspaceAccess['workspace_id'];


$fileId =
    filter_input(
        INPUT_GET,
        'file_id',
        FILTER_VALIDATE_INT
    );


if (
    $fileId === false
    || $fileId === null
    || $fileId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'A valid file ID is required.',
    ]);

    exit;
}


try {
    $pdo = db();


    /*
     * ----------------------------------------------------------------------
     * Load current user's encrypted file-key envelope
     * ----------------------------------------------------------------------
     *
     * The user must:
     *
     * 1. belong to this workspace,
     * 2. currently have access to the file,
     * 3. have an encrypted key for the file's current key version.
     *
     * The raw AES key is never stored or returned by PHP.
     */

    $statement =
        $pdo->prepare(
            '
            SELECT
                f.id,
                f.key_version,
                k.encrypted_key
            FROM drive_files AS f

            INNER JOIN drive_effective_access AS a
                ON a.file_id = f.id
                AND a.user_id = :access_user_id

            INNER JOIN drive_file_keys AS k
                ON k.file_id = f.id
                AND k.user_id = :key_user_id
                AND k.key_version = f.key_version

            WHERE
                f.id = :file_id
                AND f.workspace_id = :workspace_id

            LIMIT 1
            '
        );


    $statement->execute([
        ':access_user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    $record =
        $statement->fetch();


    if (!$record) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' =>
                'No current encrypted file key is available.',
        ]);

        exit;
    }


    $encryptedKey =
        (string) (
            $record['encrypted_key']
            ?? ''
        );


    /*
     * Basic corruption check.
     */
    if (
        $encryptedKey === ''
        || !str_starts_with(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
        || !str_contains(
            $encryptedKey,
            '-----END PGP MESSAGE-----'
        )
    ) {
        throw new RuntimeException(
            'Stored Drive key envelope is invalid.'
        );
    }


    echo json_encode([
        'success' => true,

        'file_id' =>
            (int) $record['id'],

        'key_version' =>
            (int) $record['key_version'],

        /*
         * This is still encrypted specifically for
         * the current user's OpenPGP identity.
         */
        'encrypted_key' =>
            $encryptedKey,
    ]);

    exit;
} catch (Throwable $error) {
    error_log(
        'Drive key retrieval error: '
        . $error->getMessage()
    );


    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to retrieve the encrypted file key.',
    ]);

    exit;
}