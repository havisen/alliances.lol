<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];
$currentUserId = (int) $user['id'];


/*
 * --------------------------------------------------------------------------
 * Current folder
 * --------------------------------------------------------------------------
 */

$folderIdRaw = $_GET['folder_id'] ?? '';

$folderId = null;

if ($folderIdRaw !== '' && $folderIdRaw !== null) {
    $validatedFolderId = filter_var(
        $folderIdRaw,
        FILTER_VALIDATE_INT,
        [
            'options' => [
                'min_range' => 1,
            ],
        ]
    );

    if ($validatedFolderId === false) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid folder.',
        ]);

        exit;
    }

    $folderId = (int) $validatedFolderId;
}


try {
    $pdo = db();


    /*
     * ----------------------------------------------------------------------
     * Verify current folder
     * ----------------------------------------------------------------------
     */

    $currentFolder = null;

    if ($folderId !== null) {
        $folderStatement = $pdo->prepare(
            '
            SELECT
                id,
                parent_id,
                name,
                created_by,
                created_at,
                updated_at
            FROM drive_folders
WHERE id = :folder_id
  AND workspace_id = :workspace_id
  AND trashed_at IS NULL
LIMIT 1
            '
        );

        $folderStatement->execute([
            ':folder_id' => $folderId,
            ':workspace_id' => $workspaceId,
        ]);

$folderRow = $folderStatement->fetch(PDO::FETCH_ASSOC);

if ($folderRow === false) {
    http_response_code(404);

    echo json_encode([
        'success' => false,
        'error' => 'Folder not found.',
    ]);

    exit;
}


/*
 * ------------------------------------------------------------------
 * Make sure no ancestor folder is in Trash
 * ------------------------------------------------------------------
 *
 * A child folder does not receive its own trashed_at value when a
 * parent folder is moved to Trash.
 *
 * Therefore we must walk upward through the hierarchy and reject
 * access if any ancestor has been trashed.
 */

$ancestorId =
    $folderRow['parent_id'] !== null
        ? (int) $folderRow['parent_id']
        : null;

$visitedFolderIds = [
    (int) $folderRow['id'] => true,
];

while ($ancestorId !== null) {
    /*
     * Protect against an invalid/cyclic folder hierarchy.
     */

    if (
        isset(
            $visitedFolderIds[
                $ancestorId
            ]
        )
    ) {
        throw new RuntimeException(
            'Invalid Drive folder hierarchy.'
        );
    }

    $visitedFolderIds[
        $ancestorId
    ] = true;


    $ancestorStatement =
        $pdo->prepare(
            '
                SELECT
                    parent_id,
                    trashed_at
                FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $ancestorStatement->execute([
        ':folder_id' =>
            $ancestorId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $ancestorRow =
        $ancestorStatement->fetch(
            PDO::FETCH_ASSOC
        );


    /*
     * A broken hierarchy is not considered safe to expose.
     */

    if ($ancestorRow === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Folder not found.',
        ]);

        exit;
    }


    /*
     * Any trashed ancestor makes the entire subtree part of Trash.
     */

    if (
        $ancestorRow['trashed_at'] !== null &&
        trim(
            (string) $ancestorRow['trashed_at']
        ) !== ''
    ) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Folder not found.',
        ]);

        exit;
    }


    $ancestorId =
        $ancestorRow['parent_id'] !== null
            ? (int) $ancestorRow['parent_id']
            : null;
}


$currentFolder = [
            'id' => (int) $folderRow['id'],

            'parent_id' => $folderRow['parent_id'] !== null
                ? (int) $folderRow['parent_id']
                : null,

            'name' => (string) $folderRow['name'],

            'created_by' => (int) $folderRow['created_by'],

            'created_at' => (string) $folderRow['created_at'],

            'updated_at' => (string) $folderRow['updated_at'],
        ];
    }


    /*
     * ----------------------------------------------------------------------
     * Load child folders
     * ----------------------------------------------------------------------
     */

    if ($folderId === null) {
        $folderStatement = $pdo->prepare(
            '
            SELECT
                df.id,
                df.parent_id,
                df.name,
                df.created_by,
df.created_at,
df.updated_at,
u.display_name AS owner_name,

CASE
    WHEN fav.user_id IS NULL
        THEN 0
    ELSE 1
END AS is_favorite

FROM drive_folders df

INNER JOIN users u
    ON u.id = df.created_by

LEFT JOIN drive_favorites fav
    ON fav.folder_id = df.id
   AND fav.user_id = :favorite_user_id

WHERE df.workspace_id = :workspace_id
  AND df.parent_id IS NULL
  AND df.trashed_at IS NULL

ORDER BY
                df.name COLLATE NOCASE ASC,
                df.id ASC
            '
        );

$folderStatement->execute([
    ':workspace_id' =>
        $workspaceId,

    ':favorite_user_id' =>
        $currentUserId,
]);
    } else {
        $folderStatement = $pdo->prepare(
            '
            SELECT
                df.id,
                df.parent_id,
                df.name,
                df.created_by,
df.created_at,
df.updated_at,
u.display_name AS owner_name,

CASE
    WHEN fav.user_id IS NULL
        THEN 0
    ELSE 1
END AS is_favorite

FROM drive_folders df

INNER JOIN users u
    ON u.id = df.created_by

LEFT JOIN drive_favorites fav
    ON fav.folder_id = df.id
   AND fav.user_id = :favorite_user_id

WHERE df.workspace_id = :workspace_id
  AND df.parent_id = :parent_id
  AND df.trashed_at IS NULL

ORDER BY
                df.name COLLATE NOCASE ASC,
                df.id ASC
            '
        );

$folderStatement->execute([
    ':workspace_id' =>
        $workspaceId,

    ':parent_id' =>
        $folderId,

    ':favorite_user_id' =>
        $currentUserId,
]);
    }


    $folders = [];

    while ($row = $folderStatement->fetch(PDO::FETCH_ASSOC)) {
        $folders[] = [
            'id' => (int) $row['id'],

            'parent_id' => $row['parent_id'] !== null
                ? (int) $row['parent_id']
                : null,

            'name' => (string) $row['name'],

            'created_by' => (int) $row['created_by'],

'owner_name' =>
    (string) $row['owner_name'],

'is_favorite' =>
    (int) $row['is_favorite'] === 1,

'created_at' =>
    (string) $row['created_at'],

            'updated_at' => (string) $row['updated_at'],
        ];
    }


    /*
     * ----------------------------------------------------------------------
     * Load files the current user is allowed to access
     * ----------------------------------------------------------------------
     */

    if ($folderId === null) {
        $fileStatement = $pdo->prepare(
            '
            SELECT
                df.id,
                df.folder_id,
                df.uploaded_by,
                df.original_name,
                df.mime_type,
                df.encrypted_size,
                df.encryption_version,
                df.key_version,
                df.sharing_mode,
                df.created_at,
                df.updated_at,

u.display_name AS owner_name,

dfa.can_edit,

CASE
    WHEN fav.user_id IS NULL
        THEN 0
    ELSE 1
END AS is_favorite

FROM drive_files df

            INNER JOIN drive_effective_access dfa
                ON dfa.file_id = df.id
               AND dfa.user_id = :user_id

            INNER JOIN users u
                ON u.id = df.uploaded_by

INNER JOIN drive_file_keys dfk
    ON dfk.file_id = df.id
   AND dfk.user_id = :key_user_id
   AND dfk.key_version = df.key_version

LEFT JOIN drive_favorites fav
    ON fav.file_id = df.id
   AND fav.user_id = :favorite_user_id

WHERE df.workspace_id = :workspace_id
  AND df.folder_id IS NULL
  AND df.trashed_at IS NULL

ORDER BY
                df.original_name COLLATE NOCASE ASC,
                df.id ASC
            '
        );

$fileStatement->execute([
    ':user_id' =>
        $currentUserId,

    ':key_user_id' =>
        $currentUserId,

    ':favorite_user_id' =>
        $currentUserId,

    ':workspace_id' =>
        $workspaceId,
]);
    } else {
        $fileStatement = $pdo->prepare(
            '
            SELECT
                df.id,
                df.folder_id,
                df.uploaded_by,
                df.original_name,
                df.mime_type,
                df.encrypted_size,
                df.encryption_version,
                df.key_version,
                df.sharing_mode,
                df.created_at,
                df.updated_at,

u.display_name AS owner_name,

dfa.can_edit,

CASE
    WHEN fav.user_id IS NULL
        THEN 0
    ELSE 1
END AS is_favorite

FROM drive_files df

            INNER JOIN drive_effective_access dfa
                ON dfa.file_id = df.id
               AND dfa.user_id = :user_id

            INNER JOIN users u
                ON u.id = df.uploaded_by

INNER JOIN drive_file_keys dfk
    ON dfk.file_id = df.id
   AND dfk.user_id = :key_user_id
   AND dfk.key_version = df.key_version

LEFT JOIN drive_favorites fav
    ON fav.file_id = df.id
   AND fav.user_id = :favorite_user_id

WHERE df.workspace_id = :workspace_id
  AND df.folder_id = :folder_id
  AND df.trashed_at IS NULL

ORDER BY
                df.original_name COLLATE NOCASE ASC,
                df.id ASC
            '
        );

$fileStatement->execute([
    ':user_id' =>
        $currentUserId,

    ':key_user_id' =>
        $currentUserId,

    ':favorite_user_id' =>
        $currentUserId,

    ':workspace_id' =>
        $workspaceId,

    ':folder_id' =>
        $folderId,
]);
    }


    $files = [];

    while ($row = $fileStatement->fetch(PDO::FETCH_ASSOC)) {
        $files[] = [
            'id' => (int) $row['id'],

            'folder_id' => $row['folder_id'] !== null
                ? (int) $row['folder_id']
                : null,

            'uploaded_by' => (int) $row['uploaded_by'],

            'owner_name' => (string) $row['owner_name'],

            'name' => (string) $row['original_name'],

            'mime_type' => $row['mime_type'] !== null
                ? (string) $row['mime_type']
                : null,

            'encrypted_size' => (int) $row['encrypted_size'],

            'encryption_version' =>
                (int) $row['encryption_version'],

            'key_version' =>
                (int) $row['key_version'],

            'sharing_mode' =>
                (string) $row['sharing_mode'],

            'can_edit' =>
                (int) $row['can_edit'] === 1,

            'is_favorite' =>
                (int) $row['is_favorite'] === 1,

            'is_owner' =>
                (int) $row['uploaded_by'] === $currentUserId,

            'created_at' =>
                (string) $row['created_at'],

            'updated_at' =>
                (string) $row['updated_at'],
        ];
    }


    /*
     * ----------------------------------------------------------------------
     * Return Drive contents
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' => true,
        'current_folder' => $currentFolder,
        'folders' => $folders,
        'files' => $files,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive list error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to load Drive contents.',
        'debug' => $exception->getMessage(),
        'file' => $exception->getFile(),
        'line' => $exception->getLine(),
    ]);
}