<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header(
    'Content-Type: application/json; charset=utf-8'
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$user = require_login();

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$fileId =
    filter_input(
        INPUT_POST,
        'file_id',
        FILTER_VALIDATE_INT,
        [
            'options' => [
                'min_range' => 1,
            ],
        ]
    );

if ($fileId === false || $fileId === null) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive file.',
    ]);

    exit;
}

$fileId = (int) $fileId;

try {
    $pdo = db();


    /*
     * ----------------------------------------------------------------------
     * Verify that the user can still access the file
     * ----------------------------------------------------------------------
     *
     * A stale Recent request must never create a way around Drive access
     * control.
     *
     * The user must still have:
     *
     * - access to this workspace
     * - active file access
     * - an unexpired share
     * - the current wrapped file key
     * - a file that is not in Trash
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    df.id,
                    df.folder_id

                FROM drive_files df

                INNER JOIN drive_effective_access dfa
                    ON dfa.file_id = df.id
                   AND dfa.user_id = :access_user_id

                INNER JOIN drive_file_keys dfk
                    ON dfk.file_id = df.id
                   AND dfk.user_id = :key_user_id
                   AND dfk.key_version = df.key_version

                WHERE df.id = :file_id
                  AND df.workspace_id = :workspace_id
                  AND df.trashed_at IS NULL

                  AND (
                      dfa.expires_at IS NULL
                      OR datetime(
                          dfa.expires_at
                      ) > CURRENT_TIMESTAMP
                  )

                LIMIT 1
            '
        );

    $statement->execute([
        ':access_user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $file =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );

    if ($file === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' =>
                'Drive file not found.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Verify the complete parent-folder chain
     * ----------------------------------------------------------------------
     *
     * Moving a parent folder to Trash intentionally does not set trashed_at
     * on every descendant. We therefore have to walk upward.
     */

    $folderId =
        $file['folder_id'] !== null
            ? (int) $file['folder_id']
            : null;

    $visitedFolderIds = [];

    while ($folderId !== null) {
        if (
            isset(
                $visitedFolderIds[
                    $folderId
                ]
            )
        ) {
            throw new RuntimeException(
                'Invalid Drive folder hierarchy.'
            );
        }

        $visitedFolderIds[
            $folderId
        ] = true;


        $folderStatement =
            $pdo->prepare(
                '
                    SELECT
                        parent_id,
                        trashed_at

                    FROM drive_folders

                    WHERE id = :folder_id
                      AND workspace_id =
                            :workspace_id

                    LIMIT 1
                '
            );

        $folderStatement->execute([
            ':folder_id' =>
                $folderId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $folder =
            $folderStatement->fetch(
                PDO::FETCH_ASSOC
            );

        /*
         * Broken or trashed folder chains are not considered visible.
         */

        if (
            $folder === false ||
            (
                $folder['trashed_at'] !== null &&
                trim(
                    (string) $folder[
                        'trashed_at'
                    ]
                ) !== ''
            )
        ) {
            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Drive file not found.',
            ]);

            exit;
        }


        $folderId =
            $folder['parent_id'] !== null
                ? (int) $folder[
                    'parent_id'
                ]
                : null;
    }


    /*
     * ----------------------------------------------------------------------
     * Record the open
     * ----------------------------------------------------------------------
     *
     * Each user gets one row per file. Opening the same file again only
     * advances last_opened_at.
     */

    $recentStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_recent_files (
                    user_id,
                    file_id,
                    last_opened_at
                )
                VALUES (
                    :user_id,
                    :file_id,
                    CURRENT_TIMESTAMP
                )

                ON CONFLICT (
                    user_id,
                    file_id
                )
                DO UPDATE SET
                    last_opened_at =
                        CURRENT_TIMESTAMP
            '
        );

    $recentStatement->execute([
        ':user_id' =>
            $userId,

        ':file_id' =>
            $fileId,
    ]);


    echo json_encode([
        'success' => true,
        'file_id' => $fileId,
    ]);
} catch (Throwable $error) {
    error_log(
        'Alliances Drive mark recent failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to update recent Drive files.',
    ]);
}