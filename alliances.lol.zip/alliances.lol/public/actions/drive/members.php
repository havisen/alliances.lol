<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];

try {
    $pdo = db();

    $statement = $pdo->prepare(
        '
        SELECT
            u.id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path
        FROM workspace_members wm
        INNER JOIN users u
            ON u.id = wm.user_id
        WHERE wm.workspace_id = :workspace_id
        ORDER BY
            u.display_name COLLATE NOCASE ASC,
            u.id ASC
        '
    );

    $statement->execute([
        ':workspace_id' => $workspaceId,
    ]);

    $members = [];

    while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
        $members[] = [
            'id' => (int) $row['id'],
            'name' => (string) $row['display_name'],
            'email' => (string) $row['email'],
            'job_title' => $row['job_title'] !== null
                ? (string) $row['job_title']
                : null,
            'avatar_path' => $row['avatar_path'] !== null
                ? (string) $row['avatar_path']
                : null,
            'is_current_user' =>
                (int) $row['id'] === (int) $user['id'],
        ];
    }

    echo json_encode([
        'success' => true,
        'members' => $members,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive members error: ' . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to load workspace members.',
    ]);
}