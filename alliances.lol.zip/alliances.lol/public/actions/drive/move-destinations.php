<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');


function drive_move_destinations_error(
    string $message,
    int $status = 400
): never {
    http_response_code($status);

    echo json_encode([
        'success' => false,
        'error' => $message,
    ]);

    exit;
}


try {
    /*
     * ----------------------------------------------------------------------
     * Request
     * ----------------------------------------------------------------------
     */

    if (
        $_SERVER['REQUEST_METHOD'] !==
        'GET'
    ) {
        drive_move_destinations_error(
            'Method not allowed.',
            405
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Authentication
     * ----------------------------------------------------------------------
     */

    $user =
        require_login();

    $userId =
        (int) $user['id'];

    $access =
        workspace_access(
            $userId
        );


    if ($access === null) {
        drive_move_destinations_error(
            'You do not have access to a workspace.',
            403
        );
    }


    $workspaceId =
        (int) $access[
            'workspace_id'
        ];


    /*
     * ----------------------------------------------------------------------
     * Optional item being moved
     * ----------------------------------------------------------------------
     *
     * For folders we use this information to remove the folder itself
     * and all of its descendants from the destination list.
     */

    $type =
        strtolower(
            trim(
                (string) (
                    $_GET['type'] ??
                    ''
                )
            )
        );


    $itemId =
        filter_var(
            $_GET['item_id'] ??
                null,

            FILTER_VALIDATE_INT
        );


    if (
        $type !== '' &&
        $type !== 'file' &&
        $type !== 'folder'
    ) {
        drive_move_destinations_error(
            'Invalid Drive item type.'
        );
    }


    if (
        $type !== '' &&
        (
            $itemId === false ||
            $itemId === null ||
            $itemId < 1
        )
    ) {
        drive_move_destinations_error(
            'Invalid Drive item.'
        );
    }


    $pdo =
        db();


    /*
     * ----------------------------------------------------------------------
     * Load the visible folder hierarchy
     * ----------------------------------------------------------------------
     *
     * Starting only from non-trashed root folders means descendants of a
     * trashed folder never appear as possible destinations.
     *
     * The path_ids string gives us a simple cycle guard in case corrupted
     * folder metadata ever contains a loop.
     */

    $statement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    name,
                    created_by,
                    depth,
                    path_ids,
                    path_names
                ) AS (
                    SELECT
                        df.id,
                        df.parent_id,
                        df.name,
                        df.created_by,
                        0 AS depth,
                        printf(
                            ",%d,",
                            df.id
                        ) AS path_ids,
                        df.name AS path_names
                    FROM drive_folders df
                    WHERE df.workspace_id = :workspace_id
                      AND df.parent_id IS NULL
                      AND df.trashed_at IS NULL

                    UNION ALL

                    SELECT
                        child.id,
                        child.parent_id,
                        child.name,
                        child.created_by,
                        parent.depth + 1,
                        parent.path_ids ||
                            child.id ||
                            ",",
                        parent.path_names ||
                            " / " ||
                            child.name
                    FROM drive_folders child
                    INNER JOIN visible_folders parent
                        ON parent.id =
                            child.parent_id
                    WHERE child.workspace_id =
                            :workspace_id
                      AND child.trashed_at IS NULL
                      AND instr(
                            parent.path_ids,
                            printf(
                                ",%d,",
                                child.id
                            )
                          ) = 0
                )

                SELECT
                    id,
                    parent_id,
                    name,
                    created_by,
                    depth,
                    path_ids,
                    path_names
                FROM visible_folders
                ORDER BY
                    path_names COLLATE NOCASE ASC,
                    id ASC
            '
        );


    $statement->execute([
        ':workspace_id' =>
            $workspaceId,
    ]);


    $rows =
        $statement->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * ----------------------------------------------------------------------
     * Exclude illegal destinations
     * ----------------------------------------------------------------------
     */

    $folders = [];


    foreach ($rows as $row) {
        $folderId =
            (int) $row['id'];


        /*
         * A folder cannot be moved into itself.
         */
        if (
            $type === 'folder' &&
            $folderId ===
                (int) $itemId
        ) {
            continue;
        }


        /*
         * Nor can a folder be moved into one of its descendants.
         *
         * path_ids looks like:
         *
         *     ,4,9,17,
         *
         * so checking for ",4," does not accidentally match folder 14.
         */
        if (
            $type === 'folder' &&
            str_contains(
                (string) $row[
                    'path_ids'
                ],
                ',' .
                (int) $itemId .
                ','
            )
        ) {
            continue;
        }


        $folders[] = [
            'id' =>
                $folderId,

            'parent_id' =>
                $row['parent_id'] ===
                null
                    ? null
                    : (int) $row[
                        'parent_id'
                    ],

            'name' =>
                (string) $row[
                    'name'
                ],

            'path' =>
                (string) $row[
                    'path_names'
                ],

            'depth' =>
                (int) $row[
                    'depth'
                ],

            'is_owner' =>
                (int) $row[
                    'created_by'
                ] === $userId,
        ];
    }


    /*
     * The Drive root is handled by the frontend as a special destination
     * with a null folder_id.
     */

    echo json_encode([
        'success' => true,

        'root' => [
            'id' => null,
            'name' => 'My Drive',
            'path' => 'My Drive',
        ],

        'folders' =>
            $folders,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive move destinations failed: ' .
        $exception->getMessage()
    );


    if (!headers_sent()) {
        http_response_code(500);
    }


    echo json_encode([
        'success' => false,

        'error' =>
            'Unable to load Drive folders.',
    ]);
}