<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');


function drive_move_error(
    string $message,
    int $status = 400
): never {
    http_response_code($status);

    echo json_encode([
        'success' => false,
        'error' => $message,
    ]);

    exit;
}


/*
 * Verify that a destination folder exists, belongs to
 * this workspace and is not inside Trash.
 */
function drive_move_destination_is_visible(
    PDO $pdo,
    int $workspaceId,
    ?int $folderId
): bool {
    if ($folderId === null) {
        return true;
    }

    $visited = [];

    while ($folderId !== null) {
        if (isset($visited[$folderId])) {
            return false;
        }

        $visited[$folderId] = true;

        $statement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        parent_id,
                        trashed_at
                    FROM drive_folders
                    WHERE id = :folder_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );

        $statement->execute([
            ':folder_id' => $folderId,
            ':workspace_id' => $workspaceId,
        ]);

        $folder =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$folder) {
            return false;
        }

        if ($folder['trashed_at'] !== null) {
            return false;
        }

        $folderId =
            $folder['parent_id'] === null
                ? null
                : (int) $folder['parent_id'];
    }

    return true;
}


/*
 * Check whether $possibleDescendantId is the folder itself
 * or exists anywhere below it.
 */
function drive_move_would_create_cycle(
    PDO $pdo,
    int $workspaceId,
    int $folderId,
    int $possibleDescendantId
): bool {
    if (
        $folderId ===
        $possibleDescendantId
    ) {
        return true;
    }

    $currentId =
        $possibleDescendantId;

    $visited = [];

    while ($currentId !== null) {
        if (isset($visited[$currentId])) {
            return true;
        }

        $visited[$currentId] = true;

        if ($currentId === $folderId) {
            return true;
        }

        $statement =
            $pdo->prepare(
                '
                    SELECT
                        parent_id
                    FROM drive_folders
                    WHERE id = :folder_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );

        $statement->execute([
            ':folder_id' => $currentId,
            ':workspace_id' => $workspaceId,
        ]);

        $row =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$row) {
            return false;
        }

        $currentId =
            $row['parent_id'] === null
                ? null
                : (int) $row['parent_id'];
    }

    return false;
}


try {
    if (
        $_SERVER['REQUEST_METHOD'] !==
        'POST'
    ) {
        drive_move_error(
            'Method not allowed.',
            405
        );
    }


    $user =
        require_login();

    $userId =
        (int) $user['id'];

    $access =
        workspace_access(
            $userId
        );

    if ($access === null) {
        drive_move_error(
            'You do not have access to a workspace.',
            403
        );
    }

    require_valid_csrf();


    $workspaceId =
        (int) $access['workspace_id'];

    $isAdmin =
        (bool) $access['is_admin'];


    $type =
        strtolower(
            trim(
                (string) (
                    $_POST['type'] ??
                    ''
                )
            )
        );

    $itemId =
        filter_var(
            $_POST['item_id'] ?? null,
            FILTER_VALIDATE_INT
        );


    /*
     * An empty destination means the Drive root.
     */
    $destinationRaw =
        trim(
            (string) (
                $_POST['folder_id'] ??
                ''
            )
        );

    $destinationFolderId =
        null;

    if ($destinationRaw !== '') {
        $validatedDestination =
            filter_var(
                $destinationRaw,
                FILTER_VALIDATE_INT
            );

        if (
            $validatedDestination === false ||
            $validatedDestination < 1
        ) {
            drive_move_error(
                'Invalid destination folder.'
            );
        }

        $destinationFolderId =
            (int) $validatedDestination;
    }


    if (
        $type !== 'file' &&
        $type !== 'folder'
    ) {
        drive_move_error(
            'Invalid Drive item type.'
        );
    }


    if (
        $itemId === false ||
        $itemId === null ||
        $itemId < 1
    ) {
        drive_move_error(
            'Invalid Drive item.'
        );
    }


    $pdo =
        db();


    /*
     * Validate the complete destination hierarchy.
     */
    if (
        !drive_move_destination_is_visible(
            $pdo,
            $workspaceId,
            $destinationFolderId
        )
    ) {
        drive_move_error(
            'The destination folder is unavailable.'
        );
    }


    /*
     * ==============================================================
     * Move file
     * ==============================================================
     */

    if ($type === 'file') {
        $statement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        folder_id,
                        uploaded_by,
                        trashed_at
                    FROM drive_files
                    WHERE id = :file_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );

        $statement->execute([
            ':file_id' =>
                (int) $itemId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $file =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$file) {
            drive_move_error(
                'File not found.',
                404
            );
        }


        if (
            !$isAdmin &&
            (int) $file['uploaded_by'] !==
                $userId
        ) {
            drive_move_error(
                'You do not have permission to move this file.',
                403
            );
        }


        if (
            $file['trashed_at'] !== null
        ) {
            drive_move_error(
                'Restore this file before moving it.'
            );
        }


        $currentFolderId =
            $file['folder_id'] === null
                ? null
                : (int) $file['folder_id'];


        if (
            $currentFolderId ===
            $destinationFolderId
        ) {
            echo json_encode([
                'success' => true,
                'type' => 'file',
                'item_id' => (int) $itemId,
                'folder_id' =>
                    $destinationFolderId,
                'unchanged' => true,
            ]);

            exit;
        }


        $update =
            $pdo->prepare(
                '
                    UPDATE drive_files
                    SET
                        folder_id = :folder_id,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = :file_id
                      AND workspace_id = :workspace_id
                      AND trashed_at IS NULL
                '
            );

        $update->bindValue(
            ':folder_id',
            $destinationFolderId,
            $destinationFolderId === null
                ? PDO::PARAM_NULL
                : PDO::PARAM_INT
        );

        $update->bindValue(
            ':file_id',
            (int) $itemId,
            PDO::PARAM_INT
        );

        $update->bindValue(
            ':workspace_id',
            $workspaceId,
            PDO::PARAM_INT
        );

        $update->execute();


        if ($update->rowCount() !== 1) {
            drive_move_error(
                'The file could not be moved.',
                409
            );
        }

        $activityStatement =
            $pdo->prepare(
                '
                    INSERT INTO drive_file_activity (
                        workspace_id,
                        file_id,
                        actor_user_id,
                        action,
                        details_json
                    )
                    VALUES (
                        :workspace_id,
                        :file_id,
                        :actor_user_id,
                        :action,
                        :details_json
                    )
                '
            );

        $activityStatement->execute([
            ':workspace_id' =>
                $workspaceId,

            ':file_id' =>
                (int) $itemId,

            ':actor_user_id' =>
                $userId,

            ':action' =>
                'file_moved',

            ':details_json' =>
                json_encode(
                    [
                        'from_folder_id' =>
                            $currentFolderId,

                        'to_folder_id' =>
                            $destinationFolderId,
                    ],
                    JSON_UNESCAPED_SLASHES |
                    JSON_UNESCAPED_UNICODE
                ),
        ]);


        echo json_encode([
            'success' => true,
            'type' => 'file',
            'item_id' => (int) $itemId,
            'folder_id' =>
                $destinationFolderId,
            'unchanged' => false,
        ]);

        exit;
    }


    /*
     * ==============================================================
     * Move folder
     * ==============================================================
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    parent_id,
                    created_by,
                    trashed_at
                FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':folder_id' =>
            (int) $itemId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $folder =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$folder) {
        drive_move_error(
            'Folder not found.',
            404
        );
    }


    if (
        !$isAdmin &&
        (int) $folder['created_by'] !==
            $userId
    ) {
        drive_move_error(
            'You do not have permission to move this folder.',
            403
        );
    }


    if (
        $folder['trashed_at'] !== null
    ) {
        drive_move_error(
            'Restore this folder before moving it.'
        );
    }


    if (
        $destinationFolderId !== null &&
        drive_move_would_create_cycle(
            $pdo,
            $workspaceId,
            (int) $itemId,
            $destinationFolderId
        )
    ) {
        drive_move_error(
            'A folder cannot be moved into itself or one of its subfolders.'
        );
    }


    $currentParentId =
        $folder['parent_id'] === null
            ? null
            : (int) $folder['parent_id'];


    if (
        $currentParentId ===
        $destinationFolderId
    ) {
        echo json_encode([
            'success' => true,
            'type' => 'folder',
            'item_id' => (int) $itemId,
            'folder_id' =>
                $destinationFolderId,
            'unchanged' => true,
        ]);

        exit;
    }


    $update =
        $pdo->prepare(
            '
                UPDATE drive_folders
                SET
                    parent_id = :parent_id,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NULL
            '
        );

    $update->bindValue(
        ':parent_id',
        $destinationFolderId,
        $destinationFolderId === null
            ? PDO::PARAM_NULL
            : PDO::PARAM_INT
    );

    $update->bindValue(
        ':folder_id',
        (int) $itemId,
        PDO::PARAM_INT
    );

    $update->bindValue(
        ':workspace_id',
        $workspaceId,
        PDO::PARAM_INT
    );

    $update->execute();


    if ($update->rowCount() !== 1) {
        drive_move_error(
            'The folder could not be moved.',
            409
        );
    }


    echo json_encode([
        'success' => true,
        'type' => 'folder',
        'item_id' => (int) $itemId,
        'folder_id' =>
            $destinationFolderId,
        'unchanged' => false,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive move failed: ' .
        $exception->getMessage()
    );

    if (!headers_sent()) {
        http_response_code(500);
    }

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to move the Drive item.',
    ]);
}
