<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$folderId =
    filter_input(
        INPUT_POST,
        'folder_id',
        FILTER_VALIDATE_INT
    );

if (
    !$folderId ||
    $folderId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive folder.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Load root folder
     * ----------------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    workspace_id,
                    parent_id,
                    created_by,
                    name,
                    trashed_at
                FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':folder_id' =>
            $folderId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $folder =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );

    if ($folder === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Drive folder not found.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Must be directly in Trash
     * ----------------------------------------------------------------------
     *
     * A descendant underneath a trashed folder is not itself marked with
     * trashed_at. Permanent deletion therefore starts only from an explicitly
     * trashed root.
     */

    if (
        $folder['trashed_at'] === null ||
        trim(
            (string) $folder['trashed_at']
        ) === ''
    ) {
        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' =>
                'Move this folder to Trash before permanently deleting it.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Authorization
     * ----------------------------------------------------------------------
     */

    $isCreator =
        (int) $folder['created_by'] ===
        $userId;

    $isAdmin =
        !empty(
            $access['is_admin']
        );

    if (
        !$isCreator &&
        !$isAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to permanently delete this folder.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Collect complete folder tree
     * ----------------------------------------------------------------------
     *
     * SQLite recursive CTE gives us:
     *
     * selected folder
     *     ↓
     * children
     *     ↓
     * grandchildren
     *     ↓
     * etc.
     *
     * The workspace condition is repeated in the recursive step so a broken
     * hierarchy can never cross workspace boundaries.
     */

$treeStatement =
    $pdo->prepare(
        '
            WITH RECURSIVE folder_tree (
                id,
                parent_id,
                created_by,
                depth,
                path
            ) AS (
                SELECT
                    id,
                    parent_id,
                    created_by,
                    0,
                    \'/\' || id || \'/\'
                FROM drive_folders
                WHERE id = :root_folder_id
                  AND workspace_id = :workspace_id

                UNION ALL

                SELECT
                    child.id,
                    child.parent_id,
                    child.created_by,
                    folder_tree.depth + 1,
                    folder_tree.path || child.id || \'/\'
                FROM drive_folders child

                INNER JOIN folder_tree
                    ON child.parent_id = folder_tree.id

                WHERE child.workspace_id = :recursive_workspace_id

                  /*
                   * Prevent a corrupt cyclic hierarchy from
                   * revisiting a folder already in this path.
                   */
                  AND instr(
                      folder_tree.path,
                      \'/\' || child.id || \'/\'
                  ) = 0
            )

            SELECT
                id,
                parent_id,
                created_by,
                depth
            FROM folder_tree
            ORDER BY
                depth DESC,
                id DESC
        '
    );

$treeStatement->execute([
    ':root_folder_id' =>
        $folderId,

    ':workspace_id' =>
        $workspaceId,

    ':recursive_workspace_id' =>
        $workspaceId,
]);

$folderRows =
    $treeStatement->fetchAll(
        PDO::FETCH_ASSOC
    );


    /*
     * ----------------------------------------------------------------------
     * Folder IDs
     * ----------------------------------------------------------------------
     */

$folderIds = [];

$seenFolderIds = [];


/*
 * ----------------------------------------------------------------------
 * Protect folders created by other users
 * ----------------------------------------------------------------------
 *
 * A normal user may permanently delete the complete folder tree only
 * when every folder in that tree was created by that same user.
 *
 * Workspace administrators may permanently delete the complete tree.
 */

if (!$isAdmin) {
    foreach ($folderRows as $folderRow) {
        $folderCreatorId =
            (int) (
                $folderRow['created_by'] ??
                0
            );

        if (
            $folderCreatorId <= 0 ||
            $folderCreatorId !== $userId
        ) {
            http_response_code(403);

            echo json_encode([
                'success' => false,

                'error' =>
                    'This folder contains one or more folders created by another user. Only a workspace administrator can permanently delete the complete folder tree.',
            ]);

            exit;
        }
    }
}


foreach ($folderRows as $folderRow) {
    $currentFolderId =
        (int) $folderRow['id'];

    if ($currentFolderId <= 0) {
        throw new RuntimeException(
            'Invalid folder in Drive folder tree.'
        );
    }

    if (
        isset(
            $seenFolderIds[
                $currentFolderId
            ]
        )
    ) {
        throw new RuntimeException(
            'Duplicate folder detected in Drive folder tree.'
        );
    }

    $seenFolderIds[
        $currentFolderId
    ] = true;

    $folderIds[] =
        $currentFolderId;
}


    /*
     * ----------------------------------------------------------------------
     * Build safe SQL placeholders
     * ----------------------------------------------------------------------
     *
     * IDs come from our own database and are converted to integers.
     */

    $folderPlaceholders =
        implode(
            ', ',
            array_fill(
                0,
                count($folderIds),
                '?'
            )
        );


    /*
     * ----------------------------------------------------------------------
     * Collect every file inside the tree
     * ----------------------------------------------------------------------
     */

    $fileStatement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    uploaded_by,
                    storage_id,
                    original_name
                FROM drive_files
                WHERE workspace_id = ?
                  AND folder_id IN (' . $folderPlaceholders . ')
            '
        );

    $fileStatement->execute(
        array_merge(
            [$workspaceId],
            $folderIds
        )
    );

    $files =
        $fileStatement->fetchAll(
            PDO::FETCH_ASSOC
        );

        /*
 * ----------------------------------------------------------------------
 * Protect files owned by other users
 * ----------------------------------------------------------------------
 *
 * Workspace administrators may permanently delete the complete
 * trashed folder tree.
 *
 * A normal folder creator may permanently delete the tree only when
 * every file inside that tree was uploaded by that same user.
 *
 * This validation happens before the transaction and before any
 * database row or encrypted blob is deleted.
 */

if (!$isAdmin) {
    foreach ($files as $file) {
        $fileOwnerId =
            (int) (
                $file['uploaded_by'] ??
                0
            );

        if (
            $fileOwnerId <= 0 ||
            $fileOwnerId !== $userId
        ) {
            http_response_code(403);

            echo json_encode([
                'success' => false,

                'error' =>
                    'This folder contains one or more files owned by another user. Only a workspace administrator can permanently delete the complete folder tree.',
            ]);

            exit;
        }
    }
}

    /*
     * ----------------------------------------------------------------------
     * Collect file IDs and encrypted storage IDs
     * ----------------------------------------------------------------------
     */

    $fileIds = [];

    $storageIds = [];

    foreach ($files as $file) {
        $currentFileId =
            (int) $file['id'];

        if ($currentFileId <= 0) {
            continue;
        }

        $fileIds[] =
            $currentFileId;

        $storageId =
            trim(
                (string) (
                    $file['storage_id'] ??
                    ''
                )
            );

        if ($storageId !== '') {
            $storageIds[
                $storageId
            ] = true;
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Historical encrypted version blobs
     * ----------------------------------------------------------------------
     */

    if ($fileIds) {
        $filePlaceholders =
            implode(
                ', ',
                array_fill(
                    0,
                    count($fileIds),
                    '?'
                )
            );

        $versionStatement =
            $pdo->prepare(
                '
                    SELECT storage_id
                    FROM drive_file_versions
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $versionStatement->execute(
            $fileIds
        );

        while (
            $version =
                $versionStatement->fetch(
                    PDO::FETCH_ASSOC
                )
        ) {
            $storageId =
                trim(
                    (string) (
                        $version['storage_id'] ??
                        ''
                    )
                );

            if ($storageId !== '') {
                $storageIds[
                    $storageId
                ] = true;
            }
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Begin permanent deletion
     * ----------------------------------------------------------------------
     */

    $pdo->beginTransaction();


    /*
     * ----------------------------------------------------------------------
     * Record folder-tree deletion
     * ----------------------------------------------------------------------
     *
     * This row survives deletion because folder_id becomes NULL through
     * ON DELETE SET NULL.
     *
     * Do not put decrypted content or encryption secrets in details_json.
     */

    $activityStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_file_activity (
                    workspace_id,
                    folder_id,
                    actor_user_id,
                    action,
                    details_json
                )
                VALUES (
                    :workspace_id,
                    :folder_id,
                    :actor_user_id,
                    :action,
                    :details_json
                )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':folder_id' =>
            $folderId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'folder_permanently_deleted',

        ':details_json' =>
            json_encode(
                [
                    'name' =>
                        (string) $folder['name'],

                    'deleted_folder_count' =>
                        count($folderIds),

                    'deleted_file_count' =>
                        count($fileIds),
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    /*
     * ----------------------------------------------------------------------
     * Remove file-related records
     * ----------------------------------------------------------------------
     */

    if ($fileIds) {
        $filePlaceholders =
            implode(
                ', ',
                array_fill(
                    0,
                    count($fileIds),
                    '?'
                )
            );


        /*
         * Team sharing
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_file_team_access
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            $fileIds
        );


        /*
         * File favorites
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_favorites
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            $fileIds
        );


        /*
         * Recent files
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_recent_files
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            $fileIds
        );


        /*
         * Versions
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_file_versions
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            $fileIds
        );


        /*
         * Wrapped encryption keys
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_file_keys
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            $fileIds
        );


        /*
         * Individual access
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_file_access
                    WHERE file_id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            $fileIds
        );


        /*
         * Main file rows
         */

        $statement =
            $pdo->prepare(
                '
                    DELETE FROM drive_files
                    WHERE workspace_id = ?
                      AND id IN (' . $filePlaceholders . ')
                '
            );

        $statement->execute(
            array_merge(
                [$workspaceId],
                $fileIds
            )
        );

        if (
            $statement->rowCount() !==
            count($fileIds)
        ) {
            throw new RuntimeException(
                'Unable to permanently delete all files in the folder tree.'
            );
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Folder favorites
     * ----------------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_favorites
                WHERE folder_id IN (' . $folderPlaceholders . ')
            '
        );

    $statement->execute(
        $folderIds
    );


    /*
     * ----------------------------------------------------------------------
     * Delete folders deepest-first
     * ----------------------------------------------------------------------
     *
     * Deleting deepest-first avoids relying solely on ON DELETE CASCADE for
     * the hierarchy and gives us predictable behavior.
     */

    $deleteFolderStatement =
        $pdo->prepare(
            '
                DELETE FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
            '
        );

    $deletedFolderCount = 0;

    foreach ($folderRows as $folderRow) {
        $deleteFolderStatement->execute([
            ':folder_id' =>
                (int) $folderRow['id'],

            ':workspace_id' =>
                $workspaceId,
        ]);

        $deletedFolderCount +=
            $deleteFolderStatement->rowCount();
    }

    if (
        $deletedFolderCount !==
        count($folderIds)
    ) {
        throw new RuntimeException(
            'Unable to permanently delete the complete folder tree.'
        );
    }


    $pdo->commit();


    /*
     * ----------------------------------------------------------------------
     * Delete encrypted physical blobs
     * ----------------------------------------------------------------------
     *
     * Database deletion is complete at this point.
     *
     * Filesystem deletion cannot be part of the SQLite transaction.
     */

    $cleanupFailed = false;

    foreach (
        array_keys($storageIds)
        as $storageId
    ) {
        try {
            drive_delete_stored_file(
                $storageId
            );
        } catch (Throwable $cleanupError) {
            error_log(
                'Alliances Drive folder permanent-delete storage cleanup '
                . 'failed for folder '
                . $folderId
                . ': '
                . $cleanupError->getMessage()
            );

            $cleanupFailed = true;
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' =>
            true,

        'folder_id' =>
            $folderId,

        'permanently_deleted' =>
            true,

        'deleted_folder_count' =>
            count($folderIds),

        'deleted_file_count' =>
            count($fileIds),

        'storage_cleanup_complete' =>
            !$cleanupFailed,

        'message' =>
            $cleanupFailed
                ? 'Folder permanently deleted. Some encrypted storage cleanup requires server maintenance.'
                : 'Folder permanently deleted.',
    ]);
} catch (Throwable $error) {
    if (
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive permanent folder delete failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to permanently delete the Drive folder.',
    ]);
}