<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$fileId =
    filter_input(
        INPUT_POST,
        'file_id',
        FILTER_VALIDATE_INT
    );

if (
    !$fileId ||
    $fileId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive file.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Load file
     * ----------------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    workspace_id,
                    uploaded_by,
                    storage_id,
                    original_name,
                    trashed_at
                FROM drive_files
                WHERE id = :file_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $file =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );

    if ($file === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Drive file not found.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * File must already be in Trash
     * ----------------------------------------------------------------------
     *
     * Permanent deletion must never be the first deletion step.
     */

    if (
        $file['trashed_at'] === null ||
        trim(
            (string) $file['trashed_at']
        ) === ''
    ) {
        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' =>
                'Move this file to Trash before permanently deleting it.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Authorization
     * ----------------------------------------------------------------------
     *
     * Only:
     *
     * - original owner/uploader
     * - workspace administrator
     *
     * may permanently delete the file.
     */

    $isOwner =
        (int) $file['uploaded_by'] ===
        $userId;

    $isAdmin =
        !empty(
            $access['is_admin']
        );

    if (
        !$isOwner &&
        !$isAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to permanently delete this file.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Collect encrypted storage objects
     * ----------------------------------------------------------------------
     *
     * We need both:
     *
     * - the current encrypted storage object
     * - all historical encrypted version objects
     *
     * The associative array acts as a set so a storage object cannot be
     * deleted twice.
     */

    $storageIds = [];

    $currentStorageId =
        trim(
            (string) (
                $file['storage_id'] ??
                ''
            )
        );

    if ($currentStorageId !== '') {
        $storageIds[
            $currentStorageId
        ] = true;
    }


    $versionStatement =
        $pdo->prepare(
            '
                SELECT storage_id
                FROM drive_file_versions
                WHERE file_id = :file_id
            '
        );

    $versionStatement->execute([
        ':file_id' =>
            $fileId,
    ]);

    while (
        $version =
            $versionStatement->fetch(
                PDO::FETCH_ASSOC
            )
    ) {
        $storageId =
            trim(
                (string) (
                    $version['storage_id'] ??
                    ''
                )
            );

        if ($storageId !== '') {
            $storageIds[
                $storageId
            ] = true;
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Delete database data
     * ----------------------------------------------------------------------
     */

    $pdo->beginTransaction();


    /*
     * Record the permanent deletion BEFORE removing the file.
     *
     * The activity-table migration allows file_id to become NULL when the
     * drive_files row is deleted.
     *
     * Keep only safe metadata in details_json.
     */

    $activityStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_file_activity (
                    workspace_id,
                    file_id,
                    actor_user_id,
                    action,
                    details_json
                )
                VALUES (
                    :workspace_id,
                    :file_id,
                    :actor_user_id,
                    :action,
                    :details_json
                )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':file_id' =>
            $fileId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'file_permanently_deleted',

        ':details_json' =>
            json_encode(
                [
                    'name' =>
                        (string) $file['original_name'],
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    /*
     * Team-sharing records
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_file_team_access
                WHERE file_id = :file_id
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,
    ]);


    /*
     * Favorites
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_favorites
                WHERE file_id = :file_id
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,
    ]);


    /*
     * Recent-file records
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_recent_files
                WHERE file_id = :file_id
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,
    ]);


    /*
     * Version history
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_file_versions
                WHERE file_id = :file_id
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,
    ]);


    /*
     * Wrapped encryption-key envelopes
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_file_keys
                WHERE file_id = :file_id
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,
    ]);


    /*
     * Individual access records
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_file_access
                WHERE file_id = :file_id
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,
    ]);


    /*
     * Main file record
     */

    $statement =
        $pdo->prepare(
            '
                DELETE FROM drive_files
                WHERE id = :file_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NOT NULL
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    if (
        $statement->rowCount() !== 1
    ) {
        throw new RuntimeException(
            'Unable to permanently delete the Drive file record.'
        );
    }


    $pdo->commit();


    /*
     * ----------------------------------------------------------------------
     * Delete encrypted physical storage
     * ----------------------------------------------------------------------
     *
     * Filesystem operations cannot participate in the SQLite transaction,
     * so encrypted blobs are removed only after the DB transaction succeeds.
     */

    $cleanupFailed = false;

    foreach (
        array_keys($storageIds)
        as $storageId
    ) {
        try {
            drive_delete_stored_file(
                $storageId
            );
        } catch (Throwable $cleanupError) {
            error_log(
                'Alliances Drive permanent-delete storage cleanup failed '
                . 'for file '
                . $fileId
                . ': '
                . $cleanupError->getMessage()
            );

            $cleanupFailed = true;
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' =>
            true,

        'file_id' =>
            $fileId,

        'permanently_deleted' =>
            true,

        'storage_cleanup_complete' =>
            !$cleanupFailed,

        'message' =>
            $cleanupFailed
                ? 'File permanently deleted. Some encrypted storage cleanup requires server maintenance.'
                : 'File permanently deleted.',
    ]);
} catch (Throwable $error) {
    if (
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive permanent delete failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to permanently delete the Drive file.',
    ]);
}