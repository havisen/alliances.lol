<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];


/*
 * Accept user IDs either as:
 *
 * ?user_ids[]=1&user_ids[]=2
 *
 * or:
 *
 * ?user_ids=1,2
 */
$rawUserIds = $_GET['user_ids'] ?? [];

if (is_string($rawUserIds)) {
    $rawUserIds = explode(',', $rawUserIds);
}

if (!is_array($rawUserIds)) {
    $rawUserIds = [];
}


$userIds = [];

foreach ($rawUserIds as $rawUserId) {
    $userId = filter_var(
        $rawUserId,
        FILTER_VALIDATE_INT,
        [
            'options' => [
                'min_range' => 1,
            ],
        ]
    );

    if ($userId === false) {
        continue;
    }

    $userIds[(int) $userId] = (int) $userId;
}

$userIds = array_values($userIds);


if ($userIds === []) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'At least one valid user ID is required.',
    ]);

    exit;
}


try {
    $pdo = db();

    /*
     * First verify that every requested user belongs to the
     * current user's workspace.
     */
    $placeholders = implode(
        ', ',
        array_fill(0, count($userIds), '?')
    );

    $workspaceStatement = $pdo->prepare(
        '
        SELECT
            wm.user_id
        FROM workspace_members wm
        WHERE wm.workspace_id = ?
          AND wm.user_id IN (' . $placeholders . ')
        '
    );

    $workspaceStatement->execute([
        $workspaceId,
        ...$userIds,
    ]);

    $workspaceUserIds = [];

    while (
        $row = $workspaceStatement->fetch(PDO::FETCH_ASSOC)
    ) {
        $workspaceUserIds[] = (int) $row['user_id'];
    }

    sort($workspaceUserIds);

    $expectedUserIds = $userIds;
    sort($expectedUserIds);

    if ($workspaceUserIds !== $expectedUserIds) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' => 'One or more users are not members of your workspace.',
        ]);

        exit;
    }


    /*
     * Public OpenPGP keys are stored in user_public_keys.
     *
     * This is the same public-key directory already used by
     * encrypted Messaging.
     */
    $keyStatement = $pdo->prepare(
        '
        SELECT
            upk.user_id,
            upk.public_key,
            upk.fingerprint
        FROM user_public_keys upk
        WHERE upk.user_id IN (' . $placeholders . ')
          AND upk.key_type = ?
        '
    );

    $keyStatement->execute([
        ...$userIds,
        'openpgp',
    ]);

    $keys = [];
    $foundUserIds = [];

    while ($row = $keyStatement->fetch(PDO::FETCH_ASSOC)) {
        $userId = (int) $row['user_id'];

        $foundUserIds[] = $userId;

        $keys[] = [
            'user_id' => $userId,
            'public_key' => (string) $row['public_key'],
            'fingerprint' => (string) $row['fingerprint'],
        ];
    }


    /*
     * Tell the browser exactly which requested users do not
     * currently have a published OpenPGP identity.
     */
    $missingUserIds = array_values(
        array_diff(
            $userIds,
            $foundUserIds
        )
    );


    echo json_encode([
        'success' => true,
        'keys' => $keys,
        'missing_user_ids' => $missingUserIds,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive public keys error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to load public encryption keys.',
    ]);
}