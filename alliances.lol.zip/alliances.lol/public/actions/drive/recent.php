<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Visible folder tree
     * ----------------------------------------------------------------------
     *
     * A recent file must not appear when:
     *
     * - the file itself is in Trash
     * - its parent folder is in Trash
     * - any ancestor folder is in Trash
     *
     * The recursive CTE gives us the complete visible folder tree.
     */

    $statement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    path
                ) AS (
                    SELECT
                        id,
                        parent_id,
                        \'/\' || id || \'/\'

                    FROM drive_folders

                    WHERE workspace_id =
                            :workspace_id

                      AND parent_id IS NULL

                      AND trashed_at IS NULL


                    UNION ALL


                    SELECT
                        child.id,
                        child.parent_id,

                        visible_folders.path
                            || child.id
                            || \'/\'

                    FROM drive_folders child

                    INNER JOIN visible_folders
                        ON child.parent_id =
                            visible_folders.id

                    WHERE child.workspace_id =
                            :recursive_workspace_id

                      AND child.trashed_at IS NULL

                      AND instr(
                          visible_folders.path,
                          \'/\' || child.id || \'/\'
                      ) = 0
                )

                SELECT
                    df.id,
                    df.folder_id,
                    df.uploaded_by,

                    df.original_name AS name,
                    df.mime_type,
                    df.encrypted_size,
                    df.encryption_version,
                    df.key_version,
                    df.sharing_mode,
                    df.current_version,

                    df.created_at,
                    df.updated_at,

                    u.display_name AS owner_name,

                    dfa.can_edit,
                    NULL AS expires_at,

                    drf.last_opened_at,

                    CASE
                        WHEN fav.user_id IS NULL
                            THEN 0
                        ELSE 1
                    END AS is_favorite

                FROM drive_recent_files drf

                INNER JOIN drive_files df
                    ON df.id = drf.file_id

                INNER JOIN drive_effective_access dfa
                    ON dfa.file_id = df.id
                   AND dfa.user_id =
                        :access_user_id

                INNER JOIN drive_file_keys dfk
                    ON dfk.file_id = df.id
                   AND dfk.user_id =
                        :key_user_id
                   AND dfk.key_version =
                        df.key_version

                INNER JOIN users u
                    ON u.id = df.uploaded_by

                LEFT JOIN visible_folders vf
                    ON vf.id = df.folder_id

                LEFT JOIN drive_favorites fav
                    ON fav.file_id = df.id
                   AND fav.user_id =
                        :favorite_user_id

                WHERE drf.user_id =
                        :recent_user_id

                  AND df.workspace_id =
                        :file_workspace_id

                  AND df.trashed_at IS NULL

                  AND (
                      df.folder_id IS NULL
                      OR vf.id IS NOT NULL
                  )

                ORDER BY
                    datetime(
                        drf.last_opened_at
                    ) DESC,
                    drf.file_id DESC

                LIMIT 100
            '
        );

    $statement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':recursive_workspace_id' =>
            $workspaceId,

        ':access_user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':favorite_user_id' =>
            $userId,

        ':recent_user_id' =>
            $userId,

        ':file_workspace_id' =>
            $workspaceId,
    ]);

    $files =
        $statement->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * ----------------------------------------------------------------------
     * Normalize JSON values
     * ----------------------------------------------------------------------
     */

    foreach ($files as &$file) {
        $file['id'] =
            (int) $file['id'];

        $file['folder_id'] =
            $file['folder_id'] !== null
                ? (int) $file['folder_id']
                : null;

        $file['uploaded_by'] =
            (int) $file['uploaded_by'];

        $file['encrypted_size'] =
            (int) $file['encrypted_size'];

        $file['encryption_version'] =
            (int) $file[
                'encryption_version'
            ];

        $file['key_version'] =
            (int) $file['key_version'];

        $file['current_version'] =
            (int) $file[
                'current_version'
            ];

        $file['can_edit'] =
            (bool) $file['can_edit'];

        $file['is_owner'] =
            $file['uploaded_by'] ===
            $userId;

        $file['is_favorite'] =
            (int) $file[
                'is_favorite'
            ] === 1;
    }

    unset($file);


    echo json_encode([
        'success' => true,

        /*
         * Recent currently contains files only.
         * Keep folders in the response so the frontend can use the
         * same rendering state as the other Drive sections.
         */
        'folders' => [],

        'files' =>
            $files,

        'count' =>
            count($files),
    ]);
} catch (Throwable $error) {
    error_log(
        'Alliances Drive recent load failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to load recent Drive files.',
    ]);
}