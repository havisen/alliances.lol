<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');


function drive_rename_error(
    string $message,
    int $status = 400
): never {
    http_response_code($status);

    echo json_encode([
        'success' => false,
        'error' => $message,
    ]);

    exit;
}


/*
 * --------------------------------------------------------------------------
 * Verify that a folder and all of its ancestors are active
 * --------------------------------------------------------------------------
 */

function drive_rename_folder_is_visible(
    PDO $pdo,
    int $workspaceId,
    ?int $folderId
): bool {
    if ($folderId === null) {
        return true;
    }


    $visited = [];


    while ($folderId !== null) {
        /*
         * Protect against a corrupted folder cycle.
         */
        if (isset($visited[$folderId])) {
            return false;
        }

        $visited[$folderId] = true;


        $statement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        parent_id,
                        trashed_at
                    FROM drive_folders
                    WHERE id = :folder_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );


        $statement->execute([
            ':folder_id' =>
                $folderId,

            ':workspace_id' =>
                $workspaceId,
        ]);


        $folder =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$folder) {
            return false;
        }


        if (
            $folder['trashed_at'] !== null
        ) {
            return false;
        }


        $folderId =
            $folder['parent_id'] === null
                ? null
                : (int) $folder['parent_id'];
    }


    return true;
}


try {
    /*
     * ----------------------------------------------------------------------
     * Request
     * ----------------------------------------------------------------------
     */

    if (
        $_SERVER['REQUEST_METHOD'] !==
        'POST'
    ) {
        drive_rename_error(
            'Method not allowed.',
            405
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Authentication
     * ----------------------------------------------------------------------
     */

    $user =
        require_login();


    $userId =
        (int) $user['id'];


    $access =
        workspace_access(
            $userId
        );


    if ($access === null) {
        drive_rename_error(
            'You do not have access to a workspace.',
            403
        );
    }


    require_valid_csrf();


    $workspaceId =
        (int) $access[
            'workspace_id'
        ];


    $isAdmin =
        (bool) $access[
            'is_admin'
        ];


    /*
     * ----------------------------------------------------------------------
     * Input
     * ----------------------------------------------------------------------
     */

    $type =
        strtolower(
            trim(
                (string) (
                    $_POST['type'] ??
                    ''
                )
            )
        );


    $itemId =
        filter_var(
            $_POST['item_id'] ??
                null,

            FILTER_VALIDATE_INT
        );


    $name =
        trim(
            (string) (
                $_POST['name'] ??
                ''
            )
        );


    if (
        $type !== 'file' &&
        $type !== 'folder'
    ) {
        drive_rename_error(
            'Invalid Drive item type.'
        );
    }


    if (
        $itemId === false ||
        $itemId === null ||
        $itemId < 1
    ) {
        drive_rename_error(
            'Invalid Drive item.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Name validation
     * ----------------------------------------------------------------------
     */

    if ($name === '') {
        drive_rename_error(
            'Name cannot be empty.'
        );
    }


    if (
        strlen($name) >
        200
    ) {
        drive_rename_error(
            'Use a name of 200 characters or fewer.'
        );
    }


    /*
     * Drive names are labels.
     *
     * They must never be interpreted as physical
     * filesystem paths.
     */

    if (
        str_contains(
            $name,
            '/'
        ) ||
        str_contains(
            $name,
            '\\'
        )
    ) {
        drive_rename_error(
            'Names cannot contain slashes.'
        );
    }


    if (
        $name === '.' ||
        $name === '..'
    ) {
        drive_rename_error(
            'Invalid name.'
        );
    }


    /*
     * Reject ASCII control characters.
     */

    if (
        preg_match(
            '/[\x00-\x1F\x7F]/',
            $name
        ) === 1
    ) {
        drive_rename_error(
            'The name contains invalid characters.'
        );
    }


    $pdo =
        db();


    /*
     * ======================================================================
     * FILE
     * ======================================================================
     */

    if ($type === 'file') {
        $statement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        folder_id,
                        uploaded_by,
                        original_name,
                        trashed_at
                    FROM drive_files
                    WHERE id = :file_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );


        $statement->execute([
            ':file_id' =>
                (int) $itemId,

            ':workspace_id' =>
                $workspaceId,
        ]);


        $file =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$file) {
            drive_rename_error(
                'File not found.',
                404
            );
        }


        /*
         * Only the owner or a workspace administrator
         * can rename the file.
         */

        if (
            !$isAdmin &&
            (int) $file[
                'uploaded_by'
            ] !== $userId
        ) {
            drive_rename_error(
                'You do not have permission to rename this file.',
                403
            );
        }


        /*
         * Directly trashed file.
         */

        if (
            $file['trashed_at'] !==
            null
        ) {
            drive_rename_error(
                'Restore this file before renaming it.'
            );
        }


        /*
         * A file inside a trashed folder tree is also
         * considered unavailable.
         */

        $folderId =
            $file['folder_id'] ===
            null
                ? null
                : (int) $file[
                    'folder_id'
                ];


        if (
            !drive_rename_folder_is_visible(
                $pdo,
                $workspaceId,
                $folderId
            )
        ) {
            drive_rename_error(
                'Restore the parent folder before renaming this file.'
            );
        }


        /*
         * Nothing changed.
         */

        if (
            $name ===
            (string) $file[
                'original_name'
            ]
        ) {
            echo json_encode([
                'success' =>
                    true,

                'type' =>
                    'file',

                'item_id' =>
                    (int) $itemId,

                'name' =>
                    $name,

                'unchanged' =>
                    true,
            ]);

            exit;
        }


        /*
         * Rename.
         */

        $update =
            $pdo->prepare(
                '
                    UPDATE drive_files
                    SET
                        original_name = :name,
                        updated_at = CURRENT_TIMESTAMP
                    WHERE id = :file_id
                      AND workspace_id = :workspace_id
                      AND trashed_at IS NULL
                '
            );


        $update->execute([
            ':name' =>
                $name,

            ':file_id' =>
                (int) $itemId,

            ':workspace_id' =>
                $workspaceId,
        ]);


        if (
            $update->rowCount() !==
            1
        ) {
            drive_rename_error(
                'The file could not be renamed.',
                409
            );
        }

        $activityStatement =
            $pdo->prepare(
                '
                    INSERT INTO drive_file_activity (
                        workspace_id,
                        file_id,
                        actor_user_id,
                        action,
                        details_json
                    )
                    VALUES (
                        :workspace_id,
                        :file_id,
                        :actor_user_id,
                        :action,
                        :details_json
                    )
                '
            );

        $activityStatement->execute([
            ':workspace_id' =>
                $workspaceId,

            ':file_id' =>
                (int) $itemId,

            ':actor_user_id' =>
                $userId,

            ':action' =>
                'file_renamed',

            ':details_json' =>
                json_encode(
                    [
                        'from' =>
                            (string) $file['original_name'],

                        'to' =>
                            $name,
                    ],
                    JSON_UNESCAPED_SLASHES |
                    JSON_UNESCAPED_UNICODE
                ),
        ]);


        echo json_encode([
            'success' =>
                true,

            'type' =>
                'file',

            'item_id' =>
                (int) $itemId,

            'name' =>
                $name,

            'unchanged' =>
                false,
        ]);

        exit;
    }


    /*
     * ======================================================================
     * FOLDER
     * ======================================================================
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    parent_id,
                    created_by,
                    name,
                    trashed_at
                FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );


    $statement->execute([
        ':folder_id' =>
            (int) $itemId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    $folder =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$folder) {
        drive_rename_error(
            'Folder not found.',
            404
        );
    }


    /*
     * Only the folder creator or a workspace
     * administrator can rename it.
     */

    if (
        !$isAdmin &&
        (int) $folder[
            'created_by'
        ] !== $userId
    ) {
        drive_rename_error(
            'You do not have permission to rename this folder.',
            403
        );
    }


    /*
     * Directly trashed folder.
     */

    if (
        $folder['trashed_at'] !==
        null
    ) {
        drive_rename_error(
            'Restore this folder before renaming it.'
        );
    }


    /*
     * Check the parent hierarchy as well.
     *
     * We intentionally start with parent_id rather
     * than the current folder because the current
     * folder was already checked above.
     */

    $parentId =
        $folder['parent_id'] ===
        null
            ? null
            : (int) $folder[
                'parent_id'
            ];


    if (
        !drive_rename_folder_is_visible(
            $pdo,
            $workspaceId,
            $parentId
        )
    ) {
        drive_rename_error(
            'Restore the parent folder before renaming this folder.'
        );
    }


    /*
     * Nothing changed.
     */

    if (
        $name ===
        (string) $folder['name']
    ) {
        echo json_encode([
            'success' =>
                true,

            'type' =>
                'folder',

            'item_id' =>
                (int) $itemId,

            'name' =>
                $name,

            'unchanged' =>
                true,
        ]);

        exit;
    }


    /*
     * Rename.
     */

    $update =
        $pdo->prepare(
            '
                UPDATE drive_folders
                SET
                    name = :name,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NULL
            '
        );


    $update->execute([
        ':name' =>
            $name,

        ':folder_id' =>
            (int) $itemId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    if (
        $update->rowCount() !==
        1
    ) {
        drive_rename_error(
            'The folder could not be renamed.',
            409
        );
    }


    echo json_encode([
        'success' =>
            true,

        'type' =>
            'folder',

        'item_id' =>
            (int) $itemId,

        'name' =>
            $name,

        'unchanged' =>
            false,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive rename failed: ' .
        $exception->getMessage()
    );


    if (!headers_sent()) {
        http_response_code(
            500
        );
    }


    echo json_encode([
        'success' =>
            false,

        'error' =>
            'Unable to rename the Drive item.',
    ]);
}
