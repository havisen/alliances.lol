<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$folderId =
    filter_input(
        INPUT_POST,
        'folder_id',
        FILTER_VALIDATE_INT
    );

if (
    !$folderId ||
    $folderId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive folder.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Load folder
     * ----------------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    workspace_id,
                    parent_id,
                    created_by,
                    name,
                    trashed_at
                FROM drive_folders
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':folder_id' =>
            $folderId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $folder =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );

    if ($folder === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Drive folder not found.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Folder must actually be in Trash
     * ----------------------------------------------------------------------
     *
     * Descendants of a trashed folder are effectively in Trash, but they
     * are not individually marked as trashed.
     *
     * Restore therefore operates on the explicitly trashed root folder.
     */

    if (
        $folder['trashed_at'] === null ||
        trim(
            (string) $folder['trashed_at']
        ) === ''
    ) {
        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' =>
                'This folder is not directly in Trash.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Authorization
     * ----------------------------------------------------------------------
     */

    $isCreator =
        (int) $folder['created_by'] ===
        $userId;

    $isAdmin =
        !empty(
            $access['is_admin']
        );

    if (
        !$isCreator &&
        !$isAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to restore this folder.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Determine where the folder should be restored
     * ----------------------------------------------------------------------
     *
     * If the original parent:
     *
     * - still exists
     * - belongs to this workspace
     * - is not in Trash
     * - does not have a trashed ancestor
     *
     * restore underneath it.
     *
     * Otherwise restore this folder to the Drive root.
     */

    $restoreParentId = null;

    if ($folder['parent_id'] !== null) {
        $candidateParentId =
            (int) $folder['parent_id'];

        $parentStatement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        parent_id,
                        trashed_at
                    FROM drive_folders
                    WHERE id = :folder_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );

        $parentStatement->execute([
            ':folder_id' =>
                $candidateParentId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $parent =
            $parentStatement->fetch(
                PDO::FETCH_ASSOC
            );

        if (
            $parent !== false &&
            (
                $parent['trashed_at'] === null ||
                trim(
                    (string) $parent['trashed_at']
                ) === ''
            )
        ) {
            /*
             * --------------------------------------------------------------
             * Check all ancestors of the candidate parent
             * --------------------------------------------------------------
             */

            $parentTreeIsVisible = true;

            $ancestorId =
                $parent['parent_id'] !== null
                    ? (int) $parent['parent_id']
                    : null;

            $visited = [
                $candidateParentId => true,
            ];

            while ($ancestorId !== null) {
                if (
                    isset(
                        $visited[
                            $ancestorId
                        ]
                    )
                ) {
                    throw new RuntimeException(
                        'Invalid Drive folder hierarchy.'
                    );
                }

                $visited[
                    $ancestorId
                ] = true;

                $ancestorStatement =
                    $pdo->prepare(
                        '
                            SELECT
                                parent_id,
                                trashed_at
                            FROM drive_folders
                            WHERE id = :folder_id
                              AND workspace_id = :workspace_id
                            LIMIT 1
                        '
                    );

                $ancestorStatement->execute([
                    ':folder_id' =>
                        $ancestorId,

                    ':workspace_id' =>
                        $workspaceId,
                ]);

                $ancestor =
                    $ancestorStatement->fetch(
                        PDO::FETCH_ASSOC
                    );

                if ($ancestor === false) {
                    $parentTreeIsVisible = false;
                    break;
                }

                if (
                    $ancestor['trashed_at'] !== null &&
                    trim(
                        (string) $ancestor['trashed_at']
                    ) !== ''
                ) {
                    $parentTreeIsVisible = false;
                    break;
                }

                $ancestorId =
                    $ancestor['parent_id'] !== null
                        ? (int) $ancestor['parent_id']
                        : null;
            }

            if ($parentTreeIsVisible) {
                $restoreParentId =
                    $candidateParentId;
            }
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Restore folder
     * ----------------------------------------------------------------------
     *
     * We only clear Trash state on this folder.
     *
     * Its children were never individually marked as trashed, so restoring
     * this folder automatically restores visibility of the preserved tree.
     */

    $pdo->beginTransaction();

    $restoreStatement =
        $pdo->prepare(
            '
                UPDATE drive_folders
                SET
                    parent_id = :parent_id,
                    trashed_at = NULL,
                    trashed_by = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :folder_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NOT NULL
            '
        );

    if ($restoreParentId === null) {
        $restoreStatement->bindValue(
            ':parent_id',
            null,
            PDO::PARAM_NULL
        );
    } else {
        $restoreStatement->bindValue(
            ':parent_id',
            $restoreParentId,
            PDO::PARAM_INT
        );
    }

    $restoreStatement->bindValue(
        ':folder_id',
        $folderId,
        PDO::PARAM_INT
    );

    $restoreStatement->bindValue(
        ':workspace_id',
        $workspaceId,
        PDO::PARAM_INT
    );

    $restoreStatement->execute();

    if (
        $restoreStatement->rowCount() !== 1
    ) {
        throw new RuntimeException(
            'Unable to restore the Drive folder.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Activity
     * ----------------------------------------------------------------------
     */

    $activityStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_file_activity (
                    workspace_id,
                    folder_id,
                    actor_user_id,
                    action,
                    details_json
                )
                VALUES (
                    :workspace_id,
                    :folder_id,
                    :actor_user_id,
                    :action,
                    :details_json
                )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':folder_id' =>
            $folderId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'folder_restored',

        ':details_json' =>
            json_encode(
                [
                    'name' =>
                        (string) $folder['name'],

                    'restored_to_parent_id' =>
                        $restoreParentId,
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    $pdo->commit();


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' =>
            true,

        'folder_id' =>
            $folderId,

        'restored' =>
            true,

        'parent_id' =>
            $restoreParentId,

        'message' =>
            $restoreParentId === null
                ? 'Folder restored to Drive.'
                : 'Folder restored.',
    ]);
} catch (Throwable $error) {
    if (
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive folder restore failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to restore the Drive folder.',
    ]);
}