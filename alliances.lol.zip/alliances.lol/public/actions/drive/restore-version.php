<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

require_valid_csrf();

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'You do not have access to a workspace.']);
    exit;
}

$fileId = filter_input(INPUT_POST, 'file_id', FILTER_VALIDATE_INT);
$versionId = filter_input(INPUT_POST, 'version_id', FILTER_VALIDATE_INT);

if ($fileId === false || $fileId === null || $fileId <= 0 || $versionId === false || $versionId === null || $versionId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid version restore request.']);
    exit;
}

$userId = (int) $user['id'];
$workspaceId = (int) $access['workspace_id'];
$newStorageId = null;

try {
    $pdo = db();

    $statement = $pdo->prepare(
        '
        SELECT
            f.id,
            f.workspace_id,
            f.trashed_at,
            a.can_edit,
            v.id AS version_id,
            v.version_number AS restored_from_version,
            v.storage_id,
            v.encrypted_size,
            v.encryption_version,
            v.key_version
        FROM drive_files AS f
        INNER JOIN drive_effective_access AS a
            ON a.file_id = f.id
           AND a.user_id = :user_id
        INNER JOIN drive_file_versions AS v
            ON v.file_id = f.id
           AND v.id = :version_id
        WHERE f.id = :file_id
          AND f.workspace_id = :workspace_id
        LIMIT 1
        '
    );

    $statement->execute([
        ':user_id' => $userId,
        ':version_id' => $versionId,
        ':file_id' => $fileId,
        ':workspace_id' => $workspaceId,
    ]);

    $record = $statement->fetch();

    if (!$record) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Version not found.']);
        exit;
    }

    if ((int) $record['can_edit'] !== 1) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'You do not have permission to restore this file.']);
        exit;
    }

    if ($record['trashed_at'] !== null) {
        http_response_code(409);
        echo json_encode(['success' => false, 'error' => 'Restore the file from Trash before restoring a version.']);
        exit;
    }

    $sourceStorageId = (string) $record['storage_id'];
    $sourcePath = drive_file_path($sourceStorageId);

    if (!is_file($sourcePath) || !is_readable($sourcePath)) {
        throw new RuntimeException('Encrypted version storage is missing.');
    }

    drive_ensure_storage_directory();

    do {
        $newStorageId = drive_generate_storage_id();
        $newPath = drive_file_path($newStorageId);
    } while (is_file($newPath));

    drive_ensure_file_directory($newStorageId);

    if (!copy($sourcePath, $newPath)) {
        throw new RuntimeException('Unable to copy encrypted version storage.');
    }

    $pdo->beginTransaction();

    $nextVersionStatement = $pdo->prepare(
        '
        SELECT COALESCE(MAX(version_number), 0) + 1
        FROM drive_file_versions
        WHERE file_id = :file_id
        '
    );

    $nextVersionStatement->execute([
        ':file_id' => $fileId,
    ]);

    $newVersionNumber = (int) $nextVersionStatement->fetchColumn();

    $insertStatement = $pdo->prepare(
        '
        INSERT INTO drive_file_versions (
            file_id,
            version_number,
            created_by,
            storage_id,
            encrypted_size,
            encryption_version,
            key_version
        )
        VALUES (
            :file_id,
            :version_number,
            :created_by,
            :storage_id,
            :encrypted_size,
            :encryption_version,
            :key_version
        )
        '
    );

    $insertStatement->execute([
        ':file_id' => $fileId,
        ':version_number' => $newVersionNumber,
        ':created_by' => $userId,
        ':storage_id' => $newStorageId,
        ':encrypted_size' => (int) $record['encrypted_size'],
        ':encryption_version' => (int) $record['encryption_version'],
        ':key_version' => (int) $record['key_version'],
    ]);

    $updateStatement = $pdo->prepare(
        '
        UPDATE drive_files
        SET
            storage_id = :storage_id,
            encrypted_size = :encrypted_size,
            encryption_version = :encryption_version,
            key_version = :key_version,
            current_version = :current_version,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = :file_id
          AND workspace_id = :workspace_id
        '
    );

    $updateStatement->execute([
        ':storage_id' => $newStorageId,
        ':encrypted_size' => (int) $record['encrypted_size'],
        ':encryption_version' => (int) $record['encryption_version'],
        ':key_version' => (int) $record['key_version'],
        ':current_version' => $newVersionNumber,
        ':file_id' => $fileId,
        ':workspace_id' => $workspaceId,
    ]);

    if ($updateStatement->rowCount() !== 1) {
        throw new RuntimeException('Unable to update restored Drive file.');
    }

    $activityStatement = $pdo->prepare(
        '
        INSERT INTO drive_file_activity (
            workspace_id,
            file_id,
            actor_user_id,
            action,
            details_json
        )
        VALUES (
            :workspace_id,
            :file_id,
            :actor_user_id,
            :action,
            :details_json
        )
        '
    );

    $activityStatement->execute([
        ':workspace_id' => $workspaceId,
        ':file_id' => $fileId,
        ':actor_user_id' => $userId,
        ':action' => 'version_restored',
        ':details_json' => json_encode(
            [
                'restored_from_version' => (int) $record['restored_from_version'],
                'version_number' => $newVersionNumber,
            ],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        ),
    ]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'file_id' => $fileId,
        'restored_from_version' => (int) $record['restored_from_version'],
        'version_number' => $newVersionNumber,
    ]);
} catch (Throwable $exception) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if (is_string($newStorageId) && $newStorageId !== '') {
        try {
            drive_delete_stored_file($newStorageId);
        } catch (Throwable) {
        }
    }

    error_log('Drive version restore failed: ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Unable to restore file version.']);
}
