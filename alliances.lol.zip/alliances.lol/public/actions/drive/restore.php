<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$fileId =
    filter_input(
        INPUT_POST,
        'file_id',
        FILTER_VALIDATE_INT
    );

if (
    !$fileId ||
    $fileId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid Drive file.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Load trashed file
     * ----------------------------------------------------------------------
     */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    id,
                    workspace_id,
                    folder_id,
                    uploaded_by,
                    original_name,
                    trashed_at
                FROM drive_files
                WHERE id = :file_id
                  AND workspace_id = :workspace_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $file =
        $statement->fetch(
            PDO::FETCH_ASSOC
        );

    if ($file === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Drive file not found.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Must actually be in Trash
     * ----------------------------------------------------------------------
     */

    if (
        $file['trashed_at'] === null ||
        trim(
            (string) $file['trashed_at']
        ) === ''
    ) {
        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'This file is not in Trash.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Authorization
     * ----------------------------------------------------------------------
     *
     * Restore follows the same ownership rule as moving a file to Trash:
     *
     * - original uploader
     * - workspace administrator
     */

    $isOwner =
        (int) $file['uploaded_by'] ===
        $userId;

    $isAdmin =
        !empty(
            $access['is_admin']
        );

    if (
        !$isOwner &&
        !$isAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to restore this file.',
        ]);

        exit;
    }


    /*
 * ----------------------------------------------------------------------
 * Determine restoration folder
 * ----------------------------------------------------------------------
 *
 * Restore to the original parent only when the complete parent chain
 * is still valid and visible.
 *
 * If:
 *
 * - the parent no longer exists
 * - the parent belongs to another workspace
 * - the parent is in Trash
 * - any ancestor is missing
 * - any ancestor is in Trash
 * - a corrupted folder cycle is detected
 *
 * then restore the file safely to the Drive root instead.
 */

$restoreFolderId = null;

if ($file['folder_id'] !== null) {
    $originalFolderId =
        (int) $file['folder_id'];

    if ($originalFolderId > 0) {
        $folderStatement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        parent_id,
                        trashed_at
                    FROM drive_folders
                    WHERE id = :folder_id
                      AND workspace_id = :workspace_id
                    LIMIT 1
                '
            );

        $folderStatement->execute([
            ':folder_id' =>
                $originalFolderId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $folder =
            $folderStatement->fetch(
                PDO::FETCH_ASSOC
            );


        /*
         * Assume the parent tree is invalid until every level has
         * successfully passed validation.
         */

        $parentTreeIsValid = false;

        if (
            $folder !== false &&
            $folder['trashed_at'] === null
        ) {
            $parentTreeIsValid = true;

            $visitedFolderIds = [
                (int) $folder['id'] =>
                    true,
            ];

            $ancestorId =
                $folder['parent_id'] !== null
                    ? (int) $folder['parent_id']
                    : null;


            /*
             * Walk from the immediate parent all the way to Drive root.
             */

            while (
                $ancestorId !== null &&
                $ancestorId > 0
            ) {
                /*
                 * A valid folder hierarchy can never visit the same
                 * folder twice.
                 */

                if (
                    isset(
                        $visitedFolderIds[
                            $ancestorId
                        ]
                    )
                ) {
                    $parentTreeIsValid =
                        false;

                    break;
                }

                $visitedFolderIds[
                    $ancestorId
                ] = true;


                $ancestorStatement =
                    $pdo->prepare(
                        '
                            SELECT
                                id,
                                parent_id,
                                trashed_at
                            FROM drive_folders
                            WHERE id = :folder_id
                              AND workspace_id = :workspace_id
                            LIMIT 1
                        '
                    );

                $ancestorStatement->execute([
                    ':folder_id' =>
                        $ancestorId,

                    ':workspace_id' =>
                        $workspaceId,
                ]);

                $ancestor =
                    $ancestorStatement->fetch(
                        PDO::FETCH_ASSOC
                    );


                /*
                 * Missing ancestor or trashed ancestor means the
                 * original location is not currently visible.
                 */

                if (
                    $ancestor === false ||
                    $ancestor['trashed_at'] !== null
                ) {
                    $parentTreeIsValid =
                        false;

                    break;
                }


                $ancestorId =
                    $ancestor['parent_id'] !== null
                        ? (int) $ancestor['parent_id']
                        : null;
            }
        }


        /*
         * Preserve the original parent only when the complete chain
         * survived validation.
         */

        if ($parentTreeIsValid) {
            $restoreFolderId =
                $originalFolderId;
        }
    }
}

    /*
     * ----------------------------------------------------------------------
     * Restore
     * ----------------------------------------------------------------------
     */

    $pdo->beginTransaction();

    $restoreStatement =
        $pdo->prepare(
            '
                UPDATE drive_files
                SET
                    folder_id = :folder_id,
                    trashed_at = NULL,
                    trashed_by = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :file_id
                  AND workspace_id = :workspace_id
                  AND trashed_at IS NOT NULL
            '
        );

    if ($restoreFolderId === null) {
        $restoreStatement->bindValue(
            ':folder_id',
            null,
            PDO::PARAM_NULL
        );
    } else {
        $restoreStatement->bindValue(
            ':folder_id',
            $restoreFolderId,
            PDO::PARAM_INT
        );
    }

    $restoreStatement->bindValue(
        ':file_id',
        $fileId,
        PDO::PARAM_INT
    );

    $restoreStatement->bindValue(
        ':workspace_id',
        $workspaceId,
        PDO::PARAM_INT
    );

    $restoreStatement->execute();

    if (
        $restoreStatement->rowCount() !== 1
    ) {
        throw new RuntimeException(
            'Unable to restore the Drive file.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Activity
     * ----------------------------------------------------------------------
     */

    $activityStatement =
        $pdo->prepare(
            '
                INSERT INTO drive_file_activity (
                    workspace_id,
                    file_id,
                    actor_user_id,
                    action,
                    details_json
                )
                VALUES (
                    :workspace_id,
                    :file_id,
                    :actor_user_id,
                    :action,
                    :details_json
                )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':file_id' =>
            $fileId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'file_restored',

        ':details_json' =>
            json_encode(
                [
                    'name' =>
                        (string) $file['original_name'],

                    'restored_to_folder_id' =>
                        $restoreFolderId,
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    $pdo->commit();


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' =>
            true,

        'file_id' =>
            $fileId,

        'restored' =>
            true,

        'folder_id' =>
            $restoreFolderId,

        'message' =>
            $restoreFolderId === null
                ? 'File restored to Drive.'
                : 'File restored.',
    ]);
} catch (Throwable $error) {
    if (
        $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive restore failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to restore the Drive file.',
    ]);
}