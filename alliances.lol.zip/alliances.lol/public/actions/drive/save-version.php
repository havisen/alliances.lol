<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

$user = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');


if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}


require_valid_csrf();


$workspaceAccess =
    workspace_access(
        (int) $user['id']
    );


if ($workspaceAccess === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}


$userId =
    (int) $user['id'];

$workspaceId =
    (int) $workspaceAccess['workspace_id'];


/*
|--------------------------------------------------------------------------
| Input
|--------------------------------------------------------------------------
*/

$fileId =
    filter_input(
        INPUT_POST,
        'file_id',
        FILTER_VALIDATE_INT
    );


if (
    $fileId === false
    || $fileId === null
    || $fileId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'A valid file ID is required.',
    ]);

    exit;
}


if (
    !isset($_FILES['encrypted_file'])
    || !is_array($_FILES['encrypted_file'])
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Encrypted file data is required.',
    ]);

    exit;
}


$uploadedFile =
    $_FILES['encrypted_file'];


$uploadError =
    (int) (
        $uploadedFile['error']
        ?? UPLOAD_ERR_NO_FILE
    );


if ($uploadError !== UPLOAD_ERR_OK) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'The encrypted version could not be uploaded.',
    ]);

    exit;
}


$tempPath =
    (string) (
        $uploadedFile['tmp_name']
        ?? ''
    );


if (
    $tempPath === ''
    || !is_uploaded_file($tempPath)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Invalid encrypted upload.',
    ]);

    exit;
}


$encryptedSize =
    (int) (
        $uploadedFile['size']
        ?? 0
    );


if ($encryptedSize <= 0) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'The encrypted version is empty.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Save
|--------------------------------------------------------------------------
*/

$pdo = null;
$storageId = null;
$finalPath = null;


try {
    $pdo = db();


    /*
     * ----------------------------------------------------------------------
     * Verify file access and edit permission
     * ----------------------------------------------------------------------
     */

    $fileStatement =
        $pdo->prepare(
            '
            SELECT
                f.id,
                f.workspace_id,
                f.key_version,
                f.encryption_version,
                a.can_edit
            FROM drive_files AS f

            INNER JOIN drive_effective_access AS a
                ON a.file_id = f.id
                AND a.user_id = :user_id

            INNER JOIN drive_file_keys AS k
                ON k.file_id = f.id
                AND k.user_id = :key_user_id
                AND k.key_version = f.key_version

            WHERE
                f.id = :file_id
                AND f.workspace_id = :workspace_id

            LIMIT 1
            '
        );


    $fileStatement->execute([
        ':user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    $file =
        $fileStatement->fetch();


    if (!$file) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' =>
                'File not found or access is unavailable.',
        ]);

        exit;
    }


    if ((int) $file['can_edit'] !== 1) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You do not have permission to edit this file.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Generate private storage location
     * ----------------------------------------------------------------------
     */

    drive_ensure_storage_directory();


    do {
        $storageId =
            drive_generate_storage_id();

        $finalPath =
            drive_file_path(
                $storageId
            );
    } while (
        file_exists(
            $finalPath
        )
    );


    drive_ensure_file_directory(
        $storageId
    );


    /*
     * Move only the encrypted bytes into private storage.
     */
    if (
        !move_uploaded_file(
            $tempPath,
            $finalPath
        )
    ) {
        throw new RuntimeException(
            'Unable to move encrypted Drive version into storage.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Database transaction
     * ----------------------------------------------------------------------
     */

    $pdo->beginTransaction();


    /*
     * Determine the next version number while inside
     * the transaction.
     */
    $versionStatement =
        $pdo->prepare(
            '
            SELECT
                COALESCE(
                    MAX(version_number),
                    0
                ) + 1
            FROM drive_file_versions
            WHERE file_id = :file_id
            '
        );


    $versionStatement->execute([
        ':file_id' =>
            $fileId,
    ]);


    $versionNumber =
        (int) $versionStatement
            ->fetchColumn();


    if ($versionNumber <= 0) {
        $versionNumber = 1;
    }


    /*
     * Record the encrypted version.
     */
    $insertVersion =
        $pdo->prepare(
            '
            INSERT INTO drive_file_versions (
                file_id,
                version_number,
                created_by,
                storage_id,
                encrypted_size,
                encryption_version,
                key_version
            )
            VALUES (
                :file_id,
                :version_number,
                :created_by,
                :storage_id,
                :encrypted_size,
                :encryption_version,
                :key_version
            )
            '
        );


    $insertVersion->execute([
        ':file_id' =>
            $fileId,

        ':version_number' =>
            $versionNumber,

        ':created_by' =>
            $userId,

        ':storage_id' =>
            $storageId,

        ':encrypted_size' =>
            $encryptedSize,

        ':encryption_version' =>
            (int) $file['encryption_version'],

        ':key_version' =>
            (int) $file['key_version'],
    ]);


    $versionId =
        (int) $pdo->lastInsertId();


    /*
     * The new encrypted blob becomes the current version.
     *
     * We keep the previous blob in storage so version
     * history can restore it later.
     */
    $updateFile =
        $pdo->prepare(
            '
            UPDATE drive_files
            SET
                storage_id = :storage_id,
                encrypted_size = :encrypted_size,
                current_version = :current_version,
                updated_at = CURRENT_TIMESTAMP
            WHERE
                id = :file_id
                AND workspace_id = :workspace_id
            '
        );


    $updateFile->execute([
        ':storage_id' =>
            $storageId,

        ':encrypted_size' =>
            $encryptedSize,

        ':current_version' =>
            $versionNumber,

        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    if ($updateFile->rowCount() !== 1) {
        throw new RuntimeException(
            'Unable to update the current Drive file version.'
        );
    }

    $activityStatement =
        $pdo->prepare(
            '
            INSERT INTO drive_file_activity (
                workspace_id,
                file_id,
                actor_user_id,
                action,
                details_json
            )
            VALUES (
                :workspace_id,
                :file_id,
                :actor_user_id,
                :action,
                :details_json
            )
            '
        );

    $activityStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':file_id' =>
            $fileId,

        ':actor_user_id' =>
            $userId,

        ':action' =>
            'version_created',

        ':details_json' =>
            json_encode(
                [
                    'version_number' =>
                        $versionNumber,
                ],
                JSON_UNESCAPED_SLASHES |
                JSON_UNESCAPED_UNICODE
            ),
    ]);


    $pdo->commit();


    echo json_encode([
        'success' => true,

        'file_id' =>
            $fileId,

        'version_id' =>
            $versionId,

        'version_number' =>
            $versionNumber,

        'encrypted_size' =>
            $encryptedSize,
    ]);

    exit;
} catch (Throwable $error) {
    if (
        $pdo instanceof PDO
        && $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }


    /*
     * If the encrypted blob reached permanent storage
     * but the database operation failed, remove it so
     * we do not leave an orphaned file.
     */
    if (
        is_string($storageId)
        && $storageId !== ''
    ) {
        try {
            drive_delete_stored_file(
                $storageId
            );
        } catch (Throwable) {
            /*
             * Preserve the original error.
             */
        }
    }


    error_log(
        'Drive version save error: '
        . $error->getMessage()
    );


    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to save the encrypted file version.',
    ]);

    exit;
}
