<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $user['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$query =
    trim(
        (string) (
            $_GET['q'] ??
            ''
        )
    );

if ($query === '') {
    echo json_encode([
        'success' => true,
        'query' => '',
        'folders' => [],
        'files' => [],
        'count' => 0,
    ]);

    exit;
}

/*
 * Prevent extremely large search strings from being sent
 * into every LIKE comparison.
 */
if (mb_strlen($query) > 200) {
    $query =
        mb_substr(
            $query,
            0,
            200
        );
}

$likeQuery =
    '%' . $query . '%';

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Search visible folders
     * ----------------------------------------------------------------------
     *
     * visible_folders begins only at non-trashed root folders and recursively
     * follows non-trashed children.
     *
     * A folder underneath a trashed ancestor therefore cannot appear.
     */

    $folderStatement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    created_by,
                    name,
                    created_at,
                    updated_at,
                    path
                ) AS (
                    SELECT
                        id,
                        parent_id,
                        created_by,
                        name,
                        created_at,
                        updated_at,
                        \'/\' || id || \'/\'

                    FROM drive_folders

                    WHERE workspace_id =
                            :root_workspace_id

                      AND parent_id IS NULL
                      AND trashed_at IS NULL


                    UNION ALL


                    SELECT
                        child.id,
                        child.parent_id,
                        child.created_by,
                        child.name,
                        child.created_at,
                        child.updated_at,

                        visible_folders.path
                            || child.id
                            || \'/\'

                    FROM drive_folders child

                    INNER JOIN visible_folders
                        ON child.parent_id =
                            visible_folders.id

                    WHERE child.workspace_id =
                            :child_workspace_id

                      AND child.trashed_at IS NULL

                      AND instr(
                          visible_folders.path,
                          \'/\' || child.id || \'/\'
                      ) = 0
                )

                SELECT
                    vf.id,
                    vf.parent_id,
                    vf.created_by,
                    vf.name,
                    vf.created_at,
                    vf.updated_at,

                    creator.display_name
                        AS owner_name,

                    CASE
                        WHEN fav.user_id IS NULL
                            THEN 0
                        ELSE 1
                    END AS is_favorite

                FROM visible_folders vf

                INNER JOIN users creator
                    ON creator.id =
                        vf.created_by

                LEFT JOIN drive_favorites fav
                    ON fav.folder_id =
                        vf.id
                   AND fav.user_id =
                        :favorite_user_id

                WHERE vf.created_by = :favorite_user_id AND vf.name LIKE
                        :folder_query
                        COLLATE NOCASE

                ORDER BY
                    vf.name COLLATE NOCASE ASC,
                    vf.id ASC

                LIMIT 100
            '
        );

    $folderStatement->execute([
        ':root_workspace_id' =>
            $workspaceId,

        ':child_workspace_id' =>
            $workspaceId,

        ':favorite_user_id' =>
            $userId,

        ':folder_query' =>
            $likeQuery,
    ]);

    $folders =
        $folderStatement->fetchAll(
            PDO::FETCH_ASSOC
        );


    foreach ($folders as &$folder) {
        $folder['id'] =
            (int) $folder['id'];

        $folder['parent_id'] =
            $folder['parent_id'] !== null
                ? (int) $folder['parent_id']
                : null;

        $folder['created_by'] =
            (int) $folder['created_by'];

        $folder['is_owner'] =
            $folder['created_by'] ===
            $userId;

        $folder['is_favorite'] =
            (int) $folder[
                'is_favorite'
            ] === 1;
    }

    unset($folder);


    /*
     * ----------------------------------------------------------------------
     * Search accessible files
     * ----------------------------------------------------------------------
     *
     * Searching for a filename does not weaken Drive authorization.
     *
     * The current user still needs:
     *
     * - drive_file_access
     * - a non-expired permission
     * - the current wrapped file key
     * - a non-trashed file
     * - a visible/non-trashed folder ancestry
     */

    $fileStatement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    path
                ) AS (
                    SELECT
                        id,
                        parent_id,
                        \'/\' || id || \'/\'

                    FROM drive_folders

                    WHERE workspace_id =
                            :root_workspace_id

                      AND parent_id IS NULL
                      AND trashed_at IS NULL


                    UNION ALL


                    SELECT
                        child.id,
                        child.parent_id,

                        visible_folders.path
                            || child.id
                            || \'/\'

                    FROM drive_folders child

                    INNER JOIN visible_folders
                        ON child.parent_id =
                            visible_folders.id

                    WHERE child.workspace_id =
                            :child_workspace_id

                      AND child.trashed_at IS NULL

                      AND instr(
                          visible_folders.path,
                          \'/\' || child.id || \'/\'
                      ) = 0
                )

                SELECT
                    df.id,
                    df.folder_id,
                    df.uploaded_by,

                    df.original_name AS name,
                    df.mime_type,
                    df.encrypted_size,
                    df.encryption_version,
                    df.key_version,
                    df.sharing_mode,
                    df.current_version,

                    df.created_at,
                    df.updated_at,

                    owner.display_name
                        AS owner_name,

                    dfa.can_edit,
                    NULL AS expires_at,

                    CASE
                        WHEN fav.user_id IS NULL
                            THEN 0
                        ELSE 1
                    END AS is_favorite

                FROM drive_files df

                INNER JOIN drive_effective_access dfa
                    ON dfa.file_id = df.id
                   AND dfa.user_id =
                        :access_user_id

                INNER JOIN drive_file_keys dfk
                    ON dfk.file_id = df.id
                   AND dfk.user_id =
                        :key_user_id
                   AND dfk.key_version =
                        df.key_version

                INNER JOIN users owner
                    ON owner.id =
                        df.uploaded_by

                LEFT JOIN visible_folders vf
                    ON vf.id =
                        df.folder_id

                LEFT JOIN drive_favorites fav
                    ON fav.file_id =
                        df.id
                   AND fav.user_id =
                        :favorite_user_id

                WHERE df.workspace_id =
                        :file_workspace_id

                  AND df.trashed_at IS NULL

                  AND (
                      df.folder_id IS NULL
                      OR vf.id IS NOT NULL
                  )

                   AND df.original_name LIKE
                        :file_query
                        COLLATE NOCASE

                ORDER BY
                    df.original_name
                        COLLATE NOCASE ASC,
                    df.id ASC

                LIMIT 100
            '
        );

    $fileStatement->execute([
        ':root_workspace_id' =>
            $workspaceId,

        ':child_workspace_id' =>
            $workspaceId,

        ':access_user_id' =>
            $userId,

        ':key_user_id' =>
            $userId,

        ':favorite_user_id' =>
            $userId,

        ':file_workspace_id' =>
            $workspaceId,

        ':file_query' =>
            $likeQuery,
    ]);

    $files =
        $fileStatement->fetchAll(
            PDO::FETCH_ASSOC
        );


    foreach ($files as &$file) {
        $file['id'] =
            (int) $file['id'];

        $file['folder_id'] =
            $file['folder_id'] !== null
                ? (int) $file['folder_id']
                : null;

        $file['uploaded_by'] =
            (int) $file['uploaded_by'];

        $file['encrypted_size'] =
            (int) $file[
                'encrypted_size'
            ];

        $file['encryption_version'] =
            (int) $file[
                'encryption_version'
            ];

        $file['key_version'] =
            (int) $file['key_version'];

        $file['current_version'] =
            (int) $file[
                'current_version'
            ];

        $file['can_edit'] =
            (bool) $file['can_edit'];

        $file['is_owner'] =
            $file['uploaded_by'] ===
            $userId;

        $file['is_favorite'] =
            (int) $file[
                'is_favorite'
            ] === 1;
    }

    unset($file);


    echo json_encode([
        'success' => true,

        'query' =>
            $query,

        'folders' =>
            $folders,

        'files' =>
            $files,

        'count' =>
            count($folders) +
            count($files),
    ]);
} catch (Throwable $error) {
    error_log(
        'Alliances Drive search failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to search Drive.',
    ]);
}