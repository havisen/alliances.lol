<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $user['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Shared by me
     * ----------------------------------------------------------------------
     *
     * A file appears here when:
     *
     * - the current user owns it
     * - it is not in Trash
     * - its complete folder ancestry is visible
     * - at least one OTHER user currently has active access
     *
     * The owner must also still have their own current key envelope.
     */

    $statement =
        $pdo->prepare(
            '
                WITH RECURSIVE visible_folders (
                    id,
                    parent_id,
                    path
                ) AS (
                    SELECT
                        id,
                        parent_id,
                        \'/\' || id || \'/\'

                    FROM drive_folders

                    WHERE workspace_id =
                            :root_workspace_id

                      AND parent_id IS NULL
                      AND trashed_at IS NULL


                    UNION ALL


                    SELECT
                        child.id,
                        child.parent_id,

                        visible_folders.path
                            || child.id
                            || \'/\'

                    FROM drive_folders child

                    INNER JOIN visible_folders
                        ON child.parent_id =
                            visible_folders.id

                    WHERE child.workspace_id =
                            :child_workspace_id

                      AND child.trashed_at IS NULL

                      AND instr(
                          visible_folders.path,
                          \'/\' || child.id || \'/\'
                      ) = 0
                )

                SELECT
                    df.id,
                    df.folder_id,
                    df.uploaded_by,

                    df.original_name AS name,
                    df.mime_type,
                    df.encrypted_size,
                    df.encryption_version,
                    df.key_version,
                    df.sharing_mode,
                    df.current_version,

                    df.created_at,
                    df.updated_at,

                    owner.display_name AS owner_name,

                    owner_access.can_edit,
                    NULL AS expires_at,

                    CASE
                        WHEN fav.user_id IS NULL
                            THEN 0
                        ELSE 1
                    END AS is_favorite,

                    (
                        SELECT COUNT(*)

                        FROM drive_file_access shared_access

                        WHERE shared_access.file_id =
                                df.id

                          AND shared_access.user_id !=
                                :shared_count_owner_id

                          AND (
                              shared_access.expires_at
                                  IS NULL

                              OR datetime(
                                  shared_access.expires_at
                              ) > CURRENT_TIMESTAMP
                          )

                          AND EXISTS (
                              SELECT 1

                              FROM drive_file_keys shared_key

                              WHERE shared_key.file_id =
                                        df.id

                                AND shared_key.user_id =
                                        shared_access.user_id

                                AND shared_key.key_version =
                                        df.key_version
                          )
                    ) AS shared_user_count

                FROM drive_files df

                INNER JOIN users owner
                    ON owner.id = df.uploaded_by

                INNER JOIN drive_effective_access owner_access
                    ON owner_access.file_id = df.id
                   AND owner_access.user_id =
                        :owner_access_user_id

                INNER JOIN drive_file_keys owner_key
                    ON owner_key.file_id = df.id
                   AND owner_key.user_id =
                        :owner_key_user_id
                   AND owner_key.key_version =
                        df.key_version

                LEFT JOIN visible_folders vf
                    ON vf.id = df.folder_id

                LEFT JOIN drive_favorites fav
                    ON fav.file_id = df.id
                   AND fav.user_id =
                        :favorite_user_id

                WHERE df.workspace_id =
                        :file_workspace_id

                  AND df.uploaded_by =
                        :owner_user_id

                  AND df.trashed_at IS NULL

                  AND (
                      df.folder_id IS NULL
                      OR vf.id IS NOT NULL
                  )

                  AND EXISTS (
                      SELECT 1

                      FROM drive_file_access other_access

                      WHERE other_access.file_id =
                                df.id

                        AND other_access.user_id !=
                                :other_access_owner_id

                        AND (
                            other_access.expires_at
                                IS NULL

                            OR datetime(
                                other_access.expires_at
                            ) > CURRENT_TIMESTAMP
                        )

                        AND EXISTS (
                            SELECT 1

                            FROM drive_file_keys other_key

                            WHERE other_key.file_id =
                                      df.id

                              AND other_key.user_id =
                                      other_access.user_id

                              AND other_key.key_version =
                                      df.key_version
                        )
                  )

                ORDER BY
                    datetime(df.updated_at) DESC,
                    df.id DESC
            '
        );

    $statement->execute([
        ':root_workspace_id' =>
            $workspaceId,

        ':child_workspace_id' =>
            $workspaceId,

        ':shared_count_owner_id' =>
            $userId,

        ':owner_access_user_id' =>
            $userId,

        ':owner_key_user_id' =>
            $userId,

        ':favorite_user_id' =>
            $userId,

        ':file_workspace_id' =>
            $workspaceId,

        ':owner_user_id' =>
            $userId,

        ':other_access_owner_id' =>
            $userId,
    ]);

    $files =
        $statement->fetchAll(
            PDO::FETCH_ASSOC
        );


    /*
     * Normalize values for JavaScript.
     */

    foreach ($files as &$file) {
        $file['id'] =
            (int) $file['id'];

        $file['folder_id'] =
            $file['folder_id'] !== null
                ? (int) $file['folder_id']
                : null;

        $file['uploaded_by'] =
            (int) $file['uploaded_by'];

        $file['encrypted_size'] =
            (int) $file[
                'encrypted_size'
            ];

        $file['encryption_version'] =
            (int) $file[
                'encryption_version'
            ];

        $file['key_version'] =
            (int) $file['key_version'];

        $file['current_version'] =
            (int) $file[
                'current_version'
            ];

        $file['can_edit'] =
            (bool) $file['can_edit'];

        $file['is_owner'] =
            true;

        $file['is_favorite'] =
            (int) $file[
                'is_favorite'
            ] === 1;

        $file['shared_user_count'] =
            (int) $file[
                'shared_user_count'
            ];
    }

    unset($file);


    echo json_encode([
        'success' => true,

        /*
         * Folder-level sharing has not been added yet.
         */
        'folders' => [],

        'files' => $files,

        'count' =>
            count($files),
    ]);
} catch (Throwable $error) {
    error_log(
        'Alliances Drive shared-by-me load failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to load files shared by you.',
    ]);
}