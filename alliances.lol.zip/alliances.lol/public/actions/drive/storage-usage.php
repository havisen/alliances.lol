<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];

try {
    $pdo = db();

    /*
     * Usage represents actual encrypted blobs retained by Drive.
     * Version 1 can share the same storage_id as drive_files, so
     * group by storage_id before summing to avoid double-counting.
     */
    $statement = $pdo->prepare(
        '
        SELECT
            COALESCE(SUM(size), 0) AS used_bytes
        FROM (
            SELECT
                storage_id,
                MAX(encrypted_size) AS size
            FROM (
                SELECT
                    storage_id,
                    encrypted_size
                FROM drive_files
                WHERE workspace_id = :workspace_id

                UNION ALL

                SELECT
                    v.storage_id,
                    v.encrypted_size
                FROM drive_file_versions AS v
                INNER JOIN drive_files AS f
                    ON f.id = v.file_id
                WHERE f.workspace_id = :workspace_id
            ) AS retained_storage
            GROUP BY storage_id
        ) AS distinct_storage
        '
    );

    $statement->execute([
        ':workspace_id' => $workspaceId,
    ]);

    $usedBytes = (int) (
        $statement->fetchColumn() ?: 0
    );

    echo json_encode([
        'success' => true,
        'used_bytes' => $usedBytes,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Alliances Drive storage usage failed: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to load Drive storage usage.',
    ]);
}
