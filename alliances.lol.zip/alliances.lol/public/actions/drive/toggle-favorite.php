<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' =>
            'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$userId =
    (int) $user['id'];

$type =
    strtolower(
        trim(
            (string) (
                $_POST['type'] ?? ''
            )
        )
    );

$itemId =
    filter_input(
        INPUT_POST,
        'item_id',
        FILTER_VALIDATE_INT
    );

if (
    !in_array(
        $type,
        [
            'file',
            'folder',
        ],
        true
    )
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' =>
            'Invalid Drive item type.',
    ]);

    exit;
}

if (
    !$itemId ||
    $itemId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' =>
            'Invalid Drive item.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
     * ----------------------------------------------------------------------
     * Verify the item is currently visible and accessible
     * ----------------------------------------------------------------------
     */

    if ($type === 'file') {
        $statement =
            $pdo->prepare(
                '
                    SELECT
                        df.id,
                        df.folder_id
                    FROM drive_files df

                    INNER JOIN drive_effective_access dfa
                        ON dfa.file_id = df.id
                       AND dfa.user_id = :user_id

                    INNER JOIN drive_file_keys dfk
                        ON dfk.file_id = df.id
                       AND dfk.user_id = :key_user_id
                       AND dfk.key_version =
                            df.key_version

                    WHERE df.id = :item_id
                      AND df.workspace_id =
                            :workspace_id
                      AND df.trashed_at IS NULL

                    LIMIT 1
                '
            );

        $statement->execute([
            ':user_id' =>
                $userId,

            ':key_user_id' =>
                $userId,

            ':item_id' =>
                $itemId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $item =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );

        if ($item === false) {
            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Drive file not found or no longer accessible.',
            ]);

            exit;
        }


        /*
         * If the file is inside a folder, verify the complete
         * ancestor chain is visible.
         */

        if ($item['folder_id'] !== null) {
            $folderId =
                (int) $item['folder_id'];

            $visitedFolderIds = [];

            while ($folderId > 0) {
                if (
                    isset(
                        $visitedFolderIds[
                            $folderId
                        ]
                    )
                ) {
                    http_response_code(409);

                    echo json_encode([
                        'success' => false,
                        'error' =>
                            'The Drive folder hierarchy is invalid.',
                    ]);

                    exit;
                }

                $visitedFolderIds[
                    $folderId
                ] = true;

                $folderStatement =
                    $pdo->prepare(
                        '
                            SELECT
                                id,
                                parent_id,
                                trashed_at
                            FROM drive_folders
                            WHERE id = :folder_id
                              AND workspace_id =
                                    :workspace_id
                            LIMIT 1
                        '
                    );

                $folderStatement->execute([
                    ':folder_id' =>
                        $folderId,

                    ':workspace_id' =>
                        $workspaceId,
                ]);

                $folder =
                    $folderStatement->fetch(
                        PDO::FETCH_ASSOC
                    );

                if (
                    $folder === false ||
                    $folder['trashed_at'] !== null
                ) {
                    http_response_code(404);

                    echo json_encode([
                        'success' => false,
                        'error' =>
                            'This file is inside a folder that is not currently available.',
                    ]);

                    exit;
                }

                $folderId =
                    $folder['parent_id'] !== null
                        ? (int) $folder[
                            'parent_id'
                        ]
                        : 0;
            }
        }
    } else {
        /*
         * Folder itself must be visible.
         */

        $statement =
            $pdo->prepare(
                '
                    SELECT
                        id,
                        parent_id,
                        trashed_at
                    FROM drive_folders
                    WHERE id = :item_id
                      AND workspace_id =
                            :workspace_id
                    LIMIT 1
                '
            );

        $statement->execute([
            ':item_id' =>
                $itemId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $folder =
            $statement->fetch(
                PDO::FETCH_ASSOC
            );

        if (
            $folder === false ||
            $folder['trashed_at'] !== null
        ) {
            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Drive folder not found.',
            ]);

            exit;
        }


        /*
         * Verify every ancestor remains visible.
         */

        $visitedFolderIds = [
            $itemId => true,
        ];

        $folderId =
            $folder['parent_id'] !== null
                ? (int) $folder['parent_id']
                : 0;

        while ($folderId > 0) {
            if (
                isset(
                    $visitedFolderIds[
                        $folderId
                    ]
                )
            ) {
                http_response_code(409);

                echo json_encode([
                    'success' => false,
                    'error' =>
                        'The Drive folder hierarchy is invalid.',
                ]);

                exit;
            }

            $visitedFolderIds[
                $folderId
            ] = true;

            $folderStatement =
                $pdo->prepare(
                    '
                        SELECT
                            id,
                            parent_id,
                            trashed_at
                        FROM drive_folders
                        WHERE id = :folder_id
                          AND workspace_id =
                                :workspace_id
                        LIMIT 1
                    '
                );

            $folderStatement->execute([
                ':folder_id' =>
                    $folderId,

                ':workspace_id' =>
                    $workspaceId,
            ]);

            $ancestor =
                $folderStatement->fetch(
                    PDO::FETCH_ASSOC
                );

            if (
                $ancestor === false ||
                $ancestor['trashed_at'] !== null
            ) {
                http_response_code(404);

                echo json_encode([
                    'success' => false,
                    'error' =>
                        'This folder is inside a folder that is not currently available.',
                ]);

                exit;
            }

            $folderId =
                $ancestor['parent_id'] !== null
                    ? (int) $ancestor[
                        'parent_id'
                    ]
                    : 0;
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Toggle favorite
     * ----------------------------------------------------------------------
     */

    $pdo->beginTransaction();

    if ($type === 'file') {
        $existingStatement =
            $pdo->prepare(
                '
                    SELECT 1
                    FROM drive_favorites
                    WHERE user_id = :user_id
                      AND file_id = :item_id
                    LIMIT 1
                '
            );
    } else {
        $existingStatement =
            $pdo->prepare(
                '
                    SELECT 1
                    FROM drive_favorites
                    WHERE user_id = :user_id
                      AND folder_id = :item_id
                    LIMIT 1
                '
            );
    }

    $existingStatement->execute([
        ':user_id' =>
            $userId,

        ':item_id' =>
            $itemId,
    ]);

    $isCurrentlyFavorite =
        $existingStatement->fetchColumn()
        !== false;


    if ($isCurrentlyFavorite) {
        /*
         * Remove favorite.
         */

        if ($type === 'file') {
            $toggleStatement =
                $pdo->prepare(
                    '
                        DELETE FROM drive_favorites
                        WHERE user_id = :user_id
                          AND file_id = :item_id
                    '
                );
        } else {
            $toggleStatement =
                $pdo->prepare(
                    '
                        DELETE FROM drive_favorites
                        WHERE user_id = :user_id
                          AND folder_id = :item_id
                    '
                );
        }

        $toggleStatement->execute([
            ':user_id' =>
                $userId,

            ':item_id' =>
                $itemId,
        ]);

        $isFavorite = false;
} else {
    /*
     * Add favorite.
     *
     * The favorites table records both the workspace and item type.
     * Only one of file_id / folder_id receives a value.
     */

    if ($type === 'file') {
        $toggleStatement =
            $pdo->prepare(
                '
                    INSERT INTO drive_favorites (
                        workspace_id,
                        user_id,
                        item_type,
                        file_id,
                        folder_id
                    )
                    VALUES (
                        :workspace_id,
                        :user_id,
                        :item_type,
                        :item_id,
                        NULL
                    )
                '
            );
    } else {
        $toggleStatement =
            $pdo->prepare(
                '
                    INSERT INTO drive_favorites (
                        workspace_id,
                        user_id,
                        item_type,
                        file_id,
                        folder_id
                    )
                    VALUES (
                        :workspace_id,
                        :user_id,
                        :item_type,
                        NULL,
                        :item_id
                    )
                '
            );
    }

    $toggleStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':user_id' =>
            $userId,

        ':item_type' =>
            $type,

        ':item_id' =>
            $itemId,
    ]);

    $isFavorite = true;
}

    $pdo->commit();


    /*
     * ----------------------------------------------------------------------
     * Response
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' => true,

        'type' =>
            $type,

        'item_id' =>
            $itemId,

        'is_favorite' =>
            $isFavorite,
    ]);
} catch (Throwable $error) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Alliances Drive favorite toggle failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to update Drive favorite.',
    ]);
}