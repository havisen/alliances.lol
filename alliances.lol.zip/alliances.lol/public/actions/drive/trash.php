<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $user['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$currentUserId =
    (int) $user['id'];

try {
    $pdo = db();

    $accessColumns =
        $pdo->query(
            'PRAGMA table_info(drive_file_access)'
        )->fetchAll(PDO::FETCH_ASSOC);

    $accessHasExpiry =
        false;

    foreach ($accessColumns as $column) {
        if (
            isset($column['name']) &&
            (string) $column['name'] === 'expires_at'
        ) {
            $accessHasExpiry =
                true;

            break;
        }
    }


    /*
     * ----------------------------------------------------------------------
     * Trashed folders
     * ----------------------------------------------------------------------
     */

    $folderStatement =
        $pdo->prepare(
            '
                SELECT
                    df.id,
                    df.parent_id,
                    df.name,
                    df.created_by,
                    df.created_at,
                    df.updated_at,
                    df.trashed_at,
                    df.trashed_by,

                    owner.display_name AS owner_name,

                    trasher.display_name AS trashed_by_name

                FROM drive_folders df

                INNER JOIN users owner
                    ON owner.id = df.created_by

                LEFT JOIN users trasher
                    ON trasher.id = df.trashed_by

                WHERE df.workspace_id = :workspace_id
                  AND df.trashed_at IS NOT NULL

                ORDER BY
                    df.trashed_at DESC,
                    df.id DESC
            '
        );

    $folderStatement->execute([
        ':workspace_id' =>
            $workspaceId,
    ]);

    $folders = [];

    while (
        $row =
            $folderStatement->fetch(
                PDO::FETCH_ASSOC
            )
    ) {
        $folders[] = [
            'id' =>
                (int) $row['id'],

            'parent_id' =>
                $row['parent_id'] !== null
                    ? (int) $row['parent_id']
                    : null,

            'name' =>
                (string) $row['name'],

            'created_by' =>
                (int) $row['created_by'],

            'owner_name' =>
                (string) $row['owner_name'],

            'trashed_by' =>
                $row['trashed_by'] !== null
                    ? (int) $row['trashed_by']
                    : null,

            'trashed_by_name' =>
                $row['trashed_by_name'] !== null
                    ? (string) $row['trashed_by_name']
                    : null,

            'created_at' =>
                (string) $row['created_at'],

            'updated_at' =>
                (string) $row['updated_at'],

            'trashed_at' =>
                (string) $row['trashed_at'],

            'is_owner' =>
                (int) $row['created_by'] ===
                $currentUserId,
        ];
    }


    /*
     * ----------------------------------------------------------------------
     * Trashed files
     * ----------------------------------------------------------------------
     *
     * A file is only returned when the current user still has:
     *
     * - a Drive access record
     * - non-expired access
     * - the current wrapped encryption-key envelope
     *
     * This prevents Trash from becoming a way to discover files that the
     * user can no longer access.
     */

    $accessExpirySelect =
        $accessHasExpiry
            ? ',
                    dfa.expires_at'
            : '';

    $accessExpiryWhere =
        $accessHasExpiry
            ? '
                  AND (
                      dfa.expires_at IS NULL
                      OR datetime(dfa.expires_at) > CURRENT_TIMESTAMP
                  )'
            : '';

    $fileStatement =
        $pdo->prepare(
            '
                SELECT
                    df.id,
                    df.folder_id,
                    df.uploaded_by,
                    df.original_name,
                    df.mime_type,
                    df.encrypted_size,
                    df.encryption_version,
                    df.key_version,
                    df.sharing_mode,
                    df.created_at,
                    df.updated_at,
                    df.trashed_at,
                    df.trashed_by,

                    owner.display_name AS owner_name,

                    trasher.display_name AS trashed_by_name,

                    dfa.can_edit
                    ' . $accessExpirySelect . '

                FROM drive_files df

                INNER JOIN drive_file_access dfa
                    ON dfa.file_id = df.id
                   AND dfa.user_id = :user_id

                INNER JOIN drive_file_keys dfk
                    ON dfk.file_id = df.id
                   AND dfk.user_id = :key_user_id
                   AND dfk.key_version = df.key_version

                INNER JOIN users owner
                    ON owner.id = df.uploaded_by

                LEFT JOIN users trasher
                    ON trasher.id = df.trashed_by

                WHERE df.workspace_id = :workspace_id
                  AND df.trashed_at IS NOT NULL
                  ' . $accessExpiryWhere . '

                ORDER BY
                    df.trashed_at DESC,
                    df.id DESC
            '
        );

    $fileStatement->execute([
        ':user_id' =>
            $currentUserId,

        ':key_user_id' =>
            $currentUserId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $files = [];

    while (
        $row =
            $fileStatement->fetch(
                PDO::FETCH_ASSOC
            )
    ) {
        $files[] = [
            'id' =>
                (int) $row['id'],

            'folder_id' =>
                $row['folder_id'] !== null
                    ? (int) $row['folder_id']
                    : null,

            'uploaded_by' =>
                (int) $row['uploaded_by'],

            'owner_name' =>
                (string) $row['owner_name'],

            'name' =>
                (string) $row['original_name'],

            'mime_type' =>
                $row['mime_type'] !== null
                    ? (string) $row['mime_type']
                    : null,

            'encrypted_size' =>
                (int) $row['encrypted_size'],

            'encryption_version' =>
                (int) $row['encryption_version'],

            'key_version' =>
                (int) $row['key_version'],

            'sharing_mode' =>
                (string) $row['sharing_mode'],

            'can_edit' =>
                (int) $row['can_edit'] === 1,

            'is_owner' =>
                (int) $row['uploaded_by'] ===
                $currentUserId,

            'trashed_by' =>
                $row['trashed_by'] !== null
                    ? (int) $row['trashed_by']
                    : null,

            'trashed_by_name' =>
                $row['trashed_by_name'] !== null
                    ? (string) $row['trashed_by_name']
                    : null,

            'created_at' =>
                (string) $row['created_at'],

            'updated_at' =>
                (string) $row['updated_at'],

            'trashed_at' =>
                (string) $row['trashed_at'],
        ];
    }


    /*
     * ----------------------------------------------------------------------
     * Return Trash
     * ----------------------------------------------------------------------
     */

    echo json_encode([
        'success' =>
            true,

        'folders' =>
            $folders,

        'files' =>
            $files,

        'counts' => [
            'folders' =>
                count($folders),

            'files' =>
                count($files),

            'total' =>
                count($folders) +
                count($files),
        ],
    ]);
} catch (Throwable $exception) {
    error_log(
        'Drive Trash list error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to load Drive Trash.',
    ]);
}
