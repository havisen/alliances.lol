<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();

header(
    'Content-Type: application/json; charset=utf-8'
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$workspaceAccess = workspace_access(
    (int) $user['id']
);

if ($workspaceAccess === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}


$userId =
    (int) $user['id'];

$workspaceId =
    (int) $workspaceAccess['workspace_id'];


/*
 * --------------------------------------------------------------------------
 * Input
 * --------------------------------------------------------------------------
 */

$fileId = filter_input(
    INPUT_POST,
    'file_id',
    FILTER_VALIDATE_INT
);

$targetUserId = filter_input(
    INPUT_POST,
    'user_id',
    FILTER_VALIDATE_INT
);

$action =
    trim(
        (string) (
            $_POST['action']
            ?? ''
        )
    );


if (
    $fileId === false
    || $fileId === null
    || $fileId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'A valid file ID is required.',
    ]);

    exit;
}


if (
    $targetUserId === false
    || $targetUserId === null
    || $targetUserId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'A valid user ID is required.',
    ]);

    exit;
}


$allowedActions = [
    'grant',
    'revoke',
    'set-edit',
];


if (
    !in_array(
        $action,
        $allowedActions,
        true
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid access action.',
    ]);

    exit;
}


try {
    $pdo = db();


    /*
     * ----------------------------------------------------------------------
     * Load file and verify the current user may manage it
     * ----------------------------------------------------------------------
     *
     * For now:
     *
     * - uploader can manage access
     * - workspace administrator can manage access
     *
     * A normal recipient cannot redistribute access merely because
     * they can decrypt the file.
     */

    $fileStatement = $pdo->prepare(
        '
        SELECT
            id,
            workspace_id,
            uploaded_by,
            original_name,
            key_version,
            sharing_mode
        FROM drive_files
        WHERE
            id = :file_id
            AND workspace_id = :workspace_id
        LIMIT 1
        '
    );

    $fileStatement->execute([
        ':file_id' =>
            $fileId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $file =
        $fileStatement->fetch();


    if (!$file) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'File not found.',
        ]);

        exit;
    }


    $isUploader =
        (int) $file['uploaded_by']
        === $userId;

    $isWorkspaceAdmin =
        !empty(
            $workspaceAccess['is_admin']
        );


    if (
        !$isUploader
        && !$isWorkspaceAdmin
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'You are not allowed to manage access to this file.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Verify target user belongs to this workspace
     * ----------------------------------------------------------------------
     */

    $memberStatement = $pdo->prepare(
        '
        SELECT wm.user_id
        FROM workspace_members wm
        INNER JOIN users u
            ON u.id = wm.user_id
        WHERE
            wm.workspace_id = :workspace_id
            AND wm.user_id = :user_id
            AND u.account_status = "active"
        LIMIT 1
        '
    );

    $memberStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':user_id' =>
            $targetUserId,
    ]);


    if (!$memberStatement->fetch()) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'That user is not a member of this workspace.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Protect uploader
     * ----------------------------------------------------------------------
     *
     * The uploader must always retain access to the file.
     */

    if (
        $targetUserId ===
            (int) $file['uploaded_by']
        && $action === 'revoke'
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'The file uploader cannot have access revoked.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Grant
     * ----------------------------------------------------------------------
     *
     * IMPORTANT:
     *
     * The server cannot generate the target user's wrapped AES key.
     * That must happen in the browser after decrypting the existing
     * file key locally.
     *
     * Therefore the browser must send encrypted_key when granting.
     */

    if ($action === 'grant') {
        $encryptedKey =
            trim(
                (string) (
                    $_POST['encrypted_key']
                    ?? ''
                )
            );


        if (
            $encryptedKey === ''
            || !str_starts_with(
                $encryptedKey,
                '-----BEGIN PGP MESSAGE-----'
            )
            || !str_contains(
                $encryptedKey,
                '-----END PGP MESSAGE-----'
            )
        ) {
            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'A valid encrypted file key is required.',
            ]);

            exit;
        }


        $pdo->beginTransaction();

        try {
            /*
             * Add access if it does not already exist.
             */
$accessStatement = $pdo->prepare(
    '
    INSERT INTO drive_file_access (
        file_id,
        user_id,
        can_edit,
        granted_by
    )
    VALUES (
        :file_id,
        :user_id,
        0,
        :granted_by
    )
    ON CONFLICT(file_id, user_id)
    DO UPDATE SET
        granted_by = excluded.granted_by
    '
);

$accessStatement->execute([
    ':file_id' =>
        $fileId,

    ':user_id' =>
        $targetUserId,

    ':granted_by' =>
        $userId,
]);


            /*
             * Store only the OpenPGP-wrapped AES file key.
             */
            $keyStatement = $pdo->prepare(
                '
                INSERT INTO drive_file_keys (
                    file_id,
                    user_id,
                    key_version,
                    encrypted_key
                )
                VALUES (
                    :file_id,
                    :user_id,
                    :key_version,
                    :encrypted_key
                )
                ON CONFLICT(
                    file_id,
                    user_id,
                    key_version
                )
                DO UPDATE SET
                    encrypted_key =
                        excluded.encrypted_key
                '
            );

            $keyStatement->execute([
                ':file_id' =>
                    $fileId,

                ':user_id' =>
                    $targetUserId,

                ':key_version' =>
                    (int) $file['key_version'],

                ':encrypted_key' =>
                    $encryptedKey,
            ]);


            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            throw $error;
        }

        create_notification([
            'workspace_id' => $workspaceId,
            'user_id' => $targetUserId,
            'actor_user_id' => $userId,
            'type' => 'drive_shared',
            'category' => 'drive',
            'title' => (string) $user['display_name']
                . ' shared a Drive file with you',
            'body' => (string) ($file['original_name'] ?? 'Drive file'),
            'target_type' => 'drive_file',
            'target_id' => $fileId,
            'target_url' => '/drive/',
        ]);


        echo json_encode([
            'success' => true,
            'action' => 'grant',
            'file_id' => $fileId,
            'user_id' => $targetUserId,
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Revoke
     * ----------------------------------------------------------------------
     *
     * This removes future server access and the server-side copy of
     * this user's wrapped current file key.
     *
     * It cannot revoke plaintext or key material that the recipient
     * previously downloaded while authorized.
     */

    if ($action === 'revoke') {
        $pdo->beginTransaction();

        try {
            $deleteKeys = $pdo->prepare(
                '
                DELETE FROM drive_file_keys
                WHERE
                    file_id = :file_id
                    AND user_id = :user_id
                '
            );

            $deleteKeys->execute([
                ':file_id' =>
                    $fileId,

                ':user_id' =>
                    $targetUserId,
            ]);


            $deleteAccess = $pdo->prepare(
                '
                DELETE FROM drive_file_access
                WHERE
                    file_id = :file_id
                    AND user_id = :user_id
                '
            );

            $deleteAccess->execute([
                ':file_id' =>
                    $fileId,

                ':user_id' =>
                    $targetUserId,
            ]);


            $pdo->commit();
        } catch (Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            throw $error;
        }

        create_notification([
            'workspace_id' => $workspaceId,
            'user_id' => $targetUserId,
            'actor_user_id' => $userId,
            'type' => 'drive_access_revoked',
            'category' => 'drive',
            'title' => 'Drive file access was removed',
            'body' => (string) ($file['original_name'] ?? 'Drive file'),
            'target_type' => 'drive_file',
            'target_id' => $fileId,
            'target_url' => '/drive/',
        ]);


        echo json_encode([
            'success' => true,
            'action' => 'revoke',
            'file_id' => $fileId,
            'user_id' => $targetUserId,
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Set edit permission
     * ----------------------------------------------------------------------
     */

    if ($action === 'set-edit') {
        $canEditRaw =
            (string) (
                $_POST['can_edit']
                ?? ''
            );


        if (
            $canEditRaw !== '0'
            && $canEditRaw !== '1'
        ) {
            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Invalid edit permission.',
            ]);

            exit;
        }


        $canEdit =
            $canEditRaw === '1'
                ? 1
                : 0;


        /*
         * The uploader always keeps edit permission.
         */
        if (
            $targetUserId ===
            (int) $file['uploaded_by']
            && $canEdit === 0
        ) {
            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'The file uploader must retain edit permission.',
            ]);

            exit;
        }


        /*
         * Editing only makes sense when the target user currently
         * has both access and a current wrapped key.
         */
        $accessCheck = $pdo->prepare(
            '
            SELECT
                a.user_id
            FROM drive_file_access AS a
            INNER JOIN drive_file_keys AS k
                ON k.file_id = a.file_id
                AND k.user_id = a.user_id
                AND k.key_version = :key_version
            WHERE
                a.file_id = :file_id
                AND a.user_id = :user_id
            LIMIT 1
            '
        );

        $accessCheck->execute([
            ':key_version' =>
                (int) $file['key_version'],

            ':file_id' =>
                $fileId,

            ':user_id' =>
                $targetUserId,
        ]);


        if (!$accessCheck->fetch()) {
            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'That user does not currently have access to this file.',
            ]);

            exit;
        }


        $updateStatement = $pdo->prepare(
            '
            UPDATE drive_file_access
            SET can_edit = :can_edit
            WHERE
                file_id = :file_id
                AND user_id = :user_id
            '
        );

        $updateStatement->execute([
            ':can_edit' =>
                $canEdit,

            ':file_id' =>
                $fileId,

            ':user_id' =>
                $targetUserId,
        ]);

        create_notification([
            'workspace_id' => $workspaceId,
            'user_id' => $targetUserId,
            'actor_user_id' => $userId,
            'type' => 'drive_access_changed',
            'category' => 'drive',
            'title' => 'Drive file access changed',
            'body' => (
                $canEdit === 1
                    ? 'You can now edit '
                    : 'Your edit access changed for '
                )
                . (string) ($file['original_name'] ?? 'Drive file'),
            'target_type' => 'drive_file',
            'target_id' => $fileId,
            'target_url' => '/drive/',
        ]);


        echo json_encode([
            'success' => true,
            'action' => 'set-edit',
            'file_id' => $fileId,
            'user_id' => $targetUserId,
            'can_edit' => $canEdit === 1,
        ]);

        exit;
    }


    /*
     * This should never be reached because action was validated
     * above.
     */
    throw new RuntimeException(
        'Unhandled Drive access action.'
    );
} catch (Throwable $error) {
    if (
        isset($pdo)
        && $pdo instanceof PDO
        && $pdo->inTransaction()
    ) {
        $pdo->rollBack();
    }

    /*
     * Keep the real error in the server log.
     * Never expose database details to the browser.
     */
    error_log(
        'Drive access update error: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Unable to update file access.',
    ]);

    exit;
}
