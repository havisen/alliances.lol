<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/drive/drive.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();
require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];
$currentUserId = (int) $user['id'];


/*
 * --------------------------------------------------------------------------
 * Validate metadata
 * --------------------------------------------------------------------------
 */

$originalName = trim((string) ($_POST['original_name'] ?? ''));
$mimeType = trim((string) ($_POST['mime_type'] ?? ''));
$sharingMode = trim((string) ($_POST['sharing_mode'] ?? 'selected'));

$folderIdRaw = $_POST['folder_id'] ?? '';
$folderId = null;

if ($folderIdRaw !== '' && $folderIdRaw !== null) {
    $validatedFolderId = filter_var(
        $folderIdRaw,
        FILTER_VALIDATE_INT,
        [
            'options' => [
                'min_range' => 1,
            ],
        ]
    );

    if ($validatedFolderId === false) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid folder.',
        ]);

        exit;
    }

    $folderId = (int) $validatedFolderId;
}


if ($originalName === '') {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'The file name is required.',
    ]);

    exit;
}


if (strlen($originalName) > 255) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'The file name is too long.',
    ]);

    exit;
}


if (strlen($mimeType) > 255) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'The MIME type is too long.',
    ]);

    exit;
}


if (!in_array($sharingMode, ['selected', 'workspace'], true)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid sharing mode.',
    ]);

    exit;
}


/*
 * --------------------------------------------------------------------------
 * Validate encrypted key envelopes
 * --------------------------------------------------------------------------
 */

$keyEnvelopesJson = $_POST['key_envelopes'] ?? '';

if (!is_string($keyEnvelopesJson) || $keyEnvelopesJson === '') {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted file keys are required.',
    ]);

    exit;
}


try {
    $decodedEnvelopes = json_decode(
        $keyEnvelopesJson,
        true,
        512,
        JSON_THROW_ON_ERROR
    );
} catch (JsonException $exception) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encrypted file-key data.',
    ]);

    exit;
}


if (!is_array($decodedEnvelopes) || $decodedEnvelopes === []) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'At least one encrypted file key is required.',
    ]);

    exit;
}


$keyEnvelopes = [];
$envelopeUserIds = [];

foreach ($decodedEnvelopes as $envelope) {
    if (!is_array($envelope)) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid encrypted file-key entry.',
        ]);

        exit;
    }

    $userId = filter_var(
        $envelope['user_id'] ?? null,
        FILTER_VALIDATE_INT,
        [
            'options' => [
                'min_range' => 1,
            ],
        ]
    );

    $encryptedKey = trim(
        (string) ($envelope['encrypted_key'] ?? '')
    );

    if ($userId === false) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid file-key user.',
        ]);

        exit;
    }

    $userId = (int) $userId;

    if (isset($envelopeUserIds[$userId])) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Duplicate encrypted file-key user.',
        ]);

        exit;
    }

    if (
        !str_starts_with(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid encrypted file key.',
        ]);

        exit;
    }

    if (strlen($encryptedKey) > 65535) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Encrypted file key is too large.',
        ]);

        exit;
    }

    $envelopeUserIds[$userId] = true;

    $keyEnvelopes[] = [
        'user_id' => $userId,
        'encrypted_key' => $encryptedKey,
    ];
}

$requestedUserIds = array_keys($envelopeUserIds);
sort($requestedUserIds);


/*
 * The uploader must always retain access to their own upload.
 */
if (!in_array($currentUserId, $requestedUserIds, true)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Your own encrypted file key is missing.',
    ]);

    exit;
}


/*
 * --------------------------------------------------------------------------
 * Validate encrypted file upload
 * --------------------------------------------------------------------------
 */

if (
    !isset($_FILES['encrypted_file'])
    || !is_array($_FILES['encrypted_file'])
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted file data is required.',
    ]);

    exit;
}

$uploadedFile = $_FILES['encrypted_file'];

if (
    !isset(
        $uploadedFile['error'],
        $uploadedFile['tmp_name'],
        $uploadedFile['size']
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encrypted file upload.',
    ]);

    exit;
}

if ((int) $uploadedFile['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'The encrypted file upload failed.',
    ]);

    exit;
}

$tmpName = (string) $uploadedFile['tmp_name'];
$encryptedSize = (int) $uploadedFile['size'];

if (
    $encryptedSize <= 0
    || !is_uploaded_file($tmpName)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'The encrypted file is empty or invalid.',
    ]);

    exit;
}


/*
 * --------------------------------------------------------------------------
 * Verify folder, workspace membership and sharing rules
 * --------------------------------------------------------------------------
 */

$pdo = db();

$storageId = '';
$storagePath = '';

try {
    if ($folderId !== null) {
        $folderStatement = $pdo->prepare(
            '
            SELECT id
            FROM drive_folders
            WHERE id = :folder_id
              AND workspace_id = :workspace_id
            LIMIT 1
            '
        );

        $folderStatement->execute([
            ':folder_id' => $folderId,
            ':workspace_id' => $workspaceId,
        ]);

        if ($folderStatement->fetch(PDO::FETCH_ASSOC) === false) {
            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' => 'Folder not found.',
            ]);

            exit;
        }
    }


    /*
     * Get the complete current workspace member set.
     */
    $memberStatement = $pdo->prepare(
        '
        SELECT user_id
        FROM workspace_members
        WHERE workspace_id = :workspace_id
        '
    );

    $memberStatement->execute([
        ':workspace_id' => $workspaceId,
    ]);

    $workspaceUserIds = array_map(
        'intval',
        $memberStatement->fetchAll(PDO::FETCH_COLUMN)
    );

    sort($workspaceUserIds);


    /*
     * Every envelope recipient must belong to this workspace.
     */
    foreach ($requestedUserIds as $requestedUserId) {
        if (!in_array($requestedUserId, $workspaceUserIds, true)) {
            http_response_code(403);

            echo json_encode([
                'success' => false,
                'error' => 'A file-key recipient is not a workspace member.',
            ]);

            exit;
        }
    }


    /*
     * Workspace sharing requires an envelope for EVERY current
     * workspace member.
     */
    if (
        $sharingMode === 'workspace'
        && $requestedUserIds !== $workspaceUserIds
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Workspace-shared files require an encrypted key for every workspace member.',
        ]);

        exit;
    }


    /*
     * ----------------------------------------------------------------------
     * Generate private storage destination
     * ----------------------------------------------------------------------
     */

    do {
        $storageId = drive_generate_storage_id();
        $storagePath = drive_file_path($storageId);
    } while (is_file($storagePath));

    drive_ensure_file_directory($storageId);


    /*
     * Store only the already-encrypted bytes.
     */
    if (!move_uploaded_file($tmpName, $storagePath)) {
        throw new RuntimeException(
            'Unable to store encrypted Drive file.'
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Store metadata + access + encrypted key envelopes atomically
     * ----------------------------------------------------------------------
     */

    $pdo->beginTransaction();

    $fileStatement = $pdo->prepare(
        '
        INSERT INTO drive_files (
            workspace_id,
            folder_id,
            uploaded_by,
            storage_id,
            original_name,
            mime_type,
            encrypted_size,
            encryption_version,
            key_version,
            sharing_mode
        )
        VALUES (
            :workspace_id,
            :folder_id,
            :uploaded_by,
            :storage_id,
            :original_name,
            :mime_type,
            :encrypted_size,
            1,
            1,
            :sharing_mode
        )
        '
    );

    $fileStatement->execute([
        ':workspace_id' => $workspaceId,
        ':folder_id' => $folderId,
        ':uploaded_by' => $currentUserId,
        ':storage_id' => $storageId,
        ':original_name' => $originalName,
        ':mime_type' => $mimeType !== '' ? $mimeType : null,
        ':encrypted_size' => $encryptedSize,
        ':sharing_mode' => $sharingMode,
    ]);

    $fileId = (int) $pdo->lastInsertId();

    /*
 * ----------------------------------------------------------------------
 * Record the original encrypted upload as Version 1
 * ----------------------------------------------------------------------
 *
 * The encrypted blob already stored in drive_files.storage_id is also
 * the first entry in the file's version history.
 *
 * Both records intentionally reference the same encrypted storage blob.
 * We do NOT make another physical copy of the file.
 */

$versionStatement = $pdo->prepare(
    '
    INSERT INTO drive_file_versions (
        file_id,
        version_number,
        created_by,
        storage_id,
        encrypted_size,
        encryption_version,
        key_version
    )
    VALUES (
        :file_id,
        1,
        :created_by,
        :storage_id,
        :encrypted_size,
        1,
        1
    )
    '
);

$versionStatement->execute([
    ':file_id' =>
        $fileId,

    ':created_by' =>
        $currentUserId,

    ':storage_id' =>
        $storageId,

    ':encrypted_size' =>
        $encryptedSize,
]);

    $activityStatement = $pdo->prepare(
        '
        INSERT INTO drive_file_activity (
            workspace_id,
            file_id,
            actor_user_id,
            action,
            details_json
        )
        VALUES (
            :workspace_id,
            :file_id,
            :actor_user_id,
            :action,
            :details_json
        )
        '
    );

    $activityStatement->execute([
        ':workspace_id' => $workspaceId,
        ':file_id' => $fileId,
        ':actor_user_id' => $currentUserId,
        ':action' => 'file_uploaded',
        ':details_json' => json_encode(
            [
                'name' => $originalName,
                'version_number' => 1,
            ],
            JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
        ),
    ]);

    $accessStatement = $pdo->prepare(
        '
        INSERT INTO drive_file_access (
            file_id,
            user_id,
            granted_by,
            can_edit
        )
        VALUES (
            :file_id,
            :user_id,
            :granted_by,
            :can_edit
        )
        '
    );


    $keyStatement = $pdo->prepare(
        '
        INSERT INTO drive_file_keys (
            file_id,
            user_id,
            key_version,
            encrypted_key
        )
        VALUES (
            :file_id,
            :user_id,
            1,
            :encrypted_key
        )
        '
    );


    foreach ($keyEnvelopes as $envelope) {
        $recipientUserId = (int) $envelope['user_id'];

        /*
         * Initially every recipient can view/download.
         *
         * The uploader receives edit rights because future
         * DOCX/XLSX/PDF editing will require them.
         *
         * We will add configurable editing permissions when
         * access management is implemented.
         */
        $accessStatement->execute([
            ':file_id' => $fileId,
            ':user_id' => $recipientUserId,
            ':granted_by' => $currentUserId,
            ':can_edit' =>
                $recipientUserId === $currentUserId ? 1 : 0,
        ]);

        $keyStatement->execute([
            ':file_id' => $fileId,
            ':user_id' => $recipientUserId,
            ':encrypted_key' => $envelope['encrypted_key'],
        ]);
    }


    $pdo->commit();


    echo json_encode([
        'success' => true,
        'file' => [
            'id' => $fileId,
            'name' => $originalName,
            'mime_type' => $mimeType !== '' ? $mimeType : null,
            'encrypted_size' => $encryptedSize,
            'sharing_mode' => $sharingMode,
            'key_version' => 1,
        ],
    ]);
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    /*
     * If the encrypted blob reached disk but the database operation
     * failed, remove the orphaned encrypted file.
     */
    if (
        $storageId !== ''
        && $storagePath !== ''
        && is_file($storagePath)
    ) {
        try {
            drive_delete_stored_file($storageId);
        } catch (Throwable $cleanupException) {
            error_log(
                'Drive upload cleanup error: '
                . $cleanupException->getMessage()
            );
        }
    }

    error_log(
        'Drive upload error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to save the encrypted file.',
    ]);
}
