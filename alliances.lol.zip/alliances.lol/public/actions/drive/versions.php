<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, private');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed.']);
    exit;
}

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'You do not have access to a workspace.']);
    exit;
}

$fileId = filter_input(INPUT_GET, 'file_id', FILTER_VALIDATE_INT);

if ($fileId === false || $fileId === null || $fileId <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid Drive file.']);
    exit;
}

$userId = (int) $user['id'];
$workspaceId = (int) $access['workspace_id'];

try {
    $pdo = db();

    $fileStatement = $pdo->prepare(
        '
        SELECT
            f.id,
            f.original_name,
            f.current_version,
            f.trashed_at,
            a.can_edit
        FROM drive_files AS f
        INNER JOIN drive_effective_access AS a
            ON a.file_id = f.id
           AND a.user_id = :user_id
        INNER JOIN drive_file_keys AS k
            ON k.file_id = f.id
           AND k.user_id = :key_user_id
           AND k.key_version = f.key_version
        WHERE f.id = :file_id
          AND f.workspace_id = :workspace_id
        LIMIT 1
        '
    );

    $fileStatement->execute([
        ':user_id' => $userId,
        ':key_user_id' => $userId,
        ':file_id' => $fileId,
        ':workspace_id' => $workspaceId,
    ]);

    $file = $fileStatement->fetch();

    if (!$file) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'File not found or access is unavailable.']);
        exit;
    }

    $versionsStatement = $pdo->prepare(
        '
        SELECT
            v.id,
            v.version_number,
            v.encrypted_size,
            v.encryption_version,
            v.key_version,
            v.created_at,
            u.display_name AS created_by_name
        FROM drive_file_versions AS v
        LEFT JOIN users AS u
            ON u.id = v.created_by
        WHERE v.file_id = :file_id
        ORDER BY v.version_number DESC
        LIMIT 50
        '
    );

    $versionsStatement->execute([
        ':file_id' => $fileId,
    ]);

    $versions = [];

    while ($row = $versionsStatement->fetch()) {
        $versionNumber = (int) $row['version_number'];

        $versions[] = [
            'id' => (int) $row['id'],
            'version_number' => $versionNumber,
            'encrypted_size' => (int) $row['encrypted_size'],
            'encryption_version' => (int) $row['encryption_version'],
            'key_version' => (int) $row['key_version'],
            'created_at' => (string) $row['created_at'],
            'created_by_name' => (string) ($row['created_by_name'] ?? 'Unknown user'),
            'is_current' => $versionNumber === (int) $file['current_version'],
        ];
    }

    echo json_encode([
        'success' => true,
        'file' => [
            'id' => (int) $file['id'],
            'name' => (string) $file['original_name'],
            'current_version' => (int) $file['current_version'],
            'can_edit' => (int) $file['can_edit'] === 1,
            'is_trashed' => $file['trashed_at'] !== null,
        ],
        'versions' => $versions,
    ]);
} catch (Throwable $exception) {
    error_log('Drive versions load failed: ' . $exception->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Unable to load file versions.']);
}
