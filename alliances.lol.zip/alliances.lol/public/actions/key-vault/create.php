<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/key-vault/vault.php';

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'error' => 'Method not allowed.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF protection
|--------------------------------------------------------------------------
*/

require_valid_csrf();

/*
|--------------------------------------------------------------------------
| Read encrypted Key Vault
|--------------------------------------------------------------------------
|
| The browser sends:
|
| csrf_token = CSRF token
| vault      = encrypted Key Vault envelope as JSON
|
| The Key Vault password and plaintext vault are never sent here.
|
*/

$vaultJson = $_POST['vault'] ?? '';

if (!is_string($vaultJson) || $vaultJson === '') {
    http_response_code(400);

    echo json_encode([
        'error' => 'Missing Key Vault.',
    ]);

    exit;
}

$vault = json_decode(
    $vaultJson,
    true
);

if (!is_array($vault)) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Invalid Key Vault.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Validate Key Vault envelope
|--------------------------------------------------------------------------
*/

if (
    ($vault['format'] ?? null) !== 'alliances-key-vault'
    || ($vault['version'] ?? null) !== 1
) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Unsupported Key Vault format.',
    ]);

    exit;
}

$kdf = $vault['kdf'] ?? null;
$encryption = $vault['encryption'] ?? null;

if (
    !is_array($kdf)
    || ($kdf['algorithm'] ?? null) !== 'PBKDF2'
    || ($kdf['hash'] ?? null) !== 'SHA-256'
    || ($kdf['iterations'] ?? null) !== 600000
    || !is_string($kdf['salt'] ?? null)
    || $kdf['salt'] === ''
) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Invalid Key Vault KDF configuration.',
    ]);

    exit;
}

if (
    !is_array($encryption)
    || ($encryption['algorithm'] ?? null) !== 'AES-GCM'
    || ($encryption['keyLength'] ?? null) !== 256
    || ($encryption['tagLength'] ?? null) !== 128
    || !is_string($encryption['iv'] ?? null)
    || $encryption['iv'] === ''
    || !is_string($encryption['ciphertext'] ?? null)
    || $encryption['ciphertext'] === ''
) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Invalid Key Vault encryption data.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Validate encoded cryptographic data
|--------------------------------------------------------------------------
*/

$salt = base64_decode(
    $kdf['salt'],
    true
);

$iv = base64_decode(
    $encryption['iv'],
    true
);

$ciphertext = base64_decode(
    $encryption['ciphertext'],
    true
);

if (
    $salt === false
    || strlen($salt) !== 16
) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Invalid Key Vault salt.',
    ]);

    exit;
}

if (
    $iv === false
    || strlen($iv) !== 12
) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Invalid Key Vault IV.',
    ]);

    exit;
}

if (
    $ciphertext === false
    || strlen($ciphertext) < 17
) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Invalid Key Vault ciphertext.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Make sure the user does not already have a Key Vault
|--------------------------------------------------------------------------
*/

if (key_vault_exists((int) $currentUser['id'])) {
    http_response_code(409);

    echo json_encode([
        'error' => 'A Key Vault already exists.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Encode encrypted envelope for storage
|--------------------------------------------------------------------------
*/

$encryptedVault = json_encode(
    $vault,
    JSON_UNESCAPED_SLASHES
);

if ($encryptedVault === false) {
    http_response_code(400);

    echo json_encode([
        'error' => 'Could not encode Key Vault.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Store encrypted Key Vault
|--------------------------------------------------------------------------
*/

try {
    create_key_vault(
        (int) $currentUser['id'],
        $encryptedVault,
        1
    );
} catch (Throwable $exception) {
    http_response_code(500);

    echo json_encode([
        'error' => 'Could not create Key Vault.',
    ]);

    exit;
}

echo json_encode([
    'success' => true,
]);

exit;