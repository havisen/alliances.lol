<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/key-vault/vault.php';

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$vault = load_key_vault((int) $currentUser['id']);

if ($vault === null) {
    echo json_encode([
        'exists' => false,
    ]);

    exit;
}

$encryptedVault = json_decode(
    $vault['encrypted_vault'],
    true
);

if (!is_array($encryptedVault)) {
    http_response_code(500);

    echo json_encode([
        'error' => 'Stored Key Vault is invalid.',
    ]);

    exit;
}

echo json_encode([
    'exists' => true,

    'formatVersion' => (int) $vault['format_version'],

    'vault' => $encryptedVault,
]);

exit;