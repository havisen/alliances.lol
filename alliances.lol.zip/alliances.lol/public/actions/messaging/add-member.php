<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/messaging/messaging.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access is required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$currentUserId =
    (int) $user['id'];


/*
|--------------------------------------------------------------------------
| Request data
|--------------------------------------------------------------------------
*/

$conversationId =
    filter_input(
        INPUT_POST,
        'conversation_id',
        FILTER_VALIDATE_INT
    );

$addUserId =
    filter_input(
        INPUT_POST,
        'user_id',
        FILTER_VALIDATE_INT
    );

$newKeyVersion =
    filter_input(
        INPUT_POST,
        'key_version',
        FILTER_VALIDATE_INT
    );

$keyEnvelopesJson =
    $_POST['key_envelopes']
    ?? '';


if (
    !$conversationId
    || $conversationId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation.',
    ]);

    exit;
}


if (
    !$addUserId
    || $addUserId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid member.',
    ]);

    exit;
}


if (
    !$newKeyVersion
    || $newKeyVersion <= 1
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation key version.',
    ]);

    exit;
}


if (
    !is_string($keyEnvelopesJson)
    || $keyEnvelopesJson === ''
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted key envelopes are required.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Decode encrypted key envelopes
|--------------------------------------------------------------------------
*/

try {
    $decodedEnvelopes =
        json_decode(
            $keyEnvelopesJson,
            true,
            512,
            JSON_THROW_ON_ERROR
        );
} catch (JsonException $exception) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encrypted key envelopes.',
    ]);

    exit;
}


if (
    !is_array($decodedEnvelopes)
    || $decodedEnvelopes === []
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted key envelopes are required.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Validate encrypted key envelopes
|--------------------------------------------------------------------------
|
| The browser generates the replacement AES key.
|
| PHP receives only an OpenPGP-encrypted copy of that key for each
| member who should have access to the new key version.
|
*/

$keyEnvelopes = [];

$envelopeUserIds = [];

foreach ($decodedEnvelopes as $envelope) {
    if (!is_array($envelope)) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid encrypted key envelope.',
        ]);

        exit;
    }

    $envelopeUserId =
        filter_var(
            $envelope['user_id'] ?? null,
            FILTER_VALIDATE_INT
        );

    $envelopeKeyVersion =
        filter_var(
            $envelope['key_version'] ?? null,
            FILTER_VALIDATE_INT
        );

    $encryptedKey =
        $envelope['encrypted_key']
        ?? null;


    if (
        !$envelopeUserId
        || $envelopeUserId <= 0
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid key-envelope member.',
        ]);

        exit;
    }


    if (
        !$envelopeKeyVersion
        || $envelopeKeyVersion
            !== $newKeyVersion
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid key-envelope version.',
        ]);

        exit;
    }


    if (
        !is_string($encryptedKey)
        || $encryptedKey === ''
        || strlen($encryptedKey) > 100000
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid encrypted conversation key.',
        ]);

        exit;
    }


    if (
        !str_contains(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
        || !str_contains(
            $encryptedKey,
            '-----END PGP MESSAGE-----'
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid OpenPGP key envelope.',
        ]);

        exit;
    }


    if (
        in_array(
            (int) $envelopeUserId,
            $envelopeUserIds,
            true
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Duplicate key-envelope member.',
        ]);

        exit;
    }


    $envelopeUserIds[] =
        (int) $envelopeUserId;

    $keyEnvelopes[] = [
        'user_id' =>
            (int) $envelopeUserId,

        'key_version' =>
            (int) $envelopeKeyVersion,

        'encrypted_key' =>
            $encryptedKey,
    ];
}


/*
|--------------------------------------------------------------------------
| Perform membership change + key rotation
|--------------------------------------------------------------------------
*/

$pdo = db();

try {
    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Load conversation and requester's role
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                c.id,
                c.type,
                c.key_version,
                cm.role AS requester_role
            FROM conversations AS c
            INNER JOIN conversation_members AS cm
                ON cm.conversation_id = c.id
                AND cm.user_id = :current_user_id
            WHERE
                c.id = :conversation_id
                AND c.workspace_id = :workspace_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':current_user_id' =>
            $currentUserId,

        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $conversation =
        $statement->fetch();


    if (!$conversation) {
        $pdo->rollBack();

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation not found.',
        ]);

        exit;
    }


    /*
     * Direct messages always remain exactly
     * two-person conversations.
     */
    if (
        $conversation['type']
        === 'direct'
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Members cannot be added to direct messages.',
        ]);

        exit;
    }


    /*
     * Only conversation owners and admins
     * may add members.
     */
    $requesterRole =
        (string) $conversation[
            'requester_role'
        ];

    if (
        $requesterRole !== 'owner'
        && $requesterRole !== 'admin'
    ) {
        $pdo->rollBack();

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' => 'You cannot add members to this conversation.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Verify new member belongs to this workspace
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                wm.user_id
            FROM workspace_members AS wm
            WHERE
                wm.workspace_id = :workspace_id
                AND wm.user_id = :user_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':user_id' =>
            (int) $addUserId,
    ]);

    if (!$statement->fetch()) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'The selected user is not a workspace member.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Make sure user is not already a member
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                user_id
            FROM conversation_members
            WHERE
                conversation_id = :conversation_id
                AND user_id = :user_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':user_id' =>
            (int) $addUserId,
    ]);

    if ($statement->fetch()) {
        $pdo->rollBack();

        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'This user is already a conversation member.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Validate next key version
    |--------------------------------------------------------------------------
    */

    $currentKeyVersion =
        (int) $conversation[
            'key_version'
        ];

    $expectedKeyVersion =
        $currentKeyVersion + 1;


    if (
        (int) $newKeyVersion
        !== $expectedKeyVersion
    ) {
        $pdo->rollBack();

        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'The conversation encryption key changed. Reload and try again.',
            'current_key_version' =>
                $currentKeyVersion,
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Load existing conversation members
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                user_id
            FROM conversation_members
            WHERE
                conversation_id = :conversation_id
            ORDER BY user_id ASC
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,
    ]);

    $existingMemberIds =
        array_map(
            static fn (array $row): int =>
                (int) $row['user_id'],

            $statement->fetchAll()
        );


    /*
     * The replacement key must be wrapped
     * for every existing member AND the
     * newly added member.
     */
    $newMemberIds =
        $existingMemberIds;

    $newMemberIds[] =
        (int) $addUserId;

    $newMemberIds =
        array_values(
            array_unique(
                $newMemberIds
            )
        );

    sort(
        $newMemberIds,
        SORT_NUMERIC
    );

    $submittedEnvelopeIds =
        $envelopeUserIds;

    sort(
        $submittedEnvelopeIds,
        SORT_NUMERIC
    );


    if (
        $submittedEnvelopeIds
        !== $newMemberIds
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Encrypted key envelopes do not match the new conversation membership.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Re-check every resulting member belongs to workspace
    |--------------------------------------------------------------------------
    */

    $placeholders =
        implode(
            ', ',
            array_fill(
                0,
                count($newMemberIds),
                '?'
            )
        );

    $statement =
        $pdo->prepare(
            '
            SELECT
                user_id
            FROM workspace_members
            WHERE
                workspace_id = ?
                AND user_id IN ('
                . $placeholders .
                ')
            '
        );

    $statement->execute([
        $workspaceId,
        ...$newMemberIds,
    ]);

    $workspaceMemberIds =
        array_map(
            static fn (array $row): int =>
                (int) $row['user_id'],

            $statement->fetchAll()
        );

    sort(
        $workspaceMemberIds,
        SORT_NUMERIC
    );


    if (
        $workspaceMemberIds
        !== $newMemberIds
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'One or more conversation members no longer belong to this workspace.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Insert new key envelopes
    |--------------------------------------------------------------------------
    |
    | This happens before the new member is inserted.
    |
    | If anything fails, the transaction rolls back
    | everything.
    |
    */

    $insertKey =
        $pdo->prepare(
            '
            INSERT INTO conversation_keys (
                conversation_id,
                user_id,
                key_version,
                encrypted_key
            )
            VALUES (
                :conversation_id,
                :user_id,
                :key_version,
                :encrypted_key
            )
            '
        );

    foreach ($keyEnvelopes as $envelope) {
        $insertKey->execute([
            ':conversation_id' =>
                (int) $conversationId,

            ':user_id' =>
                $envelope['user_id'],

            ':key_version' =>
                (int) $newKeyVersion,

            ':encrypted_key' =>
                $envelope[
                    'encrypted_key'
                ],
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Add new member
    |--------------------------------------------------------------------------
    |
    | Newly added people start as ordinary members.
    |
    */

    $statement =
        $pdo->prepare(
            '
            INSERT INTO conversation_members (
                conversation_id,
                user_id,
                role
            )
            VALUES (
                :conversation_id,
                :user_id,
                :role
            )
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':user_id' =>
            (int) $addUserId,

        ':role' =>
            'member',
    ]);


    /*
    |--------------------------------------------------------------------------
    | Advance conversation key version
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            UPDATE conversations
            SET
                key_version = :new_key_version,
                updated_at = CURRENT_TIMESTAMP
            WHERE
                id = :conversation_id
                AND workspace_id = :workspace_id
                AND key_version = :old_key_version
            '
        );

    $statement->execute([
        ':new_key_version' =>
            (int) $newKeyVersion,

        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,

        ':old_key_version' =>
            $currentKeyVersion,
    ]);


    if ($statement->rowCount() !== 1) {
        throw new RuntimeException(
            'Conversation key version changed during member addition.'
        );
    }


    $pdo->commit();


    /*
    |--------------------------------------------------------------------------
    | Success
    |--------------------------------------------------------------------------
    */

    echo json_encode([
        'success' => true,
        'conversation_id' =>
            (int) $conversationId,

        'added_user_id' =>
            (int) $addUserId,

        'key_version' =>
            (int) $newKeyVersion,
    ]);

    exit;
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Messaging add-member failed: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not add conversation member.',
    ]);

    exit;
}