<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3)
    . '/src/auth.php';

require_once dirname(__DIR__, 3)
    . '/src/messaging/messaging.php';

/*
|--------------------------------------------------------------------------
| Messaging conversation
|--------------------------------------------------------------------------
|
| Returns conversation metadata and members for the authenticated user.
|
| This endpoint does NOT return:
|
| - plaintext messages
| - private OpenPGP keys
| - raw conversation keys
| - another user's encrypted key envelope
|
*/

$currentUser = require_login();

header(
    'Content-Type: application/json; charset=utf-8'
);

header(
    'Cache-Control: no-store'
);

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$currentUserId =
    (int) $currentUser['id'];

$access =
    workspace_access(
        $currentUserId
    );

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];


/*
|--------------------------------------------------------------------------
| Conversation ID
|--------------------------------------------------------------------------
*/

$conversationIdRaw =
    $_GET['conversation_id']
    ?? '';

if (
    !is_string($conversationIdRaw)
    && !is_int($conversationIdRaw)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

$conversationIdString =
    (string) $conversationIdRaw;

if (
    $conversationIdString === ''
    || !ctype_digit(
        $conversationIdString
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

$conversationId =
    (int) $conversationIdString;

if ($conversationId <= 0) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Load conversation
|--------------------------------------------------------------------------
*/

try {
    /*
     * messaging_conversation() requires the
     * current user to be a conversation member.
     */

    $conversation =
        messaging_conversation(
            $conversationId,
            $currentUserId
        );

    /*
     * Deliberately use the same response when
     * the conversation does not exist or the
     * current user is not a member.
     */

    if (
        $conversation === null
        || (int) $conversation['workspace_id']
            !== $workspaceId
    ) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' =>
                'Conversation is unavailable.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Members
    |--------------------------------------------------------------------------
    */

    $memberRows =
        messaging_conversation_members(
            $conversationId
        );

    $members = [];

    foreach ($memberRows as $member) {
        $members[] = [
            'user_id' =>
                (int) $member['user_id'],

            'role' =>
                (string) $member['role'],

            'display_name' =>
                (string) $member['display_name'],

            'job_title' =>
                $member['job_title'] !== null
                    ? (string) $member['job_title']
                    : null,

            'avatar_path' =>
                $member['avatar_path'] !== null
                    ? (string) $member['avatar_path']
                    : null,

            'is_current_user' =>
                (int) $member['user_id']
                    === $currentUserId,
        ];
    }


    /*
    |--------------------------------------------------------------------------
    | Response
    |--------------------------------------------------------------------------
    */

    echo json_encode([
        'success' => true,

        'conversation' => [
            'id' =>
                (int) $conversation['id'],

            'type' =>
                (string) $conversation['type'],

            'is_workspace_admin' =>
                (bool) $access['is_admin'],

            'name' =>
                (string) $conversation['name'],

            'description' =>
                $conversation['description'] !== null
                    ? (string) $conversation['description']
                    : '',

            'key_version' =>
                (int) $conversation['key_version'],

            'role' =>
                (string) $conversation['role'],

            'created_at' =>
                (string) $conversation['created_at'],

            'updated_at' =>
                (string) $conversation['updated_at'],

            'members' =>
                $members,
        ],
    ]);
} catch (Throwable $error) {
    error_log(
        'Messaging conversation lookup failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Could not load conversation.',
    ]);
}