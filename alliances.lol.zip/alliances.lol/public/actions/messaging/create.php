<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3)
    . '/src/auth.php';

require_once dirname(__DIR__, 3)
    . '/src/messaging/messaging.php';

/*
|--------------------------------------------------------------------------
| Create encrypted Messaging conversation
|--------------------------------------------------------------------------
|
| The browser generates the raw conversation AES key and encrypts it
| separately for every member using that member's OpenPGP public key.
|
| PHP receives only encrypted OpenPGP key envelopes.
|
| The raw conversation key must never reach PHP.
|
*/

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
|
| Uses the existing CSRF protection from src/auth.php.
|
*/

require_valid_csrf();

/*
|--------------------------------------------------------------------------
| Workspace
|--------------------------------------------------------------------------
*/

$currentUserId =
    (int) $currentUser['id'];

$access =
    workspace_access(
        $currentUserId
    );

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Conversation fields
|--------------------------------------------------------------------------
*/

$type =
    trim(
        (string) (
            $_POST['type']
            ?? ''
        )
    );

$name =
    trim(
        (string) (
            $_POST['name']
            ?? ''
        )
    );

$description =
    trim(
        (string) (
            $_POST['description']
            ?? ''
        )
    );

if (
    $type !== 'group'
    && $type !== 'channel'
    && $type !== 'direct'
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation type.',
    ]);

    exit;
}

if (
    $type !== 'direct'
    && (
        $name === ''
        || mb_strlen($name) > 120
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Conversation name is required and must not exceed 120 characters.',
    ]);

    exit;
}

if (
    $type === 'direct'
    && mb_strlen($name) > 120
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Direct-message name is too long.',
    ]);

    exit;
}

if (
    mb_strlen($description) > 2000
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Conversation description must not exceed 2000 characters.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Members
|--------------------------------------------------------------------------
|
| Expected POST field:
|
| members = JSON array of user IDs
|
| Example:
|
| [1, 2, 3]
|
*/

$membersJson =
    $_POST['members']
    ?? '';

if (!is_string($membersJson)) {
    $membersJson = '';
}

try {
    $members =
        json_decode(
            $membersJson,
            true,
            512,
            JSON_THROW_ON_ERROR
        );
} catch (JsonException $error) {
    $members = null;
}

if (!is_array($members)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Invalid conversation members.',
    ]);

    exit;
}

$memberIds = [];

foreach ($members as $memberId) {
    if (
        !is_int($memberId)
        && !is_string($memberId)
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation member.',
        ]);

        exit;
    }

    $memberIdString =
        (string) $memberId;

    if (
        $memberIdString === ''
        || !ctype_digit(
            $memberIdString
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation member.',
        ]);

        exit;
    }

    $parsedMemberId =
        (int) $memberIdString;

    if ($parsedMemberId <= 0) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation member.',
        ]);

        exit;
    }

    $memberIds[] =
        $parsedMemberId;
}

/*
 * Remove duplicates.
 */

$memberIds =
    array_values(
        array_unique(
            $memberIds
        )
    );

/*
 * The creator must always be included.
 */

if (
    !in_array(
        $currentUserId,
        $memberIds,
        true
    )
) {
    $memberIds[] =
        $currentUserId;
}

/*
|--------------------------------------------------------------------------
| Direct-message membership
|--------------------------------------------------------------------------
|
| A direct message always contains exactly two different workspace users:
|
| - the authenticated user
| - one other user
|
*/

if (
    $type === 'direct'
    && count($memberIds) !== 2
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'A direct message must contain exactly two members.',
    ]);

    exit;
}

if (count($memberIds) > 200) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Too many conversation members.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Direct-message pair key
|--------------------------------------------------------------------------
|
| Sorting makes the pair independent of who starts the DM.
|
| User 7 messaging user 2:
|
|     2:7
|
*/

$dmPairKey = null;

if ($type === 'direct') {
    $dmUserIds = $memberIds;

    sort(
        $dmUserIds,
        SORT_NUMERIC
    );

    $dmPairKey =
        implode(
            ':',
            $dmUserIds
        );
}

/*
|--------------------------------------------------------------------------
| Encrypted conversation-key envelopes
|--------------------------------------------------------------------------
|
| Expected POST field:
|
| key_envelopes = JSON array
|
| Example:
|
| [
|     {
|         "user_id": 1,
|         "key_version": 1,
|         "encrypted_key": "-----BEGIN PGP MESSAGE-----..."
|     }
| ]
|
*/

$envelopesJson =
    $_POST['key_envelopes']
    ?? '';

if (!is_string($envelopesJson)) {
    $envelopesJson = '';
}

try {
    $envelopes =
        json_decode(
            $envelopesJson,
            true,
            512,
            JSON_THROW_ON_ERROR
        );
} catch (JsonException $error) {
    $envelopes = null;
}

if (!is_array($envelopes)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Invalid conversation key envelopes.',
    ]);

    exit;
}

$validatedEnvelopes = [];
$envelopeUserIds = [];

foreach ($envelopes as $envelope) {
    if (!is_array($envelope)) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation key envelope.',
        ]);

        exit;
    }

    $envelopeUserId =
        $envelope['user_id']
        ?? null;

    $keyVersion =
        $envelope['key_version']
        ?? null;

    $encryptedKey =
        $envelope['encrypted_key']
        ?? null;

    /*
     * Validate envelope user ID.
     */

    if (
        (
            !is_int($envelopeUserId)
            && !is_string($envelopeUserId)
        )
        || !ctype_digit(
            (string) $envelopeUserId
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid key-envelope user.',
        ]);

        exit;
    }

    $envelopeUserId =
        (int) $envelopeUserId;

    if ($envelopeUserId <= 0) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid key-envelope user.',
        ]);

        exit;
    }

    /*
     * Validate key version.
     */

    if (
        (
            !is_int($keyVersion)
            && !is_string($keyVersion)
        )
        || !ctype_digit(
            (string) $keyVersion
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation key version.',
        ]);

        exit;
    }

    $keyVersion =
        (int) $keyVersion;

    /*
     * Newly created conversations always
     * start at key version 1.
     */

    if ($keyVersion !== 1) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'New conversations must use key version 1.',
        ]);

        exit;
    }

    /*
     * Validate encrypted OpenPGP envelope.
     */

    if (
        !is_string($encryptedKey)
        || $encryptedKey === ''
        || strlen($encryptedKey) > 100000
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid encrypted conversation key.',
        ]);

        exit;
    }

    if (
        !str_contains(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
        || !str_contains(
            $encryptedKey,
            '-----END PGP MESSAGE-----'
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Encrypted conversation key must be an armored OpenPGP message.',
        ]);

        exit;
    }

    /*
     * Each user gets exactly one envelope.
     */

    if (
        in_array(
            $envelopeUserId,
            $envelopeUserIds,
            true
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Duplicate conversation key envelope.',
        ]);

        exit;
    }

    $envelopeUserIds[] =
        $envelopeUserId;

    $validatedEnvelopes[] = [
        'user_id' =>
            $envelopeUserId,

        'key_version' =>
            $keyVersion,

        'encrypted_key' =>
            $encryptedKey,
    ];
}

/*
|--------------------------------------------------------------------------
| Every member must have exactly one encrypted key envelope
|--------------------------------------------------------------------------
*/

$sortedMemberIds =
    $memberIds;

$sortedEnvelopeUserIds =
    $envelopeUserIds;

sort($sortedMemberIds);
sort($sortedEnvelopeUserIds);

if (
    $sortedMemberIds
    !== $sortedEnvelopeUserIds
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Every conversation member must have exactly one encrypted key envelope.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Verify all users belong to the current workspace
|--------------------------------------------------------------------------
*/

try {
    $connection = db();

/*
|--------------------------------------------------------------------------
| Existing direct message
|--------------------------------------------------------------------------
|
| There may only be one DM for a pair of users in a workspace.
|
| If it already exists, return it instead of creating another one.
|
*/

if (
    $type === 'direct'
    && $dmPairKey !== null
) {
    $existingDmStatement =
        $connection->prepare(
            'SELECT id
             FROM conversations
             WHERE workspace_id = :workspace_id
               AND type = :type
               AND dm_pair_key = :dm_pair_key
             LIMIT 1'
        );

    $existingDmStatement->execute([
        ':workspace_id' =>
            $workspaceId,

        ':type' =>
            'direct',

        ':dm_pair_key' =>
            $dmPairKey,
    ]);

    $existingConversationId =
        $existingDmStatement->fetchColumn();

    if ($existingConversationId !== false) {
        echo json_encode([
            'success' => true,

            'conversation_id' =>
                (int) $existingConversationId,

            'existing' => true,
        ]);

        exit;
    }
}

    $placeholders =
        implode(
            ',',
            array_fill(
                0,
                count($memberIds),
                '?'
            )
        );

    $statement =
        $connection->prepare(
            'SELECT user_id
             FROM workspace_members
             WHERE workspace_id = ?
               AND user_id IN ('
                . $placeholders
                . ')'
        );

    $statement->execute([
        $workspaceId,
        ...$memberIds,
    ]);

    $workspaceMemberIds =
        array_map(
            'intval',
            $statement->fetchAll(
                PDO::FETCH_COLUMN
            )
        );

    sort($workspaceMemberIds);

    if (
        $workspaceMemberIds
        !== $sortedMemberIds
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'One or more conversation members are not members of this workspace.',
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Atomic creation transaction
    |--------------------------------------------------------------------------
    |
    | Conversation, members and encrypted keys must either ALL be created
    | or NONE of them are created.
    |
    */

    $connection->beginTransaction();

    try {
        /*
        |--------------------------------------------------------------------------
        | Conversation
        |--------------------------------------------------------------------------
        */

$conversationStatement =
    $connection->prepare(
        'INSERT INTO conversations (
            workspace_id,
            created_by,
            type,
            name,
            description,
            key_version,
            dm_pair_key
        )
        VALUES (
            :workspace_id,
            :created_by,
            :type,
            :name,
            :description,
            1,
            :dm_pair_key
        )'
    );

$conversationStatement->execute([
    ':workspace_id' =>
        $workspaceId,

    ':created_by' =>
        $currentUserId,

    ':type' =>
        $type,

    ':name' =>
        $name,

    ':description' =>
        $description,

    ':dm_pair_key' =>
        $dmPairKey,
]);

        $conversationId =
            (int) $connection
                ->lastInsertId();

        if ($conversationId <= 0) {
            throw new RuntimeException(
                'Conversation could not be created.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Members
        |--------------------------------------------------------------------------
        |
        | Creator = owner
        | Everyone else = member
        |
        */

        $memberStatement =
            $connection->prepare(
                'INSERT INTO conversation_members (
                    conversation_id,
                    user_id,
                    role
                )
                VALUES (
                    :conversation_id,
                    :user_id,
                    :role
                )'
            );

        foreach ($memberIds as $memberId) {
            $role =
                $memberId === $currentUserId
                    ? 'owner'
                    : 'member';

            $memberStatement->execute([
                ':conversation_id' =>
                    $conversationId,

                ':user_id' =>
                    $memberId,

                ':role' =>
                    $role,
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Encrypted conversation keys
        |--------------------------------------------------------------------------
        |
        | These are OpenPGP ciphertext only.
        |
        | The raw 256-bit conversation AES key never reaches this endpoint.
        |
        */

        $keyStatement =
            $connection->prepare(
                'INSERT INTO conversation_keys (
                    conversation_id,
                    user_id,
                    key_version,
                    encrypted_key
                )
                VALUES (
                    :conversation_id,
                    :user_id,
                    :key_version,
                    :encrypted_key
                )'
            );

        foreach (
            $validatedEnvelopes
            as $envelope
        ) {
            $keyStatement->execute([
                ':conversation_id' =>
                    $conversationId,

                ':user_id' =>
                    $envelope['user_id'],

                ':key_version' =>
                    $envelope['key_version'],

                ':encrypted_key' =>
                    $envelope['encrypted_key'],
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Commit
        |--------------------------------------------------------------------------
        */

        $connection->commit();

        echo json_encode([
            'success' => true,
            'conversation_id' =>
                $conversationId,
        ]);
    } catch (Throwable $error) {
        if (
            $connection->inTransaction()
        ) {
            $connection->rollBack();
        }

        throw $error;
    }
} catch (Throwable $error) {
    error_log(
        'Messaging conversation creation failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Could not create conversation.',
    ]);
}