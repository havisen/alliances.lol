<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/messaging/messaging.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access is required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$currentUserId =
    (int) $user['id'];


/*
|--------------------------------------------------------------------------
| Request data
|--------------------------------------------------------------------------
*/

$conversationId =
    filter_input(
        INPUT_POST,
        'conversation_id',
        FILTER_VALIDATE_INT
    );

if (
    !$conversationId
    || $conversationId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Delete conversation
|--------------------------------------------------------------------------
|
| Only the conversation owner may permanently delete it.
|
| This operation removes:
|
| - encrypted messages
| - encrypted conversation-key envelopes
| - conversation memberships
| - the conversation itself
|
| No key rotation is required because the conversation ceases to exist.
|
*/

$pdo = db();

try {
    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Load conversation + requester's role
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                c.id,
                c.type,
                cm.role AS requester_role
            FROM conversations AS c
            INNER JOIN conversation_members AS cm
                ON cm.conversation_id = c.id
                AND cm.user_id = :current_user_id
            WHERE
                c.id = :conversation_id
                AND c.workspace_id = :workspace_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':current_user_id' =>
            $currentUserId,

        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $conversation =
        $statement->fetch();


    if (!$conversation) {
        $pdo->rollBack();

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation not found.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Owner only
    |--------------------------------------------------------------------------
    */

    if (
        (string) $conversation[
            'requester_role'
        ] !== 'owner'
    ) {
        $pdo->rollBack();

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' => 'Only the conversation owner can delete this conversation.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Delete encrypted messages
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            DELETE FROM messages
            WHERE conversation_id = :conversation_id
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,
    ]);


    /*
    |--------------------------------------------------------------------------
    | Delete encrypted key envelopes
    |--------------------------------------------------------------------------
    |
    | These contain OpenPGP-encrypted conversation
    | keys only. The server never has the raw AES keys.
    |
    */

    $statement =
        $pdo->prepare(
            '
            DELETE FROM conversation_keys
            WHERE conversation_id = :conversation_id
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,
    ]);


    /*
    |--------------------------------------------------------------------------
    | Delete memberships
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            DELETE FROM conversation_members
            WHERE conversation_id = :conversation_id
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,
    ]);


    /*
    |--------------------------------------------------------------------------
    | Delete conversation
    |--------------------------------------------------------------------------
    |
    | Keep the workspace condition on the final DELETE
    | as an additional authorization boundary.
    |
    */

    $statement =
        $pdo->prepare(
            '
            DELETE FROM conversations
            WHERE
                id = :conversation_id
                AND workspace_id = :workspace_id
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    if (
        $statement->rowCount()
        !== 1
    ) {
        throw new RuntimeException(
            'Conversation changed during deletion.'
        );
    }


    $pdo->commit();


    echo json_encode([
        'success' => true,

        'conversation_id' =>
            (int) $conversationId,
    ]);

    exit;
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Messaging delete failed: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not delete conversation.',
    ]);

    exit;
}