<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$currentUserId = (int) $currentUser['id'];

$access = workspace_access($currentUserId);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$targetUserId = filter_input(
    INPUT_GET,
    'user_id',
    FILTER_VALIDATE_INT
);

if (
    !$targetUserId
    || $targetUserId <= 0
    || $targetUserId === $currentUserId
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid direct-message user.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];
$pairIds = [$currentUserId, $targetUserId];
sort($pairIds, SORT_NUMERIC);
$dmPairKey = implode(':', $pairIds);

try {
    $connection = db();

    $memberStatement = $connection->prepare(
        'SELECT 1
         FROM workspace_members
         WHERE workspace_id = ?
           AND user_id = ?
         LIMIT 1'
    );

    $memberStatement->execute([
        $workspaceId,
        $targetUserId,
    ]);

    if ($memberStatement->fetchColumn() === false) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Workspace member not found.',
        ]);

        exit;
    }

    $conversationStatement = $connection->prepare(
        'SELECT c.id
         FROM conversations c
         INNER JOIN conversation_members cm
            ON cm.conversation_id = c.id
           AND cm.user_id = ?
         WHERE c.workspace_id = ?
           AND c.type = ?
           AND c.dm_pair_key = ?
         LIMIT 1'
    );

    $conversationStatement->execute([
        $currentUserId,
        $workspaceId,
        'direct',
        $dmPairKey,
    ]);

    $conversationId = $conversationStatement->fetchColumn();

    echo json_encode([
        'success' => true,
        'conversation_id' =>
            $conversationId !== false
                ? (int) $conversationId
                : null,
    ]);
} catch (Throwable $error) {
    error_log(
        'Messaging direct lookup failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not look up direct message.',
    ]);
}
