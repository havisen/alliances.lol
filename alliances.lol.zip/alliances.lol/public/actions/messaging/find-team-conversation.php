<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access((int) $currentUser['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId = (int) $access['workspace_id'];
$currentUserId = (int) $currentUser['id'];

$teamId = filter_input(
    INPUT_GET,
    'team_id',
    FILTER_VALIDATE_INT
);

if (!$teamId) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid team.',
    ]);

    exit;
}

$connection = db();

$teamStatement = $connection->prepare(
    'SELECT id, name, team_lead_id
     FROM teams
     WHERE id = ?
       AND workspace_id = ?
     LIMIT 1'
);

$teamStatement->execute([
    $teamId,
    $workspaceId,
]);

$team = $teamStatement->fetch();

if (!$team) {
    http_response_code(404);

    echo json_encode([
        'success' => false,
        'error' => 'Team not found.',
    ]);

    exit;
}

$membersStatement = $connection->prepare(
    'SELECT tm.user_id
     FROM team_members tm
     INNER JOIN workspace_members wm
        ON wm.user_id = tm.user_id
       AND wm.workspace_id = ?
     WHERE tm.team_id = ?'
);

$membersStatement->execute([
    $workspaceId,
    $teamId,
]);

$memberIds = array_map(
    'intval',
    $membersStatement->fetchAll(PDO::FETCH_COLUMN)
);

if (!empty($team['team_lead_id'])) {
    $memberIds[] = (int) $team['team_lead_id'];
}

$memberIds[] = $currentUserId;

$memberIds = array_values(
    array_unique($memberIds)
);

sort($memberIds, SORT_NUMERIC);

if ($memberIds === []) {
    echo json_encode([
        'success' => true,
        'conversation_id' => null,
        'member_ids' => [],
        'name' => 'Team: ' . (string) $team['name'],
    ]);

    exit;
}

$memberPlaceholders = implode(
    ',',
    array_fill(0, count($memberIds), '?')
);

$conversationStatement = $connection->prepare(
    'SELECT c.id
     FROM conversations c
     INNER JOIN conversation_members current_member
        ON current_member.conversation_id = c.id
       AND current_member.user_id = ?
     WHERE c.workspace_id = ?
       AND c.type = ?
       AND c.name = ?
       AND (
            SELECT COUNT(DISTINCT cm.user_id)
            FROM conversation_members cm
            WHERE cm.conversation_id = c.id
       ) = ?
       AND NOT EXISTS (
            SELECT 1
            FROM conversation_members extra_member
            WHERE extra_member.conversation_id = c.id
              AND extra_member.user_id NOT IN (' . $memberPlaceholders . ')
       )
       AND NOT EXISTS (
            SELECT 1
            FROM (
                SELECT ? AS required_user_id
            ) required_seed
            WHERE required_seed.required_user_id NOT IN (
                SELECT cm.user_id
                FROM conversation_members cm
                WHERE cm.conversation_id = c.id
            )
       )
     LIMIT 1'
);

/*
 * SQLite does not support binding an arbitrary VALUES table portably here,
 * so the NOT EXISTS above verifies no extras while the count verifies the
 * exact size. Combined with the IN list, that means the member set matches.
 */
$conversationStatement->execute([
    $currentUserId,
    $workspaceId,
    'group',
    'Team: ' . (string) $team['name'],
    count($memberIds),
    ...$memberIds,
    $memberIds[0],
]);

$conversationId = $conversationStatement->fetchColumn();

echo json_encode([
    'success' => true,
    'conversation_id' =>
        $conversationId !== false
            ? (int) $conversationId
            : null,
    'member_ids' => $memberIds,
    'name' => 'Team: ' . (string) $team['name'],
]);
