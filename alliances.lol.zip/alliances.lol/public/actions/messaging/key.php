<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3)
    . '/src/auth.php';

require_once dirname(__DIR__, 3)
    . '/src/messaging/messaging.php';

/*
|--------------------------------------------------------------------------
| Current user's encrypted conversation key
|--------------------------------------------------------------------------
|
| Returns ONLY the authenticated user's encrypted OpenPGP key envelope for
| a conversation.
|
| The server never decrypts the envelope and never receives the user's
| OpenPGP private key.
|
*/

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$currentUserId =
    (int) $currentUser['id'];

$access =
    workspace_access(
        $currentUserId
    );

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Conversation ID
|--------------------------------------------------------------------------
*/

$conversationIdRaw =
    $_GET['conversation_id']
    ?? '';

if (
    !is_string($conversationIdRaw)
    && !is_int($conversationIdRaw)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

$conversationIdString =
    (string) $conversationIdRaw;

if (
    $conversationIdString === ''
    || !ctype_digit(
        $conversationIdString
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

$conversationId =
    (int) $conversationIdString;

if ($conversationId <= 0) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Load encrypted envelope
|--------------------------------------------------------------------------
*/

try {
    $connection = db();

    /*
     * Verify:
     *
     * 1. Conversation belongs to the user's workspace.
     * 2. Current user is still a conversation member.
     * 3. Return only this user's envelope.
     * 4. Return the envelope matching the conversation's current key version.
     */

$statement =
    $connection->prepare(
        'SELECT
            c.id AS conversation_id,
            c.key_version AS current_key_version,
            ck.key_version,
            ck.encrypted_key
         FROM conversations c
         INNER JOIN conversation_members cm
            ON cm.conversation_id = c.id
           AND cm.user_id = :member_user_id
         INNER JOIN conversation_keys ck
            ON ck.conversation_id = c.id
           AND ck.user_id = :key_user_id
         WHERE c.id = :conversation_id
           AND c.workspace_id = :workspace_id
         ORDER BY ck.key_version ASC'
    );

    $statement->execute([
        ':member_user_id' =>
            $currentUserId,

        ':key_user_id' =>
            $currentUserId,

        ':conversation_id' =>
            $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);

$rows =
    $statement->fetchAll(
        PDO::FETCH_ASSOC
    );

if ($rows === []) {
        /*
         * Deliberately do not reveal whether
         * the conversation exists.
         */

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' =>
                'Conversation key is unavailable.',
        ]);

        exit;
    }

$currentKeyVersion =
    (int) $rows[0]['current_key_version'];

if ($currentKeyVersion <= 0) {
    throw new RuntimeException(
        'Invalid current conversation key version.'
    );
}

$keys = [];

foreach ($rows as $row) {
    $keyVersion =
        (int) $row['key_version'];

    $encryptedKey =
        (string) $row['encrypted_key'];

    if (
        $keyVersion <= 0
        || $encryptedKey === ''
    ) {
        throw new RuntimeException(
            'Invalid stored conversation key.'
        );
    }

    $keys[] = [
        'key_version' =>
            $keyVersion,

        'encrypted_key' =>
            $encryptedKey,
    ];
}

echo json_encode([
    'success' => true,

    'conversation_id' =>
        (int) $rows[0]['conversation_id'],

    'current_key_version' =>
        $currentKeyVersion,

    'keys' =>
        $keys,
]);
} catch (Throwable $error) {
    error_log(
        'Messaging conversation-key lookup failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Could not load conversation key.',
    ]);
}