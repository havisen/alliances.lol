<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/messaging/messaging.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $user['id']
);

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access is required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

$currentUserId =
    (int) $user['id'];


/*
|--------------------------------------------------------------------------
| Request data
|--------------------------------------------------------------------------
*/

$conversationId =
    filter_input(
        INPUT_POST,
        'conversation_id',
        FILTER_VALIDATE_INT
    );

$newKeyVersion =
    filter_input(
        INPUT_POST,
        'key_version',
        FILTER_VALIDATE_INT
    );

$keyEnvelopesJson =
    $_POST['key_envelopes']
    ?? '';


if (
    !$conversationId
    || $conversationId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation.',
    ]);

    exit;
}


if (
    !$newKeyVersion
    || $newKeyVersion <= 1
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation key version.',
    ]);

    exit;
}


if (
    !is_string($keyEnvelopesJson)
    || $keyEnvelopesJson === ''
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted key envelopes are required.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Decode envelopes
|--------------------------------------------------------------------------
*/

try {
    $decodedEnvelopes =
        json_decode(
            $keyEnvelopesJson,
            true,
            512,
            JSON_THROW_ON_ERROR
        );
} catch (JsonException $exception) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encrypted key envelopes.',
    ]);

    exit;
}


if (
    !is_array($decodedEnvelopes)
    || $decodedEnvelopes === []
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted key envelopes are required.',
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Validate envelopes
|--------------------------------------------------------------------------
*/

$keyEnvelopes = [];

$envelopeUserIds = [];

foreach ($decodedEnvelopes as $envelope) {
    if (!is_array($envelope)) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid encrypted key envelope.',
        ]);

        exit;
    }

    $envelopeUserId =
        filter_var(
            $envelope['user_id']
                ?? null,
            FILTER_VALIDATE_INT
        );

    $envelopeKeyVersion =
        filter_var(
            $envelope['key_version']
                ?? null,
            FILTER_VALIDATE_INT
        );

    $encryptedKey =
        $envelope['encrypted_key']
        ?? null;


    if (
        !$envelopeUserId
        || $envelopeUserId <= 0
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid key-envelope member.',
        ]);

        exit;
    }


    if (
        !$envelopeKeyVersion
        || $envelopeKeyVersion
            !== $newKeyVersion
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid key-envelope version.',
        ]);

        exit;
    }


    if (
        !is_string($encryptedKey)
        || $encryptedKey === ''
        || strlen($encryptedKey) > 100000
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid encrypted conversation key.',
        ]);

        exit;
    }


    if (
        !str_contains(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
        || !str_contains(
            $encryptedKey,
            '-----END PGP MESSAGE-----'
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid OpenPGP key envelope.',
        ]);

        exit;
    }


    if (
        in_array(
            (int) $envelopeUserId,
            $envelopeUserIds,
            true
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Duplicate key-envelope member.',
        ]);

        exit;
    }


    $envelopeUserIds[] =
        (int) $envelopeUserId;

    $keyEnvelopes[] = [
        'user_id' =>
            (int) $envelopeUserId,

        'key_version' =>
            (int) $envelopeKeyVersion,

        'encrypted_key' =>
            $encryptedKey,
    ];
}


/*
|--------------------------------------------------------------------------
| Leave + rotate
|--------------------------------------------------------------------------
*/

$pdo = db();

try {
    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Load conversation and current membership
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                c.id,
                c.type,
                c.key_version,
                cm.role
            FROM conversations AS c
            INNER JOIN conversation_members AS cm
                ON cm.conversation_id = c.id
                AND cm.user_id = :current_user_id
            WHERE
                c.id = :conversation_id
                AND c.workspace_id = :workspace_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':current_user_id' =>
            $currentUserId,

        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $conversation =
        $statement->fetch();


    if (!$conversation) {
        $pdo->rollBack();

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation not found.',
        ]);

        exit;
    }


    /*
     * Direct messages cannot be left using
     * this operation.
     */
    if (
        $conversation['type']
        === 'direct'
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Direct messages cannot be left.',
        ]);

        exit;
    }


    /*
     * The owner must transfer ownership or
     * delete the conversation instead.
     */
    if (
        $conversation['role']
        === 'owner'
    ) {
        $pdo->rollBack();

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' => 'The conversation owner cannot leave. Transfer ownership or delete the conversation instead.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Validate key version
    |--------------------------------------------------------------------------
    */

    $currentKeyVersion =
        (int) $conversation[
            'key_version'
        ];

    $expectedKeyVersion =
        $currentKeyVersion + 1;


    if (
        (int) $newKeyVersion
        !== $expectedKeyVersion
    ) {
        $pdo->rollBack();

        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'The conversation encryption key changed. Reload and try again.',
            'current_key_version' =>
                $currentKeyVersion,
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Determine remaining members
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                user_id
            FROM conversation_members
            WHERE
                conversation_id = :conversation_id
                AND user_id != :current_user_id
            ORDER BY user_id ASC
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':current_user_id' =>
            $currentUserId,
    ]);

    $remainingMemberIds =
        array_map(
            static fn (array $row): int =>
                (int) $row['user_id'],

            $statement->fetchAll()
        );


    if ($remainingMemberIds === []) {
        $pdo->rollBack();

        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'Cannot leave a conversation with no remaining members.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Envelope set must exactly equal remaining members
    |--------------------------------------------------------------------------
    */

    sort(
        $remainingMemberIds,
        SORT_NUMERIC
    );

    $submittedEnvelopeIds =
        $envelopeUserIds;

    sort(
        $submittedEnvelopeIds,
        SORT_NUMERIC
    );


    if (
        $submittedEnvelopeIds
        !== $remainingMemberIds
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Encrypted key envelopes do not match the remaining conversation membership.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Re-check workspace membership
    |--------------------------------------------------------------------------
    */

    $placeholders =
        implode(
            ', ',
            array_fill(
                0,
                count(
                    $remainingMemberIds
                ),
                '?'
            )
        );

    $statement =
        $pdo->prepare(
            '
            SELECT
                user_id
            FROM workspace_members
            WHERE
                workspace_id = ?
                AND user_id IN ('
                . $placeholders .
                ')
            '
        );

    $statement->execute([
        $workspaceId,
        ...$remainingMemberIds,
    ]);

    $workspaceMemberIds =
        array_map(
            static fn (array $row): int =>
                (int) $row['user_id'],

            $statement->fetchAll()
        );

    sort(
        $workspaceMemberIds,
        SORT_NUMERIC
    );


    if (
        $workspaceMemberIds
        !== $remainingMemberIds
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'One or more remaining members no longer belong to this workspace.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Insert replacement key envelopes
    |--------------------------------------------------------------------------
    */

    $insertKey =
        $pdo->prepare(
            '
            INSERT INTO conversation_keys (
                conversation_id,
                user_id,
                key_version,
                encrypted_key
            )
            VALUES (
                :conversation_id,
                :user_id,
                :key_version,
                :encrypted_key
            )
            '
        );

    foreach (
        $keyEnvelopes
        as $envelope
    ) {
        $insertKey->execute([
            ':conversation_id' =>
                (int) $conversationId,

            ':user_id' =>
                $envelope['user_id'],

            ':key_version' =>
                (int) $newKeyVersion,

            ':encrypted_key' =>
                $envelope[
                    'encrypted_key'
                ],
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Remove current user's membership
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            DELETE FROM conversation_members
            WHERE
                conversation_id = :conversation_id
                AND user_id = :user_id
                AND role != :owner_role
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':user_id' =>
            $currentUserId,

        ':owner_role' =>
            'owner',
    ]);


    if (
        $statement->rowCount()
        !== 1
    ) {
        throw new RuntimeException(
            'Conversation membership changed during leave operation.'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Advance key version
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            UPDATE conversations
            SET
                key_version = :new_key_version,
                updated_at = CURRENT_TIMESTAMP
            WHERE
                id = :conversation_id
                AND workspace_id = :workspace_id
                AND key_version = :old_key_version
            '
        );

    $statement->execute([
        ':new_key_version' =>
            (int) $newKeyVersion,

        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,

        ':old_key_version' =>
            $currentKeyVersion,
    ]);


    if (
        $statement->rowCount()
        !== 1
    ) {
        throw new RuntimeException(
            'Conversation key version changed during leave operation.'
        );
    }


    $pdo->commit();


    echo json_encode([
        'success' => true,

        'conversation_id' =>
            (int) $conversationId,

        'left_user_id' =>
            $currentUserId,

        'key_version' =>
            (int) $newKeyVersion,
    ]);

    exit;
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Messaging leave failed: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not leave conversation.',
    ]);

    exit;
}