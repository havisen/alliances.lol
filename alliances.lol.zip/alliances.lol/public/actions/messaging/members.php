<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3)
    . '/src/auth.php';

/*
|--------------------------------------------------------------------------
| Messaging workspace members
|--------------------------------------------------------------------------
|
| Returns users from the authenticated user's current workspace.
|
*/

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access =
    workspace_access(
        (int) $currentUser['id']
    );

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

try {
    $connection = db();

    $statement =
        $connection->prepare(
            'SELECT
                u.id,
                u.display_name,
                u.email
             FROM workspace_members wm
             INNER JOIN users u
                ON u.id = wm.user_id
             WHERE wm.workspace_id = :workspace_id
             ORDER BY
                u.display_name COLLATE NOCASE ASC,
                u.email COLLATE NOCASE ASC'
        );

    $statement->execute([
        ':workspace_id' =>
            $workspaceId,
    ]);

    $rows =
        $statement->fetchAll(
            PDO::FETCH_ASSOC
        );

    $members = [];

    foreach ($rows as $row) {
        $members[] = [
            'id' =>
                (int) $row['id'],

            /*
             * JavaScript expects this property
             * to be called "name".
             */

            'name' =>
                (string) $row['display_name'],

            'email' =>
                (string) $row['email'],

            'is_current_user' =>
                (int) $row['id']
                === (int) $currentUser['id'],
        ];
    }

    echo json_encode([
        'success' => true,
        'members' => $members,
    ]);
} catch (Throwable $error) {
    error_log(
        'Messaging workspace-member lookup failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Could not load workspace members.',
    ]);
}