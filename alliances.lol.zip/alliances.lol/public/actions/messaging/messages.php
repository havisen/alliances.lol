<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$currentUser = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $currentUser['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$conversationId =
    filter_input(
        INPUT_GET,
        'conversation_id',
        FILTER_VALIDATE_INT
    );

if (
    $conversationId === false
    || $conversationId === null
    || $conversationId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
    |--------------------------------------------------------------------------
    | Verify access to conversation
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    c.id,
                    c.key_version,
                    cm.role
                FROM conversations c
                INNER JOIN conversation_members cm
                    ON cm.conversation_id = c.id
                WHERE c.id = :conversation_id
                  AND c.workspace_id = :workspace_id
                  AND cm.user_id = :user_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':conversation_id' =>
            $conversationId,

        ':workspace_id' =>
            (int) $access['workspace_id'],

        ':user_id' =>
            (int) $currentUser['id'],
    ]);

    $conversation =
        $statement->fetch();

    if (!$conversation) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation is unavailable.',
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Retrieve encrypted messages
    |--------------------------------------------------------------------------
    |
    | No decryption happens here.
    |
    | PHP only returns ciphertext, IV and the metadata required by the
    | browser to display/decrypt the message.
    |
    */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    m.id,
                    m.conversation_id,
                    m.sender_id,
                    m.key_version,
                    m.ciphertext,
                    m.iv,
                    m.created_at,
                    m.edited_at,
                    u.display_name AS sender_name,
                    u.avatar_path AS sender_avatar
                FROM messages m
                INNER JOIN users u
                    ON u.id = m.sender_id
                WHERE m.conversation_id = :conversation_id
                ORDER BY
                    m.created_at ASC,
                    m.id ASC
                LIMIT 500
            '
        );

    $statement->execute([
        ':conversation_id' =>
            $conversationId,
    ]);

    $rows =
        $statement->fetchAll();

    $messages = [];

    foreach ($rows as $row) {
        $messages[] = [
            'id' =>
                (int) $row['id'],

            'conversation_id' =>
                (int) $row['conversation_id'],

            'sender_id' =>
                (int) $row['sender_id'],

            'key_version' =>
                (int) $row['key_version'],

            'ciphertext' =>
                (string) $row['ciphertext'],

            'iv' =>
                (string) $row['iv'],

            'created_at' =>
                (string) $row['created_at'],

            'edited_at' =>
                $row['edited_at'] !== null
                    ? (string) $row['edited_at']
                    : null,

            'sender' => [
                'name' =>
                    (string) $row['sender_name'],

                'avatar_path' =>
                    $row['sender_avatar'] !== null
                        ? (string) $row['sender_avatar']
                        : null,
            ],

            'is_current_user' =>
                (int) $row['sender_id']
                === (int) $currentUser['id'],
        ];
    }

    echo json_encode([
        'success' => true,

        'conversation_id' =>
            $conversationId,

        'current_key_version' =>
            (int) $conversation['key_version'],

        'messages' =>
            $messages,
    ]);
} catch (Throwable $exception) {
    error_log(
        'Messaging messages error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not load encrypted messages.',
    ]);
}