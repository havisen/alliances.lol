<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3)
    . '/src/auth.php';

require_once dirname(__DIR__, 3)
    . '/src/messaging/public-keys.php';

/*
|--------------------------------------------------------------------------
| Messaging public-key directory
|--------------------------------------------------------------------------
|
| Returns OpenPGP PUBLIC keys for users who belong to the caller's current
| workspace.
|
| Private keys are never stored or returned by this endpoint.
|
*/

$currentUser = require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access(
    (int) $currentUser['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Read requested user IDs
|--------------------------------------------------------------------------
|
| Request format:
|
| /actions/messaging/public-keys.php?user_ids[]=1&user_ids[]=2
|
*/

$userIds =
    $_GET['user_ids']
    ?? [];

if (!is_array($userIds)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid user IDs.',
    ]);

    exit;
}

$requestedUserIds = [];

foreach ($userIds as $userId) {
    if (
        !is_string($userId)
        && !is_int($userId)
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid user ID.',
        ]);

        exit;
    }

    $userIdString =
        (string) $userId;

    if (
        $userIdString === ''
        || !ctype_digit($userIdString)
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid user ID.',
        ]);

        exit;
    }

    $parsedUserId =
        (int) $userIdString;

    if ($parsedUserId <= 0) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Invalid user ID.',
        ]);

        exit;
    }

    $requestedUserIds[] =
        $parsedUserId;
}

$requestedUserIds =
    array_values(
        array_unique(
            $requestedUserIds
        )
    );

if ($requestedUserIds === []) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'At least one user ID is required.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Limit request size
|--------------------------------------------------------------------------
|
| Prevent an unnecessarily large public-key directory request.
|
*/

if (count($requestedUserIds) > 200) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Too many user IDs requested.',
    ]);

    exit;
}

try {
    $connection = db();

    /*
    |--------------------------------------------------------------------------
    | Verify workspace membership
    |--------------------------------------------------------------------------
    |
    | Every requested user must currently belong to the same workspace as
    | the authenticated caller.
    |
    */

    $placeholders =
        implode(
            ',',
            array_fill(
                0,
                count($requestedUserIds),
                '?'
            )
        );

    $parameters = [
        $workspaceId,
        ...$requestedUserIds,
    ];

    $statement =
        $connection->prepare(
            'SELECT user_id
             FROM workspace_members
             WHERE workspace_id = ?
               AND user_id IN ('
                . $placeholders
                . ')'
        );

    $statement->execute(
        $parameters
    );

    $workspaceUserIds =
        array_map(
            'intval',
            $statement->fetchAll(
                PDO::FETCH_COLUMN
            )
        );

    sort($workspaceUserIds);

    $expectedUserIds =
        $requestedUserIds;

    sort($expectedUserIds);

    if (
        $workspaceUserIds
        !== $expectedUserIds
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'One or more requested users are not members of this workspace.',
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Load published public keys
    |--------------------------------------------------------------------------
    */

    $publishedKeys =
        messaging_public_keys_for_users(
            $requestedUserIds
        );

    $keys = [];
    $missingUserIds = [];

    foreach (
        $requestedUserIds
        as $userId
    ) {
        if (
            !isset(
                $publishedKeys[$userId]
            )
        ) {
            $missingUserIds[] =
                $userId;

            continue;
        }

        $publishedKey =
            $publishedKeys[$userId];

        /*
         * Return only public information.
         *
         * Do not add any Key Vault data or
         * private-key fields here.
         */

        $keys[] = [
            'user_id' =>
                (int) $publishedKey['user_id'],

            'key_type' =>
                (string) $publishedKey['key_type'],

            'format_version' =>
                (int) $publishedKey['format_version'],

            'public_key' =>
                (string) $publishedKey['public_key'],

            'fingerprint' =>
                (string) $publishedKey['fingerprint'],
        ];
    }

    echo json_encode([
        'success' => true,
        'keys' => $keys,
        'missing_user_ids' =>
            $missingUserIds,
    ]);
} catch (Throwable $error) {
    error_log(
        'Messaging public-key lookup failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Could not load Messaging public keys.',
    ]);
}