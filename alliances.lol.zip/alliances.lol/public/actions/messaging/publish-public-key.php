<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/messaging/public-keys.php';

$currentUser = require_login();

header(
    'Content-Type: application/json; charset=utf-8'
);

header(
    'Cache-Control: no-store'
);

/*
|--------------------------------------------------------------------------
| Request method
|--------------------------------------------------------------------------
*/

if (
    ($_SERVER['REQUEST_METHOD'] ?? '')
    !== 'POST'
) {
    http_response_code(405);

    echo json_encode([
        'error' => 'Method not allowed.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

require_valid_csrf();

/*
|--------------------------------------------------------------------------
| Input
|--------------------------------------------------------------------------
*/

$publicKey =
    trim(
        (string) ($_POST['public_key'] ?? '')
    );

$fingerprint =
    strtolower(
        trim(
            (string) ($_POST['fingerprint'] ?? '')
        )
    );

/*
|--------------------------------------------------------------------------
| Validate public key
|--------------------------------------------------------------------------
|
| PHP does not parse OpenPGP itself.
|
| This validation only rejects obviously invalid input. The browser will
| perform OpenPGP parsing before publishing, and the fingerprint will be
| verified cryptographically in the browser.
|
*/

if (
    $publicKey === ''
    || !str_starts_with(
        $publicKey,
        '-----BEGIN PGP PUBLIC KEY BLOCK-----'
    )
    || !str_contains(
        $publicKey,
        '-----END PGP PUBLIC KEY BLOCK-----'
    )
) {
    http_response_code(400);

    echo json_encode([
        'error' =>
            'Invalid OpenPGP public key.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Size limit
|--------------------------------------------------------------------------
*/

if (strlen($publicKey) > 100000) {
    http_response_code(400);

    echo json_encode([
        'error' =>
            'OpenPGP public key is too large.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Validate fingerprint format
|--------------------------------------------------------------------------
|
| Our current OpenPGP identity produces a hexadecimal fingerprint.
|
*/

if (
    $fingerprint === ''
    || !ctype_xdigit($fingerprint)
    || strlen($fingerprint) < 32
    || strlen($fingerprint) > 128
) {
    http_response_code(400);

    echo json_encode([
        'error' =>
            'Invalid OpenPGP fingerprint.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Existing identity
|--------------------------------------------------------------------------
*/

$userId =
    (int) $currentUser['id'];

$existingKey =
    messaging_public_key_for_user(
        $userId
    );

if ($existingKey !== null) {
    /*
     * Treat publishing the exact same identity as
     * success. This makes synchronization safe to
     * retry without allowing silent key replacement.
     */

    if (
        hash_equals(
            strtolower(
                (string) $existingKey['fingerprint']
            ),
            $fingerprint
        )
        && hash_equals(
            trim(
                (string) $existingKey['public_key']
            ),
            $publicKey
        )
    ) {
        echo json_encode([
            'success' => true,
            'alreadyPublished' => true,
        ]);

        exit;
    }

    http_response_code(409);

    echo json_encode([
        'error' =>
            'A different public key is already published for this account.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Publish
|--------------------------------------------------------------------------
*/

try {
    messaging_publish_public_key(
        $userId,
        $publicKey,
        $fingerprint
    );
} catch (Throwable $error) {
    error_log(
        'Messaging public key publication failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'error' =>
            'Could not publish OpenPGP public key.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Response
|--------------------------------------------------------------------------
*/

http_response_code(201);

echo json_encode([
    'success' => true,
    'alreadyPublished' => false,
]);

exit;