<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3)
    . '/src/auth.php';

require_once dirname(__DIR__, 3)
    . '/src/messaging/messaging.php';

/*
|--------------------------------------------------------------------------
| Remove Messaging member + rotate conversation key
|--------------------------------------------------------------------------
|
| The browser generates a fresh AES conversation key and OpenPGP-wraps
| it separately for every member who will remain in the conversation.
|
| PHP receives only encrypted OpenPGP key envelopes.
|
| Member removal, new envelopes and key-version advancement happen in
| one database transaction.
|
*/

$currentUser = require_login();

header(
    'Content-Type: application/json; charset=utf-8'
);

header(
    'Cache-Control: no-store'
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$currentUserId =
    (int) $currentUser['id'];

$access =
    workspace_access(
        $currentUserId
    );

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Conversation ID
|--------------------------------------------------------------------------
*/

$conversationIdRaw =
    $_POST['conversation_id']
    ?? '';

if (
    !is_string($conversationIdRaw)
    && !is_int($conversationIdRaw)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

$conversationIdString =
    (string) $conversationIdRaw;

if (
    $conversationIdString === ''
    || !ctype_digit(
        $conversationIdString
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

$conversationId =
    (int) $conversationIdString;

if ($conversationId <= 0) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation ID.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Member to remove
|--------------------------------------------------------------------------
*/

$removeUserIdRaw =
    $_POST['user_id']
    ?? '';

if (
    !is_string($removeUserIdRaw)
    && !is_int($removeUserIdRaw)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid member.',
    ]);

    exit;
}

$removeUserIdString =
    (string) $removeUserIdRaw;

if (
    $removeUserIdString === ''
    || !ctype_digit(
        $removeUserIdString
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid member.',
    ]);

    exit;
}

$removeUserId =
    (int) $removeUserIdString;

if ($removeUserId <= 0) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid member.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Requested next key version
|--------------------------------------------------------------------------
*/

$keyVersionRaw =
    $_POST['key_version']
    ?? '';

if (
    !is_string($keyVersionRaw)
    && !is_int($keyVersionRaw)
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation key version.',
    ]);

    exit;
}

$keyVersionString =
    (string) $keyVersionRaw;

if (
    $keyVersionString === ''
    || !ctype_digit(
        $keyVersionString
    )
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation key version.',
    ]);

    exit;
}

$requestedKeyVersion =
    (int) $keyVersionString;

if ($requestedKeyVersion <= 1) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation key version.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Encrypted key envelopes
|--------------------------------------------------------------------------
*/

$envelopesJson =
    $_POST['key_envelopes']
    ?? '';

if (!is_string($envelopesJson)) {
    $envelopesJson = '';
}

try {
    $envelopes =
        json_decode(
            $envelopesJson,
            true,
            512,
            JSON_THROW_ON_ERROR
        );
} catch (JsonException $error) {
    $envelopes = null;
}

if (!is_array($envelopes)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' =>
            'Invalid conversation key envelopes.',
    ]);

    exit;
}

$validatedEnvelopes = [];

$envelopeUserIds = [];

foreach ($envelopes as $envelope) {
    if (!is_array($envelope)) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation key envelope.',
        ]);

        exit;
    }

    $envelopeUserId =
        $envelope['user_id']
        ?? null;

    $envelopeKeyVersion =
        $envelope['key_version']
        ?? null;

    $encryptedKey =
        $envelope['encrypted_key']
        ?? null;

    /*
     * Envelope user.
     */

    if (
        (
            !is_int($envelopeUserId)
            && !is_string($envelopeUserId)
        )
        || !ctype_digit(
            (string) $envelopeUserId
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid key-envelope user.',
        ]);

        exit;
    }

    $envelopeUserId =
        (int) $envelopeUserId;

    if ($envelopeUserId <= 0) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid key-envelope user.',
        ]);

        exit;
    }

    /*
     * Envelope key version.
     */

    if (
        (
            !is_int($envelopeKeyVersion)
            && !is_string($envelopeKeyVersion)
        )
        || !ctype_digit(
            (string) $envelopeKeyVersion
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid conversation key version.',
        ]);

        exit;
    }

    $envelopeKeyVersion =
        (int) $envelopeKeyVersion;

    if (
        $envelopeKeyVersion
        !== $requestedKeyVersion
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Key-envelope version mismatch.',
        ]);

        exit;
    }

    /*
     * Armored OpenPGP ciphertext.
     */

    if (
        !is_string($encryptedKey)
        || $encryptedKey === ''
        || strlen($encryptedKey) > 100000
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Invalid encrypted conversation key.',
        ]);

        exit;
    }

    if (
        !str_contains(
            $encryptedKey,
            '-----BEGIN PGP MESSAGE-----'
        )
        || !str_contains(
            $encryptedKey,
            '-----END PGP MESSAGE-----'
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Encrypted conversation key must be an armored OpenPGP message.',
        ]);

        exit;
    }

    /*
     * Exactly one envelope per remaining user.
     */

    if (
        in_array(
            $envelopeUserId,
            $envelopeUserIds,
            true
        )
    ) {
        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' =>
                'Duplicate conversation key envelope.',
        ]);

        exit;
    }

    $envelopeUserIds[] =
        $envelopeUserId;

    $validatedEnvelopes[] = [
        'user_id' =>
            $envelopeUserId,

        'key_version' =>
            $envelopeKeyVersion,

        'encrypted_key' =>
            $encryptedKey,
    ];
}

/*
|--------------------------------------------------------------------------
| Authorize + atomically rotate
|--------------------------------------------------------------------------
*/

try {
    $connection = db();

    $connection->beginTransaction();

    try {
        /*
         * Reload conversation state inside the
         * transaction. Do not trust browser role
         * or browser key-version state.
         */

        $conversationStatement =
            $connection->prepare(
                'SELECT
                    c.id,
                    c.workspace_id,
                    c.type,
                    c.key_version,
                    cm.role AS current_user_role
                 FROM conversations c
                 INNER JOIN conversation_members cm
                    ON cm.conversation_id = c.id
                   AND cm.user_id = :current_user_id
                 WHERE c.id = :conversation_id
                   AND c.workspace_id = :workspace_id
                 LIMIT 1'
            );

        $conversationStatement->execute([
            ':current_user_id' =>
                $currentUserId,

            ':conversation_id' =>
                $conversationId,

            ':workspace_id' =>
                $workspaceId,
        ]);

        $conversation =
            $conversationStatement->fetch(
                PDO::FETCH_ASSOC
            );

        if (!$conversation) {
            $connection->rollBack();

            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Conversation is unavailable.',
            ]);

            exit;
        }

        /*
         * Direct messages have fixed membership.
         */

        if (
            (string) $conversation['type']
            === 'direct'
        ) {
            $connection->rollBack();

            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Direct-message members cannot be removed.',
            ]);

            exit;
        }

        /*
         * Only conversation owners/admins may
         * remove another member.
         */

        $currentUserRole =
            (string) $conversation[
                'current_user_role'
            ];

        if (
            $currentUserRole !== 'owner'
            && $currentUserRole !== 'admin'
        ) {
            $connection->rollBack();

            http_response_code(403);

            echo json_encode([
                'success' => false,
                'error' =>
                    'You cannot remove members from this conversation.',
            ]);

            exit;
        }

        /*
         * This endpoint removes another member.
         * Leaving a conversation should be a
         * separate operation.
         */

        if (
            $removeUserId
            === $currentUserId
        ) {
            $connection->rollBack();

            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'You cannot remove yourself with this action.',
            ]);

            exit;
        }

        /*
         * Load the member being removed.
         */

        $removeMemberStatement =
            $connection->prepare(
                'SELECT role
                 FROM conversation_members
                 WHERE conversation_id =
                    :conversation_id
                   AND user_id =
                    :user_id
                 LIMIT 1'
            );

        $removeMemberStatement->execute([
            ':conversation_id' =>
                $conversationId,

            ':user_id' =>
                $removeUserId,
        ]);

        $removeMemberRole =
            $removeMemberStatement->fetchColumn();

        if ($removeMemberRole === false) {
            $connection->rollBack();

            http_response_code(404);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Conversation member is unavailable.',
            ]);

            exit;
        }

        /*
         * The owner cannot be removed.
         *
         * Ownership transfer can be implemented
         * separately later.
         */

        if (
            (string) $removeMemberRole
            === 'owner'
        ) {
            $connection->rollBack();

            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'The conversation owner cannot be removed.',
            ]);

            exit;
        }

        /*
         * An admin cannot remove another admin.
         * The owner may remove admins.
         */

        if (
            $currentUserRole === 'admin'
            && (string) $removeMemberRole
                === 'admin'
        ) {
            $connection->rollBack();

            http_response_code(403);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Only the conversation owner can remove an administrator.',
            ]);

            exit;
        }

        /*
         * Prevent stale/racing rotations.
         */

        $currentKeyVersion =
            (int) $conversation[
                'key_version'
            ];

        $expectedKeyVersion =
            $currentKeyVersion + 1;

        if (
            $requestedKeyVersion
            !== $expectedKeyVersion
        ) {
            $connection->rollBack();

            http_response_code(409);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Conversation encryption state changed. Reload the conversation and try again.',

                'current_key_version' =>
                    $currentKeyVersion,
            ]);

            exit;
        }

        /*
         * Determine exactly which members will
         * remain after the removal.
         */

        $membersStatement =
            $connection->prepare(
                'SELECT user_id
                 FROM conversation_members
                 WHERE conversation_id =
                    :conversation_id
                   AND user_id <> :remove_user_id
                 ORDER BY user_id ASC'
            );

        $membersStatement->execute([
            ':conversation_id' =>
                $conversationId,

            ':remove_user_id' =>
                $removeUserId,
        ]);

        $remainingUserIds =
            array_map(
                'intval',
                $membersStatement->fetchAll(
                    PDO::FETCH_COLUMN
                )
            );

        if ($remainingUserIds === []) {
            throw new RuntimeException(
                'Conversation must retain at least one member.'
            );
        }

        /*
         * Every remaining member must receive
         * exactly one envelope, and the removed
         * member must receive none.
         */

        $sortedEnvelopeUserIds =
            $envelopeUserIds;

        sort(
            $sortedEnvelopeUserIds,
            SORT_NUMERIC
        );

        if (
            $remainingUserIds
            !== $sortedEnvelopeUserIds
        ) {
            $connection->rollBack();

            http_response_code(400);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Key envelopes must exactly match the remaining conversation members.',
            ]);

            exit;
        }

        /*
         * Verify every remaining member still
         * belongs to this workspace.
         */

        $placeholders =
            implode(
                ',',
                array_fill(
                    0,
                    count($remainingUserIds),
                    '?'
                )
            );

        $workspaceMemberStatement =
            $connection->prepare(
                'SELECT user_id
                 FROM workspace_members
                 WHERE workspace_id = ?
                   AND user_id IN ('
                    . $placeholders
                    . ')
                 ORDER BY user_id ASC'
            );

        $workspaceMemberStatement->execute([
            $workspaceId,
            ...$remainingUserIds,
        ]);

        $workspaceMemberIds =
            array_map(
                'intval',
                $workspaceMemberStatement
                    ->fetchAll(
                        PDO::FETCH_COLUMN
                    )
            );

        if (
            $workspaceMemberIds
            !== $remainingUserIds
        ) {
            $connection->rollBack();

            http_response_code(409);

            echo json_encode([
                'success' => false,
                'error' =>
                    'Conversation membership changed. Reload and try again.',
            ]);

            exit;
        }

        /*
         * Store the new encrypted envelopes
         * BEFORE changing membership/version.
         */

        $keyStatement =
            $connection->prepare(
                'INSERT INTO conversation_keys (
                    conversation_id,
                    user_id,
                    key_version,
                    encrypted_key
                 )
                 VALUES (
                    :conversation_id,
                    :user_id,
                    :key_version,
                    :encrypted_key
                 )'
            );

        foreach (
            $validatedEnvelopes
            as $envelope
        ) {
            $keyStatement->execute([
                ':conversation_id' =>
                    $conversationId,

                ':user_id' =>
                    $envelope['user_id'],

                ':key_version' =>
                    $requestedKeyVersion,

                ':encrypted_key' =>
                    $envelope['encrypted_key'],
            ]);
        }

        /*
         * Remove access to future conversation
         * state.
         *
         * Historical key envelopes are deliberately
         * retained so previously authorized users
         * keep their historical access.
         */

        $deleteMemberStatement =
            $connection->prepare(
                'DELETE FROM conversation_members
                 WHERE conversation_id =
                    :conversation_id
                   AND user_id =
                    :user_id'
            );

        $deleteMemberStatement->execute([
            ':conversation_id' =>
                $conversationId,

            ':user_id' =>
                $removeUserId,
        ]);

        if (
            $deleteMemberStatement->rowCount()
            !== 1
        ) {
            throw new RuntimeException(
                'Conversation member could not be removed.'
            );
        }

        /*
         * Advance the current key version only
         * after the new envelopes exist.
         *
         * Include the old version in the WHERE
         * clause as an additional race guard.
         */

        $updateStatement =
            $connection->prepare(
                'UPDATE conversations
                 SET key_version =
                        :new_key_version,
                     updated_at =
                        CURRENT_TIMESTAMP
                 WHERE id =
                        :conversation_id
                   AND key_version =
                        :old_key_version'
            );

        $updateStatement->execute([
            ':new_key_version' =>
                $requestedKeyVersion,

            ':conversation_id' =>
                $conversationId,

            ':old_key_version' =>
                $currentKeyVersion,
        ]);

        if (
            $updateStatement->rowCount()
            !== 1
        ) {
            throw new RuntimeException(
                'Conversation key version could not be advanced.'
            );
        }

        $connection->commit();

        echo json_encode([
            'success' => true,

            'conversation_id' =>
                $conversationId,

            'removed_user_id' =>
                $removeUserId,

            'key_version' =>
                $requestedKeyVersion,
        ]);
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
} catch (Throwable $error) {
    error_log(
        'Messaging member removal failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' =>
            'Could not remove conversation member.',
    ]);
}