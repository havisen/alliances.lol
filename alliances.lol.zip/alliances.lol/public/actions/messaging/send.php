<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/database.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$currentUser = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access = workspace_access(
    (int) $currentUser['id']
);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access required.',
    ]);

    exit;
}

$conversationId =
    filter_input(
        INPUT_POST,
        'conversation_id',
        FILTER_VALIDATE_INT
    );

$keyVersion =
    filter_input(
        INPUT_POST,
        'key_version',
        FILTER_VALIDATE_INT
    );

$ciphertext =
    trim(
        (string) (
            $_POST['ciphertext']
            ?? ''
        )
    );

$iv =
    trim(
        (string) (
            $_POST['iv']
            ?? ''
        )
    );

if (
    $conversationId === false
    || $conversationId === null
    || $conversationId <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation.',
    ]);

    exit;
}

if (
    $keyVersion === false
    || $keyVersion === null
    || $keyVersion <= 0
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encryption key version.',
    ]);

    exit;
}

/*
|--------------------------------------------------------------------------
| Validate encoded encrypted data
|--------------------------------------------------------------------------
|
| The server never decrypts this data.
|
| These checks only make sure obviously malformed or excessively large
| values are not written to the database.
|
*/

if (
    $ciphertext === ''
    || strlen($ciphertext) > 100000
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encrypted message.',
    ]);

    exit;
}

if (
    $iv === ''
    || strlen($iv) > 100
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid encryption IV.',
    ]);

    exit;
}

$ciphertextBytes =
    base64_decode(
        $ciphertext,
        true
    );

$ivBytes =
    base64_decode(
        $iv,
        true
    );

if (
    $ciphertextBytes === false
    || $ivBytes === false
) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted message encoding is invalid.',
    ]);

    exit;
}

/*
 * AES-GCM uses a fresh 96-bit / 12-byte IV
 * for every message.
 */

if (strlen($ivBytes) !== 12) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted message IV is invalid.',
    ]);

    exit;
}

/*
 * AES-GCM ciphertext contains the authentication
 * tag as part of the Web Crypto output.
 *
 * Therefore even an empty plaintext would produce
 * at least a 16-byte authentication tag.
 */

if (strlen($ciphertextBytes) < 16) {
    http_response_code(422);

    echo json_encode([
        'success' => false,
        'error' => 'Encrypted message is invalid.',
    ]);

    exit;
}

$pdo = db();

try {
    /*
    |--------------------------------------------------------------------------
    | Verify conversation access and current key version
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
                SELECT
                    c.id,
                    c.type,
                    c.key_version,
                    cm.role
                FROM conversations c
                INNER JOIN conversation_members cm
                    ON cm.conversation_id = c.id
                WHERE c.id = :conversation_id
                  AND c.workspace_id = :workspace_id
                  AND cm.user_id = :user_id
                LIMIT 1
            '
        );

    $statement->execute([
        ':conversation_id' =>
            $conversationId,

        ':workspace_id' =>
            (int) $access['workspace_id'],

        ':user_id' =>
            (int) $currentUser['id'],
    ]);

    $conversation =
        $statement->fetch();

    if (!$conversation) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation is unavailable.',
        ]);

        exit;
    }

    /*
     * Never accept ciphertext encrypted with an
     * obsolete conversation key.
     */

    if (
        (int) $conversation['key_version']
        !== $keyVersion
    ) {
        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' =>
                'Conversation encryption key has changed. Unlock the conversation again.',
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Channel permissions
    |--------------------------------------------------------------------------
    |
    | Direct messages and ordinary group chats keep their existing rules.
    |
    | In channels, only workspace administrators can post. Team Leads who are
    | not workspace admins, and ordinary members, may still read channels but
    | cannot send messages to them.
    |
    */

    if (
        $conversation['type'] === 'channel'
        && $access['is_admin'] !== true
    ) {
        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' =>
                'Only workspace administrators can post in this channel.',
        ]);

        exit;
    }

    /*
    |--------------------------------------------------------------------------
    | Store ciphertext
    |--------------------------------------------------------------------------
    */

    $pdo->beginTransaction();

    $statement =
        $pdo->prepare(
            '
                INSERT INTO messages (
                    conversation_id,
                    sender_id,
                    key_version,
                    ciphertext,
                    iv
                )
                VALUES (
                    :conversation_id,
                    :sender_id,
                    :key_version,
                    :ciphertext,
                    :iv
                )
            '
        );

    $statement->execute([
        ':conversation_id' =>
            $conversationId,

        ':sender_id' =>
            (int) $currentUser['id'],

        ':key_version' =>
            $keyVersion,

        ':ciphertext' =>
            $ciphertext,

        ':iv' =>
            $iv,
    ]);

    $messageId =
        (int) $pdo->lastInsertId();

    /*
     * Move the conversation to the top of the
     * conversation list when activity occurs.
     */

    $statement =
        $pdo->prepare(
            '
                UPDATE conversations
                SET updated_at = CURRENT_TIMESTAMP
                WHERE id = :conversation_id
            '
        );

    $statement->execute([
        ':conversation_id' =>
            $conversationId,
    ]);

    $recipientStatement = $pdo->prepare(
        'SELECT cm.user_id
         FROM conversation_members cm
         INNER JOIN users u
             ON u.id = cm.user_id
         WHERE cm.conversation_id = ?
           AND cm.user_id <> ?
           AND u.account_status = "active"'
    );

    $recipientStatement->execute([
        $conversationId,
        (int) $currentUser['id'],
    ]);

    $recipientIds = array_map(
        static fn (array $row): int => (int) $row['user_id'],
        $recipientStatement->fetchAll()
    );

    create_notifications_for_users($recipientIds, [
        'workspace_id' => (int) $access['workspace_id'],
        'actor_user_id' => (int) $currentUser['id'],
        'type' => 'message_received',
        'category' => 'messaging',
        'title' => (string) $currentUser['display_name']
            . ' sent you a message',
        'body' => 'New encrypted message',
        'target_type' => 'conversation',
        'target_id' => $conversationId,
        'target_url' => '/messaging/?conversation_id=' . $conversationId,
    ]);

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => [
            'id' =>
                $messageId,

            'conversation_id' =>
                $conversationId,

            'sender_id' =>
                (int) $currentUser['id'],

            'key_version' =>
                $keyVersion,
        ],
    ]);
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Messaging send error: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not send encrypted message.',
    ]);
}
