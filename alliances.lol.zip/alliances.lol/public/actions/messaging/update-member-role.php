<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/messaging/messaging.php';

header(
    'Content-Type: application/json; charset=utf-8'
);

header(
    'Cache-Control: no-store'
);

$user = require_login();

if (
    $_SERVER['REQUEST_METHOD']
    !== 'POST'
) {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

require_valid_csrf();

$access =
    workspace_access(
        (int) $user['id']
    );

if (!$access) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'Workspace access is required.',
    ]);

    exit;
}

$workspaceId =
    (int) $access[
        'workspace_id'
    ];

$currentUserId =
    (int) $user['id'];


/*
|--------------------------------------------------------------------------
| Request data
|--------------------------------------------------------------------------
*/

$conversationId =
    filter_input(
        INPUT_POST,
        'conversation_id',
        FILTER_VALIDATE_INT
    );

$targetUserId =
    filter_input(
        INPUT_POST,
        'user_id',
        FILTER_VALIDATE_INT
    );

$newRole =
    isset($_POST['role'])
        ? trim(
            (string) $_POST['role']
        )
        : '';


if (
    !$conversationId
    || $conversationId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation.',
    ]);

    exit;
}


if (
    !$targetUserId
    || $targetUserId <= 0
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation member.',
    ]);

    exit;
}


/*
 * Only these two roles may be assigned
 * through this endpoint.
 *
 * Ownership cannot be assigned or removed
 * here.
 */
if (
    $newRole !== 'admin'
    && $newRole !== 'member'
) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'error' => 'Invalid conversation role.',
    ]);

    exit;
}


$pdo = db();

try {
    $pdo->beginTransaction();


    /*
    |--------------------------------------------------------------------------
    | Load conversation + requester's role
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                c.id,
                c.type,
                cm.role AS requester_role
            FROM conversations AS c
            INNER JOIN conversation_members AS cm
                ON cm.conversation_id = c.id
                AND cm.user_id = :current_user_id
            WHERE
                c.id = :conversation_id
                AND c.workspace_id = :workspace_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':current_user_id' =>
            $currentUserId,

        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);

    $conversation =
        $statement->fetch();


    if (!$conversation) {
        $pdo->rollBack();

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation not found.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Direct messages do not use role management
    |--------------------------------------------------------------------------
    */

    if (
        $conversation['type']
        === 'direct'
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'Direct-message roles cannot be changed.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Only the owner can change roles
    |--------------------------------------------------------------------------
    */

    $requesterRole =
        (string) $conversation[
            'requester_role'
        ];

    if (
        $requesterRole !== 'owner'
    ) {
        $pdo->rollBack();

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'error' => 'Only the conversation owner can change member roles.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Load target member
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            SELECT
                cm.user_id,
                cm.role
            FROM conversation_members AS cm
            WHERE
                cm.conversation_id = :conversation_id
                AND cm.user_id = :user_id
            LIMIT 1
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':user_id' =>
            (int) $targetUserId,
    ]);

    $targetMember =
        $statement->fetch();


    if (!$targetMember) {
        $pdo->rollBack();

        http_response_code(404);

        echo json_encode([
            'success' => false,
            'error' => 'Conversation member not found.',
        ]);

        exit;
    }


    $currentTargetRole =
        (string) $targetMember[
            'role'
        ];


    /*
    |--------------------------------------------------------------------------
    | Owner role cannot be changed
    |--------------------------------------------------------------------------
    */

    if (
        $currentTargetRole
        === 'owner'
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'The conversation owner role cannot be changed.',
        ]);

        exit;
    }


    /*
     * The owner should never need to change
     * their own role through this endpoint.
     */
    if (
        (int) $targetUserId
        === $currentUserId
    ) {
        $pdo->rollBack();

        http_response_code(400);

        echo json_encode([
            'success' => false,
            'error' => 'You cannot change your own conversation role.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Validate the role transition
    |--------------------------------------------------------------------------
    |
    | We deliberately only permit:
    |
    | member -> admin
    | admin  -> member
    |
    */

    $validTransition =
        (
            $currentTargetRole === 'member'
            && $newRole === 'admin'
        )
        || (
            $currentTargetRole === 'admin'
            && $newRole === 'member'
        );


    if (!$validTransition) {
        $pdo->rollBack();

        http_response_code(409);

        echo json_encode([
            'success' => false,
            'error' => 'The member already has that role or the role change is invalid.',
        ]);

        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | Update role
    |--------------------------------------------------------------------------
    */

    $statement =
        $pdo->prepare(
            '
            UPDATE conversation_members
            SET
                role = :role
            WHERE
                conversation_id = :conversation_id
                AND user_id = :user_id
                AND role = :old_role
            '
        );

    $statement->execute([
        ':role' =>
            $newRole,

        ':conversation_id' =>
            (int) $conversationId,

        ':user_id' =>
            (int) $targetUserId,

        ':old_role' =>
            $currentTargetRole,
    ]);


    if (
        $statement->rowCount()
        !== 1
    ) {
        throw new RuntimeException(
            'Conversation member role changed during the update.'
        );
    }


    /*
     * Update conversation activity metadata.
     *
     * No encryption-key rotation occurs because
     * the membership itself did not change.
     */
    $statement =
        $pdo->prepare(
            '
            UPDATE conversations
            SET
                updated_at = CURRENT_TIMESTAMP
            WHERE
                id = :conversation_id
                AND workspace_id = :workspace_id
            '
        );

    $statement->execute([
        ':conversation_id' =>
            (int) $conversationId,

        ':workspace_id' =>
            $workspaceId,
    ]);


    $pdo->commit();


    echo json_encode([
        'success' => true,

        'conversation_id' =>
            (int) $conversationId,

        'user_id' =>
            (int) $targetUserId,

        'role' =>
            $newRole,
    ]);

    exit;
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Messaging update-member-role failed: '
        . $exception->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Could not update conversation member role.',
    ]);

    exit;
}