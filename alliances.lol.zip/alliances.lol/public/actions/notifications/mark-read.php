<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$notificationId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$notificationId) {
    http_response_code(400);
    exit('Invalid notification.');
}

mark_notification_read(
    (int) $access['workspace_id'],
    (int) $user['id'],
    $notificationId
);

header('Location: /notifications/');
exit;
