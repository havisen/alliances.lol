<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);
$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$announcementId = (int) filter_input(INPUT_POST, 'announcement_id', FILTER_VALIDATE_INT);

if ($announcementId <= 0) {
    http_response_code(400);
    exit('Invalid announcement.');
}

$pdo = db();

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    $update = $pdo->prepare(
        'UPDATE project_announcements
         SET archived_at = CURRENT_TIMESTAMP,
             is_pinned = 0,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ? AND project_id = ? AND archived_at IS NULL'
    );
    $update->execute([$announcementId, $projectId]);

    if ($update->rowCount() !== 1) {
        throw new RuntimeException('Announcement not found.');
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Announcement not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Announcement not found.'
        ? 'Announcement not found.'
        : 'Could not archive the announcement.');
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
