<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);
$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$announcementId = (int) filter_input(INPUT_POST, 'announcement_id', FILTER_VALIDATE_INT);
$title = trim((string) ($_POST['title'] ?? ''));
$body = trim((string) ($_POST['body'] ?? ''));

if ($title === '' || mb_strlen($title) > 160) {
    http_response_code(400);
    exit('Announcement title is required and must be 160 characters or fewer.');
}

if (mb_strlen($body) > 10000) {
    http_response_code(400);
    exit('Announcement body must be 10000 characters or fewer.');
}

$pdo = db();
$isNew = $announcementId <= 0;

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    if ($isNew) {
        $insert = $pdo->prepare(
            'INSERT INTO project_announcements
                (project_id, author_id, title, body, is_pinned, archived_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, 0, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
        );
        $insert->execute([
            $projectId,
            (int) $user['id'],
            $title,
            $body !== '' ? $body : null,
        ]);
        $announcementId = (int) $pdo->lastInsertId();
    } else {
        $exists = $pdo->prepare(
            'SELECT id
             FROM project_announcements
             WHERE id = ? AND project_id = ? AND archived_at IS NULL'
        );
        $exists->execute([$announcementId, $projectId]);

        if ($exists->fetchColumn() === false) {
            throw new RuntimeException('Announcement not found.');
        }

        $update = $pdo->prepare(
            'UPDATE project_announcements
             SET title = ?, body = ?, updated_at = CURRENT_TIMESTAMP
             WHERE id = ? AND project_id = ? AND archived_at IS NULL'
        );
        $update->execute([
            $title,
            $body !== '' ? $body : null,
            $announcementId,
            $projectId,
        ]);

        if ($update->rowCount() !== 1) {
            throw new RuntimeException('Announcement not found.');
        }
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Announcement not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Announcement not found.'
        ? 'Announcement not found.'
        : 'Could not save the announcement.');
}

/*
 * Only a newly posted announcement fans out a notification. Editing an
 * existing announcement does not generate another event.
 */
if ($isNew) {
    try {
        $recipientIds = [];

        foreach (project_effective_members($projectId, $workspaceId) as $member) {
            $recipientId = (int) ($member['user_id'] ?? 0);

            if ($recipientId > 0 && $recipientId !== (int) $user['id']) {
                $recipientIds[] = $recipientId;
            }
        }

        create_project_notifications_for_users(
            $recipientIds,
            [
                'workspace_id' => $workspaceId,
                'actor_user_id' => (int) $user['id'],
                'type' => 'project_announcement_posted',
                'title' => 'New project announcement',
                'body' => $title,
                'target_url' => '/projects/project.php?id=' . $projectId,
            ],
            250
        );
    } catch (Throwable $notificationException) {
        // The announcement is already committed; notification failure must not
        // turn a successful Project mutation into a duplicate-post retry.
    }
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
