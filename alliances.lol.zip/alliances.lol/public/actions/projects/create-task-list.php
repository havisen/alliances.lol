<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';
require_once dirname(__DIR__, 3) . '/src/tasks/lists.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(
    INPUT_POST,
    'project_id',
    FILTER_VALIDATE_INT
);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

if ((string) $project['status'] === 'archived') {
    header(
        'Location: /projects/tasks.php?id=' . $projectId
        . '&error=' . urlencode('Archived projects cannot be modified.')
    );
    exit;
}

$name = trim((string) ($_POST['name'] ?? ''));
$startDate = trim((string) ($_POST['start_date'] ?? ''));
$deadline = trim((string) ($_POST['deadline'] ?? ''));

$submittedTeamId = filter_input(
    INPUT_POST,
    'team_id',
    FILTER_VALIDATE_INT
);
$teamId = $submittedTeamId ?: null;

$membersCanEdit = isset($_POST['members_can_edit']);

$submittedMemberIds = $_POST['member_ids'] ?? [];

if (!is_array($submittedMemberIds)) {
    $submittedMemberIds = [];
}

try {
    $listId = task_list_create(
        $workspaceId,
        (int) $user['id'],
        $name,
        $startDate !== '' ? $startDate : null,
        $deadline !== '' ? $deadline : null,
        $teamId !== null ? (int) $teamId : null,
        $membersCanEdit,
        $submittedMemberIds,
        $projectId
    );
} catch (InvalidArgumentException | RuntimeException $error) {
    header(
        'Location: /projects/tasks.php?id=' . $projectId
        . '&error=' . urlencode($error->getMessage())
    );
    exit;
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not create the task list. Please try again.');
}

/*
|--------------------------------------------------------------------------
| Notify the initial task list members (matches the global Tasks creator).
|--------------------------------------------------------------------------
*/

$recipientStatement = db()->prepare(
    'SELECT DISTINCT tlm.user_id
     FROM task_list_members tlm
     INNER JOIN users u
         ON u.id = tlm.user_id
     WHERE tlm.task_list_id = ?
       AND u.account_status = "active"'
);

$recipientStatement->execute([$listId]);

$recipientIds = array_map(
    static fn (array $row): int => (int) $row['user_id'],
    $recipientStatement->fetchAll()
);

create_notifications_for_users($recipientIds, [
    'workspace_id' => $workspaceId,
    'actor_user_id' => (int) $user['id'],
    'type' => $teamId !== null
        ? 'task_team_list_created'
        : 'task_list_created',
    'category' => 'tasks',
    'title' => $teamId !== null
        ? 'A task list was assigned to your team'
        : 'You were added to a task list',
    'body' => $name,
    'target_type' => 'task_list',
    'target_id' => $listId,
    'target_url' => '/tasks/task-list.php?id=' . $listId,
]);

header('Location: /tasks/task-list.php?id=' . $listId);
exit;