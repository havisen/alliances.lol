<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

/*
|--------------------------------------------------------------------------
| Project creation is Workspace Admin only
|--------------------------------------------------------------------------
|
| The create form is hidden for everyone else, but this guard rejects a
| direct POST from a non-admin as well.
*/

if (empty($access['is_admin'])) {
    http_response_code(403);
    exit('Only workspace administrators can create projects.');
}

/*
|--------------------------------------------------------------------------
| Resolve the workspace from trusted access context
|--------------------------------------------------------------------------
|
| workspace_id is never read from the browser. The Project always belongs
| to the authenticated user's current workspace.
*/

$workspaceId = (int) $access['workspace_id'];

$name = trim((string) ($_POST['name'] ?? ''));
$description = trim((string) ($_POST['description'] ?? ''));
$startDate = trim((string) ($_POST['start_date'] ?? ''));
$targetDate = trim((string) ($_POST['target_date'] ?? ''));

/*
|--------------------------------------------------------------------------
| Validate optional dates server-side
|--------------------------------------------------------------------------
|
| The name is validated inside project_create() via project_validate_name().
*/

foreach ([
    'start date' => $startDate,
    'target date' => $targetDate,
] as $label => $value) {
    if ($value === '') {
        continue;
    }

    if (
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)
        || !checkdate(
            (int) substr($value, 5, 2),
            (int) substr($value, 8, 2),
            (int) substr($value, 0, 4)
        )
    ) {
        http_response_code(400);
        exit('Enter a valid ' . $label . ' (YYYY-MM-DD).');
    }
}

/*
|--------------------------------------------------------------------------
| Create the Project with the creator as its initial Lead
|--------------------------------------------------------------------------
|
| The Project starts in 'planning'. The current user's ID is passed through
| $leadUserIds so project_create() writes the explicit project_members
| (role = 'lead') row atomically with the Project itself.
*/

try {
    project_create(
        $workspaceId,
        (int) $user['id'],
        $name,
        $description !== '' ? $description : null,
        $startDate !== '' ? $startDate : null,
        $targetDate !== '' ? $targetDate : null,
        [(int) $user['id']]
    );
} catch (InvalidArgumentException $error) {
    http_response_code(400);
    exit($error->getMessage());
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not create the project. Please try again.');
}

header('Location: /projects/');
exit;