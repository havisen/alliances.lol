<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';
require_once dirname(__DIR__, 3) . '/src/tasks/lists.php';
require_once dirname(__DIR__, 3) . '/src/tasks/access.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(
    INPUT_POST,
    'project_id',
    FILTER_VALIDATE_INT
);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

if ((string) $project['status'] === 'archived') {
    header(
        'Location: /projects/tasks.php?id=' . $projectId
        . '&error=' . urlencode('Archived projects cannot be modified.')
    );
    exit;
}

$taskListId = (int) filter_input(
    INPUT_POST,
    'task_list_id',
    FILTER_VALIDATE_INT
);

$list = $taskListId > 0
    ? task_list_by_id($taskListId, $workspaceId)
    : null;

if ($list === null) {
    http_response_code(404);
    exit('Task list not found.');
}

if (!task_list_can_manage($access, $list, (int) $user['id'])) {
    http_response_code(403);
    exit('You do not have permission to manage this task list.');
}

try {
    task_list_detach_project(
        $workspaceId,
        $taskListId,
        $projectId
    );
} catch (InvalidArgumentException | RuntimeException $error) {
    header(
        'Location: /projects/tasks.php?id=' . $projectId
        . '&error=' . urlencode($error->getMessage())
    );
    exit;
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not detach the task list. Please try again.');
}

header('Location: /projects/tasks.php?id=' . $projectId);
exit;