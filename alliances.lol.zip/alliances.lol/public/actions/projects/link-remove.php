<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);
if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);
$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$linkId = (int) filter_input(INPUT_POST, 'link_id', FILTER_VALIDATE_INT);
if ($linkId <= 0) {
    http_response_code(400);
    exit('Invalid link.');
}

$pdo = db();

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    $delete = $pdo->prepare(
        'DELETE FROM project_links WHERE id = ? AND project_id = ?'
    );
    $delete->execute([$linkId, $projectId]);

    if ($delete->rowCount() !== 1) {
        throw new RuntimeException('Link not found.');
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Link not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Link not found.' ? 'Link not found.' : 'Could not remove the link.');
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
