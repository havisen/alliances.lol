<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);
if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);
$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$linkId = (int) filter_input(INPUT_POST, 'link_id', FILTER_VALIDATE_INT);
$title = trim((string) ($_POST['title'] ?? ''));
$url = trim((string) ($_POST['url'] ?? ''));
$kind = trim((string) ($_POST['kind'] ?? 'link'));

if ($title === '' || mb_strlen($title) > 160) {
    http_response_code(400);
    exit('Link title is required and must be 160 characters or fewer.');
}

if ($kind === '' || mb_strlen($kind) > 40) {
    http_response_code(400);
    exit('Link kind is required and must be 40 characters or fewer.');
}

if ($url === '' || mb_strlen($url) > 2048 || filter_var($url, FILTER_VALIDATE_URL) === false) {
    http_response_code(400);
    exit('Enter a valid link URL.');
}

$scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));
if (!in_array($scheme, ['http', 'https'], true)) {
    http_response_code(400);
    exit('Only http:// and https:// links are allowed.');
}

$pdo = db();

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    if ($linkId > 0) {
        $update = $pdo->prepare(
            'UPDATE project_links
             SET title = ?, url = ?, kind = ?
             WHERE id = ? AND project_id = ?'
        );
        $update->execute([$title, $url, $kind, $linkId, $projectId]);

        if ($update->rowCount() !== 1) {
            $exists = $pdo->prepare(
                'SELECT 1 FROM project_links WHERE id = ? AND project_id = ?'
            );
            $exists->execute([$linkId, $projectId]);
            if ($exists->fetchColumn() === false) {
                throw new RuntimeException('Link not found.');
            }
        }
    } else {
        $insert = $pdo->prepare(
            'INSERT INTO project_links
                (project_id, title, url, kind, added_by, created_at)
             VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)'
        );
        $insert->execute([$projectId, $title, $url, $kind, (int) $user['id']]);
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Link not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Link not found.' ? 'Link not found.' : 'Could not save the link.');
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
