<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$milestoneId = (int) filter_input(INPUT_POST, 'milestone_id', FILTER_VALIDATE_INT);

if ($milestoneId <= 0) {
    http_response_code(400);
    exit('Invalid milestone.');
}

$pdo = db();

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    $delete = $pdo->prepare(
        'DELETE FROM project_milestones WHERE id = ? AND project_id = ?'
    );
    $delete->execute([$milestoneId, $projectId]);

    if ($delete->rowCount() !== 1) {
        throw new RuntimeException('Milestone not found.');
    }

    // Compact positions after deletion.
    $remaining = $pdo->prepare(
        'SELECT id FROM project_milestones WHERE project_id = ? ORDER BY position ASC, id ASC'
    );
    $remaining->execute([$projectId]);

    $reposition = $pdo->prepare(
        'UPDATE project_milestones SET position = ?, updated_at = CURRENT_TIMESTAMP
         WHERE id = ? AND project_id = ?'
    );

    $position = 1;
    foreach ($remaining->fetchAll(PDO::FETCH_COLUMN) as $remainingId) {
        $reposition->execute([$position++, (int) $remainingId, $projectId]);
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Milestone not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Milestone not found.'
        ? 'Milestone not found.'
        : 'Could not delete the milestone.');
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
