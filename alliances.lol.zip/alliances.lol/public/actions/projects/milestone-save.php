<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$milestoneId = (int) filter_input(INPUT_POST, 'milestone_id', FILTER_VALIDATE_INT);
$title = trim((string) ($_POST['title'] ?? ''));
$description = trim((string) ($_POST['description'] ?? ''));
$dueDate = trim((string) ($_POST['due_date'] ?? ''));

if ($title === '' || mb_strlen($title) > 160) {
    http_response_code(400);
    exit('Milestone title is required and must be 160 characters or fewer.');
}

if (mb_strlen($description) > 4000) {
    http_response_code(400);
    exit('Milestone description must be 4000 characters or fewer.');
}

if ($dueDate !== '') {
    if (
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dueDate)
        || !checkdate(
            (int) substr($dueDate, 5, 2),
            (int) substr($dueDate, 8, 2),
            (int) substr($dueDate, 0, 4)
        )
    ) {
        http_response_code(400);
        exit('Enter a valid due date (YYYY-MM-DD).');
    }
}

$pdo = db();

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    if ($milestoneId > 0) {
        $exists = $pdo->prepare(
            'SELECT id FROM project_milestones WHERE id = ? AND project_id = ?'
        );
        $exists->execute([$milestoneId, $projectId]);

        if ($exists->fetchColumn() === false) {
            throw new RuntimeException('Milestone not found.');
        }

        $update = $pdo->prepare(
            'UPDATE project_milestones
             SET title = ?, description = ?, due_date = ?, updated_at = CURRENT_TIMESTAMP
             WHERE id = ? AND project_id = ?'
        );
        $update->execute([
            $title,
            $description !== '' ? $description : null,
            $dueDate !== '' ? $dueDate : null,
            $milestoneId,
            $projectId,
        ]);
    } else {
        $position = $pdo->prepare(
            'SELECT COALESCE(MAX(position), 0) + 1 FROM project_milestones WHERE project_id = ?'
        );
        $position->execute([$projectId]);

        $insert = $pdo->prepare(
            'INSERT INTO project_milestones
                (project_id, title, description, due_date, status, position, created_by, completed_by, completed_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
        );
        $insert->execute([
            $projectId,
            $title,
            $description !== '' ? $description : null,
            $dueDate !== '' ? $dueDate : null,
            'open',
            (int) $position->fetchColumn(),
            (int) $user['id'],
        ]);
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Milestone not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Milestone not found.'
        ? 'Milestone not found.'
        : 'Could not save the milestone.');
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
