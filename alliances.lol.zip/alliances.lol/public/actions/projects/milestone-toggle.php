<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0 ? project_by_id($projectId, $workspaceId) : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}


$milestoneId = (int) filter_input(INPUT_POST, 'milestone_id', FILTER_VALIDATE_INT);

if ($milestoneId <= 0) {
    http_response_code(400);
    exit('Invalid milestone.');
}

$pdo = db();

try {
    $pdo->beginTransaction();
    project_assert_writable($projectId, $pdo);

    $statement = $pdo->prepare(
        'SELECT id, status
         FROM project_milestones
         WHERE id = ? AND project_id = ?'
    );
    $statement->execute([$milestoneId, $projectId]);
    $milestone = $statement->fetch(PDO::FETCH_ASSOC);

    if ($milestone === false) {
        throw new RuntimeException('Milestone not found.');
    }

    if ((string) $milestone['status'] === 'completed') {
        $update = $pdo->prepare(
            'UPDATE project_milestones
             SET status = ?, completed_by = NULL, completed_at = NULL, updated_at = CURRENT_TIMESTAMP
             WHERE id = ? AND project_id = ?'
        );
        $update->execute(['open', $milestoneId, $projectId]);
    } else {
        $update = $pdo->prepare(
            'UPDATE project_milestones
             SET status = ?, completed_by = ?, completed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
             WHERE id = ? AND project_id = ?'
        );
        $update->execute(['completed', (int) $user['id'], $milestoneId, $projectId]);
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code($exception->getMessage() === 'Milestone not found.' ? 404 : 409);
    exit($exception->getMessage() === 'Milestone not found.'
        ? 'Milestone not found.'
        : 'Could not update the milestone.');
}

header('Location: /projects/project.php?id=' . $projectId, true, 303);
exit;
