<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}
require_valid_csrf();
$userId = (int) $user['id'];
$access = workspace_access($userId);
if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}
$workspaceId = (int) $access['workspace_id'];
$projectId = (int) ($_POST['project_id'] ?? 0);
$project = project_by_id($projectId, $workspaceId);
if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}
if (!project_user_can_manage($access, $userId, $projectId)) {
    http_response_code(403);
    exit('Project management permission required.');
}
project_require_writable_request($project);
$connection = db();
try {
    $connection->beginTransaction();
    project_assert_writable($projectId, $connection);
    $action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
    $pageId = filter_var($_POST['page_id'] ?? 0, FILTER_VALIDATE_INT);
    $page = $connection->prepare(
        'SELECT id, page_key
         FROM project_overview_pages
         WHERE id = ? AND project_id = ? AND archived_at IS NULL AND is_visible = 1'
    );
    $page->execute([$pageId, $projectId]);
    $pageRow = $page->fetch(PDO::FETCH_ASSOC);
    if ($pageRow === false) {
        throw new InvalidArgumentException('Page unavailable.');
    }
    $pageKey = (string) $pageRow['page_key'];
    $moduleId = filter_var($_POST['module_id'] ?? 0, FILTER_VALIDATE_INT);
    $module = null;
    if ($action !== 'add') {
        $find = $connection->prepare('SELECT * FROM project_overview_modules WHERE id = ? AND page_id = ? AND project_id = ?');
        $find->execute([$moduleId, $pageId, $projectId]);
        $module = $find->fetch();
        if (!$module) {
            throw new InvalidArgumentException('Module unavailable.');
        }
    }
    if (in_array($action, ['add', 'duplicate'], true)) {
        $count = $connection->prepare('SELECT COUNT(*) FROM project_overview_modules WHERE page_id = ? AND project_id = ?');
        $count->execute([$pageId, $projectId]);
        if ((int) $count->fetchColumn() >= 24) {
            throw new InvalidArgumentException('A page can contain up to 24 modules.');
        }
        $key = $module['module_key'] ?? (is_string($_POST['module_key'] ?? null) ? $_POST['module_key'] : '');
        $meta = project_overview_module_meta($key);
        if ($meta === null) {
            throw new InvalidArgumentException('Invalid module type.');
        }
        $config = $module !== null ? project_overview_decode_config($key, $module['config']) : project_overview_normalize_config($key, []);
        project_overview_validate_resource_config($projectId, $workspaceId, $userId, $key, $config);
        $insert = $connection->prepare('INSERT INTO project_overview_modules
            (project_id, page_id, module_key, title, position, col_span, visibility, config)
            SELECT ?, ?, ?, ?, COALESCE(MAX(position), -1) + 1, ?, ?, ? FROM project_overview_modules WHERE page_id = ?');
        $insert->execute([$projectId, $pageId, $key, $module['title'] ?? $meta['label'],
            $module['col_span'] ?? $meta['default_span'], $module['visibility'] ?? 'all',
            json_encode($config, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), $pageId]);
    } elseif ($action === 'save') {
        $title = is_string($_POST['title'] ?? null) ? trim($_POST['title']) : '';
        $span = filter_var($_POST['col_span'] ?? 1, FILTER_VALIDATE_INT);
        $visibility = $_POST['visibility'] ?? 'all';
        if (mb_strlen($title) > 120 || $span === false || $span < 1 || $span > 3 || !in_array($visibility, ['all', 'leads'], true)) {
            throw new InvalidArgumentException('Invalid title, span, or visibility.');
        }
        $input = $_POST['config'] ?? [];
        if (!is_array($input)) {
            throw new InvalidArgumentException('Invalid configuration.');
        }
        $config = project_overview_normalize_config($module['module_key'], $input);
        project_overview_validate_resource_config($projectId, $workspaceId, $userId, $module['module_key'], $config);
        $update = $connection->prepare('UPDATE project_overview_modules SET title = ?, col_span = ?, visibility = ?, config = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND project_id = ?');
        $update->execute([$title, $span, $visibility, json_encode($config, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE), $moduleId, $projectId]);
    } elseif ($action === 'remove') {
        $connection->prepare('DELETE FROM project_overview_modules WHERE id = ? AND project_id = ?')->execute([$moduleId, $projectId]);
    } elseif ($action === 'up' || $action === 'down') {
        $rows = project_overview_modules_all($projectId, $pageId);
        $index = array_search((int) $moduleId, array_map(static fn(array $r): int => (int) $r['id'], $rows), true);
        $other = $index + ($action === 'up' ? -1 : 1);
        if (isset($rows[$other])) {
            [$rows[$index], $rows[$other]] = [$rows[$other], $rows[$index]];
        }
        $update = $connection->prepare('UPDATE project_overview_modules SET position = ? WHERE id = ? AND project_id = ?');
        foreach ($rows as $position => $row) {
            $update->execute([$position, $row['id'], $projectId]);
        }
    } else {
        throw new InvalidArgumentException('Unknown module action.');
    }
    $connection->commit();
    header('Location: /projects/project.php?id=' . $projectId . '&page=' . urlencode($pageKey), true, 303);
} catch (Throwable $error) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }
    $message = $error instanceof InvalidArgumentException ? $error->getMessage() : 'Could not save the module.';
    header('Location: /projects/project.php?id=' . $projectId . '&page=' . urlencode($pageKey ?? '') . '&error=' . urlencode($message), true, 303);
}
exit;
