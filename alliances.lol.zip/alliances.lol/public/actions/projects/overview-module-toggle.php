<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

$moduleId = (int) filter_input(INPUT_POST, 'module_id', FILTER_VALIDATE_INT);

if ($moduleId <= 0) {
    http_response_code(400);
    exit('Invalid module.');
}

$connection = db();

$statement = $connection->prepare(
    'SELECT m.id, m.page_id, p.page_key, m.is_enabled
     FROM project_overview_modules AS m
     INNER JOIN project_overview_pages AS p
        ON p.id = m.page_id
       AND p.project_id = m.project_id
     WHERE m.id = ?
       AND m.project_id = ?
       AND p.archived_at IS NULL
       AND p.is_visible = 1'
);
$statement->execute([$moduleId, $projectId]);
$module = $statement->fetch(PDO::FETCH_ASSOC);

if ($module === false) {
    http_response_code(404);
    exit('Module not found.');
}

$nextEnabled = (int) $module['is_enabled'] === 1 ? 0 : 1;

try {
    $connection->beginTransaction();

    project_assert_writable($projectId, $connection);

    $update = $connection->prepare(
        'UPDATE project_overview_modules
         SET is_enabled = ?
         WHERE id = ?
           AND project_id = ?
           AND EXISTS (
               SELECT 1
               FROM project_overview_pages
               WHERE id = project_overview_modules.page_id
                 AND project_id = project_overview_modules.project_id
                 AND archived_at IS NULL
                 AND is_visible = 1
           )'
    );
    $update->execute([$nextEnabled, $moduleId, $projectId]);

    if ($update->rowCount() !== 1) {
        throw new RuntimeException('Module is no longer available.');
    }

    $connection->commit();
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    http_response_code(409);
    exit('Could not update the Overview module.');
}

header(
    'Location: /projects/project.php?id=' . $projectId . '&page=' . urlencode((string) $module['page_key']),
    true,
    303
);
exit;
