<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

$action = trim((string) ($_POST['action'] ?? ''));
$allowedActions = ['create', 'rename', 'move_up', 'move_down', 'set_default', 'archive'];

if (!in_array($action, $allowedActions, true)) {
    http_response_code(400);
    exit('Invalid Overview page action.');
}

$pageId = (int) filter_input(INPUT_POST, 'page_id', FILTER_VALIDATE_INT);
$pdo = db();

$redirect = static function (int $projectId, ?string $pageKey = null, ?string $error = null): never {
    $location = '/projects/project.php?id=' . $projectId;

    if ($pageKey !== null && $pageKey !== '') {
        $location .= '&page=' . urlencode($pageKey);
    }

    if ($error !== null && $error !== '') {
        $location .= '&error=' . urlencode($error);
    }

    header('Location: ' . $location, true, 303);
    exit;
};

$normaliseTitle = static function (string $value): string {
    $value = trim(preg_replace('/\s+/u', ' ', $value) ?? '');

    if ($value === '') {
        throw new InvalidArgumentException('Page title is required.');
    }

    if (mb_strlen($value) > 80) {
        throw new InvalidArgumentException('Page title must be 80 characters or fewer.');
    }

    return $value;
};

$pageKey = null;

try {
    $pdo->beginTransaction();

    // Re-check inside the transaction so a concurrent Project archive cannot
    // race an Overview mutation.
    project_assert_writable($projectId, $pdo);

    if ($action === 'create') {
        $title = $normaliseTitle((string) ($_POST['title'] ?? ''));

        $count = $pdo->prepare(
            'SELECT COUNT(*)
             FROM project_overview_pages
             WHERE project_id = ? AND archived_at IS NULL'
        );
        $count->execute([$projectId]);

        if ((int) $count->fetchColumn() >= 8) {
            throw new RuntimeException('A Project can have at most 8 active Overview pages.');
        }

        $position = $pdo->prepare(
            'SELECT COALESCE(MAX(position), 0) + 1
             FROM project_overview_pages
             WHERE project_id = ? AND archived_at IS NULL'
        );
        $position->execute([$projectId]);
        $nextPosition = (int) $position->fetchColumn();

        $hasDefault = $pdo->prepare(
            'SELECT 1
             FROM project_overview_pages
             WHERE project_id = ? AND archived_at IS NULL AND is_default = 1
             LIMIT 1'
        );
        $hasDefault->execute([$projectId]);
        $isDefault = $hasDefault->fetchColumn() === false ? 1 : 0;

        // page_key is an immutable internal identifier. It is deliberately
        // independent of the editable title.
        $pageKey = 'page_' . bin2hex(random_bytes(8));

        $insert = $pdo->prepare(
            'INSERT INTO project_overview_pages
                (project_id, page_key, title, position, is_visible, is_default, archived_at, config_json, created_at, updated_at)
             VALUES (?, ?, ?, ?, 1, ?, NULL, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
        );
        $insert->execute([
            $projectId,
            $pageKey,
            $title,
            $nextPosition,
            $isDefault,
            '{}',
        ]);

        $pageId = (int) $pdo->lastInsertId();
    } else {
        if ($pageId <= 0) {
            throw new InvalidArgumentException('Invalid Overview page.');
        }

        $pageStatement = $pdo->prepare(
            'SELECT id, page_key, title, position, is_default, archived_at
             FROM project_overview_pages
             WHERE id = ? AND project_id = ?'
        );
        $pageStatement->execute([$pageId, $projectId]);
        $page = $pageStatement->fetch(PDO::FETCH_ASSOC);

        if ($page === false) {
            throw new RuntimeException('Overview page not found.');
        }

        $pageKey = (string) $page['page_key'];

        if ($page['archived_at'] !== null) {
            throw new RuntimeException('Archived Overview pages cannot be modified.');
        }

        if ($action === 'rename') {
            $title = $normaliseTitle((string) ($_POST['title'] ?? ''));

            $update = $pdo->prepare(
                'UPDATE project_overview_pages
                 SET title = ?, updated_at = CURRENT_TIMESTAMP
                 WHERE id = ? AND project_id = ? AND archived_at IS NULL'
            );
            $update->execute([$title, $pageId, $projectId]);
        } elseif ($action === 'set_default') {
            if ((int) $page['is_default'] !== 1) {
                // Clear first to satisfy the one-active-default unique index.
                $clear = $pdo->prepare(
                    'UPDATE project_overview_pages
                     SET is_default = 0, updated_at = CURRENT_TIMESTAMP
                     WHERE project_id = ? AND archived_at IS NULL AND is_default = 1'
                );
                $clear->execute([$projectId]);

                $set = $pdo->prepare(
                    'UPDATE project_overview_pages
                     SET is_default = 1, updated_at = CURRENT_TIMESTAMP
                     WHERE id = ? AND project_id = ? AND archived_at IS NULL'
                );
                $set->execute([$pageId, $projectId]);

                if ($set->rowCount() !== 1) {
                    throw new RuntimeException('Could not set the default Overview page.');
                }
            }
        } elseif ($action === 'archive') {
            $active = $pdo->prepare(
                'SELECT id, is_default
                 FROM project_overview_pages
                 WHERE project_id = ? AND archived_at IS NULL
                 ORDER BY position ASC, id ASC'
            );
            $active->execute([$projectId]);
            $activePages = $active->fetchAll(PDO::FETCH_ASSOC);

            if (count($activePages) <= 1) {
                throw new RuntimeException('A Project must retain at least one active Overview page.');
            }

            if ((int) $page['is_default'] === 1) {
                $replacementId = null;

                foreach ($activePages as $candidate) {
                    if ((int) $candidate['id'] !== $pageId) {
                        $replacementId = (int) $candidate['id'];
                        break;
                    }
                }

                if ($replacementId === null) {
                    throw new RuntimeException('A replacement default Overview page is required.');
                }

                $clear = $pdo->prepare(
                    'UPDATE project_overview_pages
                     SET is_default = 0, updated_at = CURRENT_TIMESTAMP
                     WHERE id = ? AND project_id = ? AND archived_at IS NULL'
                );
                $clear->execute([$pageId, $projectId]);

                $promote = $pdo->prepare(
                    'UPDATE project_overview_pages
                     SET is_default = 1, updated_at = CURRENT_TIMESTAMP
                     WHERE id = ? AND project_id = ? AND archived_at IS NULL'
                );
                $promote->execute([$replacementId, $projectId]);

                if ($promote->rowCount() !== 1) {
                    throw new RuntimeException('Could not promote a replacement default Overview page.');
                }
            }

            $archive = $pdo->prepare(
                'UPDATE project_overview_pages
                 SET archived_at = CURRENT_TIMESTAMP,
                     is_visible = 0,
                     is_default = 0,
                     updated_at = CURRENT_TIMESTAMP
                 WHERE id = ? AND project_id = ? AND archived_at IS NULL'
            );
            $archive->execute([$pageId, $projectId]);

            if ($archive->rowCount() !== 1) {
                throw new RuntimeException('Could not archive the Overview page.');
            }

            // Keep active positions compact after archival.
            $remaining = $pdo->prepare(
                'SELECT id
                 FROM project_overview_pages
                 WHERE project_id = ? AND archived_at IS NULL
                 ORDER BY position ASC, id ASC'
            );
            $remaining->execute([$projectId]);

            $reposition = $pdo->prepare(
                'UPDATE project_overview_pages
                 SET position = ?, updated_at = CURRENT_TIMESTAMP
                 WHERE id = ? AND project_id = ?'
            );

            $position = 1;
            foreach ($remaining->fetchAll(PDO::FETCH_COLUMN) as $remainingId) {
                $reposition->execute([$position++, (int) $remainingId, $projectId]);
            }

            $pageId = null;
        } elseif ($action === 'move_up' || $action === 'move_down') {
            $ordered = $pdo->prepare(
                'SELECT id, position
                 FROM project_overview_pages
                 WHERE project_id = ? AND archived_at IS NULL
                 ORDER BY position ASC, id ASC'
            );
            $ordered->execute([$projectId]);
            $pages = $ordered->fetchAll(PDO::FETCH_ASSOC);

            $index = null;
            foreach ($pages as $i => $candidate) {
                if ((int) $candidate['id'] === $pageId) {
                    $index = $i;
                    break;
                }
            }

            if ($index === null) {
                throw new RuntimeException('Overview page not found.');
            }

            $swapIndex = $action === 'move_up' ? $index - 1 : $index + 1;

            if ($swapIndex >= 0 && $swapIndex < count($pages)) {
                // Re-number the ordered active set after swapping IDs. This
                // avoids relying on positions being unique before remediation.
                $ids = array_map(
                    static fn(array $item): int => (int) $item['id'],
                    $pages
                );

                [$ids[$index], $ids[$swapIndex]] = [$ids[$swapIndex], $ids[$index]];

                $reposition = $pdo->prepare(
                    'UPDATE project_overview_pages
                     SET position = ?, updated_at = CURRENT_TIMESTAMP
                     WHERE id = ? AND project_id = ? AND archived_at IS NULL'
                );

                foreach ($ids as $newIndex => $id) {
                    $reposition->execute([$newIndex + 1, $id, $projectId]);
                }
            }
        }
    }

    $pdo->commit();
    $redirect($projectId, $pageKey);
} catch (InvalidArgumentException $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $redirect($projectId, $pageKey, $exception->getMessage());
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $message = $exception->getMessage();

    // Keep unexpected storage details out of the response.
    $safeMessages = [
        'A Project can have at most 8 active Overview pages.',
        'Overview page not found.',
        'Archived Overview pages cannot be modified.',
        'Could not set the default Overview page.',
        'A Project must retain at least one active Overview page.',
        'A replacement default Overview page is required.',
        'Could not promote a replacement default Overview page.',
        'Could not archive the Overview page.',
    ];

    if (!in_array($message, $safeMessages, true)) {
        $message = 'Could not update the Overview page.';
    }

    $redirect($projectId, $pageKey, $message);
}
