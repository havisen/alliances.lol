<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects/overview.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

$pageId = (int) filter_input(INPUT_POST, 'page_id', FILTER_VALIDATE_INT);

if ($pageId <= 0) {
    http_response_code(400);
    exit('Invalid page.');
}

$pdo = db();

try {
    $pdo->beginTransaction();

    // Re-check Project writability inside the transaction so a concurrent
    // archive of the Project cannot race this mutation.
    project_assert_writable($projectId, $pdo);

    $statement = $pdo->prepare(
        'SELECT id, page_key, is_default, archived_at
         FROM project_overview_pages
         WHERE id = ? AND project_id = ?'
    );
    $statement->execute([$pageId, $projectId]);
    $page = $statement->fetch(PDO::FETCH_ASSOC);

    if ($page === false) {
        $pdo->rollBack();
        http_response_code(404);
        exit('Page not found.');
    }

    // This legacy endpoint is archive-only. Archived pages are intentionally
    // not restored here; the Overview lifecycle has no hard-delete or toggle
    // semantics.
    if ($page['archived_at'] !== null) {
        $pdo->rollBack();
        http_response_code(409);
        exit('This Overview page is already archived.');
    }

    $activeStatement = $pdo->prepare(
        'SELECT id
         FROM project_overview_pages
         WHERE project_id = ? AND archived_at IS NULL
         ORDER BY position ASC, id ASC'
    );
    $activeStatement->execute([$projectId]);
    $activeIds = array_map('intval', $activeStatement->fetchAll(PDO::FETCH_COLUMN));

    if (count($activeIds) <= 1) {
        $pdo->rollBack();
        http_response_code(409);
        exit('A Project must retain at least one active Overview page.');
    }

    if ((int) $page['is_default'] === 1) {
        $replacementId = null;

        foreach ($activeIds as $candidateId) {
            if ($candidateId !== $pageId) {
                $replacementId = $candidateId;
                break;
            }
        }

        if ($replacementId === null) {
            $pdo->rollBack();
            http_response_code(409);
            exit('A replacement default Overview page is required.');
        }

        // Clear the old default before assigning the replacement so the
        // partial unique index remains satisfied throughout the transaction.
        $clearDefault = $pdo->prepare(
            'UPDATE project_overview_pages
             SET is_default = 0, updated_at = CURRENT_TIMESTAMP
             WHERE id = ? AND project_id = ? AND archived_at IS NULL'
        );
        $clearDefault->execute([$pageId, $projectId]);

        $setDefault = $pdo->prepare(
            'UPDATE project_overview_pages
             SET is_default = 1, updated_at = CURRENT_TIMESTAMP
             WHERE id = ? AND project_id = ? AND archived_at IS NULL'
        );
        $setDefault->execute([$replacementId, $projectId]);

        if ($setDefault->rowCount() !== 1) {
            throw new RuntimeException('Could not promote a replacement default Overview page.');
        }
    }

    $archive = $pdo->prepare(
        'UPDATE project_overview_pages
         SET archived_at = CURRENT_TIMESTAMP,
             is_visible = 0,
             is_default = 0,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ? AND project_id = ? AND archived_at IS NULL'
    );
    $archive->execute([$pageId, $projectId]);

    if ($archive->rowCount() !== 1) {
        throw new RuntimeException('Could not archive the Overview page.');
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    http_response_code(409);
    exit('Could not archive the Overview page.');
}

header('Location: /projects/project.php?id=' . $projectId . '&page=' . urlencode((string) $page['page_key']), true, 303);
exit;
