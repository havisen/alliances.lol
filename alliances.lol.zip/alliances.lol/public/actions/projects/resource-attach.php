<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';
require_once dirname(__DIR__, 3) . '/src/projects/resources.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(INPUT_POST, 'project_id', FILTER_VALIDATE_INT);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

$kind = (string) filter_input(INPUT_POST, 'kind', FILTER_DEFAULT);
$resourceId = (int) filter_input(INPUT_POST, 'resource_id', FILTER_VALIDATE_INT);

try {
    project_resource_attach(
        $projectId,
        $kind,
        $resourceId,
        (int) $user['id'],
        $workspaceId
    );
} catch (InvalidArgumentException $error) {
    header(
        'Location: /projects/project.php?id=' . $projectId
        . '&page=resources&error=' . urlencode($error->getMessage())
    );
    exit;
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not attach the resource. Please try again.');
}

header('Location: /projects/project.php?id=' . $projectId . '&page=resources');
exit;