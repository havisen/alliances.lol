<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

/*
|--------------------------------------------------------------------------
| Resolve the workspace from trusted access context
|--------------------------------------------------------------------------
|
| workspace_id is never read from the browser. The Project is always managed
| within the authenticated user's current workspace.
*/

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(
    INPUT_POST,
    'project_id',
    FILTER_VALIDATE_INT
);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
|
| Only a Workspace Admin or an explicit Project Lead may change status.
*/

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

/*
|--------------------------------------------------------------------------
| Change status through the domain helper
|--------------------------------------------------------------------------
|
| The submitted status is never trusted directly. project_set_status() only
| accepts known statuses and keeps completed_at / archived_at centralized.
*/

$status = trim((string) ($_POST['status'] ?? ''));

try {
    project_set_status($projectId, $workspaceId, $status);
} catch (InvalidArgumentException $error) {
    http_response_code(400);
    exit($error->getMessage());
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not update the project status. Please try again.');
}

header('Location: /projects/project.php?id=' . $projectId);
exit;