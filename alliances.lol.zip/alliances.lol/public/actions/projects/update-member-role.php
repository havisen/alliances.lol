<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';
require_once dirname(__DIR__, 3) . '/src/notifications.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(
    INPUT_POST,
    'project_id',
    FILTER_VALIDATE_INT
);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

$targetUserId = (int) filter_input(
    INPUT_POST,
    'user_id',
    FILTER_VALIDATE_INT
);

$role = (string) ($_POST['role'] ?? '');
$previousRole = $targetUserId > 0
    ? project_direct_role($projectId, $workspaceId, $targetUserId)
    : null;

try {
    project_update_direct_member_role(
        $projectId,
        $workspaceId,
        $targetUserId,
        $role
    );
} catch (InvalidArgumentException | RuntimeException $error) {
    header(
        'Location: /projects/people.php?id=' . $projectId
        . '&error=' . urlencode($error->getMessage())
    );
    exit;
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not update the project member role. Please try again.');
}

/*
 * Notify only on an actual transition into the Project Lead role.
 * Re-saving an existing lead does not generate another notification.
 */
if (
    $role === 'lead'
    && $previousRole !== 'lead'
    && $targetUserId !== (int) $user['id']
) {
    try {
        create_project_notifications_for_users(
            [$targetUserId],
            [
                'workspace_id' => $workspaceId,
                'actor_user_id' => (int) $user['id'],
                'type' => 'project_lead_assigned',
                'title' => 'You were assigned Project Lead',
                'body' => (string) ($project['name'] ?? 'Project'),
                'target_type' => 'project',
                'target_id' => $projectId,
                'target_url' => '/projects/project.php?id=' . $projectId,
            ],
            1
        );
    } catch (Throwable $notificationError) {
        // Role update succeeded; notification failure must not cause a retry.
    }
}

header('Location: /projects/people.php?id=' . $projectId, true, 303);
exit;