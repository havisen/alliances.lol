<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/projects.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

/*
|--------------------------------------------------------------------------
| Resolve the workspace from trusted access context
|--------------------------------------------------------------------------
|
| workspace_id is never read from the browser. The Project is always edited
| within the authenticated user's current workspace.
*/

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(
    INPUT_POST,
    'project_id',
    FILTER_VALIDATE_INT
);

$project = $projectId > 0
    ? project_by_id($projectId, $workspaceId)
    : null;

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
|
| Only a Workspace Admin or an explicit Project Lead may manage a Project.
| This is enforced here regardless of any hidden form controls.
*/

project_require_writable_request($project);

if (!project_user_can_manage($access, (int) $user['id'], $projectId)) {
    http_response_code(403);
    exit('You do not have permission to manage this project.');
}

$name = trim((string) ($_POST['name'] ?? ''));
$description = trim((string) ($_POST['description'] ?? ''));
$startDate = trim((string) ($_POST['start_date'] ?? ''));
$targetDate = trim((string) ($_POST['target_date'] ?? ''));
$icon = trim((string) ($_POST['icon'] ?? ''));
$color = trim((string) ($_POST['color'] ?? ''));
$health = trim((string) ($_POST['health'] ?? 'unknown'));

/*
|--------------------------------------------------------------------------
| Validate optional dates server-side
|--------------------------------------------------------------------------
|
| The name is validated inside project_update() via project_validate_name().
*/

foreach ([
    'start date' => $startDate,
    'target date' => $targetDate,
] as $label => $value) {
    if ($value === '') {
        continue;
    }

    if (
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)
        || !checkdate(
            (int) substr($value, 5, 2),
            (int) substr($value, 8, 2),
            (int) substr($value, 0, 4)
        )
    ) {
        http_response_code(400);
        exit('Enter a valid ' . $label . ' (YYYY-MM-DD).');
    }
}

try {
    project_update(
        $projectId,
        $workspaceId,
        $name,
        $description !== '' ? $description : null,
        $startDate !== '' ? $startDate : null,
        $targetDate !== '' ? $targetDate : null,
        $icon,
        $color,
        $health
    );
} catch (InvalidArgumentException $error) {
    http_response_code(400);
    exit($error->getMessage());
} catch (Throwable $error) {
    http_response_code(500);
    exit('Could not update the project. Please try again.');
}

header('Location: /projects/project.php?id=' . $projectId);
exit;