<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/search.php';

header('Content-Type: application/json; charset=utf-8');

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed.',
    ]);

    exit;
}

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'error' => 'You do not have access to a workspace.',
    ]);

    exit;
}

$query = trim((string) ($_GET['q'] ?? ''));

if ($query === '') {
    echo json_encode([
        'success' => true,
        'query' => '',
        'results' => [],
        'count' => 0,
    ]);

    exit;
}

try {
    $search = alliances_search($user, $access, $query);

    echo json_encode([
        'success' => true,
        'query' => $query,
        'results' => $search['results'],
        'count' => $search['count'],
    ]);
} catch (Throwable $error) {
    error_log(
        'Alliances universal search failed: '
        . $error->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'error' => 'Unable to search.',
    ]);
}
