<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

$user = require_login();
$connection = db();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$listId = filter_input(INPUT_POST, 'task_list_id', FILTER_VALIDATE_INT);
$memberId = filter_input(INPUT_POST, 'member_id', FILTER_VALIDATE_INT);

if (!$listId || !$memberId) {
    http_response_code(400);
    exit('Invalid request.');
}

$listStatement = $connection->prepare(
    'SELECT
        tl.id,
        tl.workspace_id,
        tl.created_by,
        tl.members_can_edit
     FROM task_lists tl
     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?
     WHERE tl.id = ?
     LIMIT 1'
);

$listStatement->execute([
    $user['id'],
    $listId,
]);

$list = $listStatement->fetch();

$listStatement->execute([$listId, $user['id']]);
$list = $listStatement->fetch();

if (!$list) {
    http_response_code(403);
    exit('You do not have access to this task list.');
}

$canEdit = (int) $list['created_by'] === (int) $user['id']
    || (int) $list['members_can_edit'] === 1;

if (!$canEdit) {
    http_response_code(403);
    exit('You do not have permission to add members.');
}

$memberStatement = $connection->prepare(
    'SELECT user_id
     FROM workspace_members
     WHERE workspace_id = ?
       AND user_id = ?'
);

$workspaceId = (int) $list['workspace_id'];
$memberStatement->execute([$workspaceId, $memberId]);

if ($memberStatement->fetchColumn() === false) {
    http_response_code(400);
    exit('That user is not part of this workspace.');
}



$insert = $connection->prepare(
    'INSERT OR IGNORE INTO task_list_members (task_list_id, user_id)
     VALUES (?, ?)'
);

$insert->execute([$listId, $memberId]);

header('Location: /tasks/task-list.php?id=' . $listId);
exit;