<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/tasks/access.php';

$user = require_login();
$connection = db();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Method not allowed.');
}

require_valid_csrf();
$taskId = filter_input(INPUT_POST, 'task_id', FILTER_VALIDATE_INT);
// Keep older completion forms working; reopening must be explicitly requested.
$action = $_POST['action'] ?? 'complete';

if (!$taskId || $taskId <= 0 || !in_array($action, ['complete', 'reopen'], true)) {
    http_response_code(400);
    exit('Invalid task action.');
}

$access = workspace_access((int) $user['id']);
if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$userId = (int) $user['id'];

try {
    $connection->beginTransaction();
    $task = task_for_member($workspaceId, $userId, $taskId);

    if ($task === null) {
        $connection->rollBack();
        http_response_code(404);
        exit('Task not found or unavailable.');
    }

    if (!task_can_complete($task, $userId)) {
        $connection->rollBack();
        http_response_code(403);
        exit('Only the list creator or assigned member can complete or reopen this task.');
    }

    $status = $action === 'complete' ? 'completed' : 'pending';

    if ($task['status'] !== $status) {
        $statement = $connection->prepare(
            'UPDATE tasks
             SET status = ?,
                 completed_at = CASE WHEN ? = "completed" THEN CURRENT_TIMESTAMP ELSE NULL END
             WHERE id = ? AND task_list_id = ?'
        );
        $statement->execute([$status, $status, $taskId, $task['task_list_id']]);

        if ($status === 'completed') {
            // Preserve automatic list completion when its last pending task finishes.
            $statement = $connection->prepare(
                'UPDATE task_lists SET status = "completed", completed_at = CURRENT_TIMESTAMP
                 WHERE id = ? AND workspace_id = ? AND status != "completed"
                   AND NOT EXISTS (
                       SELECT 1 FROM tasks WHERE task_list_id = task_lists.id AND status = "pending"
                   )'
            );
        } else {
            $statement = $connection->prepare(
                'UPDATE task_lists SET status = "active", completed_at = NULL
                 WHERE id = ? AND workspace_id = ?'
            );
        }
        $statement->execute([$task['task_list_id'], $workspaceId]);
    }

    $connection->commit();
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }
    header('Location: /tasks/task.php?id=' . $taskId . '&state_error=1', true, 303);
    exit;
}

// A repeated submission is idempotent, including completion timestamps.
header('Location: /tasks/task.php?id=' . $taskId . '&state=' . $status, true, 303);
exit;
