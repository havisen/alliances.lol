<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

$user = require_login();
$connection = db();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$listId = filter_input(
    INPUT_POST,
    'list_id',
    FILTER_VALIDATE_INT
);

if (!$listId) {
    http_response_code(400);
    exit('Invalid task list.');
}

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Load task list
|--------------------------------------------------------------------------
*/

$statement = $connection->prepare(
    'SELECT
        id,
        created_by
     FROM task_lists
     WHERE id = ?
       AND workspace_id = ?
     LIMIT 1'
);

$statement->execute([
    $listId,
    $workspaceId,
]);

$list = $statement->fetch();

if (!$list) {
    http_response_code(404);
    exit('Task list not found.');
}

/*
|--------------------------------------------------------------------------
| Permission
|--------------------------------------------------------------------------
*/

$isCreator =
    (int) $list['created_by'] === (int) $user['id'];

$isAdmin =
    !empty($access['is_admin']);

if (!$isCreator && !$isAdmin) {
    http_response_code(403);
    exit('You do not have permission to delete this task list.');
}

/*
|--------------------------------------------------------------------------
| Delete
|--------------------------------------------------------------------------
*/

try {
    $connection->beginTransaction();

    /*
     * Delete dependent data first.
     *
     * This works even if your SQLite schema does not have
     * ON DELETE CASCADE enabled.
     */

    $statement = $connection->prepare(
        'DELETE FROM daily_task_occurrences
         WHERE task_id IN (
             SELECT id
             FROM tasks
             WHERE task_list_id = ?
         )'
    );

    $statement->execute([$listId]);

    $statement = $connection->prepare(
        'DELETE FROM tasks
         WHERE task_list_id = ?'
    );

    $statement->execute([$listId]);

    $statement = $connection->prepare(
        'DELETE FROM task_list_members
         WHERE task_list_id = ?'
    );

    $statement->execute([$listId]);

    $statement = $connection->prepare(
        'DELETE FROM task_lists
         WHERE id = ?
           AND workspace_id = ?'
    );

    $statement->execute([
        $listId,
        $workspaceId,
    ]);

    $connection->commit();

} catch (Throwable $exception) {

    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    http_response_code(500);
    exit('Could not delete the task list.');
}

header('Location: /tasks/tasks.php');
exit;