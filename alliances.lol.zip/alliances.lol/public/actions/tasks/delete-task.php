<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

$user = require_login();
$connection = db();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

require_valid_csrf();

$taskId = filter_input(
    INPUT_POST,
    'task_id',
    FILTER_VALIDATE_INT
);

if (!$taskId) {
    http_response_code(400);
    exit('Invalid task.');
}

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Load task
|--------------------------------------------------------------------------
*/

$statement = $connection->prepare(
    'SELECT
        t.id,
        t.task_list_id,
        tl.created_by,
        tl.members_can_edit
     FROM tasks t
     INNER JOIN task_lists tl
         ON tl.id = t.task_list_id
     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?
     WHERE t.id = ?
       AND tl.workspace_id = ?
     LIMIT 1'
);

$statement->execute([
    $user['id'],
    $taskId,
    $workspaceId,
]);

$task = $statement->fetch();

if (!$task) {
    http_response_code(404);
    exit('Task not found.');
}

/*
|--------------------------------------------------------------------------
| Permission
|--------------------------------------------------------------------------
|
| A task can be deleted by:
|
| - workspace administrator
| - task-list creator
| - task-list member when members_can_edit is enabled
|
*/

$isAdmin = !empty($access['is_admin']);

$isCreator =
    (int) $task['created_by'] === (int) $user['id'];

$memberCanEdit =
    (int) $task['members_can_edit'] === 1;

if (
    !$isAdmin
    && !$isCreator
    && !$memberCanEdit
) {
    http_response_code(403);
    exit('You do not have permission to delete this task.');
}

/*
|--------------------------------------------------------------------------
| Delete task
|--------------------------------------------------------------------------
*/

try {
    $connection->beginTransaction();

    /*
     * Remove a daily occurrence first if this task came from
     * the Daily Tasks system.
     */

    $statement = $connection->prepare(
        'DELETE FROM daily_task_occurrences
         WHERE task_id = ?'
    );

    $statement->execute([$taskId]);

    $statement = $connection->prepare(
        'DELETE FROM tasks
         WHERE id = ?'
    );

    $statement->execute([$taskId]);

    $connection->commit();

} catch (Throwable $exception) {

    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    http_response_code(500);
    exit('Could not delete the task.');
}

/*
|--------------------------------------------------------------------------
| Redirect
|--------------------------------------------------------------------------
*/

$redirect = trim((string) ($_POST['redirect'] ?? ''));

if ($redirect === 'overview') {
    header('Location: /tasks/index.php');
    exit;
}

header(
    'Location: /tasks/task-list.php?id='
    . (int) $task['task_list_id']
);

exit;