<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';
require_once dirname(__DIR__, 3) . '/src/tasks/advanced.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Method not allowed.');
}

require_valid_csrf();

$userId = (int) $user['id'];
$access = workspace_access($userId);
if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}
$workspaceId = (int) $access['workspace_id'];

$taskId = filter_input(INPUT_POST, 'task_id', FILTER_VALIDATE_INT);
$fieldKey = is_string($_POST['field_key'] ?? null) ? $_POST['field_key'] : '';
$action = $_POST['action'] ?? '';

$allowedActions = [
    'save_relations',
    'save_evidence',
    'save_artifact',
    'save_checklist',
    'save_table',
    'save_repeater',
    'save_approval',
    'request_approval',
];

if (!$taskId || $taskId <= 0 || !preg_match('/^[A-Za-z0-9_-]{1,64}$/', $fieldKey)
    || !in_array($action, $allowedActions, true)) {
    http_response_code(400);
    exit('Invalid advanced-field action.');
}

$task = task_for_member($workspaceId, $userId, $taskId);
if ($task === null) {
    http_response_code(404);
    exit('Task not found or unavailable.');
}

$definition = work_template_task_definition($workspaceId, $taskId);
$field = $definition !== null
    ? work_template_advanced_field_by_key($definition['sections'], $fieldKey)
    : null;

if ($field === null) {
    http_response_code(400);
    exit('Field not found for this task.');
}

$type = (string) $field['field_type'];
if (!work_template_field_is_normalized($type) || !work_template_field_available($type)) {
    http_response_code(400);
    exit('That field type cannot be edited here.');
}

// Approval is an independent decision permission, still requiring Task visibility.
if ($action === 'save_approval'
    ? !work_template_approval_can_decide($field, $userId)
    : !task_can_edit($task, $userId)) {
    http_response_code(403);
    exit('You do not have permission to edit this task.');
}

try {
    switch ($action) {
        case 'save_relations':
            if (!in_array($type, [
                'relation', 'task_relation', 'project_relation',
                'file_relation', 'record_relation',
            ], true)) {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $allowedTypes = work_template_advanced_target_types($field);
            $rawTypes = $_POST['target_type'] ?? [];
            $rawIds = $_POST['target_id'] ?? [];
            $rawTypes = is_array($rawTypes) ? array_values($rawTypes) : [];
            $rawIds = is_array($rawIds) ? array_values($rawIds) : [];
            $rows = [];
            $count = min(count($rawTypes), count($rawIds));
            for ($i = 0; $i < $count; ++$i) {
                $targetType = (string) $rawTypes[$i];
                $targetId = filter_var($rawIds[$i], FILTER_VALIDATE_INT);
                if (!in_array($targetType, $allowedTypes, true)
                    || $targetId === false || (int) $targetId <= 0) {
                    http_response_code(400);
                    exit('Invalid relation target.');
                }
                $resolved = work_template_advanced_resolve_target(
                    $workspaceId,
                    $userId,
                    $access,
                    $targetType,
                    (int) $targetId
                );
                if ($resolved === null) {
                    http_response_code(400);
                    exit('One or more relation targets are unavailable.');
                }
                $rows[] = ['target_type' => $targetType, 'target_id' => (int) $targetId];
            }
            work_template_advanced_replace_relations($taskId, $fieldKey, array_slice($rows, 0, 200));
            break;

        case 'save_evidence':
            if (!in_array($type, ['file', 'files', 'photo', 'photos'], true)) {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $rawIds = $_POST['drive_file_id'] ?? [];
            $rawIds = is_array($rawIds) ? array_values($rawIds) : [];
            $rows = [];
            foreach (array_slice($rawIds, 0, 200) as $rawId) {
                $fileId = filter_var($rawId, FILTER_VALIDATE_INT);
                if ($fileId === false || (int) $fileId <= 0) {
                    http_response_code(400);
                    exit('Invalid Drive file reference.');
                }
                $file = work_template_drive_visible_file($workspaceId, $userId, (int) $fileId);
                if ($file === null) {
                    http_response_code(400);
                    exit('You do not have access to one of these Drive files.');
                }
                if (($type === 'photo' || $type === 'photos')
                    && !work_template_drive_file_is_image($file['mime_type'])) {
                    http_response_code(400);
                    exit('Photos must reference an image file.');
                }
                $rows[] = ['drive_file_id' => (int) $fileId, 'mime_type' => $file['mime_type']];
            }
            if (($type === 'file' || $type === 'photo') && count($rows) > 1) {
                $rows = array_slice($rows, 0, 1);
            }
            work_template_advanced_replace_evidence($taskId, $fieldKey, $rows);
            break;

        case 'save_artifact':
            if (!in_array($type, ['signature', 'drawing'], true)) {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $payload = (string) ($_POST['payload'] ?? '');
            if (strlen($payload) > 512000) {
                http_response_code(400);
                exit('The drawing payload is too large.');
            }
            work_template_advanced_upsert_artifact($taskId, $fieldKey, [
                'kind' => $type,
                'signer_id' => $type === 'signature' ? $userId : null,
                'signer_name' => $type === 'signature' ? (string) ($user['display_name'] ?? '') : null,
                'signed_at' => $type === 'signature' ? date('c') : null,
                'typed_name' => $type === 'signature' ? trim((string) ($_POST['typed_name'] ?? '')) : null,
                'mime_type' => 'image/png',
                'width' => filter_var($_POST['width'] ?? null, FILTER_VALIDATE_INT),
                'height' => filter_var($_POST['height'] ?? null, FILTER_VALIDATE_INT),
                'payload' => $payload,
            ]);
            break;

        case 'save_checklist':
            if (!in_array($type, ['checklist', 'structured_checklist'], true)) {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $steps = (array) ($field['config']['steps'] ?? []);
            $submitted = [];
            $raw = $_POST['steps'] ?? [];
            if (is_array($raw)) {
                foreach ($steps as $step) {
                    $key = (string) $step['key'];
                    $state = $raw[$key] ?? null;
                    if (is_array($state)) {
                        $submitted[$key] = [
                            'checked' => !empty($state['checked']),
                            'result' => (string) ($state['result'] ?? ''),
                            'notes' => (string) ($state['notes'] ?? ''),
                        ];
                    }
                }
            }
            work_template_advanced_save_checklist(
                $taskId,
                $fieldKey,
                $steps,
                $submitted,
                $type === 'structured_checklist'
            );
            break;

        case 'save_table':
            if ($type !== 'table') {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $columns = (array) ($field['config']['columns'] ?? []);
            $rawRows = $_POST['rows'] ?? [];
            $rawRows = is_array($rawRows) ? array_values($rawRows) : [];
            $submittedRows = [];
            $rowIndex = 0;
            foreach (array_slice($rawRows, 0, 200) as $rawCellRow) {
                if (!is_array($rawCellRow)) {
                    continue;
                }
                $cells = [];
                foreach ($columns as $column) {
                    $cells[(string) $column['key']] = (string) ($rawCellRow[(string) $column['key']] ?? '');
                }
                $submittedRows['row' . $rowIndex] = $cells;
                ++$rowIndex;
            }
            work_template_advanced_save_table($taskId, $fieldKey, $columns, $submittedRows);
            break;

        case 'save_repeater':
            if ($type !== 'repeater') {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $children = (array) ($field['config']['children'] ?? []);
            $rawInstances = $_POST['instances'] ?? [];
            $rawInstances = is_array($rawInstances) ? array_values($rawInstances) : [];
            $submittedInstances = [];
            $instanceIndex = 0;
            foreach (array_slice($rawInstances, 0, 200) as $rawChildRow) {
                if (!is_array($rawChildRow)) {
                    continue;
                }
                $values = [];
                foreach ($children as $child) {
                    $values[(string) $child['key']] = (string) ($rawChildRow[(string) $child['key']] ?? '');
                }
                $submittedInstances['inst' . $instanceIndex] = $values;
                ++$instanceIndex;
            }
            work_template_advanced_save_repeater($taskId, $fieldKey, $children, $submittedInstances);
            break;

        case 'save_approval':
        case 'request_approval':
            if ($type !== 'approval') {
                http_response_code(400);
                exit('This action is not valid for this field.');
            }
            $decision = (string) ($_POST['decision'] ?? '');
            if (!in_array($decision, ['approved', 'rejected', 'changes_requested', 'pending'], true)) {
                http_response_code(400);
                exit('Choose a valid decision.');
            }
            $comment = trim((string) ($_POST['comment'] ?? ''));
            work_template_advanced_append_approval($workspaceId, $taskId, $fieldKey, [
                'event_type' => $action === 'request_approval' ? 'requested' : 'decision',
                'decision' => $decision,
                'comment' => $comment !== '' ? $comment : null,
                'decided_by' => $userId,
                'decided_by_name' => (string) ($user['display_name'] ?? ''),
                'expected_decision_id' => filter_var($_POST['expected_decision_id'] ?? -1, FILTER_VALIDATE_INT),
            ]);
            break;

        default:
            http_response_code(400);
            exit('Unknown advanced-field action.');
    }
} catch (Throwable $error) {
    header('Location: /tasks/task.php?id=' . $taskId . '&advanced_error=1', true, 303);
    exit;
}

header('Location: /tasks/task.php?id=' . $taskId . '&advanced=ok', true, 303);
exit;
