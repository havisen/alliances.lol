<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/src/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Location: /');
    exit;
}

$user = require_login();
require_valid_csrf();

$workspaceId = filter_input(INPUT_POST, 'workspace_id', FILTER_VALIDATE_INT);

if ($workspaceId === false || $workspaceId === null || $workspaceId <= 0) {
    http_response_code(400);
    exit('Invalid workspace.');
}

if (!switch_workspace((int) $user['id'], (int) $workspaceId)) {
    http_response_code(403);
    exit('You are not a member of that workspace.');
}

/*
 * Safe redirect back to where the user was, only when the Referer is on the
 * same host (never an attacker-controlled external URL).
 */
$redirectTo = '/';

$referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
$expectedHost = (string) ($_SERVER['HTTP_HOST'] ?? '');

if ($referer !== '' && $expectedHost !== '') {
    $parts = parse_url($referer);

    $refererHost = (string) ($parts['host'] ?? '');

    if ($refererHost !== '') {
        if (isset($parts['port'])) {
            $refererHost .= ':' . $parts['port'];
        }

        if (hash_equals(strtolower($expectedHost), strtolower($refererHost))) {
            $redirectTo = (string) ($parts['path'] ?? '/');

            if (isset($parts['query'])) {
                $redirectTo .= '?' . $parts['query'];
            }
        }
    }
}

header('Location: ' . $redirectTo);
exit;