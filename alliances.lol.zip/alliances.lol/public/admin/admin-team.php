<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

$user = require_login();
$connection = db();

$access = require_administration_access($user);

$workspaceId = (int) $access['workspace_id'];
$isAdmin = (bool) $access['is_admin'];

$teamId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

/*
|--------------------------------------------------------------------------
| Creating a new team
|--------------------------------------------------------------------------
|
| Only workspace administrators can create teams.
|
*/

if (!$teamId) {
    if (!$isAdmin) {
        http_response_code(403);
        exit('Only workspace administrators can create teams.');
    }

    /*
     * admin.php already contains the Create Team form, so normally users
     * should not reach admin-team.php without an ID.
     */
    header('Location: /admin/admin.php#create-team');
    exit;
}

/*
|--------------------------------------------------------------------------
| Load team
|--------------------------------------------------------------------------
*/

$teamStatement = $connection->prepare(
    'SELECT
        t.id,
        t.name,
        t.description,
        t.status,
        t.team_lead_id,
        lead.display_name AS team_lead_name,
        lead.email AS team_lead_email,
        lead.job_title AS team_lead_job_title,
        lead.avatar_path AS team_lead_avatar
     FROM teams t
     LEFT JOIN users lead
         ON lead.id = t.team_lead_id
     WHERE t.id = ?
       AND t.workspace_id = ?
     LIMIT 1'
);

$teamStatement->execute([
    $teamId,
    $workspaceId,
]);

$team = $teamStatement->fetch();

if (!$team) {
    http_response_code(404);
    exit('Team not found.');
}

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
|
| Admin:
|   Can open and edit any team in the workspace.
|
| Team Lead:
|   Can open only teams they lead.
|   Their view is read-only.
|
*/

if (!$isAdmin && !can_manage_team($access, (int) $team['id'])) {
    http_response_code(403);
    exit('You cannot access this team.');
}

/*
|--------------------------------------------------------------------------
| Workspace users
|--------------------------------------------------------------------------
|
| Admin needs the complete list for the membership editor.
|
*/

$workspaceUsers = [];

if ($isAdmin) {
    $usersStatement = $connection->prepare(
        'SELECT
            u.id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path,
            wm.role
         FROM users u
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id
         WHERE wm.workspace_id = ?
         ORDER BY u.display_name ASC'
    );

    $usersStatement->execute([$workspaceId]);
    $workspaceUsers = $usersStatement->fetchAll();
}

/*
|--------------------------------------------------------------------------
| Team members
|--------------------------------------------------------------------------
*/

$membersStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.email,
        u.job_title,
        u.avatar_path,
        wm.role
     FROM team_members tm
     INNER JOIN users u
         ON u.id = tm.user_id
     INNER JOIN workspace_members wm
         ON wm.user_id = u.id
        AND wm.workspace_id = ?
     WHERE tm.team_id = ?
     ORDER BY
        CASE
            WHEN u.id = ? THEN 0
            ELSE 1
        END,
        u.display_name ASC'
);

$membersStatement->execute([
    $workspaceId,
    $team['id'],
    $team['team_lead_id'] ?? 0,
]);

$teamMembers = $membersStatement->fetchAll();

if (!$isAdmin) {
    $workspaceUsers = $teamMembers;
}

$selectedMemberIds = [];

foreach ($teamMembers as $member) {
    $selectedMemberIds[] = (int) $member['id'];
}

$memberCount = count($teamMembers);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>
        <?= htmlspecialchars(
            $team['name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?>
        | Alliances
    </title>
</head>
<body>
<?php render_navigation($user); ?>

    <main class="profile-page">
        <header class="profile-page-heading admin-user-page-heading">
            <div>
                <p class="profile-eyebrow">
                    <?= $isAdmin ? 'Team administration' : 'My team' ?>
                </p>

                <h1>
                    <?= htmlspecialchars(
                        $team['name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h1>

                <p class="profile-page-description">
                    <?php if ($isAdmin): ?>
                        Manage this team's structure, Team Lead, and members.
                    <?php else: ?>
                        View the team you lead and administer its members.
                    <?php endif; ?>
                </p>
            </div>

            <a
                class="admin-back-link"
                href="/admin/admin.php"
            >
                ← Back to Administration
            </a>
        </header>

        <section class="admin-summary-card">
            <div class="admin-workspace-info">
                <span class="admin-summary-label">
                    Team
                </span>

                <h2>
                    <?= htmlspecialchars(
                        $team['name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h2>

                <p>
                    <?php if ($isAdmin): ?>
                        Workspace team
                    <?php else: ?>
                        You are the Team Lead
                    <?php endif; ?>
                </p>
            </div>

            <div class="admin-summary-stats">
                <div class="admin-stat">
                    <strong><?= $memberCount ?></strong>

                    <span>
                        <?= $memberCount === 1 ? 'Member' : 'Members' ?>
                    </span>
                </div>
            </div>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Team Lead</h2>

                    <p>
                        The person responsible for this team.
                    </p>
                </div>
            </div>

            <?php if ($team['team_lead_id']): ?>
                <a
                    class="profile-person admin-team-lead-profile"
                    href="/profile/?id=<?= (int) $team['team_lead_id'] ?>"
                >
                    <?php if (!empty($team['team_lead_avatar'])): ?>
                        <img
                            class="org-avatar"
                            src="<?= htmlspecialchars(
                                $team['team_lead_avatar'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt=""
                        >
                    <?php else: ?>
                        <span class="org-avatar org-avatar-placeholder">
                            <?= htmlspecialchars(
                                strtoupper(
                                    substr(
                                        $team['team_lead_name'] ?? '?',
                                        0,
                                        1
                                    )
                                ),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>
                    <?php endif; ?>

                    <span class="profile-person-details">
                        <strong>
                            <?= htmlspecialchars(
                                $team['team_lead_name'] ?? 'Unknown user',
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </strong>

                        <small>
                            <?php if (!empty($team['team_lead_job_title'])): ?>
                                <?= htmlspecialchars(
                                    $team['team_lead_job_title'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            <?php else: ?>
                                <?= htmlspecialchars(
                                    $team['team_lead_email'] ?? '',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            <?php endif; ?>
                        </small>
                    </span>
                </a>
            <?php else: ?>
                <div class="profile-empty-state">
                    This team does not currently have a Team Lead.
                </div>
            <?php endif; ?>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Team members</h2>

                    <p>
                        People who currently belong to this team.
                    </p>
                </div>
            </div>

            <?php if ($teamMembers === []): ?>
                <div class="profile-empty-state">
                    This team does not have any members yet.
                </div>
            <?php else: ?>
                <div class="admin-user-list">
                    <?php foreach ($teamMembers as $member): ?>
                        <?php
                        $isTeamLeadMember =
                            (int) $member['id']
                            === (int) $team['team_lead_id'];
                        ?>

                        <article class="admin-user-row">
                            <a
                                class="admin-user-profile"
                                href="/profile/?id=<?= (int) $member['id'] ?>"
                            >
                                <?php if (!empty($member['avatar_path'])): ?>
                                    <img
                                        class="admin-user-avatar"
                                        src="<?= htmlspecialchars(
                                            $member['avatar_path'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        alt=""
                                    >
                                <?php else: ?>
                                    <span class="admin-user-avatar admin-user-avatar-placeholder">
                                        <?= htmlspecialchars(
                                            strtoupper(
                                                substr(
                                                    $member['display_name'],
                                                    0,
                                                    1
                                                )
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>
                                <?php endif; ?>

                                <span class="admin-user-details">
                                    <span class="admin-user-name">
                                        <?= htmlspecialchars(
                                            $member['display_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                        <?php if ($isTeamLeadMember): ?>
                                            <span class="admin-role-badge">
                                                Team Lead
                                            </span>
                                        <?php elseif ($member['role'] === 'admin'): ?>
                                            <span class="admin-role-badge">
                                                Admin
                                            </span>
                                        <?php endif; ?>
                                    </span>

                                    <span class="admin-user-job">
                                        <?= htmlspecialchars(
                                            $member['job_title']
                                                ?: 'No job title',
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                    <span class="admin-user-email">
                                        <?= htmlspecialchars(
                                            $member['email'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>
                                </span>
                            </a>

                            <?php
                            $canEditMember = $isAdmin;

                            if (
                                !$isAdmin
                                && !$isTeamLeadMember
                                && $member['role'] !== 'admin'
                            ) {
                                $canEditMember = can_manage_user(
                                    $access,
                                    (int) $member['id']
                                );
                            }
                            ?>

                            <?php if ($canEditMember): ?>
                                <a
                                    class="admin-manage-link"
                                    href="/admin/admin-user.php?id=<?= (int) $member['id'] ?>"
                                >
                                    Edit
                                    <span aria-hidden="true">→</span>
                                </a>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($isAdmin || can_manage_team($access, (int) $team['id'])): ?>
            <section class="profile-section">
                <div class="profile-section-heading">
                    <div>
                        <h2>Team settings</h2>

                        <p>
                            <?php if ($isAdmin): ?>
                                Change the team name, Team Lead, and membership.
                            <?php else: ?>
                                Manage membership for the team you lead.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <form
                    class="profile-edit-form"
                    method="post"
                    action="/actions/admin/admin-update-team.php"
                >
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="update">

                    <input
                        type="hidden"
                        name="team_id"
                        value="<?= (int) $team['id'] ?>"
                    >

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="name">
                                Team name
                            </label>

                            <p>
                                The name shown throughout the workspace.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="name"
                                type="text"
                                name="name"
                                maxlength="120"
                                required
                                <?= $isAdmin ? '' : 'disabled' ?>
                                value="<?= htmlspecialchars(
                                    $team['name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >
                        </div>
                    </div>

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="team_lead_id">
                                Team Lead
                            </label>

                            <p>
                                The Team Lead can administer people in this team.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <select
                                id="team_lead_id"
                                name="team_lead_id"
                                required
                                <?= $isAdmin ? '' : 'disabled' ?>
                            >
                                <?php foreach ($workspaceUsers as $workspaceUser): ?>
                                    <option
                                        value="<?= (int) $workspaceUser['id'] ?>"
                                        <?= (int) $workspaceUser['id']
                                            === (int) $team['team_lead_id']
                                            ? 'selected'
                                            : ''
                                        ?>
                                    >
                                        <?= htmlspecialchars(
                                            $workspaceUser['display_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                        <?php if (!empty($workspaceUser['job_title'])): ?>
                                            —
                                            <?= htmlspecialchars(
                                                $workspaceUser['job_title'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="profile-form-row profile-form-row-top">
                        <div class="profile-form-label">
                            <span class="admin-field-title">
                                Team members
                            </span>

                            <p>
                                Select everyone who belongs to this team.
                                The selected Team Lead is always added
                                automatically.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <div class="admin-member-selector">
                                <?php foreach ($workspaceUsers as $workspaceUser): ?>
                                    <?php
                                    $isSelected = in_array(
                                        (int) $workspaceUser['id'],
                                        $selectedMemberIds,
                                        true
                                    );
                                    ?>

                                    <label class="admin-member-option">
                                        <input
                                            type="checkbox"
                                            name="member_ids[]"
                                            value="<?= (int) $workspaceUser['id'] ?>"
                                            <?= $isSelected ? 'checked' : '' ?>
                                        >

                                        <?php if (!empty($workspaceUser['avatar_path'])): ?>
                                            <img
                                                class="org-avatar"
                                                src="<?= htmlspecialchars(
                                                    $workspaceUser['avatar_path'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>"
                                                alt=""
                                            >
                                        <?php else: ?>
                                            <span class="org-avatar org-avatar-placeholder">
                                                <?= htmlspecialchars(
                                                    strtoupper(
                                                        substr(
                                                            $workspaceUser['display_name'],
                                                            0,
                                                            1
                                                        )
                                                    ),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </span>
                                        <?php endif; ?>

                                        <span class="profile-person-details">
                                            <strong>
                                                <?= htmlspecialchars(
                                                    $workspaceUser['display_name'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                            <small>
                                                <?= htmlspecialchars(
                                                    $workspaceUser['job_title']
                                                        ?: $workspaceUser['email'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <div class="profile-form-actions">
                        <button type="submit">
                            <?= $isAdmin ? 'Save team' : 'Save membership' ?>
                        </button>
                    </div>
                </form>
            </section>

            <?php if ($isAdmin): ?>
            <section class="profile-section">
                <div class="profile-section-heading">
                    <div>
                        <h2>Team lifecycle</h2>

                        <p>
                            Archive this team without deleting historical records.
                        </p>
                    </div>
                </div>

                <div class="admin-account-details">
                    <div class="admin-account-detail">
                        <span>Status</span>

                        <strong>
                            <?= $team['status'] === 'archived'
                                ? 'Archived'
                                : 'Active'
                            ?>
                        </strong>
                    </div>
                </div>

                <?php if ($team['status'] !== 'archived'): ?>
                    <form
                        class="profile-edit-form"
                        method="post"
                        action="/actions/admin/admin-update-team.php"
                    >
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="archive">
                        <input type="hidden" name="team_id" value="<?= (int) $team['id'] ?>">

                        <div class="profile-form-actions">
                            <button type="submit">
                                Archive team
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </section>
            <?php endif; ?>
        <?php else: ?>
            <section class="profile-section">
                <div class="profile-section-heading">
                    <div>
                        <h2>Team administration</h2>

                        <p>
                            Your Team Lead permissions apply to the people
                            in this team.
                        </p>
                    </div>
                </div>

                <div class="admin-team-permission-note">
                    <strong>You can administer team members.</strong>

                    <p>
                        You can edit member profile information from this
                        page. Team membership, the Team Lead, and the team
                        name are controlled by a workspace administrator.
                    </p>
                </div>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
