<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/notifications.php';

$currentUser = require_login();
$connection = db();

$access = require_administration_access($currentUser);

$workspaceId = (int) $access['workspace_id'];
$isAdmin = (bool) $access['is_admin'];

$userId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$userId) {
    http_response_code(404);
    exit('User not found.');
}

/*
|--------------------------------------------------------------------------
| Load target user
|--------------------------------------------------------------------------
*/

$userStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.email,
        u.job_title,
        u.description,
        u.avatar_path,
        u.account_status,
        wm.role
     FROM users u
     INNER JOIN workspace_members wm
         ON wm.user_id = u.id
     WHERE u.id = ?
       AND wm.workspace_id = ?
     LIMIT 1'
);

$userStatement->execute([
    $userId,
    $workspaceId,
]);

$managedUser = $userStatement->fetch();

if (!$managedUser) {
    http_response_code(404);
    exit('User not found.');
}

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
|
| Admin:
|   Can manage every user in the workspace.
|
| Team Lead:
|   Can manage members of teams they lead.
|   Cannot manage workspace administrators.
|
*/

if (!$isAdmin) {
    if ($managedUser['role'] === 'admin') {
        http_response_code(403);
        exit('You cannot administer this user.');
    }

    if (!can_manage_user($access, (int) $managedUser['id'])) {
        http_response_code(403);
        exit('You cannot administer this user.');
    }
}

/*
|--------------------------------------------------------------------------
| Save changes
|--------------------------------------------------------------------------
*/

$error = null;
$updated = isset($_GET['updated']) && $_GET['updated'] === '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $action = (string) ($_POST['action'] ?? 'profile');

    if ($action === 'profile') {
        $jobTitle = trim($_POST['job_title'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if (strlen($jobTitle) > 120) {
            $error = 'Job title must be 120 characters or fewer.';
        } elseif (strlen($description) > 2000) {
            $error = 'Description must be 2,000 characters or fewer.';
        }

        if ($error === null) {
            /*
             * Re-check authorization immediately before the update.
             */
            if (!$isAdmin) {
                if ($managedUser['role'] === 'admin') {
                    http_response_code(403);
                    exit('You cannot administer this user.');
                }

                if (!can_manage_user($access, (int) $managedUser['id'])) {
                    http_response_code(403);
                    exit('You cannot administer this user.');
                }
            }

            $updateStatement = $connection->prepare(
                'UPDATE users
                 SET job_title = ?,
                     description = ?
                 WHERE id = ?
                   AND EXISTS (
                       SELECT 1
                       FROM workspace_members wm
                       WHERE wm.user_id = users.id
                         AND wm.workspace_id = ?
                   )'
            );

            $updateStatement->execute([
                $jobTitle !== '' ? $jobTitle : null,
                $description !== '' ? $description : null,
                $managedUser['id'],
                $workspaceId,
            ]);

            admin_audit_log(
                $workspaceId,
                (int) $currentUser['id'],
                'user_profile_updated',
                'user',
                (int) $managedUser['id']
            );

            header(
                'Location: /admin/admin-user.php?id='
                . (int) $managedUser['id']
                . '&updated=1'
            );
            exit;
        }

        $managedUser['job_title'] = $jobTitle;
        $managedUser['description'] = $description;
    } elseif ($isAdmin) {
        $targetUserId = (int) $managedUser['id'];
        $isSelf = $targetUserId === (int) $currentUser['id'];

        if ($action === 'role') {
            $newRole = (string) ($_POST['role'] ?? '');

            if (!in_array($newRole, ['admin', 'member'], true)) {
                $error = 'Choose a valid workspace role.';
            } else {
                $adminCountStatement = $connection->prepare(
                    'SELECT COUNT(*)
                     FROM workspace_members
                     WHERE workspace_id = ?
                       AND role = ?'
                );

                $adminCountStatement->execute([$workspaceId, 'admin']);
                $adminCount = (int) $adminCountStatement->fetchColumn();

                if (
                    $managedUser['role'] === 'admin'
                    && $newRole === 'member'
                    && $adminCount <= 1
                ) {
                    $error = 'This workspace must keep at least one administrator.';
                } else {
                    $statement = $connection->prepare(
                        'UPDATE workspace_members
                         SET role = ?
                         WHERE workspace_id = ?
                           AND user_id = ?'
                    );

                    $statement->execute([$newRole, $workspaceId, $targetUserId]);

                    admin_audit_log(
                        $workspaceId,
                        (int) $currentUser['id'],
                        'user_role_changed',
                        'user',
                        $targetUserId,
                        'Role changed to ' . $newRole . '.'
                    );

                    create_notification([
                        'workspace_id' => $workspaceId,
                        'user_id' => $targetUserId,
                        'actor_user_id' => (int) $currentUser['id'],
                        'type' => 'account_role_changed',
                        'category' => 'security',
                        'title' => 'Your workspace role changed',
                        'body' => 'Your role is now '
                            . ($newRole === 'admin'
                                ? 'Administrator'
                                : 'Member')
                            . '.',
                        'target_type' => 'user',
                        'target_id' => $targetUserId,
                        'target_url' => '/profile/?id=' . $targetUserId,
                    ]);

                    header('Location: /admin/admin-user.php?id=' . $targetUserId . '&updated=1');
                    exit;
                }
            }
        } elseif ($action === 'account_status') {
            $newStatus = (string) ($_POST['account_status'] ?? '');

            if (!in_array($newStatus, ['active', 'deactivated'], true)) {
                $error = 'Choose a valid account status.';
            } elseif ($isSelf && $newStatus === 'deactivated') {
                $error = 'You cannot deactivate your own account.';
            } else {
                $adminCountStatement = $connection->prepare(
                    'SELECT COUNT(*)
                     FROM workspace_members wm
                     INNER JOIN users u
                         ON u.id = wm.user_id
                     WHERE wm.workspace_id = ?
                       AND wm.role = ?
                       AND u.account_status = ?'
                );

                $adminCountStatement->execute([$workspaceId, 'admin', 'active']);
                $activeAdminCount = (int) $adminCountStatement->fetchColumn();

                if (
                    $managedUser['role'] === 'admin'
                    && $newStatus === 'deactivated'
                    && $activeAdminCount <= 1
                ) {
                    $error = 'This workspace must keep at least one active administrator.';
                } else {
                    $statement = $connection->prepare(
                        'UPDATE users
                         SET account_status = ?
                         WHERE id = ?
                           AND EXISTS (
                               SELECT 1
                               FROM workspace_members wm
                               WHERE wm.user_id = users.id
                                 AND wm.workspace_id = ?
                           )'
                    );

                    $statement->execute([$newStatus, $targetUserId, $workspaceId]);

                    if ($newStatus === 'deactivated') {
                        revoke_all_user_sessions($targetUserId, false);
                    }

                    admin_audit_log(
                        $workspaceId,
                        (int) $currentUser['id'],
                        $newStatus === 'active'
                            ? 'user_reactivated'
                            : 'user_deactivated',
                        'user',
                        $targetUserId
                    );

                    if ($newStatus === 'active') {
                        create_notification([
                            'workspace_id' => $workspaceId,
                            'user_id' => $targetUserId,
                            'actor_user_id' => (int) $currentUser['id'],
                            'type' => 'account_reactivated',
                            'category' => 'security',
                            'title' => 'Your account was reactivated',
                            'body' => 'You can sign in to Alliances again.',
                            'target_type' => 'user',
                            'target_id' => $targetUserId,
                            'target_url' => '/settings/?section=security',
                        ]);
                    }

                    header('Location: /admin/admin-user.php?id=' . $targetUserId . '&updated=1');
                    exit;
                }
            }
        } elseif ($action === 'password') {
            $newPassword = (string) ($_POST['password'] ?? '');

            if (strlen($newPassword) < 12) {
                $error = 'Password must be at least 12 characters.';
            } elseif (strlen($newPassword) > 4096) {
                $error = 'Password is too long.';
            } else {
                $statement = $connection->prepare(
                    'UPDATE users
                     SET password_hash = ?
                     WHERE id = ?
                       AND EXISTS (
                           SELECT 1
                           FROM workspace_members wm
                           WHERE wm.user_id = users.id
                             AND wm.workspace_id = ?
                       )'
                );

                $statement->execute([
                    password_hash($newPassword, PASSWORD_DEFAULT),
                    $targetUserId,
                    $workspaceId,
                ]);

                revoke_all_user_sessions($targetUserId, $isSelf);

                admin_audit_log(
                    $workspaceId,
                    (int) $currentUser['id'],
                    'user_password_reset',
                    'user',
                    $targetUserId
                );

                create_notification([
                    'workspace_id' => $workspaceId,
                    'user_id' => $targetUserId,
                    'actor_user_id' => (int) $currentUser['id'],
                    'type' => 'account_password_reset',
                    'category' => 'security',
                    'title' => 'Your account password was reset',
                    'body' => 'Your Key Vault password was not changed.',
                    'target_type' => 'user',
                    'target_id' => $targetUserId,
                    'target_url' => '/settings/?section=security',
                ]);

                header('Location: /admin/admin-user.php?id=' . $targetUserId . '&updated=1');
                exit;
            }
        } elseif ($action === 'sessions') {
            revoke_all_user_sessions($targetUserId, $isSelf);

            admin_audit_log(
                $workspaceId,
                (int) $currentUser['id'],
                'user_sessions_revoked',
                'user',
                $targetUserId
            );

            create_notification([
                'workspace_id' => $workspaceId,
                'user_id' => $targetUserId,
                'actor_user_id' => (int) $currentUser['id'],
                'type' => 'security_sessions_revoked',
                'category' => 'security',
                'title' => 'Your active sessions were signed out',
                'body' => 'An administrator revoked active sessions for your account.',
                'target_type' => 'user',
                'target_id' => $targetUserId,
                'target_url' => '/settings/?section=security',
            ]);

            header('Location: /admin/admin-user.php?id=' . $targetUserId . '&updated=1');
            exit;
        }
    } else {
        http_response_code(403);
        exit('Only workspace administrators can perform this action.');
    }
}

/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$teamsStatement = $connection->prepare(
    'SELECT
        t.id,
        t.name,
        t.team_lead_id,
        lead.display_name AS team_lead_name
     FROM teams t
     LEFT JOIN users lead
         ON lead.id = t.team_lead_id
     WHERE t.workspace_id = ?
       AND (
            t.team_lead_id = ?
            OR EXISTS (
                SELECT 1
                FROM team_members tm
                WHERE tm.team_id = t.id
                  AND tm.user_id = ?
            )
       )
     ORDER BY t.name ASC'
);

$teamsStatement->execute([
    $workspaceId,
    $managedUser['id'],
    $managedUser['id'],
]);

$userTeams = $teamsStatement->fetchAll();

$activeSessions = $isAdmin
    ? active_user_sessions((int) $managedUser['id'])
    : [];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>
        Edit
        <?= htmlspecialchars(
            $managedUser['display_name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?>
        | Alliances
    </title>
</head>
<body>
<?php render_navigation($currentUser); ?>
    <main class="profile-page">
        <header class="profile-page-heading admin-user-page-heading">
            <div>
                <p class="profile-eyebrow">
                    Administration
                </p>

                <h1>Edit user</h1>

                <p class="profile-page-description">
                    Manage this person's workspace profile information.
                </p>
            </div>

            <a
                class="admin-back-link"
                href="/admin/admin.php"
            >
                ← Back to Administration
            </a>
        </header>

        <section class="profile-summary-card">
            <div class="profile-summary-avatar">
                <?php if (!empty($managedUser['avatar_path'])): ?>
                    <img
                        class="profile-avatar"
                        src="<?= htmlspecialchars(
                            $managedUser['avatar_path'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        alt=""
                    >
                <?php else: ?>
                    <div class="profile-avatar profile-avatar-placeholder">
                        <?= htmlspecialchars(
                            strtoupper(
                                substr(
                                    $managedUser['display_name'],
                                    0,
                                    1
                                )
                            ),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="profile-summary-details">
                <div class="admin-user-title-line">
                    <h2>
                        <?= htmlspecialchars(
                            $managedUser['display_name'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </h2>

                    <?php if ($managedUser['role'] === 'admin'): ?>
                        <span class="admin-role-badge">
                            Admin
                        </span>
                    <?php endif; ?>
                </div>

                <?php if (!empty($managedUser['job_title'])): ?>
                    <p class="profile-job-title">
                        <?= htmlspecialchars(
                            $managedUser['job_title'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </p>
                <?php endif; ?>

                <a
                    class="profile-email"
                    href="mailto:<?= htmlspecialchars(
                        $managedUser['email'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                >
                    <?= htmlspecialchars(
                        $managedUser['email'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </a>
            </div>
        </section>

        <?php if ($updated): ?>
            <div class="admin-success-message">
                Changes saved successfully.
            </div>
        <?php endif; ?>

        <?php if ($error !== null): ?>
            <div class="profile-alert profile-alert-error admin-user-alert">
                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </div>
        <?php endif; ?>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Profile information</h2>

                    <p>
                        Information displayed to people in the workspace.
                    </p>
                </div>
            </div>

            <form
                class="profile-edit-form"
                method="post"
            >
                <?= csrf_input() ?>
                <input type="hidden" name="action" value="profile">

                <div class="profile-form-row">
                    <div class="profile-form-label">
                        <label for="display_name">
                            Display name
                        </label>

                        <p>
                            The user's name is shown throughout Alliances.
                        </p>
                    </div>

                    <div class="profile-form-control">
                        <input
                            id="display_name"
                            type="text"
                            value="<?= htmlspecialchars(
                                $managedUser['display_name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            disabled
                        >

                        <p class="admin-readonly-note">
                            Display names cannot be changed here yet.
                        </p>
                    </div>
                </div>

                <div class="profile-form-row">
                    <div class="profile-form-label">
                        <label for="email">
                            Email
                        </label>

                        <p>
                            The email address used by this account.
                        </p>
                    </div>

                    <div class="profile-form-control">
                        <input
                            id="email"
                            type="email"
                            value="<?= htmlspecialchars(
                                $managedUser['email'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            disabled
                        >

                        <p class="admin-readonly-note">
                            Email addresses cannot be changed here.
                        </p>
                    </div>
                </div>

                <div class="profile-form-row">
                    <div class="profile-form-label">
                        <label for="job_title">
                            Job title
                        </label>

                        <p>
                            The person's role or position in the organization.
                        </p>
                    </div>

                    <div class="profile-form-control">
                        <input
                            id="job_title"
                            type="text"
                            name="job_title"
                            maxlength="120"
                            value="<?= htmlspecialchars(
                                $managedUser['job_title'] ?? '',
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            placeholder="e.g. Account Manager"
                        >
                    </div>
                </div>

                <div class="profile-form-row profile-form-row-top">
                    <div class="profile-form-label">
                        <label for="description">
                            About
                        </label>

                        <p>
                            A short description displayed on the person's
                            profile.
                        </p>
                    </div>

                    <div class="profile-form-control">
                        <textarea
                            id="description"
                            name="description"
                            maxlength="2000"
                            placeholder="Add a short description..."
                        ><?= htmlspecialchars(
                            $managedUser['description'] ?? '',
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?></textarea>

                        <p class="profile-field-hint">
                            Maximum 2,000 characters.
                        </p>
                    </div>
                </div>

                <div class="profile-form-actions">
                    <button type="submit">
                        Save changes
                    </button>
                </div>
            </form>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Organization</h2>

                    <p>
                        Teams this person currently belongs to or leads.
                    </p>
                </div>
            </div>

            <?php if ($userTeams === []): ?>
                <div class="profile-empty-state">
                    This user is not currently assigned to a team.
                </div>
            <?php else: ?>
                <div class="admin-user-team-list">
                    <?php foreach ($userTeams as $team): ?>
                        <div class="admin-user-team-row">
                            <div>
                                <span class="profile-team-label">
                                    <?= (int) $team['team_lead_id']
                                        === (int) $managedUser['id']
                                        ? 'Team Lead'
                                        : 'Team member'
                                    ?>
                                </span>

                                <h3>
                                    <?= alliances_team_link(
                                        (int) $team['id'],
                                        (string) $team['name']
                                    ) ?>
                                </h3>

                                <?php if (
                                    (int) $team['team_lead_id']
                                    !== (int) $managedUser['id']
                                    && !empty($team['team_lead_name'])
                                ): ?>
                                    <p>
                                        Led by
                                        <?= alliances_profile_link(
                                            (int) $team['team_lead_id'],
                                            (string) $team['team_lead_name']
                                        ) ?>
                                    </p>
                                <?php endif; ?>
                            </div>

                            <?php if ($isAdmin): ?>
                                <a
                                    class="admin-manage-link"
                                    href="/admin/admin-team.php?id=<?= (int) $team['id'] ?>"
                                >
                                    Manage team
                                    <span aria-hidden="true">→</span>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="profile-section admin-account-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Account</h2>

                    <p>
                        Account and workspace access information.
                    </p>
                </div>
            </div>

            <div class="admin-account-details">
                <div class="admin-account-detail">
                    <span>Workspace role</span>

                    <strong>
                        <?= $managedUser['role'] === 'admin'
                            ? 'Administrator'
                            : 'Member'
                        ?>
                    </strong>
                </div>

                <div class="admin-account-detail">
                    <span>Account status</span>

                    <strong>
                        <?= $managedUser['account_status'] === 'deactivated'
                            ? 'Deactivated'
                            : 'Active'
                        ?>
                    </strong>
                </div>

                <div class="admin-account-detail">
                    <span>User ID</span>

                    <strong>
                        #<?= (int) $managedUser['id'] ?>
                    </strong>
                </div>
            </div>

            <?php if ($isAdmin): ?>
                <div class="profile-form-grid">
                    <form class="profile-edit-form" method="post">
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="role">

                        <div class="profile-form-row">
                            <div class="profile-form-label">
                                <label for="role">Workspace role</label>
                                <p>Use only the existing administrator/member roles.</p>
                            </div>

                            <div class="profile-form-control">
                                <select id="role" name="role">
                                    <option value="member" <?= $managedUser['role'] === 'member' ? 'selected' : '' ?>>
                                        Member
                                    </option>
                                    <option value="admin" <?= $managedUser['role'] === 'admin' ? 'selected' : '' ?>>
                                        Administrator
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="profile-form-actions">
                            <button type="submit">Save role</button>
                        </div>
                    </form>

                    <form class="profile-edit-form" method="post">
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="account_status">

                        <div class="profile-form-row">
                            <div class="profile-form-label">
                                <label for="account_status">Account status</label>
                                <p>Deactivated users cannot sign in and active sessions are revoked.</p>
                            </div>

                            <div class="profile-form-control">
                                <select id="account_status" name="account_status">
                                    <option value="active" <?= $managedUser['account_status'] === 'active' ? 'selected' : '' ?>>
                                        Active
                                    </option>
                                    <option value="deactivated" <?= $managedUser['account_status'] === 'deactivated' ? 'selected' : '' ?>>
                                        Deactivated
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="profile-form-actions">
                            <button type="submit">Save status</button>
                        </div>
                    </form>

                    <form class="profile-edit-form" method="post">
                        <?= csrf_input() ?>
                        <input type="hidden" name="action" value="password">

                        <div class="profile-form-row">
                            <div class="profile-form-label">
                                <label for="password">New account password</label>
                                <p>This does not change the separate Key Vault password.</p>
                            </div>

                            <div class="profile-form-control">
                                <input
                                    id="password"
                                    type="password"
                                    name="password"
                                    minlength="12"
                                    autocomplete="new-password"
                                >
                            </div>
                        </div>

                        <div class="profile-form-actions">
                            <button type="submit">Reset password</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($isAdmin): ?>
            <section class="profile-section admin-account-section">
                <div class="profile-section-heading">
                    <div>
                        <h2>Sessions</h2>

                        <p>
                            Active device sessions recorded for this account.
                        </p>
                    </div>
                </div>

                <?php if ($activeSessions === []): ?>
                    <div class="profile-empty-state">
                        No active sessions are currently recorded.
                    </div>
                <?php else: ?>
                    <div class="admin-account-details">
                        <?php foreach ($activeSessions as $session): ?>
                            <div class="admin-account-detail">
                                <span>
                                    <?= htmlspecialchars(
                                        $session['user_agent'] ?: 'Unknown device',
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>

                                <strong>
                                    Last seen
                                    <?= htmlspecialchars(
                                        $session['last_seen_at'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </strong>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <form class="profile-edit-form" method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="sessions">

                    <div class="profile-form-actions">
                        <button type="submit">
                            Revoke active sessions
                        </button>
                    </div>
                </form>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
