<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

$user = require_login();
$connection = db();

$access = require_administration_access($user);

$workspaceId = (int) $access['workspace_id'];
$isAdmin = (bool) $access['is_admin'];
$isTeamLead = (bool) $access['is_team_lead'];
$searchQuery = trim((string) ($_GET['q'] ?? ''));
$roleFilter = (string) ($_GET['role'] ?? '');
$statusFilter = (string) ($_GET['status'] ?? '');

if (!in_array($roleFilter, ['', 'admin', 'member'], true)) {
    $roleFilter = '';
}

if (!in_array($statusFilter, ['', 'active', 'deactivated'], true)) {
    $statusFilter = '';
}

/*
|--------------------------------------------------------------------------
| Workspace
|--------------------------------------------------------------------------
*/

$workspaceStatement = $connection->prepare(
    'SELECT id, name
     FROM workspaces
     WHERE id = ?
     LIMIT 1'
);

$workspaceStatement->execute([$workspaceId]);
$workspace = $workspaceStatement->fetch();

if (!$workspace) {
    http_response_code(404);
    exit('Workspace not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isAdmin) {
        http_response_code(403);
        exit('Only workspace administrators can update workspace settings.');
    }

    require_valid_csrf();

    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'workspace') {
        $workspaceName = trim((string) ($_POST['workspace_name'] ?? ''));

        if ($workspaceName === '') {
            http_response_code(400);
            exit('Workspace name is required.');
        }

        if (strlen($workspaceName) > 120) {
            http_response_code(400);
            exit('Workspace name must be 120 characters or fewer.');
        }

        $statement = $connection->prepare(
            'UPDATE workspaces
             SET name = ?
             WHERE id = ?'
        );

        $statement->execute([$workspaceName, $workspaceId]);

        admin_audit_log(
            $workspaceId,
            (int) $user['id'],
            'workspace_renamed',
            'workspace',
            $workspaceId
        );

        header('Location: /admin/admin.php?updated=1');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Users visible to this administrator
|--------------------------------------------------------------------------
|
| Admin:
|   Every user in the workspace.
|
| Team Lead:
|   Only users who belong to a team they lead.
|
*/

$users = [];

if ($isAdmin) {
    $usersStatement = $connection->prepare(
        'SELECT
            u.id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path,
            u.account_status,
            wm.role
         FROM users u
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id
         WHERE wm.workspace_id = ?'
        . ($searchQuery !== ''
            ? ' AND (
                u.display_name LIKE ?
                OR u.email LIKE ?
                OR u.job_title LIKE ?
            )'
            : '')
        . ($roleFilter !== ''
            ? ' AND wm.role = ?'
            : '')
        . ($statusFilter !== ''
            ? ' AND u.account_status = ?'
            : '')
        . '
         ORDER BY u.display_name ASC'
    );

    $userParameters = [$workspaceId];

    if ($searchQuery !== '') {
        $likeQuery = '%' . $searchQuery . '%';
        $userParameters[] = $likeQuery;
        $userParameters[] = $likeQuery;
        $userParameters[] = $likeQuery;
    }

    if ($roleFilter !== '') {
        $userParameters[] = $roleFilter;
    }

    if ($statusFilter !== '') {
        $userParameters[] = $statusFilter;
    }

    $usersStatement->execute($userParameters);
    $users = $usersStatement->fetchAll();
} else {
    $teamIds = $access['team_ids'];

    if ($teamIds !== []) {
        $placeholders = implode(
            ',',
            array_fill(0, count($teamIds), '?')
        );

        $parameters = [$workspaceId];

        foreach ($teamIds as $teamId) {
            $parameters[] = $teamId;
        }

        $usersStatement = $connection->prepare(
            'SELECT DISTINCT
                u.id,
                u.display_name,
                u.email,
                u.job_title,
                u.avatar_path,
                u.account_status,
                wm.role
             FROM users u
             INNER JOIN workspace_members wm
                 ON wm.user_id = u.id
             INNER JOIN team_members tm
                 ON tm.user_id = u.id
             WHERE wm.workspace_id = ?
               AND tm.team_id IN (' . $placeholders . ')
               AND u.account_status = ?
             ORDER BY u.display_name ASC'
        );

        $parameters[] = 'active';

        $usersStatement->execute($parameters);
        $users = $usersStatement->fetchAll();
    }
}

/*
|--------------------------------------------------------------------------
| Teams visible to this administrator
|--------------------------------------------------------------------------
*/

$teams = [];

if ($isAdmin) {
    $teamsStatement = $connection->prepare(
        'SELECT
            t.id,
            t.name,
            t.team_lead_id,
            lead.display_name AS team_lead_name,
            lead.job_title AS team_lead_job_title,
            lead.avatar_path AS team_lead_avatar,
            COUNT(DISTINCT tm.user_id) AS member_count
         FROM teams t
         LEFT JOIN users lead
             ON lead.id = t.team_lead_id
         LEFT JOIN team_members tm
             ON tm.team_id = t.id
         WHERE t.workspace_id = ?
         GROUP BY
            t.id,
            t.name,
            t.team_lead_id,
            lead.display_name,
            lead.job_title,
            lead.avatar_path
         ORDER BY t.name ASC'
    );

    $teamsStatement->execute([$workspaceId]);
    $teams = $teamsStatement->fetchAll();
} else {
    $teamIds = $access['team_ids'];

    if ($teamIds !== []) {
        $placeholders = implode(
            ',',
            array_fill(0, count($teamIds), '?')
        );

        $parameters = [$workspaceId];

        foreach ($teamIds as $teamId) {
            $parameters[] = $teamId;
        }

        $teamsStatement = $connection->prepare(
            'SELECT
                t.id,
                t.name,
                t.team_lead_id,
                lead.display_name AS team_lead_name,
                lead.job_title AS team_lead_job_title,
                lead.avatar_path AS team_lead_avatar,
                COUNT(DISTINCT tm.user_id) AS member_count
             FROM teams t
             LEFT JOIN users lead
                 ON lead.id = t.team_lead_id
             LEFT JOIN team_members tm
                 ON tm.team_id = t.id
             WHERE t.workspace_id = ?
               AND t.id IN (' . $placeholders . ')
             GROUP BY
                t.id,
                t.name,
                t.team_lead_id,
                lead.display_name,
                lead.job_title,
                lead.avatar_path
             ORDER BY t.name ASC'
        );

        $teamsStatement->execute($parameters);
        $teams = $teamsStatement->fetchAll();
    }
}

$userCount = count($users);
$teamCount = count($teams);

$adminOverview = [
    'admins' => 0,
    'team_leads' => 0,
    'active_sessions' => 0,
    'deactivated_users' => 0,
    'drive_files' => 0,
    'drive_folders' => 0,
    'drive_bytes' => 0,
];

$recentAuditEvents = [];

if ($isAdmin) {
    $adminCountStatement = $connection->prepare(
        'SELECT COUNT(*)
         FROM workspace_members
         WHERE workspace_id = ?
           AND role = ?'
    );
    $adminCountStatement->execute([$workspaceId, 'admin']);
    $adminOverview['admins'] = (int) $adminCountStatement->fetchColumn();

    $teamLeadCountStatement = $connection->prepare(
        'SELECT COUNT(DISTINCT team_lead_id)
         FROM teams
         WHERE workspace_id = ?
           AND team_lead_id IS NOT NULL
           AND status = ?'
    );
    $teamLeadCountStatement->execute([$workspaceId, 'active']);
    $adminOverview['team_leads'] = (int) $teamLeadCountStatement->fetchColumn();

    $activeSessionsStatement = $connection->prepare(
        'SELECT COUNT(*)
         FROM user_sessions us
         INNER JOIN workspace_members wm
             ON wm.user_id = us.user_id
         WHERE wm.workspace_id = ?
           AND us.revoked_at IS NULL'
    );
    $activeSessionsStatement->execute([$workspaceId]);
    $adminOverview['active_sessions'] = (int) $activeSessionsStatement->fetchColumn();

    $deactivatedUsersStatement = $connection->prepare(
        'SELECT COUNT(*)
         FROM users u
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id
         WHERE wm.workspace_id = ?
           AND u.account_status = ?'
    );
    $deactivatedUsersStatement->execute([$workspaceId, 'deactivated']);
    $adminOverview['deactivated_users'] = (int) $deactivatedUsersStatement->fetchColumn();

    $driveFilesStatement = $connection->prepare(
        'SELECT COUNT(*), COALESCE(SUM(encrypted_size), 0)
         FROM drive_files
         WHERE workspace_id = ?'
    );
    $driveFilesStatement->execute([$workspaceId]);
    $driveFileStats = $driveFilesStatement->fetch(PDO::FETCH_NUM);
    $adminOverview['drive_files'] = (int) ($driveFileStats[0] ?? 0);
    $adminOverview['drive_bytes'] = (int) ($driveFileStats[1] ?? 0);

    $driveFoldersStatement = $connection->prepare(
        'SELECT COUNT(*)
         FROM drive_folders
         WHERE workspace_id = ?'
    );
    $driveFoldersStatement->execute([$workspaceId]);
    $adminOverview['drive_folders'] = (int) $driveFoldersStatement->fetchColumn();

    $auditStatement = $connection->prepare(
        'SELECT
            a.action,
            a.target_type,
            a.target_id,
            a.details,
            a.created_at,
            actor.display_name AS actor_name
         FROM admin_audit_events a
         LEFT JOIN users actor
            ON actor.id = a.actor_user_id
         WHERE a.workspace_id = ?
         ORDER BY a.created_at DESC
         LIMIT 10'
    );
    $auditStatement->execute([$workspaceId]);
    $recentAuditEvents = $auditStatement->fetchAll();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Administration | Alliances</title>
</head>
<body>
<?php render_navigation($user); ?>

    <main class="admin-page">
        <header class="admin-page-heading">
            <div>
                <p class="profile-eyebrow">
                    <?= $isAdmin ? 'Workspace administration' : 'Team administration' ?>
                </p>

                <h1>Administration</h1>

                <p class="admin-page-description">
                    <?php if ($isAdmin): ?>
                        Manage the people and teams in your workspace.
                    <?php else: ?>
                        Manage the people in the
                        <?= $teamCount === 1 ? 'team' : 'teams' ?>
                        you lead.
                    <?php endif; ?>
                </p>
            </div>

            <?php if ($isAdmin): ?>
                <div class="admin-heading-actions">
                    <a
                        class="button-link admin-secondary-button"
                        href="#create-team"
                    >
                        Create team
                    </a>

                    <a
                        class="button-link"
                        href="#add-user"
                    >
                        Add user
                    </a>
                </div>
            <?php endif; ?>
        </header>

        <section class="admin-summary-card">
            <div class="admin-workspace-info">
                <span class="admin-summary-label">Workspace</span>

                <h2>
                    <?= htmlspecialchars(
                        $workspace['name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h2>

                <p>
                    <?= $isAdmin
                        ? 'Full workspace administration'
                        : 'Team Lead access'
                    ?>
                </p>
            </div>

            <div class="admin-summary-stats">
                <div class="admin-stat">
                    <strong><?= $userCount ?></strong>

                    <span>
                        <?= $isAdmin ? 'Workspace users' : 'Team members' ?>
                    </span>
                </div>

                <div class="admin-stat">
                    <strong><?= $teamCount ?></strong>

                    <span>
                        <?= $isAdmin ? 'Teams' : 'Teams led' ?>
                    </span>
                </div>
            </div>
        </section>

        <?php if ($isAdmin): ?>
            <section class="profile-section">
                <div class="profile-section-heading admin-section-heading">
                    <div>
                        <h2>Overview</h2>

                        <p>
                            Real workspace administration totals from the current database.
                        </p>
                    </div>
                </div>

                <div class="admin-summary-stats">
                    <div class="admin-stat">
                        <strong><?= (int) $adminOverview['admins'] ?></strong>
                        <span>Administrators</span>
                    </div>

                    <div class="admin-stat">
                        <strong><?= (int) $adminOverview['team_leads'] ?></strong>
                        <span>Team Leads</span>
                    </div>

                    <div class="admin-stat">
                        <strong><?= (int) $adminOverview['active_sessions'] ?></strong>
                        <span>Active sessions</span>
                    </div>

                    <div class="admin-stat">
                        <strong><?= (int) $adminOverview['deactivated_users'] ?></strong>
                        <span>Deactivated accounts</span>
                    </div>
                </div>
            </section>

            <section class="profile-section">
                <div class="profile-section-heading admin-section-heading">
                    <div>
                        <h2>Workspace</h2>

                        <p>
                            Workspace-level information used throughout Alliances.
                        </p>
                    </div>
                </div>

                <form class="profile-edit-form" method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="workspace">

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="workspace_name">Workspace name</label>
                            <p>Use the existing workspace record as the source of truth.</p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="workspace_name"
                                type="text"
                                name="workspace_name"
                                maxlength="120"
                                required
                                value="<?= htmlspecialchars(
                                    $workspace['name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >
                        </div>
                    </div>

                    <div class="profile-form-actions">
                        <button type="submit">Save workspace</button>
                    </div>
                </form>
            </section>

            <section class="profile-section">
                <div class="profile-section-heading admin-section-heading">
                    <div>
                        <h2>Storage</h2>

                        <p>
                            Drive storage metadata only. Encrypted file contents are not read.
                        </p>
                    </div>
                </div>

                <div class="admin-summary-stats">
                    <div class="admin-stat">
                        <strong><?= (int) $adminOverview['drive_files'] ?></strong>
                        <span>Files</span>
                    </div>

                    <div class="admin-stat">
                        <strong><?= (int) $adminOverview['drive_folders'] ?></strong>
                        <span>Folders</span>
                    </div>

                    <div class="admin-stat">
                        <strong>
                            <?= number_format((int) $adminOverview['drive_bytes']) ?> B
                        </strong>
                        <span>Encrypted storage</span>
                    </div>
                </div>
            </section>

            <section class="profile-section">
                <div class="profile-section-heading admin-section-heading">
                    <div>
                        <h2>Audit</h2>

                        <p>
                            Recent workspace administrative activity.
                        </p>
                    </div>
                </div>

                <?php if ($recentAuditEvents === []): ?>
                    <div class="profile-empty-state">
                        No administrative activity has been recorded yet.
                    </div>
                <?php else: ?>
                    <div class="admin-user-list">
                        <?php foreach ($recentAuditEvents as $event): ?>
                            <article class="admin-user-row">
                                <span class="admin-user-details">
                                    <span class="admin-user-name">
                                        <?= htmlspecialchars(
                                            str_replace('_', ' ', $event['action']),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                    <span class="admin-user-job">
                                        <?= htmlspecialchars(
                                            $event['details']
                                                ?: (($event['target_type'] ?? 'item')
                                                    . ' #'
                                                    . ((int) ($event['target_id'] ?? 0))),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                    <span class="admin-user-email">
                                        <?= htmlspecialchars(
                                            ($event['actor_name'] ?: 'System')
                                            . ' - '
                                            . $event['created_at'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>
                                </span>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <section class="profile-section">
            <div class="profile-section-heading admin-section-heading">
                <div>
                    <h2>
                        <?= $isAdmin ? 'Workspace members' : 'Team members' ?>
                    </h2>

                    <p>
                        <?php if ($isAdmin): ?>
                            View and manage people with access to this workspace.
                        <?php else: ?>
                            People who belong to the teams you lead.
                        <?php endif; ?>
                    </p>
                </div>

                <?php if ($isAdmin): ?>
                    <a
                        class="admin-text-action"
                        href="#add-user"
                    >
                        Add user
                    </a>
                <?php endif; ?>
            </div>

            <?php if ($isAdmin): ?>
                <form class="profile-edit-form" method="get">
                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="q">Search people</label>
                            <p>Filter by display name, email, or job title.</p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="q"
                                type="search"
                                name="q"
                                value="<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8') ?>"
                            >
                        </div>
                    </div>

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="role">Role</label>
                            <p>Limit results by workspace role.</p>
                        </div>

                        <div class="profile-form-control">
                            <select id="role" name="role">
                                <option value="">Any role</option>
                                <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>
                                    Administrator
                                </option>
                                <option value="member" <?= $roleFilter === 'member' ? 'selected' : '' ?>>
                                    Member
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="status">Account status</label>
                            <p>Show active or deactivated accounts.</p>
                        </div>

                        <div class="profile-form-control">
                            <select id="status" name="status">
                                <option value="">Any status</option>
                                <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>
                                    Active
                                </option>
                                <option value="deactivated" <?= $statusFilter === 'deactivated' ? 'selected' : '' ?>>
                                    Deactivated
                                </option>
                            </select>
                        </div>
                    </div>

                    <div class="profile-form-actions">
                        <button type="submit">Filter people</button>
                    </div>
                </form>
            <?php endif; ?>

            <?php if ($users === []): ?>
                <div class="profile-empty-state">
                    No users are available to manage.
                </div>
            <?php else: ?>
                <div class="admin-user-list">
                    <?php foreach ($users as $managedUser): ?>
                        <article class="admin-user-row">
                            <a
                                class="admin-user-profile"
                                href="/profile/?id=<?= (int) $managedUser['id'] ?>"
                            >
                                <?php if (!empty($managedUser['avatar_path'])): ?>
                                    <img
                                        class="admin-user-avatar"
                                        src="<?= htmlspecialchars(
                                            $managedUser['avatar_path'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        alt=""
                                    >
                                <?php else: ?>
                                    <span class="admin-user-avatar admin-user-avatar-placeholder">
                                        <?= htmlspecialchars(
                                            strtoupper(
                                                substr(
                                                    $managedUser['display_name'],
                                                    0,
                                                    1
                                                )
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>
                                <?php endif; ?>

                                <span class="admin-user-details">
                                    <span class="admin-user-name">
                                        <?= htmlspecialchars(
                                            $managedUser['display_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                        <?php if ($managedUser['role'] === 'admin'): ?>
                                            <span class="admin-role-badge">
                                                Admin
                                            </span>
                                        <?php endif; ?>

                                        <?php if (($managedUser['account_status'] ?? 'active') === 'deactivated'): ?>
                                            <span class="admin-role-badge">
                                                Deactivated
                                            </span>
                                        <?php endif; ?>
                                    </span>

                                    <?php if (!empty($managedUser['job_title'])): ?>
                                        <span class="admin-user-job">
                                            <?= htmlspecialchars(
                                                $managedUser['job_title'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="admin-user-job admin-user-job-empty">
                                            No job title
                                        </span>
                                    <?php endif; ?>

                                    <span class="admin-user-email">
                                        <?= htmlspecialchars(
                                            $managedUser['email'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>
                                </span>
                            </a>

                            <?php if (
                                $isAdmin
                                || can_manage_user(
                                    $access,
                                    (int) $managedUser['id']
                                )
                            ): ?>
                                <a
                                    class="admin-manage-link"
                                    href="/admin/admin-user.php?id=<?= (int) $managedUser['id'] ?>"
                                >
                                    Edit
                                    <span aria-hidden="true">→</span>
                                </a>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading admin-section-heading">
                <div>
                    <h2><?= $isAdmin ? 'Teams' : 'My teams' ?></h2>

                    <p>
                        <?php if ($isAdmin): ?>
                            Manage team structure, Team Leads, and membership.
                        <?php else: ?>
                            Teams where you are currently the Team Lead.
                        <?php endif; ?>
                    </p>
                </div>

                <?php if ($isAdmin): ?>
                    <a
                        class="admin-text-action"
                        href="#create-team"
                    >
                        Create team
                    </a>
                <?php endif; ?>
            </div>

            <?php if ($teams === []): ?>
                <div class="profile-empty-state">
                    <?= $isAdmin
                        ? 'No teams have been created yet.'
                        : 'You are not currently leading a team.'
                    ?>
                </div>
            <?php else: ?>
                <div class="admin-team-grid">
                    <?php foreach ($teams as $team): ?>
                        <article class="admin-team-card-new">
                            <div class="admin-team-card-header">
                                <div>
                                    <span class="profile-team-label">
                                        Team
                                    </span>

                                    <h3>
                                        <?= alliances_team_link(
                                            (int) $team['id'],
                                            (string) $team['name']
                                        ) ?>
                                    </h3>
                                </div>

                                <span class="admin-member-count">
                                    <?= (int) $team['member_count'] ?>
                                    <?= (int) $team['member_count'] === 1
                                        ? 'member'
                                        : 'members'
                                    ?>
                                </span>
                            </div>

                            <div class="admin-team-lead">
                                <span class="admin-summary-label">
                                    Team Lead
                                </span>

                                <?php if ($team['team_lead_id']): ?>
                                    <a
                                        class="profile-person"
                                        href="/profile/?id=<?= (int) $team['team_lead_id'] ?>"
                                    >
                                        <?php if (!empty($team['team_lead_avatar'])): ?>
                                            <img
                                                class="org-avatar"
                                                src="<?= htmlspecialchars(
                                                    $team['team_lead_avatar'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>"
                                                alt=""
                                            >
                                        <?php else: ?>
                                            <span class="org-avatar org-avatar-placeholder">
                                                <?= htmlspecialchars(
                                                    strtoupper(
                                                        substr(
                                                            $team['team_lead_name']
                                                                ?? '?',
                                                            0,
                                                            1
                                                        )
                                                    ),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </span>
                                        <?php endif; ?>

                                        <span class="profile-person-details">
                                            <strong>
                                                <?= htmlspecialchars(
                                                    $team['team_lead_name']
                                                        ?? 'Unknown user',
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                            <?php if (!empty($team['team_lead_job_title'])): ?>
                                                <small>
                                                    <?= htmlspecialchars(
                                                        $team['team_lead_job_title'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </small>
                                            <?php endif; ?>
                                        </span>
                                    </a>
                                <?php else: ?>
                                    <p class="admin-no-lead">
                                        No Team Lead assigned
                                    </p>
                                <?php endif; ?>
                            </div>

                            <div class="admin-team-card-footer">
                                <a
                                    class="admin-text-action"
                                    href="/team.php?id=<?= (int) $team['id'] ?>"
                                >
                                    Open team page
                                </a>

                                <a
                                    class="admin-manage-link"
                                    href="/admin/admin-team.php?id=<?= (int) $team['id'] ?>"
                                >
                                    <?= $isAdmin ? 'Manage team' : 'View team' ?>
                                    <span aria-hidden="true">→</span>
                                </a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($isAdmin): ?>
            <section
                id="add-user"
                class="profile-section admin-form-section"
            >
                <div class="profile-section-heading">
                    <div>
                        <h2>Add user</h2>

                        <p>
                            Create a new account and add it to this workspace.
                        </p>
                    </div>
                </div>

                <form
                    class="profile-edit-form"
                    method="post"
                    action="/actions/admin/admin-create-user.php"
                >
                    <?= csrf_input() ?>
                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="display_name">
                                Display name
                            </label>

                            <p>
                                The name shown throughout Alliances.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="display_name"
                                type="text"
                                name="display_name"
                                required
                                maxlength="100"
                            >
                        </div>
                    </div>

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="email">
                                Email
                            </label>

                            <p>
                                Used by the user to sign in.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="email"
                                type="email"
                                name="email"
                                required
                                autocomplete="off"
                            >
                        </div>
                    </div>

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="password">
                                Temporary password
                            </label>

                            <p>
                                Set the initial password for this account.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="password"
                                type="password"
                                name="password"
                                required
                                minlength="8"
                                autocomplete="new-password"
                            >
                        </div>
                    </div>

                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="job_title">
                                Job title
                            </label>

                            <p>
                                Optional position displayed on the user's profile.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="job_title"
                                type="text"
                                name="job_title"
                                maxlength="120"
                                placeholder="e.g. Sales Manager"
                            >
                        </div>
                    </div>

                    <div class="profile-form-actions">
                        <button type="submit">
                            Create user
                        </button>
                    </div>
                </form>
            </section>

            <section
                id="create-team"
                class="profile-section admin-form-section"
            >
                <div class="profile-section-heading">
                    <div>
                        <h2>Create team</h2>

                        <p>
                            Create a team and choose its Team Lead and members.
                        </p>
                    </div>
                </div>

                <form
                    class="profile-edit-form"
                    method="post"
                    action="/actions/admin/admin-create-team.php"
                >
                    <?= csrf_input() ?>
                    <div class="profile-form-row">
                        <div class="profile-form-label">
                            <label for="team_name">
                                Team name
                            </label>

                            <p>
                                Give the team a clear workspace name.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <input
                                id="team_name"
                                type="text"
                                name="name"
                                required
                                maxlength="120"
                                placeholder="e.g. Sales"
                            >
                        </div>
                    </div>

                    <div class="profile-form-row profile-form-row-top">
                        <div class="profile-form-label">
                            <label for="team_lead_id">
                                Team Lead
                            </label>

                            <p>
                                The Team Lead can administer members of this team.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <select
                                id="team_lead_id"
                                name="team_lead_id"
                                required
                            >
                                <option value="">
                                    Choose Team Lead
                                </option>

                                <?php foreach ($users as $workspaceUser): ?>
                                    <option value="<?= (int) $workspaceUser['id'] ?>">
                                        <?= htmlspecialchars(
                                            $workspaceUser['display_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="profile-form-row profile-form-row-top">
                        <div class="profile-form-label">
                            <span class="admin-field-title">
                                Team members
                            </span>

                            <p>
                                Select the people who belong to this team.
                                The Team Lead is added automatically.
                            </p>
                        </div>

                        <div class="profile-form-control">
                            <div class="admin-member-selector">
                                <?php foreach ($users as $workspaceUser): ?>
                                    <label class="admin-member-option">
                                        <input
                                            type="checkbox"
                                            name="member_ids[]"
                                            value="<?= (int) $workspaceUser['id'] ?>"
                                        >

                                        <?php if (!empty($workspaceUser['avatar_path'])): ?>
                                            <img
                                                class="org-avatar"
                                                src="<?= htmlspecialchars(
                                                    $workspaceUser['avatar_path'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>"
                                                alt=""
                                            >
                                        <?php else: ?>
                                            <span class="org-avatar org-avatar-placeholder">
                                                <?= htmlspecialchars(
                                                    strtoupper(
                                                        substr(
                                                            $workspaceUser['display_name'],
                                                            0,
                                                            1
                                                        )
                                                    ),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </span>
                                        <?php endif; ?>

                                        <span class="profile-person-details">
                                            <strong>
                                                <?= htmlspecialchars(
                                                    $workspaceUser['display_name'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                            <small>
                                                <?= htmlspecialchars(
                                                    $workspaceUser['job_title']
                                                        ?: $workspaceUser['email'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </small>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <div class="profile-form-actions">
                        <button type="submit">
                            Create team
                        </button>
                    </div>
                </form>
            </section>
        <?php endif; ?>
    </main>
</body>
</html>
