/*
 * Alliances — Command Palette
 *
 * Global Ctrl+K / Cmd+K overlay that provides permission-aware navigation
 * and universal search (see /actions/search.php).
 */

(function () {
    'use strict';

    const palette = document.getElementById('command-palette');
    const input = document.getElementById('command-palette-input');
    const results = document.getElementById('command-palette-results');

    if (!palette || !input || !results) {
        return;
    }

    const navNode = document.getElementById('command-palette-nav');

    let navCommands = [];

    if (navNode) {
        try {
            navCommands = JSON.parse(navNode.textContent);
        } catch (error) {
            navCommands = [];
        }
    }

    const SEARCH_ENDPOINT = '/actions/search.php';
    const MIN_QUERY_LENGTH = 1;
    const DEBOUNCE_MS = 150;

    const BADGES = {
        people: 'People',
        team: 'Team',
        project: 'Project',
        task: 'Task',
        task_list: 'List',
        calendar_event: 'Event',
        drive_file: 'File',
        drive_folder: 'Folder',
    };

    let items = [];
    let activeIndex = -1;
    let debounceTimer = null;
    let requestSequence = 0;

    function createItem(item, index) {
        const anchor = document.createElement('a');
        anchor.className = 'command-palette-item';
        anchor.href = item.url || '#';
        anchor.setAttribute('role', 'option');
        anchor.dataset.index = String(index);

        const badge = document.createElement('span');
        badge.className = 'command-palette-item-badge';
        badge.textContent = item.badge || 'Go';

        const text = document.createElement('span');
        text.className = 'command-palette-item-text';

        const title = document.createElement('span');
        title.className = 'command-palette-item-title';
        title.textContent = item.title || item.label || '';

        const subtitle = document.createElement('span');
        subtitle.className = 'command-palette-item-subtitle';
        subtitle.textContent = item.subtitle || item.hint || '';

        text.appendChild(title);
        text.appendChild(subtitle);

        anchor.appendChild(badge);
        anchor.appendChild(text);

        anchor.addEventListener('mouseenter', () => {
            setActive(index);
        });

        return anchor;
    }

    function setActive(index) {
        const active = results.querySelector('.command-palette-item.is-active');

        if (active) {
            active.classList.remove('is-active');
        }

        activeIndex = index;

        const next = results.querySelectorAll('.command-palette-item')[index];

        if (next) {
            next.classList.add('is-active');
            next.scrollIntoView({ block: 'nearest' });
        }
    }

    function render(rows) {
        items = rows;
        results.textContent = '';
        activeIndex = -1;

        if (!rows.length) {
            const empty = document.createElement('div');
            empty.className = 'command-palette-empty';
            empty.textContent = 'No results.';
            results.appendChild(empty);
            return;
        }

        rows.forEach((row, index) => {
            results.appendChild(createItem(row, index));
        });

        setActive(0);
    }

    function renderNavCommands() {
        render(navCommands.map((command) => ({
            ...command,
            badge: 'Go',
        })));
    }

    function renderSearchResults(rows) {
        render(rows.map((row) => ({
            title: row.title,
            subtitle: row.subtitle || '',
            url: row.url,
            badge: BADGES[row.type] || row.type,
        })));
    }

    async function runSearch(query) {
        const sequence = ++requestSequence;

        try {
            const response = await fetch(
                SEARCH_ENDPOINT + '?q=' + encodeURIComponent(query),
                { headers: { Accept: 'application/json' } }
            );

            if (!response.ok) {
                throw new Error('Search request failed.');
            }

            const payload = await response.json();

            if (sequence !== requestSequence) {
                return;
            }

            if (!payload.success) {
                render([]);
                return;
            }

            renderSearchResults(payload.results || []);
        } catch (error) {
            if (sequence !== requestSequence) {
                return;
            }

            items = [];
            activeIndex = -1;
            results.textContent = '';

            const message = document.createElement('div');
            message.className = 'command-palette-empty';
            message.textContent = 'Search is unavailable right now.';
            results.appendChild(message);
        }
    }

    function onInput() {
        const query = input.value.trim();

        if (debounceTimer) {
            clearTimeout(debounceTimer);
        }

        if (query.length < MIN_QUERY_LENGTH) {
            requestSequence++;
            renderNavCommands();
            return;
        }

        debounceTimer = setTimeout(() => {
            runSearch(query);
        }, DEBOUNCE_MS);
    }

    function openPalette() {
        palette.hidden = false;
        input.value = '';
        renderNavCommands();
        window.requestAnimationFrame(() => input.focus());
    }

    function closePalette() {
        palette.hidden = true;
        input.value = '';
        requestSequence++;

        if (debounceTimer) {
            clearTimeout(debounceTimer);
        }
    }

    document.addEventListener('keydown', (event) => {
        const isOpen = !palette.hidden;
        const isOpenShortcut =
            (event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k';

        if (isOpenShortcut) {
            event.preventDefault();

            if (isOpen) {
                closePalette();
            } else {
                openPalette();
            }

            return;
        }

        if (!isOpen) {
            return;
        }

        if (event.key === 'Escape') {
            event.preventDefault();
            closePalette();
            return;
        }

        if (event.key === 'ArrowDown') {
            event.preventDefault();

            if (activeIndex < items.length - 1) {
                setActive(activeIndex + 1);
            }

            return;
        }

        if (event.key === 'ArrowUp') {
            event.preventDefault();

            if (activeIndex > 0) {
                setActive(activeIndex - 1);
            }

            return;
        }

        if (event.key === 'Enter') {
            const active = results.querySelectorAll('.command-palette-item')[activeIndex];

            if (active) {
                event.preventDefault();
                closePalette();
                window.location.href = active.href;
            }
        }
    });

    palette.addEventListener('click', (event) => {
        if (event.target.closest('[data-command-palette-close]')) {
            closePalette();
            return;
        }

        if (event.target.closest('.command-palette-item')) {
            closePalette();
        }
    });

    input.addEventListener('input', onInput);
})();
