<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/auth.php';
require_once dirname(__DIR__) . '/src/notifications.php';
require_once dirname(__DIR__) . '/src/projects.php';

$user = require_login();
$connection = db();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Selected month
|--------------------------------------------------------------------------
*/

$monthInput =
    isset($_GET['month'])
        ? trim((string) $_GET['month'])
        : date('Y-m');

if (!preg_match('/^\d{4}-\d{2}$/', $monthInput)) {
    $monthInput = date('Y-m');
}

$month =
    DateTimeImmutable::createFromFormat(
        '!Y-m',
        $monthInput
    );

if (
    $month === false
    || $month->format('Y-m') !== $monthInput
) {
    $month =
        new DateTimeImmutable(
            'first day of this month'
        );
}

$monthStart =
    $month->modify(
        'first day of this month'
    );

$monthEnd =
    $monthStart->modify(
        'first day of next month'
    );

$previousMonth =
    $month->modify('-1 month')
        ->format('Y-m');

$nextMonth =
    $month->modify('+1 month')
        ->format('Y-m');

$currentMonth =
    (new DateTimeImmutable())
        ->format('Y-m');

$today =
    (new DateTimeImmutable())
        ->format('Y-m-d');

/*
|--------------------------------------------------------------------------
| Create event
|--------------------------------------------------------------------------
*/

$error = null;

$formTitle = '';
$formDescription = '';
$formStartsAt = '';
$formEndsAt = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $formTitle =
        trim((string) ($_POST['title'] ?? ''));

    $formDescription =
        trim((string) ($_POST['description'] ?? ''));

    $formStartsAt =
        trim((string) ($_POST['starts_at'] ?? ''));

    $formEndsAt =
        trim((string) ($_POST['ends_at'] ?? ''));

    if ($formTitle === '') {
        $error = 'Enter an event title.';
    } elseif (strlen($formTitle) > 200) {
        $error =
            'Event titles can be up to 200 characters.';
    } elseif ($formStartsAt === '') {
        $error =
            'Choose when the event starts.';
    }

    /*
    |--------------------------------------------------------------------------
    | Validate start
    |--------------------------------------------------------------------------
    */

    $startsAt = null;

    if ($error === null) {
        $startsAt =
            DateTimeImmutable::createFromFormat(
                'Y-m-d\TH:i',
                $formStartsAt
            );

        $startErrors =
            DateTimeImmutable::getLastErrors();

        $startValid =
            $startsAt !== false
            && (
                $startErrors === false
                || (
                    $startErrors['warning_count'] === 0
                    && $startErrors['error_count'] === 0
                )
            )
            && $startsAt->format(
                'Y-m-d\TH:i'
            ) === $formStartsAt;

        if (!$startValid) {
            $error =
                'Choose a valid event start date and time.';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Validate end
    |--------------------------------------------------------------------------
    */

    $endsAt = null;

    if (
        $error === null
        && $formEndsAt !== ''
    ) {
        $endsAt =
            DateTimeImmutable::createFromFormat(
                'Y-m-d\TH:i',
                $formEndsAt
            );

        $endErrors =
            DateTimeImmutable::getLastErrors();

        $endValid =
            $endsAt !== false
            && (
                $endErrors === false
                || (
                    $endErrors['warning_count'] === 0
                    && $endErrors['error_count'] === 0
                )
            )
            && $endsAt->format(
                'Y-m-d\TH:i'
            ) === $formEndsAt;

        if (!$endValid) {
            $error =
                'Choose a valid event end date and time.';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | End cannot be before start
    |--------------------------------------------------------------------------
    */

    if (
        $error === null
        && $startsAt instanceof DateTimeImmutable
        && $endsAt instanceof DateTimeImmutable
        && $endsAt < $startsAt
    ) {
        $error =
            'The event end time cannot be before the start time.';
    }

    /*
    |--------------------------------------------------------------------------
    | Insert event
    |--------------------------------------------------------------------------
    */

    if (
        $error === null
        && $startsAt instanceof DateTimeImmutable
    ) {
        $statement = $connection->prepare(
            'INSERT INTO calendar_events
                (
                    workspace_id,
                    created_by,
                    title,
                    description,
                    starts_at,
                    ends_at
                )
             VALUES (?, ?, ?, ?, ?, ?)'
        );

        $statement->execute([
            $workspaceId,
            $user['id'],
            $formTitle,
            $formDescription !== ''
                ? $formDescription
                : null,
            $startsAt->format(
                'Y-m-d H:i:s'
            ),
            $endsAt instanceof DateTimeImmutable
                ? $endsAt->format(
                    'Y-m-d H:i:s'
                )
                : null,
        ]);

        $eventId = (int) $connection->lastInsertId();

        $recipientStatement = $connection->prepare(
            'SELECT wm.user_id
             FROM workspace_members wm
             INNER JOIN users u
                 ON u.id = wm.user_id
             WHERE wm.workspace_id = ?
               AND u.account_status = "active"'
        );

        $recipientStatement->execute([$workspaceId]);

        $recipientIds = array_map(
            static fn (array $row): int => (int) $row['user_id'],
            $recipientStatement->fetchAll()
        );

        create_notifications_for_users($recipientIds, [
            'workspace_id' => $workspaceId,
            'actor_user_id' => (int) $user['id'],
            'type' => 'calendar_event_created',
            'category' => 'calendar',
            'title' => (string) $user['display_name']
                . ' added a calendar event',
            'body' => $formTitle,
            'target_type' => 'calendar_event',
            'target_id' => $eventId,
            'target_url' => '/calendar.php?month=' . $startsAt->format('Y-m'),
        ]);

        header(
            'Location: /calendar.php?month='
            . $startsAt->format('Y-m')
        );

        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Workspace events
|--------------------------------------------------------------------------
|
| Calendar events are shared across the workspace.
|
*/

$eventsStatement = $connection->prepare(
    'SELECT
        ce.id,
        ce.title,
        ce.description,
        ce.starts_at,
        ce.ends_at,
        ce.created_by,

        creator.display_name AS creator_name,
        creator.avatar_path AS creator_avatar

     FROM calendar_events ce

     INNER JOIN users creator
         ON creator.id = ce.created_by

     INNER JOIN workspace_members creator_membership
         ON creator_membership.workspace_id = ce.workspace_id
        AND creator_membership.user_id = ce.created_by

     WHERE ce.workspace_id = ?
       AND ce.starts_at >= ?
       AND ce.starts_at < ?

     ORDER BY
        ce.starts_at ASC,
        ce.id ASC'
);

$eventsStatement->execute([
    $workspaceId,
    $monthStart->format(
        'Y-m-d 00:00:00'
    ),
    $monthEnd->format(
        'Y-m-d 00:00:00'
    ),
]);

$events = $eventsStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Task-list deadlines
|--------------------------------------------------------------------------
|
| Deadlines only appear when the current user belongs to that task list.
|
*/

$deadlinesStatement = $connection->prepare(
    'SELECT
        tl.id,
        tl.name,
        tl.deadline,
        tl.status,
        tl.team_id,

        team.name AS team_name

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     LEFT JOIN teams team
         ON team.id = tl.team_id
        AND team.workspace_id = tl.workspace_id

     WHERE tl.workspace_id = ?
       AND tl.deadline >= ?
       AND tl.deadline < ?

     ORDER BY
        tl.deadline ASC,
        tl.id ASC'
);

$deadlinesStatement->execute([
    $user['id'],
    $workspaceId,
    $monthStart->format('Y-m-d'),
    $monthEnd->format('Y-m-d'),
]);

$deadlines = $deadlinesStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Project milestones
|--------------------------------------------------------------------------
| Candidate rows are workspace/month scoped, then filtered through the
| canonical Project authorization policy before metadata reaches the UI.
*/
$milestonesStatement = $connection->prepare(
    'SELECT pm.id, pm.project_id, pm.title, pm.due_date, pm.status,
            p.name AS project_name
     FROM project_milestones pm
      INNER JOIN projects p
          ON p.id = pm.project_id
      WHERE p.workspace_id = ?
        AND pm.due_date >= ?
       AND pm.due_date < ?
     ORDER BY pm.due_date ASC, pm.position ASC, pm.id ASC'
);
$milestonesStatement->execute([
    $workspaceId,
    $monthStart->format('Y-m-d'),
    $monthEnd->format('Y-m-d'),
]);
$milestones = [];
foreach ($milestonesStatement->fetchAll() as $milestone) {
    $projectId = (int) ($milestone['project_id'] ?? 0);
    if ($projectId <= 0 || !project_user_can_view($access, (int) $user['id'], $projectId)) {
        continue;
    }
    $milestones[] = $milestone;
}

/*
|--------------------------------------------------------------------------
| Calendar items
|--------------------------------------------------------------------------
*/

$calendarItems = [];

foreach ($events as $event) {
    try {
        $startsAt =
            new DateTimeImmutable(
                $event['starts_at']
            );

        $day =
            (int) $startsAt->format('j');

        $calendarItems[$day][] = [
            'type' => 'event',
            'id' => (int) $event['id'],
            'title' => $event['title'],
            'description' =>
                $event['description'],
            'time' =>
                $startsAt->format('H:i'),
            'creator_name' =>
                $event['creator_name'],
            'creator_avatar' =>
                $event['creator_avatar'],
            'url' => null,
        ];
    } catch (Exception $exception) {
        continue;
    }
}

foreach ($milestones as $milestone) {
    try {
        $dueDate = new DateTimeImmutable((string) $milestone['due_date']);
        $day = (int) $dueDate->format('j');
        $calendarItems[$day][] = [
            'type' => 'milestone',
            'id' => (int) $milestone['id'],
            'title' => (string) $milestone['title'],
            'description' => null,
            'time' => 'Milestone',
            'project_name' => (string) $milestone['project_name'],
            'project_id' => (int) $milestone['project_id'],
            'status' => (string) $milestone['status'],
            'url' => '/projects/project.php?id=' . (int) $milestone['project_id'],
        ];
    } catch (Exception $exception) {
        continue;
    }
}

foreach ($deadlines as $deadline) {
    try {
        $deadlineTime =
            new DateTimeImmutable(
                $deadline['deadline']
            );

        $day =
            (int) $deadlineTime->format('j');

        $calendarItems[$day][] = [
            'type' => 'deadline',
            'id' => (int) $deadline['id'],
            'title' => $deadline['name'],
            'description' => null,
            'time' => 'Deadline',
            'team_name' =>
                $deadline['team_name'],
            'team_id' =>
                $deadline['team_id'],
            'status' =>
                $deadline['status'],
            'url' =>
                '/tasks/task-list.php?id='
                . (int) $deadline['id'],
        ];
    } catch (Exception $exception) {
        continue;
    }
}

/*
|--------------------------------------------------------------------------
| Sort each day
|--------------------------------------------------------------------------
*/

foreach ($calendarItems as &$items) {
    usort(
        $items,
        static function (
            array $first,
            array $second
        ): int {
            return strcmp(
                $first['time'],
                $second['time']
            );
        }
    );
}

unset($items);

/*
|--------------------------------------------------------------------------
| Calendar grid
|--------------------------------------------------------------------------
|
| ISO weekday:
|
| Monday = 1
| Sunday = 7
|
*/

$firstDayOffset =
    (int) $monthStart->format('N') - 1;

$daysInMonth =
    (int) $monthStart->format('t');

$totalCalendarCells =
    $firstDayOffset + $daysInMonth;

$trailingCells =
    (7 - ($totalCalendarCells % 7)) % 7;

/*
|--------------------------------------------------------------------------
| Month summary
|--------------------------------------------------------------------------
*/

$eventCount =
    count($events);

$deadlineCount =
    count($deadlines);

$milestoneCount =
    count($milestones);

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Calendar | Alliances</title>

</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main calendar-page">

    <!-- ================================================================
         PAGE HEADER
         ================================================================ -->

    <header class="page-header calendar-page-header">

        <div class="page-header-content">

            <span class="page-eyebrow">
                Workspace
            </span>

            <h1>
                Calendar
            </h1>

            <p class="page-description">
                See shared workspace events, Project milestones, and
                deadlines from your task lists.
            </p>

        </div>

        <div class="page-header-actions">

            <button
                type="button"
                class="primary-action"
                id="open-calendar-event"
                aria-expanded="<?= $error !== null
                    ? 'true'
                    : 'false' ?>"
                aria-controls="calendar-event-panel"
            >
                <span aria-hidden="true">
                    +
                </span>

                Add event
            </button>

        </div>

    </header>

    <!-- ================================================================
         CREATE EVENT
         ================================================================ -->

    <section
        class="calendar-create-panel <?= $error !== null
            ? 'is-open'
            : '' ?>"
        id="calendar-event-panel"
        <?= $error === null
            ? 'hidden'
            : '' ?>
    >

        <div class="task-create-header">

            <div>

                <h2>
                    Add calendar event
                </h2>

                <p>
                    Events are visible to everyone in this workspace.
                </p>

            </div>

            <button
                type="button"
                class="icon-button"
                id="close-calendar-event"
                aria-label="Close"
            >
                ×
            </button>

        </div>

        <?php if ($error !== null): ?>

            <div
                class="form-message form-message-error"
                role="alert"
            >
                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </div>

        <?php endif; ?>

        <form
            method="post"
            class="calendar-create-form"
        >

            <?= csrf_input() ?>

            <div class="calendar-create-main">

                <label class="form-field">

                    <span class="form-label">
                        Event title
                    </span>

                    <input
                        type="text"
                        name="title"
                        required
                        maxlength="200"
                        placeholder="e.g. Weekly planning meeting"
                        value="<?= htmlspecialchars(
                            $formTitle,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >

                </label>

                <label class="form-field">

                    <span class="form-label">
                        Description
                    </span>

                    <span class="form-hint">
                        Optional
                    </span>

                    <textarea
                        name="description"
                        rows="3"
                        placeholder="Add details about the event..."
                    ><?= htmlspecialchars(
                        $formDescription,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?></textarea>

                </label>

            </div>

            <div class="calendar-create-times">

                <label class="form-field">

                    <span class="form-label">
                        Starts
                    </span>

                    <input
                        type="datetime-local"
                        name="starts_at"
                        required
                        value="<?= htmlspecialchars(
                            $formStartsAt,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >

                </label>

                <label class="form-field">

                    <span class="form-label">
                        Ends
                    </span>

                    <span class="form-hint">
                        Optional
                    </span>

                    <input
                        type="datetime-local"
                        name="ends_at"
                        value="<?= htmlspecialchars(
                            $formEndsAt,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >

                </label>

            </div>

            <div class="task-create-actions">

                <button
                    type="button"
                    class="secondary-action"
                    id="cancel-calendar-event"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="primary-action"
                >
                    Add event
                </button>

            </div>

        </form>

    </section>

    <!-- ================================================================
         CALENDAR TOOLBAR
         ================================================================ -->

    <section class="calendar-workspace">

        <div class="calendar-toolbar">

            <div class="calendar-month-navigation">

                <a
                    class="calendar-nav-button"
                    href="/calendar.php?month=<?= htmlspecialchars(
                        $previousMonth,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                    aria-label="Previous month"
                >
                    ←
                </a>

                <div class="calendar-current-month">

                    <h2>
                        <?= htmlspecialchars(
                            $month->format('F Y'),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </h2>

                    <span>
                        <?= $eventCount ?>
                        <?= $eventCount === 1
                            ? 'event'
                            : 'events' ?>

                        <span aria-hidden="true">
                            ·
                        </span>

                        <?= $deadlineCount ?>
                        <?= $deadlineCount === 1
                            ? 'deadline'
                            : 'deadlines' ?>

                        <span aria-hidden="true">·</span>

                        <?= $milestoneCount ?>
                        <?= $milestoneCount === 1
                            ? 'milestone'
                            : 'milestones' ?>
                    </span>

                </div>

                <a
                    class="calendar-nav-button"
                    href="/calendar.php?month=<?= htmlspecialchars(
                        $nextMonth,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                    aria-label="Next month"
                >
                    →
                </a>

            </div>

            <?php if (
                $month->format('Y-m')
                !== $currentMonth
            ): ?>

                <a
                    href="/calendar.php?month=<?= htmlspecialchars(
                        $currentMonth,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                    class="secondary-action calendar-today-button"
                >
                    Today
                </a>

            <?php endif; ?>

        </div>

        <!-- ============================================================
             LEGEND
             ============================================================ -->

        <div class="calendar-legend">

            <span class="calendar-legend-item">

                <span
                    class="calendar-legend-dot event"
                    aria-hidden="true"
                ></span>

                Workspace event

            </span>

            <span class="calendar-legend-item">

                <span
                    class="calendar-legend-dot deadline"
                    aria-hidden="true"
                ></span>

                Task list deadline

            </span>

            <span class="calendar-legend-item">
                <span class="calendar-legend-dot milestone" aria-hidden="true"></span>
                Project milestone
            </span>

        </div>

        <!-- ============================================================
             CALENDAR
             ============================================================ -->

        <div class="calendar-panel">

            <div class="calendar-grid calendar-weekdays">

                <div>Mon</div>
                <div>Tue</div>
                <div>Wed</div>
                <div>Thu</div>
                <div>Fri</div>
                <div>Sat</div>
                <div>Sun</div>

            </div>

            <div class="calendar-grid calendar-days">

                <!-- EMPTY CELLS BEFORE MONTH -->

                <?php for (
                    $i = 0;
                    $i < $firstDayOffset;
                    $i++
                ): ?>

                    <div
                        class="calendar-day calendar-empty"
                        aria-hidden="true"
                    ></div>

                <?php endfor; ?>

                <!-- DAYS -->

                <?php for (
                    $day = 1;
                    $day <= $daysInMonth;
                    $day++
                ): ?>

                    <?php
                    $dateString =
                        $monthStart
                            ->setDate(
                                (int) $monthStart->format('Y'),
                                (int) $monthStart->format('m'),
                                $day
                            )
                            ->format('Y-m-d');

                    $isToday =
                        $dateString === $today;

                    $dayItems =
                        $calendarItems[$day] ?? [];
                    ?>

                    <div
                        class="calendar-day <?= $isToday
                            ? 'is-today'
                            : '' ?>"
                    >

                        <div class="calendar-day-header">

                            <span
                                class="calendar-day-number"
                                <?= $isToday
                                    ? 'aria-current="date"'
                                    : '' ?>
                            >
                                <?= $day ?>
                            </span>

                            <?php if ($dayItems !== []): ?>

                                <span class="calendar-day-count">
                                    <?= count($dayItems) ?>
                                </span>

                            <?php endif; ?>

                        </div>

                        <div class="calendar-day-items">

                            <?php foreach (
                                $dayItems as $item
                            ): ?>

                                <?php if (
                                    $item['type']
                                    === 'deadline'
                                ): ?>

                                    <div
                                        class="calendar-item deadline"
                                        title="<?= htmlspecialchars(
                                            $item['title'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                    >

                                        <span class="calendar-item-time">
                                            <?= htmlspecialchars(
                                                $item['time'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </span>

                                        <a
                                            href="<?= htmlspecialchars(
                                                $item['url'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>"
                                            class="calendar-item-title calendar-task-link"
                                        >
                                            <?= htmlspecialchars(
                                                $item['title'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </a>

                                        <?php if (!empty($item['team_name'])): ?>
                                            <span class="calendar-item-team">
                                                <?= alliances_team_link(
                                                    (int) ($item['team_id'] ?? 0),
                                                    (string) $item['team_name'],
                                                    'team-link calendar-team-link'
                                                ) ?>
                                            </span>
                                        <?php endif; ?>

                                    </div>

                                <?php elseif ($item['type'] === 'milestone'): ?>

                                    <div
                                        class="calendar-item milestone"
                                        title="<?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?>"
                                    >
                                        <span class="calendar-item-time">
                                            <?= htmlspecialchars($item['time'], ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                        <a
                                            href="<?= htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8') ?>"
                                            class="calendar-item-title"
                                        >
                                            <?= htmlspecialchars($item['title'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                        <span class="calendar-item-team">
                                            <?= htmlspecialchars($item['project_name'], ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                    </div>

                                <?php else: ?>

                                    <div
                                        class="calendar-item event"
                                        title="<?= htmlspecialchars(
                                            $item['title'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                    >

                                        <span class="calendar-item-time">
                                            <?= htmlspecialchars(
                                                $item['time'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </span>

                                        <span class="calendar-item-title">
                                            <?= htmlspecialchars(
                                                $item['title'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </span>

                                    </div>

                                <?php endif; ?>

                            <?php endforeach; ?>

                        </div>

                    </div>

                <?php endfor; ?>

                <!-- EMPTY CELLS AFTER MONTH -->

                <?php for (
                    $i = 0;
                    $i < $trailingCells;
                    $i++
                ): ?>

                    <div
                        class="calendar-day calendar-empty"
                        aria-hidden="true"
                    ></div>

                <?php endfor; ?>

            </div>

        </div>

    </section>

</main>

<script>
    const calendarEventPanel =
        document.getElementById(
            'calendar-event-panel'
        );

    const openCalendarEvent =
        document.getElementById(
            'open-calendar-event'
        );

    const closeCalendarEvent =
        document.getElementById(
            'close-calendar-event'
        );

    const cancelCalendarEvent =
        document.getElementById(
            'cancel-calendar-event'
        );

    function showCalendarEventPanel() {
        if (!calendarEventPanel) {
            return;
        }

        calendarEventPanel.hidden = false;

        calendarEventPanel.classList.add(
            'is-open'
        );

        if (openCalendarEvent) {
            openCalendarEvent.setAttribute(
                'aria-expanded',
                'true'
            );
        }

        const titleInput =
            calendarEventPanel.querySelector(
                'input[name="title"]'
            );

        if (titleInput) {
            window.setTimeout(() => {
                titleInput.focus();
            }, 50);
        }
    }

    function hideCalendarEventPanel() {
        if (!calendarEventPanel) {
            return;
        }

        calendarEventPanel.classList.remove(
            'is-open'
        );

        calendarEventPanel.hidden = true;

        if (openCalendarEvent) {
            openCalendarEvent.setAttribute(
                'aria-expanded',
                'false'
            );
        }
    }

    if (openCalendarEvent) {
        openCalendarEvent.addEventListener(
            'click',
            showCalendarEventPanel
        );
    }

    if (closeCalendarEvent) {
        closeCalendarEvent.addEventListener(
            'click',
            hideCalendarEventPanel
        );
    }

    if (cancelCalendarEvent) {
        cancelCalendarEvent.addEventListener(
            'click',
            hideCalendarEventPanel
        );
    }
</script>

</body>
</html>
