"use strict";

import * as openpgp from "/assets/vendor/openpgp/openpgp.min.mjs";


/*
 * ==========================================================================
 * Alliances Drive — Client-side cryptography
 * ==========================================================================
 *
 * File contents are encrypted in the browser.
 *
 * The server must never receive:
 *
 * - plaintext file contents
 * - raw AES file keys
 * - OpenPGP private keys
 * - Key Vault passwords
 *
 * Encryption:
 *
 * File
 *   ↓
 * random AES-256 key
 *   ↓
 * AES-GCM
 *   ↓
 * encrypted file
 *
 * AES key
 *   ↓
 * OpenPGP public key of each authorized user
 *   ↓
 * encrypted key envelope for each user
 */


/*
 * --------------------------------------------------------------------------
 * Constants
 * --------------------------------------------------------------------------
 */

const FILE_FORMAT_MAGIC = "ALLIANCES-DRIVE";
const FILE_FORMAT_VERSION = 1;

const AES_KEY_BITS = 256;
const AES_GCM_IV_BYTES = 12;


/*
 * --------------------------------------------------------------------------
 * Utilities
 * --------------------------------------------------------------------------
 */

function randomBytes(length) {
    const bytes = new Uint8Array(length);

    crypto.getRandomValues(bytes);

    return bytes;
}


function uint32ToBytes(value) {
    const bytes = new Uint8Array(4);

    const view = new DataView(bytes.buffer);

    view.setUint32(0, value, false);

    return bytes;
}


function bytesToUint32(bytes) {
    if (!(bytes instanceof Uint8Array) || bytes.length !== 4) {
        throw new Error("Invalid 32-bit integer.");
    }

    const view = new DataView(
        bytes.buffer,
        bytes.byteOffset,
        bytes.byteLength
    );

    return view.getUint32(0, false);
}


function concatBytes(...arrays) {
    const totalLength = arrays.reduce(
        (total, array) => total + array.length,
        0
    );

    const result = new Uint8Array(totalLength);

    let offset = 0;

    for (const array of arrays) {
        result.set(array, offset);
        offset += array.length;
    }

    return result;
}


function bytesToBase64(bytes) {
    let binary = "";

    const chunkSize = 0x8000;

    for (
        let offset = 0;
        offset < bytes.length;
        offset += chunkSize
    ) {
        const chunk = bytes.subarray(
            offset,
            Math.min(offset + chunkSize, bytes.length)
        );

        binary += String.fromCharCode(...chunk);
    }

    return btoa(binary);
}


function base64ToBytes(value) {
    const binary = atob(value);

    const bytes = new Uint8Array(binary.length);

    for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
    }

    return bytes;
}


/*
 * --------------------------------------------------------------------------
 * Generate AES-256 file key
 * --------------------------------------------------------------------------
 */

export function generateFileKey() {
    return randomBytes(AES_KEY_BITS / 8);
}


/*
 * --------------------------------------------------------------------------
 * Encrypt file
 * --------------------------------------------------------------------------
 *
 * We create a self-contained encrypted blob:
 *
 * [4 bytes header length]
 * [JSON header]
 * [AES-GCM ciphertext + authentication tag]
 *
 * Header example:
 *
 * {
 *   "format": "ALLIANCES-DRIVE",
 *   "version": 1,
 *   "algorithm": "AES-GCM",
 *   "iv": "base64..."
 * }
 *
 * The IV is NOT secret.
 *
 * Keeping it with the encrypted blob means PHP/SQLite doesn't need to
 * understand the cryptographic format.
 */

export async function encryptFile(file, fileKeyBytes) {
    if (!(file instanceof File)) {
        throw new Error("A valid file is required.");
    }

    if (
        !(fileKeyBytes instanceof Uint8Array) ||
        fileKeyBytes.length !== 32
    ) {
        throw new Error("A valid AES-256 file key is required.");
    }


    const iv = randomBytes(AES_GCM_IV_BYTES);


    const cryptoKey = await crypto.subtle.importKey(
        "raw",
        fileKeyBytes,
        {
            name: "AES-GCM",
        },
        false,
        [
            "encrypt",
        ]
    );


    /*
     * Plaintext exists only in browser memory.
     *
     * For the first Drive version we're using the browser's normal
     * ArrayBuffer encryption API.
     *
     * Later, large-file support can move to chunked encryption/upload
     * without changing the server's trust model.
     */
const plaintext =
    await file.arrayBuffer();


// Empty files are valid, including a newly created TXT document.


const encryptedBuffer =
    await crypto.subtle.encrypt(
        {
            name: "AES-GCM",
            iv,
            tagLength: 128,
        },
        cryptoKey,
        plaintext
    );


    const header = {
        format: FILE_FORMAT_MAGIC,
        version: FILE_FORMAT_VERSION,
        algorithm: "AES-GCM",
        iv: bytesToBase64(iv),
    };


    const headerBytes = new TextEncoder().encode(
        JSON.stringify(header)
    );


    const headerLengthBytes =
        uint32ToBytes(headerBytes.length);


    const encryptedBytes = new Uint8Array(
        encryptedBuffer
    );


    const blobBytes = concatBytes(
        headerLengthBytes,
        headerBytes,
        encryptedBytes
    );


    return new Blob(
        [
            blobBytes,
        ],
        {
            type: "application/octet-stream",
        }
    );
}


/*
 * --------------------------------------------------------------------------
 * Read encrypted Drive blob
 * --------------------------------------------------------------------------
 */

export async function parseEncryptedFile(blob) {
    if (!(blob instanceof Blob)) {
        throw new Error("Invalid encrypted file.");
    }


    const buffer = await blob.arrayBuffer();

    const bytes = new Uint8Array(buffer);


    if (bytes.length < 5) {
        throw new Error("Encrypted file is invalid.");
    }


    const headerLength = bytesToUint32(
        bytes.subarray(0, 4)
    );


    if (
        headerLength <= 0 ||
        headerLength > 65536 ||
        4 + headerLength >= bytes.length
    ) {
        throw new Error("Encrypted file header is invalid.");
    }


    const headerBytes = bytes.subarray(
        4,
        4 + headerLength
    );


    let header;

    try {
        header = JSON.parse(
            new TextDecoder().decode(headerBytes)
        );
    } catch {
        throw new Error("Encrypted file header is invalid.");
    }


    if (
        header?.format !== FILE_FORMAT_MAGIC ||
        header?.version !== FILE_FORMAT_VERSION ||
        header?.algorithm !== "AES-GCM" ||
        typeof header?.iv !== "string"
    ) {
        throw new Error(
            "Unsupported encrypted Drive file."
        );
    }


    const iv = base64ToBytes(header.iv);


    if (iv.length !== AES_GCM_IV_BYTES) {
        throw new Error(
            "Encrypted file IV is invalid."
        );
    }


    const ciphertext = bytes.slice(
        4 + headerLength
    );


    return {
        header,
        iv,
        ciphertext,
    };
}


/*
 * --------------------------------------------------------------------------
 * Decrypt file
 * --------------------------------------------------------------------------
 *
 * We'll use this when Download/Open is implemented.
 */

export async function decryptFile(
    encryptedBlob,
    fileKeyBytes
) {
    if (
        !(fileKeyBytes instanceof Uint8Array) ||
        fileKeyBytes.length !== 32
    ) {
        throw new Error(
            "A valid AES-256 file key is required."
        );
    }


    const {
        iv,
        ciphertext,
    } = await parseEncryptedFile(
        encryptedBlob
    );


    const cryptoKey = await crypto.subtle.importKey(
        "raw",
        fileKeyBytes,
        {
            name: "AES-GCM",
        },
        false,
        [
            "decrypt",
        ]
    );


    try {
        return await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv,
                tagLength: 128,
            },
            cryptoKey,
            ciphertext
        );
    } catch {
        throw new Error(
            "Unable to decrypt file. The file may be damaged or the key is incorrect."
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * OpenPGP-wrap a file key
 * --------------------------------------------------------------------------
 *
 * The raw 32-byte AES key is converted to base64 and encrypted to one
 * recipient's OpenPGP public key.
 *
 * The returned armored PGP message is safe to store on the server.
 */

export async function wrapFileKeyForUser(
    fileKeyBytes,
    armoredPublicKey
) {
    if (
        !(fileKeyBytes instanceof Uint8Array) ||
        fileKeyBytes.length !== 32
    ) {
        throw new Error(
            "A valid AES-256 file key is required."
        );
    }


    if (
        typeof armoredPublicKey !== "string" ||
        !armoredPublicKey.includes(
            "-----BEGIN PGP PUBLIC KEY BLOCK-----"
        )
    ) {
        throw new Error(
            "A valid OpenPGP public key is required."
        );
    }


    const publicKey = await openpgp.readKey({
        armoredKey: armoredPublicKey,
    });


    const message = await openpgp.createMessage({
        text: bytesToBase64(fileKeyBytes),
    });


    return await openpgp.encrypt({
        message,
        encryptionKeys: publicKey,
        format: "armored",
    });
}


/*
 * --------------------------------------------------------------------------
 * Unwrap a file key
 * --------------------------------------------------------------------------
 *
 * We'll use this when opening/downloading encrypted files.
 *
 * privateKey must already have been obtained from the locally unlocked
 * Key Vault.
 */

export async function unwrapFileKey(
    armoredEncryptedKey,
    privateKey
) {
    if (
        typeof armoredEncryptedKey !== "string" ||
        !armoredEncryptedKey.includes(
            "-----BEGIN PGP MESSAGE-----"
        )
    ) {
        throw new Error(
            "Invalid encrypted file key."
        );
    }


    if (!privateKey) {
        throw new Error(
            "Your Key Vault must be unlocked."
        );
    }


    const message = await openpgp.readMessage({
        armoredMessage: armoredEncryptedKey,
    });


    const result = await openpgp.decrypt({
        message,
        decryptionKeys: privateKey,
        format: "utf8",
    });


    const fileKeyBytes = base64ToBytes(
        String(result.data).trim()
    );


    if (fileKeyBytes.length !== 32) {
        throw new Error(
            "Decrypted file key is invalid."
        );
    }


    return fileKeyBytes;
}


/*
 * --------------------------------------------------------------------------
 * Best-effort key cleanup
 * --------------------------------------------------------------------------
 *
 * JavaScript cannot guarantee that every internal/runtime copy of a
 * secret is erased, but callers should overwrite the Uint8Array once
 * they're finished with the raw file key.
 */

export function clearFileKey(fileKeyBytes) {
    if (fileKeyBytes instanceof Uint8Array) {
        fileKeyBytes.fill(0);
    }
}