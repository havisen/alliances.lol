"use strict";
import { openDocxPackage, readSurface, DOCX_MIME } from "./drive-docx-engine.js";

function el(tag, className = "", text = "") {
    const node = document.createElement(tag);
    node.className = className;
    node.textContent = text;
    return node;
}

export async function mountDocxEditor({container, fileName, blob, canEdit, onDirtyChange, onStatus, onRequestSave}) {
    const model = await openDocxPackage(blob);
    let destroyed = false;
    let savedState;
    let dirty = false;
    let selection = null;
    let zoom = 1;
    let history = [];
    let historyIndex = 0;
    let beforeEdit = null;
    let lastInputType = null;
    let lastEditTime = 0;
    let composing = false;
    const exports = new WeakMap();
    const root = el("div", "drive-docx-editor");
    const toolbar = el("div", "drive-docx-toolbar");
    toolbar.setAttribute("role", "toolbar");
    toolbar.setAttribute("aria-label", "Document tools");
    const row = el("div", "drive-docx-toolbar-row");
    const tools = el("div", "drive-docx-toolbar-row");
    row.classList.add("drive-docx-toolbar-primary");
    tools.classList.add("drive-docx-toolbar-secondary");
    const historyGroup = el("div", "drive-docx-toolbar-group");
    historyGroup.setAttribute("aria-label", "History");
    const formatGroup = el("div", "drive-docx-toolbar-group");
    formatGroup.setAttribute("aria-label", "Text formatting");
    const fontGroup = el("div", "drive-docx-toolbar-group drive-docx-font-group");
    fontGroup.setAttribute("aria-label", "Font size");
    const alignGroup = el("div", "drive-docx-toolbar-group");
    alignGroup.setAttribute("aria-label", "Paragraph alignment");
    const findGroup = el("div", "drive-docx-toolbar-group drive-docx-find-group");
    findGroup.setAttribute("aria-label", "Find in document");
    const zoomGroup = el("div", "drive-docx-toolbar-group drive-docx-zoom-group");
    zoomGroup.setAttribute("aria-label", "Zoom");
    const metaGroup = el("div", "drive-docx-toolbar-group drive-docx-meta-group");
    metaGroup.setAttribute("aria-label", "Document status");
    const status = el("span", "drive-docx-editor-status");
    const stats = el("span", "drive-docx-count");
    const page = el("div", "drive-editor-document-surface drive-docx-page drive-docx-document-flow");
    page.contentEditable = String(Boolean(canEdit));
    page.setAttribute("role", "textbox");
    page.setAttribute("aria-label", "Document text");
    page.setAttribute("aria-multiline", "true");
    page.setAttribute("aria-readonly", String(!canEdit));
    page.spellcheck = true;
    const workspace = el("div", "drive-docx-workspace");
    workspace.append(page);
    toolbar.append(row, tools);
    root.append(toolbar, workspace);
    container.replaceChildren(root);
    model.render(page);
    const snapshot = () => JSON.stringify(readSurface(page));
    savedState = snapshot();

    function capture() {
        const sel = window.getSelection();
        function point(node, offset) {
            if (!node || !page.contains(node)) return null;
            const path = [];
            while (node !== page) { path.unshift(Array.prototype.indexOf.call(node.parentNode.childNodes, node)); node = node.parentNode; }
            return {path, offset};
        }
        return {html: page.innerHTML, anchor: point(sel.anchorNode, sel.anchorOffset), focus: point(sel.focusNode, sel.focusOffset)};
    }
    function record(previous, inputType = null) {
        const next = capture();
        if (history[historyIndex]?.html === next.html) return;
        const groupTyping = inputType === "insertText" && lastInputType === inputType &&
            Date.now() - lastEditTime < 1000 && historyIndex > 0 &&
            previous?.html === history[historyIndex].html &&
            JSON.stringify(previous.anchor) === JSON.stringify(previous.focus) &&
            JSON.stringify(previous.anchor) === JSON.stringify(history[historyIndex].anchor);
        lastInputType = inputType; lastEditTime = Date.now();
        if (groupTyping) { history[historyIndex] = next; return; }
        if (previous) history[historyIndex] = previous;
        history = history.slice(0, historyIndex + 1);
        history.push(next); historyIndex++;
        if (history.length > 150) { history.shift(); historyIndex--; }
    }
    function restore(index) {
        if (!canEdit || index < 0 || index >= history.length) return;
        historyIndex = index;
        lastInputType = null;
        const state = history[index];
        page.innerHTML = state.html;
        page.focus();
        function point(saved) { return saved?.path.reduce((node, i) => node?.childNodes[i], page); }
        const anchor = point(state.anchor), focus = point(state.focus);
        if (anchor && focus) window.getSelection().setBaseAndExtent(anchor, state.anchor.offset, focus, state.focus.offset);
        rememberSelection(); update();
    }
    history = [capture()];

    function update() {
        if (destroyed) return;
        dirty = snapshot() !== savedState;
        status.textContent = canEdit ? (dirty ? "Unsaved changes" : "Saved") : "View only";
        status.classList.toggle("is-dirty", dirty);
        const text = readSurface(page).map(b => b.runs?.map(r => r.text).join("") || "").join("\n");
        stats.textContent = `${text.trim() ? text.trim().split(/\s+/).length : 0} words · ${text.length} characters`;
        onDirtyChange?.(dirty);
    }
    function rememberSelection() {
        const sel = window.getSelection();
        if (sel.rangeCount && page.contains(sel.anchorNode) && page.contains(sel.focusNode)) selection = sel.getRangeAt(0).cloneRange();
    }
    function restoreSelection() {
        page.focus();
        if (selection && page.contains(selection.startContainer) && page.contains(selection.endContainer)) {
            const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(selection);
        }
    }
    function command(name, value = null) {
        if (!canEdit || destroyed) return;
        restoreSelection();
        const previous = capture();
        if (name.startsWith("justify")) {
            const align = {justifyLeft: "left", justifyCenter: "center", justifyRight: "right", justifyFull: "justify"}[name];
            const sel = window.getSelection();
            const range = sel.rangeCount ? sel.getRangeAt(0) : null;
            // Native justify commands split soft breaks into paragraphs in Chrome.
            // Apply alignment to the existing blocks without changing their text.
            if (range) for (const block of page.querySelectorAll("p, div:not([data-protected])")) {
                if (!block.closest("[data-protected]") && range.intersectsNode(block)) block.style.textAlign = align;
            }
        } else document.execCommand(name, false, value);
        record(previous);
        rememberSelection(); update();
    }
    function button(parent, label, action, editing = true, title = label) {
        const b = el("button", "drive-docx-tool-button", label);
        b.type = "button";
        b.title = title;
        b.setAttribute("aria-label", title);
        b.disabled = editing && !canEdit;
        b.addEventListener("mousedown", e => e.preventDefault());
        b.addEventListener("click", action);
        parent.append(b);
        return b;
    }
    button(historyGroup, "↶", () => restore(historyIndex - 1), true, "Undo");
    button(historyGroup, "↷", () => restore(historyIndex + 1), true, "Redo");
    button(formatGroup, "B", () => command("bold"), true, "Bold").classList.add("drive-docx-bold-button");
    button(formatGroup, "I", () => command("italic"), true, "Italic").classList.add("drive-docx-italic-button");
    button(formatGroup, "U", () => command("underline"), true, "Underline").classList.add("drive-docx-underline-button");
    // Browser font sizes map to Word point sizes during OOXML serialization.
    const size = el("select", "drive-docx-tool-button");
    size.setAttribute("aria-label", "Font size");
    [["", "Font size"], ["1", "8 pt"], ["2", "10 pt"], ["3", "12 pt"], ["4", "14 pt"], ["5", "18 pt"], ["6", "24 pt"], ["7", "36 pt"]].forEach(([v, label]) => {
        const option = el("option", "", label); option.value = v; size.append(option);
    });
    size.disabled = !canEdit;
    size.addEventListener("change", () => { if (size.value) command("fontSize", size.value); size.value = ""; });
    fontGroup.append(size);
    for (const [label, display, cmd] of [["Align left", "Left", "justifyLeft"], ["Center", "Center", "justifyCenter"], ["Align right", "Right", "justifyRight"], ["Justify", "Justify", "justifyFull"]]) {
        button(alignGroup, display, () => command(cmd), true, label);
    }
    row.append(historyGroup, formatGroup, fontGroup, alignGroup);
    const find = el("input", "drive-docx-find-input");
    find.type = "search";
    find.placeholder = "Find in document";
    find.setAttribute("aria-label", "Find in document");
    const found = el("span", "drive-docx-search-status");
    let matchIndex = -1;
    function search(direction = 1) {
        const query = find.value.toLocaleLowerCase();
        const walker = document.createTreeWalker(page, NodeFilter.SHOW_TEXT);
        const nodes = []; let text = ""; let node;
        while ((node = walker.nextNode())) {
            if (node.parentElement.closest("[data-protected]")) continue;
            nodes.push({node, start: text.length}); text += node.textContent;
        }
        const matches = [];
        if (query) {
            for (let i = text.toLocaleLowerCase().indexOf(query); i >= 0; i = text.toLocaleLowerCase().indexOf(query, i + Math.max(1, query.length))) matches.push(i);
        }
        if (!matches.length) { found.textContent = query ? "No matches" : ""; return; }
        matchIndex = (matchIndex + direction + matches.length) % matches.length;
        const start = matches[matchIndex], end = start + query.length;
        const first = nodes.find(n => n.start + n.node.length > start);
        const last = nodes.find(n => n.start + n.node.length >= end);
        const range = document.createRange();
        range.setStart(first.node, start - first.start); range.setEnd(last.node, end - last.start);
        const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
        selection = range.cloneRange();
        first.node.parentElement.scrollIntoView({block: "nearest"});
        found.textContent = `${matchIndex + 1} of ${matches.length}`;
    }
    findGroup.append(find);
    button(findGroup, "Prev", () => search(-1), false, "Previous match");
    button(findGroup, "Next", () => search(1), false, "Next match");
    findGroup.append(found);
    tools.append(findGroup);
    find.addEventListener("input", () => { matchIndex = -1; });
    find.addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); search(e.shiftKey ? -1 : 1); } });
    const zoomLabel = el("span", "drive-docx-zoom", "100%");
    function changeZoom(delta) {
        zoom = Math.max(0.5, Math.min(1.5, Math.round((zoom + delta) * 10) / 10));
        page.style.setProperty("--drive-docx-zoom", zoom);
        zoomLabel.textContent = `${Math.round(zoom * 100)}%`;
    }
    button(zoomGroup, "−", () => changeZoom(-0.1), false, "Zoom out");
    zoomGroup.append(zoomLabel);
    button(zoomGroup, "+", () => changeZoom(0.1), false, "Zoom in");
    metaGroup.append(stats, status);
    tools.append(zoomGroup, metaGroup);
    page.addEventListener("beforeinput", e => {
        if (e.inputType === "historyUndo" || e.inputType === "historyRedo") {
            e.preventDefault(); restore(historyIndex + (e.inputType === "historyUndo" ? -1 : 1)); return;
        }
        if (!composing) beforeEdit = capture();
    });
    page.addEventListener("input", e => {
        if (!e.isComposing && !composing) { record(beforeEdit, e.inputType); beforeEdit = null; }
        update();
    });
    page.addEventListener("compositionstart", () => { beforeEdit = capture(); composing = true; });
    page.addEventListener("compositionend", () => { composing = false; record(beforeEdit); beforeEdit = null; update(); });
    page.addEventListener("paste", e => {
        e.preventDefault();
        if (canEdit) document.execCommand("insertText", false, e.clipboardData?.getData("text/plain") || "");
    });
    // Keep dropped HTML and remote images out of a locally decrypted document.
    page.addEventListener("drop", e => e.preventDefault());
    root.addEventListener("keydown", e => {
        if (!(e.ctrlKey || e.metaKey)) return;
        if (e.key.toLowerCase() === "s") { e.preventDefault(); if (canEdit) onRequestSave?.(); }
        if (e.key.toLowerCase() === "f") { e.preventDefault(); find.focus(); find.select(); }
        if (page.contains(e.target) && e.key.toLowerCase() === "z") { e.preventDefault(); restore(historyIndex + (e.shiftKey ? 1 : -1)); }
        if (page.contains(e.target) && e.key.toLowerCase() === "y") { e.preventDefault(); restore(historyIndex + 1); }
    });
    page.addEventListener("focus", () => {
        if (canEdit) document.execCommand("defaultParagraphSeparator", false, "p");
    });
    document.addEventListener("selectionchange", rememberSelection);
    update();
    onStatus?.(canEdit ? "DOCX ready. Tables and embedded content are preserved as view-only items." : "DOCX opened in view-only mode.");
    return {
        type: "docx", fileName, mimeType: DOCX_MIME,
        get canEdit() { return Boolean(canEdit); },
        get isDirty() { return dirty; },
        async getSaveBlob() {
            if (destroyed) throw new Error("The editor has been closed.");
            if (!canEdit) throw new Error("This document is view only.");
            const state = readSurface(page);
            const output = await model.generateBlob(state);
            exports.set(output, JSON.stringify(state));
            return output;
        },
        markSaved(output) {
            if (!exports.has(output)) return;
            // Only acknowledge the exported snapshot, never edits made during upload.
            savedState = exports.get(output); update();
        },
        destroy() {
            destroyed = true;
            document.removeEventListener("selectionchange", rememberSelection);
            model.destroy(); container.replaceChildren();
        },
    };
}
