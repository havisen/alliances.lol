"use strict";
const W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
export const DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
let zipPromise;
async function loadJsZip() {
    if (window.JSZip) return window.JSZip;
    if (!zipPromise) zipPromise = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "/assets/vendor/jszip/jszip.min.js";
        script.onload = () => window.JSZip ? resolve(window.JSZip) : reject(new Error("DOCX ZIP engine unavailable."));
        script.onerror = () => { zipPromise = null; script.remove(); reject(new Error("Unable to load the local DOCX ZIP engine.")); };
        document.head.append(script);
    });
    return zipPromise;
}
const children = (node, name) => Array.from(node.children).filter(n => n.namespaceURI === W && n.localName === name);
const prop = (node, name) => node && children(node, name)[0];
const value = node => node?.getAttributeNS(W, "val");
const on = node => Boolean(node) && !["0", "false", "off"].includes(value(node));
const word = (doc, name) => doc.createElementNS(W, `w:${name}`);
const xml = node => new XMLSerializer().serializeToString(node);
function parse(text) {
    const doc = new DOMParser().parseFromString(text, "application/xml");
    if (doc.querySelector("parsererror")) throw new Error("Invalid DOCX XML.");
    return doc;
}
function simple(p) {
    return p.localName === "p" && p.namespaceURI === W && !p.getElementsByTagNameNS(W, "sectPr").length &&
        Array.from(p.children).every(n => n.namespaceURI === W && (n.localName === "pPr" ||
            (n.localName === "r" && Array.from(n.children).every(c => c.namespaceURI === W && ["rPr", "t", "br", "cr", "tab"].includes(c.localName)) &&
                !Array.from(n.children).some(c => c.localName === "br" && c.getAttributeNS(W, "type") && c.getAttributeNS(W, "type") !== "textWrapping"))));
}
function setProperty(doc, props, name, val) {
    children(props, name).forEach(n => n.remove());
    const node = word(doc, name);
    node.setAttributeNS(W, "w:val", String(val));
    props.append(node);
}

// Patch a clone of the original XML; retain other package entries and untouched blocks.
export async function openDocxPackage(blob) {
    const JSZip = await loadJsZip();
    const bytes = await blob.arrayBuffer();
    const zip = await JSZip.loadAsync(bytes);
    const entry = zip.file("word/document.xml");
    if (!entry) throw new Error("This file has no Word document body.");
    const source = parse(await entry.async("string"));
    const body = source.getElementsByTagNameNS(W, "body")[0];
    if (!body) throw new Error("This file has no Word document body.");
    const blocks = Array.from(body.children).filter(n => n.localName !== "sectPr");
    const runSources = new Map();
    const initial = new Map();
    const initialRuns = new Map();
    let destroyed = false;
    let initialSnapshot;
    const protectedIds = blocks.flatMap((n, i) => simple(n) ? [] : [String(i)]);

    function render(surface) {
        surface.replaceChildren();
        blocks.forEach((block, index) => {
            const p = document.createElement(simple(block) ? "p" : "div");
            p.dataset.source = String(index);
            if (!simple(block)) {
                p.dataset.protected = String(index);
                p.contentEditable = "false";
                p.className = "drive-docx-protected";
                const preview = Array.from(block.getElementsByTagNameNS(W, "t")).map(n => n.textContent).join(" ");
                p.textContent = `${block.localName === "tbl" ? "Table" : "Embedded content"} (preserved, view only)${preview ? ": " + preview : ""}`;
            } else {
                p.className = "drive-docx-paragraph";
                const alignment = value(prop(prop(block, "pPr"), "jc"));
                if (["left", "center", "right", "both"].includes(alignment)) p.style.textAlign = alignment === "both" ? "justify" : alignment;
                children(block, "r").forEach((run, ri) => {
                    const span = document.createElement("span");
                    const id = `${index}:${ri}`;
                    span.dataset.run = id;
                    runSources.set(id, run);
                    const pr = prop(run, "rPr");
                    if (prop(pr, "b")) span.style.fontWeight = on(prop(pr, "b")) ? "bold" : "normal";
                    if (prop(pr, "i")) span.style.fontStyle = on(prop(pr, "i")) ? "italic" : "normal";
                    if (prop(pr, "u")) span.style.textDecoration = value(prop(pr, "u")) === "none" ? "none" : "underline";
                    const size = Number(value(prop(pr, "sz")));
                    if (size > 0 && size <= 800) span.style.fontSize = `${size / 2}pt`;
                    for (const node of run.children) {
                        if (node.localName === "t") span.append(document.createTextNode(node.textContent));
                        if (["br", "cr"].includes(node.localName)) {
                            const br = document.createElement("br"); br.dataset.docxBreak = "true"; span.append(br);
                        }
                        if (node.localName === "tab") span.append(document.createTextNode("\t"));
                    }
                    p.append(span);
                });
                if (!p.hasChildNodes()) p.append(document.createElement("br"));
            }
            surface.append(p);
        });
        if (!surface.children.length) surface.append(document.createElement("p"));
        const state = readSurface(surface);
        state.forEach(b => { if (b.source != null) initial.set(b.source, JSON.stringify(b)); });
        state.forEach(b => b.runs?.forEach(r => { if (r.source != null) initialRuns.set(r.source, r); }));
        initialSnapshot = JSON.stringify(state);
    }

    async function generateBlob(state) {
        if (destroyed) throw new Error("DOCX editor has been closed.");
        if (JSON.stringify(state) === initialSnapshot) return blob;
        const actualProtected = state.filter(b => b.protected != null).map(b => b.protected);
        if (JSON.stringify(actualProtected) !== JSON.stringify(protectedIds)) {
            throw new Error("A preserved table or embedded item was removed or moved. Undo that change before saving.");
        }
        const doc = source.cloneNode(true);
        const target = doc.getElementsByTagNameNS(W, "body")[0];
        const section = children(target, "sectPr")[0] || null;
        Array.from(target.children).filter(n => n !== section).forEach(n => n.remove());
        const used = new Set();
        for (const block of state) {
            const original = block.source == null ? null : blocks[Number(block.source)];
            let p;
            if (block.protected != null || (!used.has(block.source) && initial.get(block.source) === JSON.stringify(block))) {
                p = doc.importNode(original, true);
            } else {
                p = word(doc, "p");
                const sourceProps = original && simple(original) && prop(original, "pPr");
                const pPr = sourceProps ? doc.importNode(sourceProps, true) : word(doc, "pPr");
                const originalBlock = initial.has(block.source) ? JSON.parse(initial.get(block.source)) : null;
                if (!originalBlock || originalBlock.align !== block.align) {
                    setProperty(doc, pPr, "jc", block.align === "justify" ? "both" : block.align);
                }
                p.append(pPr);
                for (const run of block.runs) {
                    if (!run.text) continue;
                    const r = word(doc, "r");
                    const old = prop(runSources.get(run.source), "rPr");
                    const pr = old ? doc.importNode(old, true) : word(doc, "rPr");
                    const before = initialRuns.get(run.source);
                    // Leave inherited Word styling alone unless the corresponding
                    // toolbar property actually changed in the browser.
                    if (!before || before.bold !== run.bold) setProperty(doc, pr, "b", run.bold ? "1" : "0");
                    if (!before || before.italic !== run.italic) setProperty(doc, pr, "i", run.italic ? "1" : "0");
                    if (!before || before.underline !== run.underline) setProperty(doc, pr, "u", run.underline ? "single" : "none");
                    if (!before || before.size !== run.size) setProperty(doc, pr, "sz", Math.round(run.size * 2));
                    r.append(pr);
                    for (const part of run.text.split(/([\n\t])/)) {
                        if (part === "\n") r.append(word(doc, "br"));
                        else if (part === "\t") r.append(word(doc, "tab"));
                        else if (part) {
                            const t = word(doc, "t");
                            t.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve");
                            t.textContent = part; r.append(t);
                        }
                    }
                    p.append(r);
                }
            }
            used.add(block.source);
            target.insertBefore(p, section);
        }
        const output = await JSZip.loadAsync(bytes);
        output.file("word/document.xml", xml(doc));
        return output.generateAsync({type: "blob", mimeType: DOCX_MIME, compression: "DEFLATE"});
    }
    return { render, generateBlob, destroy() { destroyed = true; runSources.clear(); initial.clear(); initialRuns.clear(); } };
}

// Read structural paragraphs, never visual line wrapping or layout-dependent innerText.
export function readSurface(surface) {
    const result = [];
    let current = null;
    const lastNodes = new WeakMap();
    function begin(element) {
        const style = getComputedStyle(element);
        current = { source: element.dataset?.source ?? null, align: ["center", "right", "justify"].includes(style.textAlign) ? style.textAlign : "left", runs: [] };
        result.push(current);
    }
    function visit(node) {
        if (node.nodeType === Node.ELEMENT_NODE && node.dataset.protected != null) {
            current = null;
            result.push({source: node.dataset.source, protected: node.dataset.protected});
            return;
        }
        if (node.nodeType === Node.ELEMENT_NODE && /^(P|DIV|H[1-6]|LI|BLOCKQUOTE)$/.test(node.tagName)) {
            current = null;
            if (!Array.from(node.children).some(c => /^(P|DIV|H[1-6]|LI|BLOCKQUOTE)$/.test(c.tagName))) begin(node);
            Array.from(node.childNodes).forEach(visit);
            current = null;
            return;
        }
        if (node.nodeType === Node.TEXT_NODE || node.nodeName === "BR") {
            if (!current) begin(node.parentElement);
            const parent = node.parentElement;
            const style = getComputedStyle(parent);
            let underline = false;
            for (let el = parent; el && el !== surface; el = el.parentElement) {
                if (getComputedStyle(el).textDecorationLine.includes("underline")) underline = true;
            }
            const text = node.nodeName === "BR" ? "\n" : node.textContent.replace(/\u00a0/g, " ");
            current.runs.push({source: parent.closest("[data-run]")?.dataset.run ?? null, text,
                bold: Number(style.fontWeight) >= 600 || style.fontWeight === "bold", italic: style.fontStyle === "italic",
                underline, size: Math.round(parseFloat(style.fontSize) * 0.75 * 2) / 2 || 11});
            lastNodes.set(current, node);
        } else if (node.nodeType === Node.ELEMENT_NODE) Array.from(node.childNodes).forEach(visit);
    }
    Array.from(surface.childNodes).forEach(visit);
    for (const block of result) {
        // A final direct BR is the browser's caret placeholder. A BR inside an
        // imported run is a real Word soft break and must survive export.
        if (block.runs?.at(-1)?.text === "\n" && !lastNodes.get(block)?.dataset?.docxBreak) block.runs.pop();
    }
    return result.length ? result : [{source: null, align: "left", runs: []}];
}

export async function createBlankDocx() {
    const JSZip = await loadJsZip();
    const zip = new JSZip();
    zip.file("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
    zip.file("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
    zip.file("word/document.xml", `<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="${W}"><w:body><w:p/><w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>`);
    return zip.generateAsync({type: "blob", mimeType: DOCX_MIME, compression: "DEFLATE"});
}
