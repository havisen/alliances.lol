"use strict";

import {
    decryptFile,
    unwrapFileKey,
    clearFileKey,
} from "./drive-crypto.js";

import {
    hasActiveVaultSession,
    getOpenPgpPrivateKey,
} from "./drive-vault.js";


/*
 * ==========================================================================
 * Alliances Drive — Local file download/decryption
 * ==========================================================================
 *
 * Server sends:
 *
 * - encrypted file blob
 * - current user's OpenPGP-wrapped AES file key
 * - filename/MIME metadata
 *
 * Browser:
 *
 * - restores OpenPGP private key from unlocked Key Vault
 * - decrypts the wrapped AES key locally
 * - decrypts file contents locally
 * - creates the final download locally
 *
 * The plaintext file and raw AES key are never sent back to PHP.
 */


/*
 * --------------------------------------------------------------------------
 * Base64 helpers
 * --------------------------------------------------------------------------
 */

function base64ToText(value) {
    try {
        const binary =
            atob(value);

        const bytes =
            new Uint8Array(
                binary.length
            );

        for (
            let index = 0;
            index < binary.length;
            index += 1
        ) {
            bytes[index] =
                binary.charCodeAt(
                    index
                );
        }

        return new TextDecoder().decode(
            bytes
        );
    } catch {
        throw new Error(
            "Invalid encrypted file metadata."
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Read an error response
 * --------------------------------------------------------------------------
 */

async function readErrorResponse(
    response
) {
    try {
        const contentType =
            response.headers.get(
                "Content-Type"
            ) ?? "";

        if (
            contentType.includes(
                "application/json"
            )
        ) {
            const data =
                await response.json();

            return (
                data?.error ||
                "Unable to retrieve file."
            );
        }

        const text =
            await response.text();

        if (text.trim()) {
            return text.trim();
        }
    } catch {
        // Use generic message below.
    }

    return "Unable to retrieve file.";
}


/*
 * --------------------------------------------------------------------------
 * Trigger browser download
 * --------------------------------------------------------------------------
 */

function saveDecryptedFile(
    plaintext,
    filename,
    mimeType
) {
    const blob =
        new Blob(
            [
                plaintext,
            ],
            {
                type:
                    mimeType ||
                    "application/octet-stream",
            }
        );


    const objectUrl =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );

    link.href =
        objectUrl;

    link.download =
        filename ||
        "download";


    /*
     * The element does not need to be visible.
     */
    link.style.display =
        "none";

    document.body.appendChild(
        link
    );

    link.click();

    link.remove();


    /*
     * Keep the object URL alive briefly so the browser has
     * enough time to begin the download.
     */
    window.setTimeout(
        () => {
            URL.revokeObjectURL(
                objectUrl
            );
        },
        1000
    );
}


/*
 * --------------------------------------------------------------------------
 * Download and decrypt
 * --------------------------------------------------------------------------
 */

export async function decryptDriveFile(
    fileId,
    {
        onStatus = null,
    } = {}
) {
    const numericFileId =
        Number(fileId);


    if (
        !Number.isInteger(
            numericFileId
        ) ||
        numericFileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }


    if (
        !hasActiveVaultSession()
    ) {
        throw new Error(
            "Your Key Vault is locked. Open Key Vault and unlock it before opening encrypted files."
        );
    }


    const setStatus =
        typeof onStatus ===
        "function"
            ? onStatus
            : () => {};


    let fileKey = null;


    try {
        /*
         * Load the private OpenPGP key locally.
         */
        setStatus(
            "Opening Key Vault…"
        );


        const privateKey =
            await getOpenPgpPrivateKey();


        /*
         * Ask PHP for encrypted bytes and this user's
         * encrypted file-key envelope.
         */
        setStatus(
            "Downloading encrypted file…"
        );


        const response =
            await fetch(
                "/actions/drive/download.php"
                + "?file_id="
                + encodeURIComponent(
                    String(
                        numericFileId
                    )
                ),
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    cache:
                        "no-store",
                }
            );


        if (!response.ok) {
            throw new Error(
                await readErrorResponse(
                    response
                )
            );
        }


        /*
         * Metadata from download.php.
         */
        const encryptedKeyHeader =
            response.headers.get(
                "X-Alliances-Drive-Key"
            );

        const filenameHeader =
            response.headers.get(
                "X-Alliances-Drive-Name"
            );

        const mimeHeader =
            response.headers.get(
                "X-Alliances-Drive-Mime"
            );


        if (
            !encryptedKeyHeader
        ) {
            throw new Error(
                "The encrypted file key is missing."
            );
        }


        /*
         * PHP base64-encodes the armored PGP envelope before
         * placing it in the HTTP header.
         */
        const encryptedKey =
            base64ToText(
                encryptedKeyHeader
            );


        const filename =
            filenameHeader
                ? base64ToText(
                    filenameHeader
                )
                : "download";


        const mimeType =
            mimeHeader
                ? base64ToText(
                    mimeHeader
                )
                : "application/octet-stream";


        /*
         * Response body is still ciphertext.
         */
        const encryptedBlob =
            await response.blob();


        /*
         * Recover the random AES-256 file key using the
         * current user's private OpenPGP key.
         */
        setStatus(
            "Decrypting file key on this device…"
        );


        fileKey =
            await unwrapFileKey(
                encryptedKey,
                privateKey
            );


        /*
         * Decrypt file contents locally.
         */
        setStatus(
            "Decrypting file on this device…"
        );


        const plaintext =
            await decryptFile(
                encryptedBlob,
                fileKey
            );


        /*
         * Raw AES key is no longer required.
         */
        clearFileKey(
            fileKey
        );

        fileKey = null;


        setStatus(
            "File decrypted."
        );


        /*
         * Return the decrypted contents to the caller.
         *
         * The plaintext exists only in this browser.
         * It is never sent back to PHP by this function.
         */
        return {
            success: true,
            plaintext,
            filename,
            mimeType,
        };
    } finally {
        /*
         * Best-effort cleanup if an error occurred before the
         * normal key cleanup above.
         */
        if (fileKey) {
            clearFileKey(
                fileKey
            );
        }
    }
}

/*
 * --------------------------------------------------------------------------
 * Download decrypted file
 * --------------------------------------------------------------------------
 */

export async function downloadDriveFile(
    fileId,
    {
        onStatus = null,
    } = {}
) {
    const result =
        await decryptDriveFile(
            fileId,
            {
                onStatus,
            }
        );


    saveDecryptedFile(
        result.plaintext,
        result.filename,
        result.mimeType
    );


    return {
        success: true,
        filename:
            result.filename,
        mimeType:
            result.mimeType,
    };
}