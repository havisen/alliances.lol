"use strict";

import {
    decryptFile,
    unwrapFileKey,
    clearFileKey,
} from "./drive-crypto.js";

import {
    hasActiveVaultSession,
    getOpenPgpPrivateKey,
} from "./drive-vault.js";


/*
|--------------------------------------------------------------------------
| Base64 metadata decoder
|--------------------------------------------------------------------------
*/

function base64ToText(value) {
    if (
        typeof value !== "string" ||
        value === ""
    ) {
        return "";
    }

    try {
        const binary =
            atob(value);

        const bytes =
            new Uint8Array(
                binary.length
            );

        for (
            let index = 0;
            index < binary.length;
            index += 1
        ) {
            bytes[index] =
                binary.charCodeAt(
                    index
                );
        }

        return new TextDecoder().decode(
            bytes
        );
    } catch {
        throw new Error(
            "Invalid encrypted Drive metadata."
        );
    }
}


/*
|--------------------------------------------------------------------------
| Read error response
|--------------------------------------------------------------------------
*/

async function getErrorMessage(
    response,
    fallback
) {
    try {
        const result =
            await response.json();

        if (
            result &&
            typeof result.error ===
                "string" &&
            result.error !== ""
        ) {
            return result.error;
        }
    } catch {
        /*
         * The endpoint normally returns binary data,
         * so a failed binary response may not contain
         * usable JSON.
         */
    }

    return fallback;
}


/*
|--------------------------------------------------------------------------
| Supported editor types
|--------------------------------------------------------------------------
*/

export function getDriveEditorType(
    fileName,
    mimeType
) {
    const name =
        String(
            fileName ?? ""
        ).toLowerCase();

    const mime =
        String(
            mimeType ?? ""
        ).toLowerCase();


    if (
        name.endsWith(".docx") ||
        mime ===
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
        return "docx";
    }


    if (
        name.endsWith(".xlsx") ||
        mime ===
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ) {
        return "xlsx";
    }


    if (
        name.endsWith(".pdf") ||
        mime ===
            "application/pdf"
    ) {
        return "pdf";
    }


    if (name.endsWith(".txt") || mime.split(";")[0].trim() === "text/plain") return "txt";

    return null;
}


/*
|--------------------------------------------------------------------------
| Load and decrypt file for editor
|--------------------------------------------------------------------------
*/

export async function loadDriveEditorFile(
    fileId,
    {
        onStatus = null,
    } = {}
) {
    const numericFileId =
        Number(fileId);


    if (
        !Number.isInteger(
            numericFileId
        ) ||
        numericFileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }


    if (
        !hasActiveVaultSession()
    ) {
        throw new Error(
            "Your Key Vault is locked. Unlock it before opening encrypted files."
        );
    }


    const setStatus =
        (message) => {
            if (
                typeof onStatus ===
                "function"
            ) {
                onStatus(
                    message
                );
            }
        };


    let fileKey = null;


    try {
        /*
         * --------------------------------------------------------------
         * Get the current user's private OpenPGP key locally
         * --------------------------------------------------------------
         */

        setStatus(
            "Unlocking file key…"
        );


        const privateKey =
            await getOpenPgpPrivateKey();


        /*
         * --------------------------------------------------------------
         * Fetch encrypted document
         * --------------------------------------------------------------
         */

        setStatus(
            "Loading encrypted document…"
        );


        const response =
            await fetch(
                "/actions/drive/editor-file.php"
                + "?file_id="
                + encodeURIComponent(
                    String(
                        numericFileId
                    )
                ),
                {
                    method:
                        "GET",

                    credentials:
                        "same-origin",

                    cache:
                        "no-store",
                }
            );


        if (!response.ok) {
            throw new Error(
                await getErrorMessage(
                    response,
                    "Unable to load the encrypted document."
                )
            );
        }


        /*
         * --------------------------------------------------------------
         * Read metadata
         * --------------------------------------------------------------
         */

        const nameHeader =
            response.headers.get(
                "X-Alliances-Drive-Name"
            );


        const mimeHeader =
            response.headers.get(
                "X-Alliances-Drive-Mime"
            );


        const encryptedKeyHeader =
            response.headers.get(
                "X-Alliances-Drive-Key"
            );


        const keyVersionHeader =
            response.headers.get(
                "X-Alliances-Drive-Key-Version"
            );


        const encryptionVersionHeader =
            response.headers.get(
                "X-Alliances-Drive-Encryption-Version"
            );


        const canEditHeader =
            response.headers.get(
                "X-Alliances-Drive-Can-Edit"
            );


        if (!encryptedKeyHeader) {
            throw new Error(
                "The encrypted file key is missing."
            );
        }


        const fileName =
            base64ToText(
                nameHeader ?? ""
            ) || "file";


        const mimeType =
            base64ToText(
                mimeHeader ?? ""
            ) ||
            "application/octet-stream";


        const encryptedKey =
            base64ToText(
                encryptedKeyHeader
            );


        const keyVersion =
            Number(
                keyVersionHeader ??
                "1"
            );


        const encryptionVersion =
            Number(
                encryptionVersionHeader ??
                "1"
            );


        const canEdit =
            canEditHeader ===
            "1";


        const editorType =
            getDriveEditorType(
                fileName,
                mimeType
            );


        /*
         * --------------------------------------------------------------
         * Read encrypted blob
         * --------------------------------------------------------------
         */

const encryptedBlob =
    await response.blob();


console.log(
    "Drive editor encrypted blob:",
    {
        size:
            encryptedBlob.size,

        type:
            encryptedBlob.type,

        fileName,

        mimeType,
    }
);


if (
    encryptedBlob.size ===
    0
) {
    throw new Error(
        "The server returned an empty encrypted file."
    );
}


/*
 * --------------------------------------------------------------
 * Unwrap AES key locally
 * --------------------------------------------------------------
 */

        setStatus(
            "Decrypting file key…"
        );


        fileKey =
            await unwrapFileKey(
                encryptedKey,
                privateKey
            );


        /*
         * --------------------------------------------------------------
         * Decrypt document locally
         * --------------------------------------------------------------
         */

        setStatus(
            "Decrypting document locally…"
        );


        const decryptedData =
            await decryptFile(
                encryptedBlob,
                fileKey
            );


        /*
         * decryptFile may return a Blob, ArrayBuffer or
         * Uint8Array depending on the crypto helper.
         *
         * Normalize it to a Blob for the editors.
         */

        let plaintextBlob;


        if (
            decryptedData instanceof
            Blob
        ) {
            plaintextBlob =
                new Blob(
                    [
                        await decryptedData
                            .arrayBuffer(),
                    ],
                    {
                        type:
                            mimeType,
                    }
                );
        } else if (
            decryptedData instanceof
            ArrayBuffer
        ) {
            plaintextBlob =
                new Blob(
                    [
                        decryptedData,
                    ],
                    {
                        type:
                            mimeType,
                    }
                );
        } else if (
            ArrayBuffer.isView(
                decryptedData
            )
        ) {
            plaintextBlob =
                new Blob(
                    [
                        decryptedData,
                    ],
                    {
                        type:
                            mimeType,
                    }
                );
        } else {
            throw new Error(
                "The decrypted document format is invalid."
            );
        }

const debugPlaintextBytes =
    new Uint8Array(
        await plaintextBlob.arrayBuffer()
    );


console.log(
    "Drive editor decrypted blob:",
    "size=" + plaintextBlob.size,
    "type=" + plaintextBlob.type,
    "first16=" +
        Array.from(
            debugPlaintextBytes.slice(
                0,
                16
            )
        )
            .map(
                (byte) =>
                    byte
                        .toString(16)
                        .padStart(2, "0")
            )
            .join(" ")
);


if (plaintextBlob.size === 0 && editorType !== "txt") {
    throw new Error(
        "The encrypted file decrypted successfully, but the resulting document is empty."
    );
}

        setStatus(
            "Document decrypted."
        );


        /*
         * The plaintext Blob exists only in browser memory.
         *
         * It is not uploaded back to PHP unless another
         * browser-side component first encrypts it.
         */

        return {
            fileId:
                numericFileId,

            name:
                fileName,

            mimeType,

            editorType,

            canEdit,

            keyVersion:
                Number.isFinite(
                    keyVersion
                )
                    ? keyVersion
                    : 1,

            encryptionVersion:
                Number.isFinite(
                    encryptionVersion
                )
                    ? encryptionVersion
                    : 1,

            blob:
                plaintextBlob,
        };
    } finally {
        /*
         * The editor receives the decrypted document,
         * not the raw AES file key.
         *
         * Clear our local reference to the AES key as
         * soon as decryption finishes.
         */
        if (fileKey) {
            try {
                clearFileKey(
                    fileKey
                );
            } catch {
                /*
                 * Best-effort cleanup only.
                 */
            }
        }
    }
}