"use strict";

import {
    encryptFile,
    unwrapFileKey,
    clearFileKey,
} from "./drive-crypto.js";

import {
    hasActiveVaultSession,
    getOpenPgpPrivateKey,
} from "./drive-vault.js";


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

function getCsrfToken() {
    const meta =
        document.querySelector(
            'meta[name="csrf-token"]'
        );

    const token =
        meta?.getAttribute(
            "content"
        ) ?? "";

    if (token === "") {
        throw new Error(
            "The security token is missing. Refresh the page and try again."
        );
    }

    return token;
}


/*
|--------------------------------------------------------------------------
| JSON response helper
|--------------------------------------------------------------------------
*/

async function readJsonResponse(
    response,
    fallbackMessage
) {
    let result = null;

    try {
        result =
            await response.json();
    } catch {
        throw new Error(
            fallbackMessage
        );
    }

    if (
        !response.ok ||
        !result ||
        result.success !== true
    ) {
        throw new Error(
            typeof result?.error ===
                "string" &&
            result.error !== ""
                ? result.error
                : fallbackMessage
        );
    }

    return result;
}


/*
|--------------------------------------------------------------------------
| Retrieve current user's wrapped file key
|--------------------------------------------------------------------------
|
| key.php returns only the OpenPGP-encrypted AES file key.
|
| The raw AES key is recovered locally with the user's Key Vault private
| key and is never sent back to PHP.
|
*/

async function getWrappedFileKey(
    fileId
) {
    const response =
        await fetch(
            "/actions/drive/key.php"
            + "?file_id="
            + encodeURIComponent(
                String(fileId)
            ),
            {
                method: "GET",
                credentials:
                    "same-origin",
                cache:
                    "no-store",
            }
        );

    const result =
        await readJsonResponse(
            response,
            "Unable to retrieve the encrypted file key."
        );

    if (
        typeof result.encrypted_key !==
            "string" ||
        result.encrypted_key === ""
    ) {
        throw new Error(
            "The encrypted file key is missing."
        );
    }

    return {
        encryptedKey:
            result.encrypted_key,

        keyVersion:
            Number(
                result.key_version ??
                1
            ),
    };
}


/*
|--------------------------------------------------------------------------
| Normalize editor output
|--------------------------------------------------------------------------
*/

function normalizeEditedFile(
    editedFile,
    fileName,
    mimeType
) {
    if (
        editedFile instanceof Blob
    ) {
        /*
         * encryptFile() currently expects a File-like object.
         * Wrap the editor Blob in a File while keeping all plaintext
         * browser-side.
         */
        return new File(
            [editedFile],
            fileName,
            {
                type:
                    mimeType ||
                    editedFile.type ||
                    "application/octet-stream",

                lastModified:
                    Date.now(),
            }
        );
    }


    if (
        editedFile instanceof
        ArrayBuffer
    ) {
        return new File(
            [editedFile],
            fileName,
            {
                type:
                    mimeType ||
                    "application/octet-stream",

                lastModified:
                    Date.now(),
            }
        );
    }


    if (
        ArrayBuffer.isView(
            editedFile
        )
    ) {
        return new File(
            [editedFile],
            fileName,
            {
                type:
                    mimeType ||
                    "application/octet-stream",

                lastModified:
                    Date.now(),
            }
        );
    }


    throw new Error(
        "The editor did not provide a valid document."
    );
}


/*
|--------------------------------------------------------------------------
| Save encrypted editor version
|--------------------------------------------------------------------------
*/

export async function saveDriveEditorVersion(
    fileId,
    editedFile,
    {
        fileName = "file",
        mimeType =
            "application/octet-stream",
        onStatus = null,
    } = {}
) {
    const numericFileId =
        Number(fileId);


    if (
        !Number.isInteger(
            numericFileId
        ) ||
        numericFileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }


    if (
        !hasActiveVaultSession()
    ) {
        throw new Error(
            "Your Key Vault is locked. Unlock it before saving encrypted files."
        );
    }


    const setStatus =
        (message) => {
            if (
                typeof onStatus ===
                    "function"
            ) {
                onStatus(
                    message
                );
            }
        };


    let fileKey = null;


    try {
        /*
         * --------------------------------------------------------------
         * Obtain private OpenPGP key locally
         * --------------------------------------------------------------
         */

        setStatus(
            "Preparing encryption…"
        );


        const privateKey =
            await getOpenPgpPrivateKey();


        /*
         * --------------------------------------------------------------
         * Retrieve current wrapped AES key
         * --------------------------------------------------------------
         */

        const {
            encryptedKey,
            keyVersion,
        } =
            await getWrappedFileKey(
                numericFileId
            );


        /*
         * --------------------------------------------------------------
         * Unwrap AES key locally
         * --------------------------------------------------------------
         */

        setStatus(
            "Unlocking file key…"
        );


        fileKey =
            await unwrapFileKey(
                encryptedKey,
                privateKey
            );


        /*
         * --------------------------------------------------------------
         * Normalize editor output
         * --------------------------------------------------------------
         */

        const plaintextFile =
            normalizeEditedFile(
                editedFile,
                fileName,
                mimeType
            );


        /*
         * --------------------------------------------------------------
         * Encrypt edited document locally
         * --------------------------------------------------------------
         *
         * encryptFile() generates a fresh AES-GCM IV for this encrypted
         * version.
         */

        setStatus(
            "Encrypting document locally…"
        );


        const encryptedBlob =
            await encryptFile(
                plaintextFile,
                fileKey
            );


        if (
            !(
                encryptedBlob instanceof
                Blob
            )
        ) {
            throw new Error(
                "Unable to create the encrypted document version."
            );
        }


        /*
         * --------------------------------------------------------------
         * Upload ciphertext only
         * --------------------------------------------------------------
         */

        setStatus(
            "Saving encrypted version…"
        );


        const formData =
            new FormData();


        formData.append(
            "csrf_token",
            getCsrfToken()
        );


        formData.append(
            "file_id",
            String(
                numericFileId
            )
        );


        formData.append(
            "encrypted_file",
            encryptedBlob,
            "encrypted-drive-file.bin"
        );


        const response =
            await fetch(
                "/actions/drive/save-version.php",
                {
                    method:
                        "POST",

                    credentials:
                        "same-origin",

                    body:
                        formData,
                }
            );


        const result =
            await readJsonResponse(
                response,
                "Unable to save the encrypted document version."
            );


        setStatus(
            "Saved."
        );


        return {
            ...result,

            keyVersion:
                Number.isFinite(
                    keyVersion
                )
                    ? keyVersion
                    : 1,
        };
    } finally {
        /*
         * Best-effort key cleanup.
         *
         * JavaScript cannot guarantee physical memory erasure, but we
         * clear the Uint8Array as soon as this operation finishes.
         */

        if (fileKey) {
            try {
                clearFileKey(
                    fileKey
                );
            } catch {
                /*
                 * Nothing else to do.
                 */
            }
        }
    }
}