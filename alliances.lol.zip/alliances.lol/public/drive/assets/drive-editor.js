"use strict";
import { mountTxtEditor } from "./drive-txt-editor.js";

import {
    loadDriveEditorFile,
} from "./drive-editor-file.js";

import {
    saveDriveEditorVersion,
} from "./drive-editor-save.js";

import {
    mountDocxEditor,
} from "./drive-docx-editor.js";

import {
    createXlsxEditor,
} from "./drive-xlsx-editor.js";

/*
 * ==========================================================================
 * Alliances — Drive Editor Controller
 * ==========================================================================
 *
 * Responsibilities:
 *
 *   1. Load and decrypt the Drive file locally.
 *   2. Mount the correct browser-side editor.
 *   3. Track whether the document has changed.
 *   4. Serialize edited content locally.
 *   5. Encrypt it locally before saving a new Drive version.
 *
 * Plaintext document contents are never submitted to PHP.
 */


/*
 * --------------------------------------------------------------------------
 * Page elements
 * --------------------------------------------------------------------------
 */

const fileIdMeta =
    document.querySelector(
        'meta[name="alliances-drive-file-id"]'
    );


const filenameElement =
    document.getElementById(
        "drive-editor-filename"
    );


const typeElement =
    document.getElementById(
        "drive-editor-type"
    );


const readonlyElement =
    document.getElementById(
        "drive-editor-readonly"
    );


const statusElement =
    document.getElementById(
        "drive-editor-status"
    );


const loadingElement =
    document.getElementById(
        "drive-editor-loading"
    );


const loadingStatusElement =
    document.getElementById(
        "drive-editor-loading-status"
    );


const errorElement =
    document.getElementById(
        "drive-editor-error"
    );


const errorMessageElement =
    document.getElementById(
        "drive-editor-error-message"
    );


const editorContainer =
    document.getElementById(
        "drive-editor-container"
    );


const saveButton =
    document.getElementById(
        "drive-editor-save"
    );


const downloadButton =
    document.getElementById(
        "drive-editor-download"
    );


/*
 * --------------------------------------------------------------------------
 * Editor state
 * --------------------------------------------------------------------------
 */

let editorFile =
    null;


let activeEditor =
    null;


let plaintextObjectUrl =
    null;


let saving =
    false;


/*
 * --------------------------------------------------------------------------
 * Status
 * --------------------------------------------------------------------------
 */

function setStatus(
    message
) {
    if (statusElement) {
        statusElement.textContent =
            message;
    }


    if (
        loadingStatusElement &&
        !loadingElement?.hidden
    ) {
        loadingStatusElement.textContent =
            message;
    }
}


/*
 * --------------------------------------------------------------------------
 * Save button state
 * --------------------------------------------------------------------------
 */

function updateSaveButton() {
    if (!saveButton) {
        return;
    }


    const canSave =
        Boolean(
            editorFile &&
            activeEditor &&
            editorFile.canEdit &&
            activeEditor.canEdit &&
            activeEditor.isDirty &&
            !saving
        );


    saveButton.disabled =
        !canSave;


    saveButton.textContent =
        saving
            ? "Saving…"
            : "Save";
}


/*
 * --------------------------------------------------------------------------
 * Error state
 * --------------------------------------------------------------------------
 */

function showError(
    error
) {
    console.error(
        "Drive editor error:",
        error
    );


    if (loadingElement) {
        loadingElement.hidden =
            true;
    }


    if (editorContainer) {
        editorContainer.hidden =
            true;
    }


    if (errorElement) {
        errorElement.hidden =
            false;
    }


    if (errorMessageElement) {
        errorMessageElement.textContent =
            error instanceof Error
                ? error.message
                : "Unable to open this encrypted file.";
    }


    if (statusElement) {
        statusElement.textContent =
            "Unable to open file.";
    }


    if (saveButton) {
        saveButton.disabled =
            true;
    }


    if (downloadButton) {
        downloadButton.disabled =
            true;
    }
}


/*
 * --------------------------------------------------------------------------
 * File type label
 * --------------------------------------------------------------------------
 */

function getEditorTypeLabel(
    editorType
) {
    switch (editorType) {
        case "txt":
            return "TXT";

        case "docx":
            return "DOCX";

        case "xlsx":
            return "XLSX";

        case "pdf":
            return "PDF";

        default:
            return "FILE";
    }
}


/*
 * --------------------------------------------------------------------------
 * Unsupported editor
 * --------------------------------------------------------------------------
 */

function renderUnsupportedFile() {
    if (!editorContainer) {
        return;
    }


    editorContainer.replaceChildren();


    const wrapper =
        document.createElement(
            "div"
        );


    wrapper.className =
        "drive-editor-placeholder";


    const title =
        document.createElement(
            "strong"
        );


    title.textContent =
        "No built-in editor is available for this file type.";


    const description =
        document.createElement(
            "p"
        );


    description.textContent =
        "You can still download the decrypted file to this device.";


    wrapper.append(
        title,
        description
    );


    editorContainer.appendChild(
        wrapper
    );
}


/*
 * --------------------------------------------------------------------------
 * Editor placeholder
 * --------------------------------------------------------------------------
 *
 * XLSX and PDF will be replaced by their own editor modules.
 */

function renderEditorPlaceholder(
    file
) {
    if (!editorContainer) {
        return;
    }


    editorContainer.replaceChildren();


    const wrapper =
        document.createElement(
            "div"
        );


    wrapper.className =
        "drive-editor-placeholder";


    const title =
        document.createElement(
            "strong"
        );


    title.textContent =
        `${getEditorTypeLabel(
            file.editorType
        )} editor ready`;


    const description =
        document.createElement(
            "p"
        );


    description.textContent =
        file.canEdit
            ? "The document has been decrypted locally. Its built-in editor will be connected next."
            : "The document has been decrypted locally in view-only mode.";


    wrapper.append(
        title,
        description
    );


    editorContainer.appendChild(
        wrapper
    );
}


/*
 * --------------------------------------------------------------------------
 * Decrypted download
 * --------------------------------------------------------------------------
 */

function downloadDecryptedFile() {
    if (!editorFile) {
        return;
    }


    if (plaintextObjectUrl) {
        URL.revokeObjectURL(
            plaintextObjectUrl
        );

        plaintextObjectUrl =
            null;
    }


    plaintextObjectUrl =
        URL.createObjectURL(
            editorFile.blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href =
        plaintextObjectUrl;


    link.download =
        editorFile.name;


    link.style.display =
        "none";


    document.body.appendChild(
        link
    );


    link.click();

    link.remove();


    window.setTimeout(
        () => {
            if (
                plaintextObjectUrl
            ) {
                URL.revokeObjectURL(
                    plaintextObjectUrl
                );

                plaintextObjectUrl =
                    null;
            }
        },
        1000
    );
}


/*
 * --------------------------------------------------------------------------
 * Mount editor
 * --------------------------------------------------------------------------
 */

async function mountEditor(
    file
) {
    if (!editorContainer) {
        throw new Error(
            "Drive editor container is unavailable."
        );
    }


    /*
     * Destroy an existing editor before mounting another one.
     */

    if (
        activeEditor &&
        typeof activeEditor.destroy ===
            "function"
    ) {
        activeEditor.destroy();
    }


    activeEditor =
        null;


    updateSaveButton();


    /*
     * ----------------------------------------------------------------------
     * DOCX / TXT
     * ----------------------------------------------------------------------
     */

    if (
        file.editorType === "docx" ||
        file.editorType === "txt"
    ) {
        activeEditor =
            await (
                file.editorType === "txt"
                    ? mountTxtEditor
                    : mountDocxEditor
            )({
                container:
                    editorContainer,

                fileName:
                    file.name,

                blob:
                    file.blob,

                canEdit:
                    file.canEdit,

                onDirtyChange:
                    () => {
                        updateSaveButton();
                    },

                onStatus:
                    setStatus,

                onRequestSave:
                    () => {
                        void saveCurrentDocument();
                    },
            });


        updateSaveButton();

        return;
    }


    /*
     * ----------------------------------------------------------------------
     * XLSX
     * ----------------------------------------------------------------------
     *
     * The Drive controller has already decrypted the XLSX file locally.
     *
     * The spreadsheet editor receives only the plaintext browser Blob.
     * It does not communicate with PHP itself.
     */

    if (
        file.editorType === "xlsx"
    ) {
        setStatus(
            "Opening spreadsheet locally…"
        );


        const xlsxEditor =
            await createXlsxEditor({
                container:
                    editorContainer,

                blob:
                    file.blob,

                fileName:
                    file.name,

                canEdit:
                    file.canEdit,
            });


        /*
         * Adapt the XLSX editor to the same interface already used by
         * the DOCX/TXT editors.
         *
         * drive-editor.js expects:
         *
         *     activeEditor.canEdit
         *     activeEditor.isDirty
         *     activeEditor.getSaveBlob()
         *     activeEditor.markSaved()
         *     activeEditor.destroy()
         */

        activeEditor = {
            canEdit:
                file.canEdit,

            get isDirty() {
                return xlsxEditor.isDirty();
            },

            async getSaveBlob() {
                return xlsxEditor
                    .getSaveBlob();
            },

            markSaved() {
                xlsxEditor.markSaved();

                updateSaveButton();
            },

            destroy() {
                xlsxEditor.destroy();
            },
        };


        /*
         * Keep the main Drive Save button synchronized with changes made
         * inside the spreadsheet.
         */

        xlsxEditor.engine.onChange(
            () => {
                updateSaveButton();
            }
        );


        setStatus(
            file.canEdit
                ? "Spreadsheet ready."
                : "Spreadsheet opened in view-only mode."
        );


        updateSaveButton();

        return;
    }


    /*
     * ----------------------------------------------------------------------
     * PDF
     * ----------------------------------------------------------------------
     *
     * PDF still uses the placeholder until its editor is implemented.
     */

    if (
        file.editorType === "pdf"
    ) {
        renderEditorPlaceholder(
            file
        );


        setStatus(
            file.canEdit
                ? "PDF document decrypted locally."
                : "PDF document opened in view-only mode."
        );


        return;
    }


    /*
     * ----------------------------------------------------------------------
     * Unsupported
     * ----------------------------------------------------------------------
     */

    renderUnsupportedFile();


    setStatus(
        "File decrypted locally. No built-in editor is available."
    );
}

/*
 * --------------------------------------------------------------------------
 * Apply loaded file to page
 * --------------------------------------------------------------------------
 */

async function showLoadedFile(
    file
) {
    editorFile =
        file;


    if (filenameElement) {
        filenameElement.textContent =
            file.name;
    }


    if (typeElement) {
        typeElement.textContent =
            getEditorTypeLabel(
                file.editorType
            );

        typeElement.hidden =
            false;
    }


    if (readonlyElement) {
        readonlyElement.hidden =
            file.canEdit;
    }


    if (loadingElement) {
        loadingElement.hidden =
            true;
    }


    if (errorElement) {
        errorElement.hidden =
            true;
    }


    if (editorContainer) {
        editorContainer.hidden =
            false;
    }


    if (downloadButton) {
        downloadButton.disabled =
            false;
    }


    updateSaveButton();


    await mountEditor(
        file
    );
}


/*
 * --------------------------------------------------------------------------
 * Save encrypted Drive version
 * --------------------------------------------------------------------------
 */

async function saveCurrentDocument() {
    if (
        saving ||
        !editorFile ||
        !activeEditor
    ) {
        return;
    }


    if (
        !editorFile.canEdit ||
        !activeEditor.canEdit
    ) {
        setStatus(
            "You only have view access to this document."
        );

        return;
    }


    if (!activeEditor.isDirty) {
        setStatus(
            "No changes to save."
        );

        updateSaveButton();

        return;
    }


    saving =
        true;


    updateSaveButton();


    try {
        setStatus(
            "Preparing document locally…"
        );


        /*
         * The editor serializes the plaintext document locally.
         *
         * This Blob is never submitted directly to PHP.
         */

        const editedBlob =
            await activeEditor
                .getSaveBlob();


        if (
            !(editedBlob instanceof Blob)
        ) {
            throw new Error(
                "The editor did not produce a valid document."
            );
        }


        setStatus(
            "Encrypting updated document locally…"
        );


        const result =
            await saveDriveEditorVersion(
                editorFile.fileId,
                editedBlob,
                {
                    fileName:
                        editorFile.name,

                    mimeType:
                        editorFile.mimeType,

                    onStatus:
                        setStatus,
                }
            );


        /*
         * Keep the newly serialized plaintext Blob as the current browser
         * copy. It remains only in browser memory.
         */

        editorFile.blob =
            editedBlob;


        if (
            typeof activeEditor.markSaved ===
            "function"
        ) {
            activeEditor.markSaved(
                editedBlob
            );
        }


        const versionNumber =
            Number(
                result?.version_number ??
                result?.versionNumber ??
                0
            );


        if (
            Number.isInteger(
                versionNumber
            ) &&
            versionNumber > 0
        ) {
            setStatus(
                `Saved encrypted version ${versionNumber}.`
            );
        } else {
            setStatus(
                "Changes saved as a new encrypted version."
            );
        }
    } catch (error) {
        console.error(
            "Drive editor save error:",
            error
        );


        setStatus(
            error instanceof Error
                ? error.message
                : "Unable to save document."
        );
    } finally {
        saving =
            false;


        updateSaveButton();
    }
}


/*
 * --------------------------------------------------------------------------
 * Open editor
 * --------------------------------------------------------------------------
 */

async function openEditor() {
    const fileId =
        Number(
            fileIdMeta?.getAttribute(
                "content"
            ) ??
            "0"
        );


    if (
        !Number.isInteger(
            fileId
        ) ||
        fileId <= 0
    ) {
        showError(
            new Error(
                "Invalid Drive file."
            )
        );

        return;
    }


    try {
        setStatus(
            "Loading encrypted document…"
        );


        const file =
            await loadDriveEditorFile(
                fileId,
                {
                    onStatus:
                        setStatus,
                }
            );


        await showLoadedFile(
            file
        );
    } catch (error) {
        showError(
            error
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Events
 * --------------------------------------------------------------------------
 */

if (downloadButton) {
    downloadButton.addEventListener(
        "click",
        () => {
            downloadDecryptedFile();
        }
    );
}


if (saveButton) {
    saveButton.addEventListener(
        "click",
        () => {
            void saveCurrentDocument();
        }
    );
}


/*
 * --------------------------------------------------------------------------
 * Cleanup
 * --------------------------------------------------------------------------
 */

window.addEventListener(
    "pagehide",
    () => {
        if (plaintextObjectUrl) {
            URL.revokeObjectURL(
                plaintextObjectUrl
            );

            plaintextObjectUrl =
                null;
        }


        if (
            activeEditor &&
            typeof activeEditor.destroy ===
                "function"
        ) {
            activeEditor.destroy();
        }


        activeEditor =
            null;


        /*
         * Drop our reference to the decrypted document.
         *
         * JavaScript cannot guarantee physical memory erasure, but this
         * controller does not deliberately persist the plaintext Blob.
         */

        editorFile =
            null;
    }
);


/*
 * --------------------------------------------------------------------------
 * Start
 * --------------------------------------------------------------------------
 */

openEditor();