"use strict";

export async function mountTxtEditor({container, fileName, blob, canEdit, onDirtyChange, onStatus, onRequestSave}) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    // Refuse an unknown encoding rather than silently corrupting it on save.
    const bom = bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf;
    let original;
    try { original = new TextDecoder("utf-8", {fatal: true}).decode(bytes); }
    catch { throw new Error("This TXT file is not UTF-8. Convert it to UTF-8 before editing."); }
    const newline = original.includes("\r\n") ? "\r\n" : original.includes("\r") ? "\r" : "\n";
    let saved = original.replace(/\r\n?/g, "\n");
    let destroyed = false;
    const exports = new WeakMap();
    const root = document.createElement("div");
    root.className = "drive-txt-editor";
    const status = document.createElement("div");
    status.className = "drive-docx-toolbar";
    const input = document.createElement("textarea");
    input.className = "drive-txt-input";
    input.setAttribute("aria-label", "Text document");
    input.readOnly = !canEdit;
    input.spellcheck = true;
    input.value = saved;
    root.append(status, input);
    container.replaceChildren(root);
    function update() {
        const text = input.value;
        status.textContent = `${canEdit ? (text === saved ? "Saved" : "Unsaved changes") : "View only"} · ${text.trim() ? text.trim().split(/\s+/).length : 0} words · ${text.length} characters · UTF-8`;
        onDirtyChange?.(text !== saved);
    }
    input.addEventListener("input", update);
    input.addEventListener("keydown", e => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") {
            e.preventDefault(); if (canEdit) onRequestSave?.();
        }
    });
    update(); onStatus?.(canEdit ? "Text document ready for editing." : "Text document opened in view-only mode.");
    return {
        type: "txt", fileName, mimeType: "text/plain",
        get canEdit() { return Boolean(canEdit); },
        get isDirty() { return input.value !== saved; },
        async getSaveBlob() {
            if (destroyed || !canEdit) throw new Error("This text document cannot be edited.");
            const state = input.value;
            const output = state === original.replace(/\r\n?/g, "\n") ? blob :
                new Blob([bom ? new Uint8Array([0xef, 0xbb, 0xbf]) : "", state.replace(/\n/g, newline)], {type: "text/plain;charset=utf-8"});
            exports.set(output, state); return output;
        },
        markSaved(output) { if (exports.has(output)) { saved = exports.get(output); update(); } },
        destroy() { destroyed = true; container.replaceChildren(); },
    };
}
