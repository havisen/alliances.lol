"use strict";

import * as openpgp from "/assets/vendor/openpgp/openpgp.min.mjs";


/*
 * ==========================================================================
 * Alliances Drive — Key Vault session access
 * ==========================================================================
 *
 * Drive never receives or stores the user's Key Vault password.
 *
 * It reads the temporary 8-hour Key Vault session already created by
 * Key Vault and restores the vault locally in the browser.
 */


/*
 * --------------------------------------------------------------------------
 * Session keys
 * --------------------------------------------------------------------------
 */

const SESSION_DATA_KEY =
    "alliances.key-vault.session-data";

const SESSION_KEY_KEY =
    "alliances.key-vault.session-key";

const SESSION_EXPIRES_KEY =
    "alliances.key-vault.expires-at";

const SESSION_USER_KEY =
    "alliances.key-vault.user-id";


/*
 * --------------------------------------------------------------------------
 * Utilities
 * --------------------------------------------------------------------------
 */

function base64ToBytes(value) {
    const binary = atob(value);

    const bytes =
        new Uint8Array(binary.length);

    for (
        let index = 0;
        index < binary.length;
        index += 1
    ) {
        bytes[index] =
            binary.charCodeAt(index);
    }

    return bytes;
}


function clearBytes(bytes) {
    if (
        bytes instanceof Uint8Array
    ) {
        bytes.fill(0);
    }
}


function clearInvalidSession() {
    localStorage.removeItem(
        SESSION_DATA_KEY
    );

    localStorage.removeItem(
        SESSION_KEY_KEY
    );

    localStorage.removeItem(
        SESSION_EXPIRES_KEY
    );

    localStorage.removeItem(
        SESSION_USER_KEY
    );
}


/*
 * --------------------------------------------------------------------------
 * Current user
 * --------------------------------------------------------------------------
 */

function getCurrentUserId() {
    const value =
        document.querySelector(
            'meta[name="alliances-user-id"]'
        )?.content ?? "";

    const userId =
        Number(value);

    if (
        !Number.isInteger(userId) ||
        userId <= 0
    ) {
        throw new Error(
            "Unable to determine the authenticated user."
        );
    }

    return userId;
}


/*
 * --------------------------------------------------------------------------
 * Check whether a workday Key Vault session exists
 * --------------------------------------------------------------------------
 */

export function hasActiveVaultSession() {
    try {
        const currentUserId =
            getCurrentUserId();

        const storedUserId =
            Number(
                localStorage.getItem(
                    SESSION_USER_KEY
                ) ?? 0
            );

        const expiresAt =
            Number(
                localStorage.getItem(
                    SESSION_EXPIRES_KEY
                ) ?? 0
            );

        const hasSessionData =
            Boolean(
                localStorage.getItem(
                    SESSION_DATA_KEY
                )
            );

        const hasSessionKey =
            Boolean(
                localStorage.getItem(
                    SESSION_KEY_KEY
                )
            );

        return (
            storedUserId ===
                currentUserId &&
            Number.isFinite(
                expiresAt
            ) &&
            expiresAt >
                Date.now() &&
            hasSessionData &&
            hasSessionKey
        );
    } catch {
        return false;
    }
}


/*
 * --------------------------------------------------------------------------
 * Restore unlocked vault
 * --------------------------------------------------------------------------
 */

export async function getUnlockedVault() {
    const currentUserId =
        getCurrentUserId();

    const storedUserId =
        Number(
            localStorage.getItem(
                SESSION_USER_KEY
            ) ?? 0
        );


    /*
     * The temporary vault session must belong to the
     * currently authenticated Alliances account.
     */
    if (
        !Number.isInteger(
            storedUserId
        ) ||
        storedUserId <= 0 ||
        storedUserId !==
            currentUserId
    ) {
        clearInvalidSession();

        throw new Error(
            "Your Key Vault is locked. Open Key Vault and unlock it first."
        );
    }


    const expiresAt =
        Number(
            localStorage.getItem(
                SESSION_EXPIRES_KEY
            ) ?? 0
        );


    if (
        !Number.isFinite(
            expiresAt
        ) ||
        expiresAt <=
            Date.now()
    ) {
        clearInvalidSession();

        throw new Error(
            "Your Key Vault session has expired. Unlock Key Vault again."
        );
    }


    const encryptedSessionText =
        localStorage.getItem(
            SESSION_DATA_KEY
        );

    const sessionKeyText =
        localStorage.getItem(
            SESSION_KEY_KEY
        );


    if (
        !encryptedSessionText ||
        !sessionKeyText
    ) {
        clearInvalidSession();

        throw new Error(
            "Your Key Vault is locked. Open Key Vault and unlock it first."
        );
    }


    let sessionEnvelope;

    try {
        sessionEnvelope =
            JSON.parse(
                encryptedSessionText
            );
    } catch {
        clearInvalidSession();

        throw new Error(
            "The Key Vault session is invalid. Unlock Key Vault again."
        );
    }


    if (
        !sessionEnvelope ||
        typeof sessionEnvelope !==
            "object" ||
        typeof sessionEnvelope.iv !==
            "string" ||
        typeof sessionEnvelope.ciphertext !==
            "string"
    ) {
        clearInvalidSession();

        throw new Error(
            "The Key Vault session is invalid. Unlock Key Vault again."
        );
    }


    let rawSessionKey = null;
    let iv = null;
    let ciphertext = null;


    try {
        rawSessionKey =
            base64ToBytes(
                sessionKeyText
            );

        iv =
            base64ToBytes(
                sessionEnvelope.iv
            );

        ciphertext =
            base64ToBytes(
                sessionEnvelope.ciphertext
            );
    } catch {
        clearBytes(
            rawSessionKey
        );

        clearInvalidSession();

        throw new Error(
            "The Key Vault session is invalid. Unlock Key Vault again."
        );
    }


    if (
        rawSessionKey.length !== 32 ||
        iv.length !== 12
    ) {
        clearBytes(
            rawSessionKey
        );

        clearInvalidSession();

        throw new Error(
            "The Key Vault session is invalid. Unlock Key Vault again."
        );
    }


    try {
        const cryptoKey =
            await crypto.subtle.importKey(
                "raw",
                rawSessionKey,
                {
                    name: "AES-GCM",
                },
                false,
                [
                    "decrypt",
                ]
            );


        const plaintext =
            await crypto.subtle.decrypt(
                {
                    name: "AES-GCM",
                    iv,
                    tagLength: 128,
                },
                cryptoKey,
                ciphertext
            );


        const vault =
            JSON.parse(
                new TextDecoder().decode(
                    plaintext
                )
            );


        if (
            !vault ||
            typeof vault !==
                "object"
        ) {
            throw new Error(
                "Invalid vault."
            );
        }


        return vault;
    } catch {
        clearInvalidSession();

        throw new Error(
            "Unable to restore the Key Vault session. Unlock Key Vault again."
        );
    } finally {
        clearBytes(
            rawSessionKey
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Get OpenPGP identity from the unlocked vault
 * --------------------------------------------------------------------------
 */

export async function getOpenPgpIdentity() {
    const vault =
        await getUnlockedVault();

    /*
     * This matches the canonical Alliances Key Vault format:
     *
     * vault.identity.openpgp
     *
     * {
     *     publicKey: "...",
     *     privateKey: "...",
     *     fingerprint: "..."
     * }
     */
    const identity =
        vault.identity?.openpgp ??
        null;


    if (
        !identity ||
        typeof identity !== "object"
    ) {
        throw new Error(
            "No OpenPGP identity exists in your Key Vault."
        );
    }


    const publicKey =
        identity.publicKey;

    const privateKey =
        identity.privateKey;

    const fingerprint =
        identity.fingerprint;


    if (
        typeof publicKey !== "string" ||
        publicKey === "" ||
        !publicKey.includes(
            "-----BEGIN PGP PUBLIC KEY BLOCK-----"
        )
    ) {
        throw new Error(
            "Your Key Vault does not contain a valid OpenPGP public key."
        );
    }


    if (
        typeof privateKey !== "string" ||
        privateKey === "" ||
        !privateKey.includes(
            "-----BEGIN PGP PRIVATE KEY BLOCK-----"
        )
    ) {
        throw new Error(
            "Your Key Vault does not contain a valid OpenPGP private key."
        );
    }


    if (
        typeof fingerprint !== "string" ||
        fingerprint === ""
    ) {
        throw new Error(
            "Your Key Vault does not contain a valid OpenPGP fingerprint."
        );
    }


    return {
        publicKey,
        privateKey,
        fingerprint,
    };
}


/*
 * --------------------------------------------------------------------------
 * Get parsed OpenPGP private key
 * --------------------------------------------------------------------------
 */

export async function getOpenPgpPrivateKey() {
    const identity =
        await getOpenPgpIdentity();


    const privateKey =
        await openpgp.readPrivateKey({
            armoredKey:
                identity.privateKey,
        });


    /*
     * Alliances currently protects this private key by storing it
     * inside the encrypted Key Vault rather than giving the OpenPGP
     * key itself another passphrase.
     */
    if (
        typeof privateKey.isDecrypted ===
            "function" &&
        !privateKey.isDecrypted()
    ) {
        throw new Error(
            "Your OpenPGP private key is still locked."
        );
    }


    return privateKey;
}