"use strict";

import {
    AlliancesXlsxEngine,
    cellAddress,
    columnIndexToName,
} from "./drive-xlsx-engine.js";


const DEFAULT_ROWS = 100;
const DEFAULT_COLUMNS = 26;


/*
|--------------------------------------------------------------------------
| Alliances XLSX Editor
|--------------------------------------------------------------------------
|
| Excel-like browser-side editor UI.
|
| This module does NOT:
| - upload files
| - decrypt files
| - encrypt files
| - communicate with PHP
|
| It receives a plaintext XLSX Blob from the existing Drive editor
| controller and returns a plaintext XLSX Blob through getSaveBlob().
|
| The existing Drive controller remains responsible for encryption
| and encrypted version saving.
|
*/


export class AlliancesXlsxEditor {
    constructor({
        container,
        blob = null,
        fileName = "Workbook.xlsx",
        canEdit = true,
    } = {}) {
        if (!(container instanceof HTMLElement)) {
            throw new Error(
                "The XLSX editor requires a container element."
            );
        }

        this.container = container;
        this.blob = blob;
        this.fileName = fileName;
        this.canEdit = Boolean(canEdit);

        this.engine =
            new AlliancesXlsxEngine();

        this.selectedRow = 0;
        this.selectedColumn = 0;

        this.editingCell = null;

        this.minimumRows =
            DEFAULT_ROWS;

        this.minimumColumns =
            DEFAULT_COLUMNS;

        this.elements = {};

        this.unsubscribeEngine = null;

        this.boundKeyDown =
            this.handleKeyDown.bind(this);

        this.boundBeforeUnload =
            this.handleBeforeUnload.bind(this);
    }


    /*
    |--------------------------------------------------------------------------
    | Initialization
    |--------------------------------------------------------------------------
    */

    async initialize() {
        if (this.blob instanceof Blob) {
            await this.engine.loadBlob(
                this.blob,
                this.fileName
            );
        } else {
            await this.engine.createBlank(
                this.fileName
            );
        }

        this.renderShell();

        this.unsubscribeEngine =
            this.engine.onChange(
                () => {
                    this.updateSaveState();
                }
            );

        this.renderWorkbook();

        document.addEventListener(
            "keydown",
            this.boundKeyDown
        );

        window.addEventListener(
            "beforeunload",
            this.boundBeforeUnload
        );

        return this;
    }


    destroy() {
        document.removeEventListener(
            "keydown",
            this.boundKeyDown
        );

        window.removeEventListener(
            "beforeunload",
            this.boundBeforeUnload
        );

        if (this.unsubscribeEngine) {
            this.unsubscribeEngine();
            this.unsubscribeEngine = null;
        }

        this.container.innerHTML = "";
    }


    /*
    |--------------------------------------------------------------------------
    | Shell
    |--------------------------------------------------------------------------
    */

    renderShell() {
        this.container.innerHTML = `
            <div class="xlsx-editor">

                <div class="xlsx-toolbar">

                    <div class="xlsx-toolbar-group">

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="undo"
                            title="Undo"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            ↶
                        </button>

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="redo"
                            title="Redo"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            ↷
                        </button>

                    </div>


                    <div class="xlsx-toolbar-divider"></div>


                    <div class="xlsx-toolbar-group">

                        <button
                            type="button"
                            class="xlsx-toolbar-button xlsx-format-button"
                            data-xlsx-action="bold"
                            title="Bold"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            <strong>B</strong>
                        </button>

                        <button
                            type="button"
                            class="xlsx-toolbar-button xlsx-format-button"
                            data-xlsx-action="italic"
                            title="Italic"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            <em>I</em>
                        </button>

                        <button
                            type="button"
                            class="xlsx-toolbar-button xlsx-format-button"
                            data-xlsx-action="underline"
                            title="Underline"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            <span style="text-decoration: underline;">U</span>
                        </button>

                    </div>


                    <div class="xlsx-toolbar-divider"></div>


                    <div class="xlsx-toolbar-group">

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="insert-row"
                            title="Insert row above"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            + Row
                        </button>

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="insert-column"
                            title="Insert column to the left"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            + Column
                        </button>

                    </div>


                    <div class="xlsx-toolbar-divider"></div>


                    <div class="xlsx-toolbar-group">

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="delete-row"
                            title="Delete selected row"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            Delete row
                        </button>

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="delete-column"
                            title="Delete selected column"
                            ${this.canEdit ? "" : "disabled"}
                        >
                            Delete column
                        </button>

                    </div>


                    <div class="xlsx-toolbar-spacer"></div>


                    <div class="xlsx-toolbar-group">

                        <button
                            type="button"
                            class="xlsx-toolbar-button"
                            data-xlsx-action="find"
                            title="Find"
                        >
                            Find
                        </button>

                    </div>

                </div>


                <div class="xlsx-formula-bar">

                    <div
                        class="xlsx-name-box"
                        data-xlsx-name-box
                    >
                        A1
                    </div>

                    <div class="xlsx-formula-symbol">
                        fx
                    </div>

                    <input
                        type="text"
                        class="xlsx-formula-input"
                        data-xlsx-formula-input
                        autocomplete="off"
                        spellcheck="false"
                        ${this.canEdit ? "" : "readonly"}
                    >

                </div>


                <div
                    class="xlsx-find-bar"
                    data-xlsx-find-bar
                    hidden
                >

                    <input
                        type="search"
                        class="xlsx-find-input"
                        data-xlsx-find-input
                        placeholder="Find in worksheet"
                        autocomplete="off"
                    >

                    <span
                        class="xlsx-find-result"
                        data-xlsx-find-result
                    ></span>

                    <button
                        type="button"
                        class="xlsx-toolbar-button"
                        data-xlsx-action="find-next"
                    >
                        Next
                    </button>

                    <button
                        type="button"
                        class="xlsx-toolbar-button"
                        data-xlsx-action="close-find"
                    >
                        ×
                    </button>

                </div>


                <div
                    class="xlsx-grid-viewport"
                    data-xlsx-grid-viewport
                >
                    <table
                        class="xlsx-grid"
                        data-xlsx-grid
                    ></table>
                </div>


                <div class="xlsx-bottom-bar">

                    <div
                        class="xlsx-sheet-tabs"
                        data-xlsx-sheet-tabs
                    ></div>

                    ${
                        this.canEdit
                            ? `
                                <button
                                    type="button"
                                    class="xlsx-add-sheet-button"
                                    data-xlsx-action="add-sheet"
                                    title="Add worksheet"
                                >
                                    +
                                </button>
                            `
                            : ""
                    }

                    <div class="xlsx-bottom-spacer"></div>

                    <div
                        class="xlsx-editor-state"
                        data-xlsx-editor-state
                    >
                        Ready
                    </div>

                </div>

            </div>
        `;


        this.elements.grid =
            this.container.querySelector(
                "[data-xlsx-grid]"
            );

        this.elements.viewport =
            this.container.querySelector(
                "[data-xlsx-grid-viewport]"
            );

        this.elements.nameBox =
            this.container.querySelector(
                "[data-xlsx-name-box]"
            );

        this.elements.formulaInput =
            this.container.querySelector(
                "[data-xlsx-formula-input]"
            );

        this.elements.sheetTabs =
            this.container.querySelector(
                "[data-xlsx-sheet-tabs]"
            );

        this.elements.state =
            this.container.querySelector(
                "[data-xlsx-editor-state]"
            );

        this.elements.findBar =
            this.container.querySelector(
                "[data-xlsx-find-bar]"
            );

        this.elements.findInput =
            this.container.querySelector(
                "[data-xlsx-find-input]"
            );

        this.elements.findResult =
            this.container.querySelector(
                "[data-xlsx-find-result]"
            );


        this.container.addEventListener(
            "click",
            (event) => {
                this.handleClick(event);
            }
        );


        this.elements.formulaInput
            .addEventListener(
                "keydown",
                (event) => {
                    if (
                        event.key === "Enter" &&
                        this.canEdit
                    ) {
                        event.preventDefault();

                        this.commitFormulaInput();
                    }
                }
            );


        this.elements.formulaInput
            .addEventListener(
                "blur",
                () => {
                    if (this.canEdit) {
                        this.commitFormulaInput();
                    }
                }
            );


        this.elements.findInput
            .addEventListener(
                "input",
                () => {
                    this.runFind();
                }
            );


        this.elements.findInput
            .addEventListener(
                "keydown",
                (event) => {
                    if (event.key === "Enter") {
                        event.preventDefault();

                        this.selectNextFindResult();
                    }

                    if (event.key === "Escape") {
                        event.preventDefault();

                        this.closeFind();
                    }
                }
            );
    }


    /*
    |--------------------------------------------------------------------------
    | Workbook rendering
    |--------------------------------------------------------------------------
    */

    renderWorkbook() {
        this.renderGrid();
        this.renderSheetTabs();
        this.updateSelection();
        this.updateSaveState();
    }


    renderGrid() {
        const sheetName =
            this.engine.getActiveSheetName();

        const range =
            this.engine.getSheetRange(
                sheetName
            );

        const rowCount =
            Math.max(
                this.minimumRows,
                range.endRow + 10
            );

        const columnCount =
            Math.max(
                this.minimumColumns,
                range.endColumn + 5
            );


        const table =
            this.elements.grid;

        table.innerHTML = "";


        /*
         * Column headers
         */
        const thead =
            document.createElement(
                "thead"
            );

        const headerRow =
            document.createElement(
                "tr"
            );


        const corner =
            document.createElement(
                "th"
            );

        corner.className =
            "xlsx-grid-corner";

        headerRow.appendChild(
            corner
        );


        for (
            let column = 0;
            column < columnCount;
            column += 1
        ) {
            const header =
                document.createElement(
                    "th"
                );

            header.className =
                "xlsx-column-header";

            header.dataset.column =
                String(column);

            header.textContent =
                columnIndexToName(
                    column
                );


            const width =
                this.engine.getColumnWidth(
                    column,
                    sheetName
                );

            header.style.width =
                `${width}px`;

            header.style.minWidth =
                `${width}px`;

            header.style.maxWidth =
                `${width}px`;


            headerRow.appendChild(
                header
            );
        }


        thead.appendChild(
            headerRow
        );

        table.appendChild(
            thead
        );


        /*
         * Worksheet cells
         */
        const tbody =
            document.createElement(
                "tbody"
            );


        for (
            let row = 0;
            row < rowCount;
            row += 1
        ) {
            const rowElement =
                document.createElement(
                    "tr"
                );


            const rowHeader =
                document.createElement(
                    "th"
                );

            rowHeader.className =
                "xlsx-row-header";

            rowHeader.dataset.row =
                String(row);

            rowHeader.textContent =
                String(row + 1);

            rowElement.appendChild(
                rowHeader
            );


            for (
                let column = 0;
                column < columnCount;
                column += 1
            ) {
                const cell =
                    this.createCellElement(
                        row,
                        column,
                        sheetName
                    );


                rowElement.appendChild(
                    cell
                );
            }


            tbody.appendChild(
                rowElement
            );
        }


        table.appendChild(
            tbody
        );
    }


    createCellElement(
        row,
        column,
        sheetName
    ) {
        const element =
            document.createElement(
                "td"
            );

        element.className =
            "xlsx-cell";

        element.dataset.row =
            String(row);

        element.dataset.column =
            String(column);

        element.dataset.address =
            cellAddress(
                row,
                column
            );


        const width =
            this.engine.getColumnWidth(
                column,
                sheetName
            );

        element.style.width =
            `${width}px`;

        element.style.minWidth =
            `${width}px`;

        element.style.maxWidth =
            `${width}px`;


        const value =
            this.engine
                .getCellFormattedValue(
                    row,
                    column,
                    sheetName
                );


        element.textContent =
            value;


        this.applyCellVisualStyle(
            element,
            row,
            column,
            sheetName
        );


        return element;
    }


    applyCellVisualStyle(
        element,
        row,
        column,
        sheetName
    ) {
        const style =
            this.engine.getCellStyle(
                row,
                column,
                sheetName
            );


        if (style?.font?.bold) {
            element.style.fontWeight =
                "700";
        }


        if (style?.font?.italic) {
            element.style.fontStyle =
                "italic";
        }


        if (style?.font?.underline) {
            element.style.textDecoration =
                "underline";
        }


        const horizontal =
            style?.alignment?.horizontal;


        if (
            horizontal === "center" ||
            horizontal === "right" ||
            horizontal === "left"
        ) {
            element.style.textAlign =
                horizontal;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Sheet tabs
    |--------------------------------------------------------------------------
    */

    renderSheetTabs() {
        const container =
            this.elements.sheetTabs;

        container.innerHTML = "";


        const activeSheet =
            this.engine.getActiveSheetName();


        for (
            const sheetName
            of this.engine.getSheetNames()
        ) {
            const button =
                document.createElement(
                    "button"
                );

            button.type =
                "button";

            button.className =
                "xlsx-sheet-tab";

            if (
                sheetName ===
                activeSheet
            ) {
                button.classList.add(
                    "is-active"
                );
            }

            button.dataset.sheetName =
                sheetName;

            button.textContent =
                sheetName;

            button.title =
                this.canEdit
                    ? "Click to open. Double-click to rename."
                    : "Open worksheet";


            button.addEventListener(
                "dblclick",
                (event) => {
                    event.preventDefault();

                    if (!this.canEdit) {
                        return;
                    }

                    this.renameSheet(
                        sheetName
                    );
                }
            );


            container.appendChild(
                button
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Selection
    |--------------------------------------------------------------------------
    */

    selectCell(
        row,
        column,
        {
            scrollIntoView = false,
        } = {}
    ) {
        this.selectedRow =
            Math.max(
                0,
                Number(row) || 0
            );

        this.selectedColumn =
            Math.max(
                0,
                Number(column) || 0
            );


        this.ensureGridContainsSelection();

        this.updateSelection();


        if (scrollIntoView) {
            const cell =
                this.getSelectedCellElement();

            cell?.scrollIntoView({
                block: "nearest",
                inline: "nearest",
            });
        }
    }


    ensureGridContainsSelection() {
        const rows =
            this.elements.grid
                .querySelectorAll(
                    "tbody tr"
                ).length;

        const columns =
            this.elements.grid
                .querySelectorAll(
                    "thead .xlsx-column-header"
                ).length;


        if (
            this.selectedRow >= rows ||
            this.selectedColumn >= columns
        ) {
            this.minimumRows =
                Math.max(
                    this.minimumRows,
                    this.selectedRow + 20
                );

            this.minimumColumns =
                Math.max(
                    this.minimumColumns,
                    this.selectedColumn + 10
                );

            this.renderGrid();
        }
    }


    updateSelection() {
        this.container
            .querySelectorAll(
                ".xlsx-cell.is-selected"
            )
            .forEach(
                (element) => {
                    element.classList.remove(
                        "is-selected"
                    );
                }
            );


        this.container
            .querySelectorAll(
                ".xlsx-row-header.is-selected"
            )
            .forEach(
                (element) => {
                    element.classList.remove(
                        "is-selected"
                    );
                }
            );


        this.container
            .querySelectorAll(
                ".xlsx-column-header.is-selected"
            )
            .forEach(
                (element) => {
                    element.classList.remove(
                        "is-selected"
                    );
                }
            );


        const cell =
            this.getSelectedCellElement();


        if (cell) {
            cell.classList.add(
                "is-selected"
            );
        }


        const rowHeader =
            this.container.querySelector(
                `.xlsx-row-header[data-row="${this.selectedRow}"]`
            );

        rowHeader?.classList.add(
            "is-selected"
        );


        const columnHeader =
            this.container.querySelector(
                `.xlsx-column-header[data-column="${this.selectedColumn}"]`
            );

        columnHeader?.classList.add(
            "is-selected"
        );


        this.elements.nameBox.textContent =
            cellAddress(
                this.selectedRow,
                this.selectedColumn
            );


        this.elements.formulaInput.value =
            this.engine.getCellDisplayValue(
                this.selectedRow,
                this.selectedColumn
            );


        this.updateFormattingButtons();
    }


    getSelectedCellElement() {
        return this.container.querySelector(
            `.xlsx-cell[data-row="${this.selectedRow}"][data-column="${this.selectedColumn}"]`
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Cell editing
    |--------------------------------------------------------------------------
    */

    beginCellEdit(
        cell,
        initialText = null
    ) {
        if (
            !this.canEdit ||
            !(cell instanceof HTMLElement)
        ) {
            return;
        }


        this.finishCellEdit(
            false
        );


        const row =
            Number(
                cell.dataset.row
            );

        const column =
            Number(
                cell.dataset.column
            );


        this.selectCell(
            row,
            column
        );


        const originalValue =
            this.engine.getCellDisplayValue(
                row,
                column
            );


        const input =
            document.createElement(
                "input"
            );

        input.type =
            "text";

        input.className =
            "xlsx-cell-input";

        input.value =
            initialText !== null
                ? initialText
                : originalValue;

        input.spellcheck =
            false;


        cell.textContent = "";

        cell.appendChild(
            input
        );

        cell.classList.add(
            "is-editing"
        );


        this.editingCell = {
            element: cell,
            input,
            row,
            column,
            originalValue,
        };


        input.addEventListener(
            "keydown",
            (event) => {
                if (event.key === "Enter") {
                    event.preventDefault();

                    this.finishCellEdit(
                        true
                    );

                    this.selectCell(
                        row + 1,
                        column,
                        {
                            scrollIntoView:
                                true,
                        }
                    );
                }


                if (event.key === "Tab") {
                    event.preventDefault();

                    this.finishCellEdit(
                        true
                    );

                    this.selectCell(
                        row,
                        column + (
                            event.shiftKey
                                ? -1
                                : 1
                        ),
                        {
                            scrollIntoView:
                                true,
                        }
                    );
                }


                if (event.key === "Escape") {
                    event.preventDefault();

                    this.finishCellEdit(
                        false
                    );
                }
            }
        );


        input.addEventListener(
            "blur",
            () => {
                this.finishCellEdit(
                    true
                );
            }
        );


        input.focus();

        input.select();
    }


    finishCellEdit(
        commit = true
    ) {
        if (!this.editingCell) {
            return;
        }


        const {
            element,
            input,
            row,
            column,
            originalValue,
        } =
            this.editingCell;


        /*
         * Clear before changing focus/DOM so the blur handler
         * cannot commit the cell twice.
         */
        this.editingCell =
            null;


        if (commit) {
            const value =
                input.value;

            if (
                value !==
                originalValue
            ) {
                this.engine.setCellValue(
                    row,
                    column,
                    value
                );
            }
        }


        element.classList.remove(
            "is-editing"
        );


        this.refreshCell(
            row,
            column
        );


        this.updateSelection();
    }


    refreshCell(
        row,
        column
    ) {
        const existing =
            this.container.querySelector(
                `.xlsx-cell[data-row="${row}"][data-column="${column}"]`
            );


        if (!existing) {
            return;
        }


        const replacement =
            this.createCellElement(
                row,
                column,
                this.engine
                    .getActiveSheetName()
            );


        existing.replaceWith(
            replacement
        );
    }


    commitFormulaInput() {
        if (!this.canEdit) {
            return;
        }


        const value =
            this.elements
                .formulaInput
                .value;


        const current =
            this.engine.getCellDisplayValue(
                this.selectedRow,
                this.selectedColumn
            );


        if (value === current) {
            return;
        }


        this.engine.setCellValue(
            this.selectedRow,
            this.selectedColumn,
            value
        );


        this.refreshCell(
            this.selectedRow,
            this.selectedColumn
        );


        this.updateSelection();
    }


    /*
    |--------------------------------------------------------------------------
    | Formatting
    |--------------------------------------------------------------------------
    */

    toggleFontStyle(
        property
    ) {
        if (!this.canEdit) {
            return;
        }


        const style =
            this.engine.getCellStyle(
                this.selectedRow,
                this.selectedColumn
            );


        const font = {
            ...(style.font || {}),
        };


        font[property] =
            !Boolean(
                font[property]
            );


        this.engine.patchCellStyle(
            this.selectedRow,
            this.selectedColumn,
            {
                font,
            }
        );


        this.refreshCell(
            this.selectedRow,
            this.selectedColumn
        );


        this.updateSelection();
    }


    updateFormattingButtons() {
        const style =
            this.engine.getCellStyle(
                this.selectedRow,
                this.selectedColumn
            );


        const font =
            style.font || {};


        for (
            const property
            of [
                "bold",
                "italic",
                "underline",
            ]
        ) {
            const button =
                this.container.querySelector(
                    `[data-xlsx-action="${property}"]`
                );


            button?.classList.toggle(
                "is-active",
                Boolean(
                    font[property]
                )
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Rows / columns
    |--------------------------------------------------------------------------
    */

    insertRow() {
        if (!this.canEdit) {
            return;
        }


        this.engine.insertRow(
            this.selectedRow
        );

        this.renderGrid();

        this.updateSelection();
    }


    deleteRow() {
        if (!this.canEdit) {
            return;
        }


        this.engine.deleteRow(
            this.selectedRow
        );


        this.selectedRow =
            Math.max(
                0,
                this.selectedRow - 1
            );


        this.renderGrid();

        this.updateSelection();
    }


    insertColumn() {
        if (!this.canEdit) {
            return;
        }


        this.engine.insertColumn(
            this.selectedColumn
        );

        this.renderGrid();

        this.updateSelection();
    }


    deleteColumn() {
        if (!this.canEdit) {
            return;
        }


        this.engine.deleteColumn(
            this.selectedColumn
        );


        this.selectedColumn =
            Math.max(
                0,
                this.selectedColumn - 1
            );


        this.renderGrid();

        this.updateSelection();
    }


    /*
    |--------------------------------------------------------------------------
    | Worksheet management
    |--------------------------------------------------------------------------
    */

    addSheet() {
        if (!this.canEdit) {
            return;
        }


        this.finishCellEdit(
            true
        );


        this.engine.addSheet(
            "Sheet"
        );


        this.selectedRow = 0;
        this.selectedColumn = 0;

        this.renderWorkbook();
    }


    switchSheet(
        sheetName
    ) {
        this.finishCellEdit(
            true
        );


        this.engine.setActiveSheet(
            sheetName
        );


        this.selectedRow = 0;
        this.selectedColumn = 0;

        this.renderWorkbook();
    }


    renameSheet(
        sheetName
    ) {
        if (!this.canEdit) {
            return;
        }


        const requested =
            window.prompt(
                "Worksheet name:",
                sheetName
            );


        if (requested === null) {
            return;
        }


        try {
            this.engine.renameSheet(
                sheetName,
                requested
            );

            this.renderSheetTabs();
        } catch (error) {
            window.alert(
                error.message ||
                "Unable to rename worksheet."
            );
        }
    }


    deleteActiveSheet() {
        if (!this.canEdit) {
            return;
        }


        const sheetName =
            this.engine.getActiveSheetName();


        if (
            !window.confirm(
                `Delete worksheet "${sheetName}"?`
            )
        ) {
            return;
        }


        try {
            this.engine.deleteSheet(
                sheetName
            );

            this.selectedRow = 0;
            this.selectedColumn = 0;

            this.renderWorkbook();
        } catch (error) {
            window.alert(
                error.message ||
                "Unable to delete worksheet."
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Find
    |--------------------------------------------------------------------------
    */

    openFind() {
        this.elements.findBar.hidden =
            false;

        this.elements.findInput.focus();

        this.elements.findInput.select();

        this.runFind();
    }


    closeFind() {
        this.elements.findBar.hidden =
            true;

        this.findResults = [];
        this.findResultIndex = -1;

        this.elements.findResult.textContent =
            "";
    }


    runFind() {
        const query =
            this.elements
                .findInput
                .value;


        this.findResults =
            this.engine.find(
                query
            );


        this.findResultIndex =
            this.findResults.length
                ? 0
                : -1;


        this.updateFindResultText();


        if (
            this.findResultIndex >= 0
        ) {
            this.goToFindResult(
                this.findResultIndex
            );
        }
    }


    selectNextFindResult() {
        if (
            !Array.isArray(
                this.findResults
            ) ||
            this.findResults.length === 0
        ) {
            this.runFind();
            return;
        }


        this.findResultIndex =
            (
                this.findResultIndex + 1
            ) %
            this.findResults.length;


        this.goToFindResult(
            this.findResultIndex
        );


        this.updateFindResultText();
    }


    goToFindResult(
        index
    ) {
        const result =
            this.findResults?.[
                index
            ];


        if (!result) {
            return;
        }


        this.selectCell(
            result.rowIndex,
            result.columnIndex,
            {
                scrollIntoView:
                    true,
            }
        );
    }


    updateFindResultText() {
        if (
            !this.findResults ||
            this.findResults.length === 0
        ) {
            this.elements
                .findResult
                .textContent =
                this.elements
                    .findInput
                    .value
                    ? "No matches"
                    : "";

            return;
        }


        this.elements
            .findResult
            .textContent =
            `${this.findResultIndex + 1} of ${this.findResults.length}`;
    }


    /*
    |--------------------------------------------------------------------------
    | Click handling
    |--------------------------------------------------------------------------
    */

    handleClick(event) {
        const cell =
            event.target.closest(
                ".xlsx-cell"
            );


        if (
            cell &&
            this.container.contains(
                cell
            )
        ) {
            const row =
                Number(
                    cell.dataset.row
                );

            const column =
                Number(
                    cell.dataset.column
                );


            this.selectCell(
                row,
                column
            );


            if (
                event.detail >= 2 &&
                this.canEdit
            ) {
                this.beginCellEdit(
                    cell
                );
            }

            return;
        }


        const sheetTab =
            event.target.closest(
                "[data-sheet-name]"
            );


        if (sheetTab) {
            this.switchSheet(
                sheetTab.dataset
                    .sheetName
            );

            return;
        }


        const actionButton =
            event.target.closest(
                "[data-xlsx-action]"
            );


        if (!actionButton) {
            return;
        }


        const action =
            actionButton.dataset
                .xlsxAction;


        switch (action) {
            case "bold":
                this.toggleFontStyle(
                    "bold"
                );
                break;

            case "italic":
                this.toggleFontStyle(
                    "italic"
                );
                break;

            case "underline":
                this.toggleFontStyle(
                    "underline"
                );
                break;

            case "insert-row":
                this.insertRow();
                break;

            case "delete-row":
                this.deleteRow();
                break;

            case "insert-column":
                this.insertColumn();
                break;

            case "delete-column":
                this.deleteColumn();
                break;

            case "add-sheet":
                this.addSheet();
                break;

            case "find":
                this.openFind();
                break;

            case "find-next":
                this.selectNextFindResult();
                break;

            case "close-find":
                this.closeFind();
                break;

            /*
             * Undo/redo controls are present in the toolbar now
             * so the layout does not need changing later.
             *
             * History will be wired after the basic editor is
             * connected and tested.
             */
            case "undo":
            case "redo":
                break;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Keyboard handling
    |--------------------------------------------------------------------------
    */

    handleKeyDown(event) {
        if (
            !this.container.isConnected
        ) {
            return;
        }


        const target =
            event.target;


        if (
            target instanceof HTMLInputElement ||
            target instanceof HTMLTextAreaElement
        ) {
            if (
                event.ctrlKey &&
                event.key.toLowerCase() ===
                    "f"
            ) {
                event.preventDefault();
                this.openFind();
            }

            return;
        }


        if (
            event.ctrlKey &&
            event.key.toLowerCase() ===
                "f"
        ) {
            event.preventDefault();

            this.openFind();
            return;
        }


        if (
            event.ctrlKey &&
            event.key.toLowerCase() ===
                "b" &&
            this.canEdit
        ) {
            event.preventDefault();

            this.toggleFontStyle(
                "bold"
            );

            return;
        }


        if (
            event.ctrlKey &&
            event.key.toLowerCase() ===
                "i" &&
            this.canEdit
        ) {
            event.preventDefault();

            this.toggleFontStyle(
                "italic"
            );

            return;
        }


        if (
            event.ctrlKey &&
            event.key.toLowerCase() ===
                "u" &&
            this.canEdit
        ) {
            event.preventDefault();

            this.toggleFontStyle(
                "underline"
            );

            return;
        }


        if (
            event.key === "Enter"
        ) {
            event.preventDefault();


            if (this.canEdit) {
                const cell =
                    this.getSelectedCellElement();

                this.beginCellEdit(
                    cell
                );
            }

            return;
        }


        if (
            event.key === "Delete" &&
            this.canEdit
        ) {
            event.preventDefault();

            this.engine.setCellValue(
                this.selectedRow,
                this.selectedColumn,
                ""
            );

            this.refreshCell(
                this.selectedRow,
                this.selectedColumn
            );

            this.updateSelection();

            return;
        }


        if (
            this.canEdit &&
            event.key.length === 1 &&
            !event.ctrlKey &&
            !event.metaKey &&
            !event.altKey
        ) {
            event.preventDefault();

            const cell =
                this.getSelectedCellElement();

            this.beginCellEdit(
                cell,
                event.key
            );

            return;
        }


        let nextRow =
            this.selectedRow;

        let nextColumn =
            this.selectedColumn;


        switch (event.key) {
            case "ArrowUp":
                nextRow -= 1;
                break;

            case "ArrowDown":
                nextRow += 1;
                break;

            case "ArrowLeft":
                nextColumn -= 1;
                break;

            case "ArrowRight":
                nextColumn += 1;
                break;

            case "Tab":
                nextColumn +=
                    event.shiftKey
                        ? -1
                        : 1;
                break;

            default:
                return;
        }


        event.preventDefault();


        this.selectCell(
            Math.max(
                0,
                nextRow
            ),
            Math.max(
                0,
                nextColumn
            ),
            {
                scrollIntoView:
                    true,
            }
        );
    }


    /*
    |--------------------------------------------------------------------------
    | State
    |--------------------------------------------------------------------------
    */

    updateSaveState() {
        if (!this.elements.state) {
            return;
        }


        if (!this.canEdit) {
            this.elements
                .state
                .textContent =
                "View only";

            return;
        }


        this.elements
            .state
            .textContent =
            this.engine.isDirty()
                ? "Unsaved changes"
                : "Saved";
    }


    markSaved() {
        this.engine.markSaved();

        this.updateSaveState();
    }


    handleBeforeUnload(event) {
        if (
            !this.canEdit ||
            !this.engine.isDirty()
        ) {
            return;
        }


        event.preventDefault();

        event.returnValue = "";
    }


    /*
    |--------------------------------------------------------------------------
    | Drive editor interface
    |--------------------------------------------------------------------------
    */

    async getSaveBlob() {
        this.finishCellEdit(
            true
        );

        this.commitFormulaInput();

        return this.engine
            .getSaveBlob();
    }


    isDirty() {
        return this.engine.isDirty();
    }
}


/*
|--------------------------------------------------------------------------
| Convenience initializer
|--------------------------------------------------------------------------
*/

export async function createXlsxEditor(
    options
) {
    const editor =
        new AlliancesXlsxEditor(
            options
        );

    await editor.initialize();

    return editor;
}