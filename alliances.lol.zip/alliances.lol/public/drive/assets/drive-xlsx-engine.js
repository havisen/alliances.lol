"use strict";

/*
|--------------------------------------------------------------------------
| Alliances Drive XLSX Engine
|--------------------------------------------------------------------------
|
| Browser-side XLSX workbook engine.
|
| Responsibilities:
|
| - Load an XLSX Blob locally.
| - Keep the workbook in browser memory only.
| - Expose worksheets and cells to the editor UI.
| - Edit cell values and formulas.
| - Add / rename / delete worksheets.
| - Add / delete rows and columns.
| - Preserve basic cell formatting.
| - Export the edited workbook back to a real XLSX Blob.
|
| The XLSX library is loaded locally from:
|
| /assets/vendor/xlsx/xlsx.full.min.js
|
| Plaintext workbook contents are never sent to PHP by this module.
|
*/


const XLSX_LIBRARY_URL =
    "/assets/vendor/xlsx/xlsx.full.min.js";


let xlsxLibraryPromise = null;


/*
|--------------------------------------------------------------------------
| Load local SheetJS library
|--------------------------------------------------------------------------
*/

function loadXlsxLibrary() {
    if (
        window.XLSX &&
        typeof window.XLSX.read === "function" &&
        typeof window.XLSX.write === "function"
    ) {
        return Promise.resolve(window.XLSX);
    }


    if (xlsxLibraryPromise) {
        return xlsxLibraryPromise;
    }


    xlsxLibraryPromise =
        new Promise((resolve, reject) => {
            const existingScript =
                document.querySelector(
                    'script[data-alliances-xlsx-library="1"]'
                );


            if (existingScript) {
                existingScript.addEventListener(
                    "load",
                    () => {
                        if (window.XLSX) {
                            resolve(window.XLSX);
                            return;
                        }

                        reject(
                            new Error(
                                "The XLSX library loaded but did not initialize."
                            )
                        );
                    },
                    {
                        once: true,
                    }
                );

                existingScript.addEventListener(
                    "error",
                    () => {
                        reject(
                            new Error(
                                "Unable to load the XLSX library."
                            )
                        );
                    },
                    {
                        once: true,
                    }
                );

                return;
            }


            const script =
                document.createElement("script");

            script.src =
                XLSX_LIBRARY_URL;

            script.async = true;

            script.dataset.alliancesXlsxLibrary =
                "1";


            script.addEventListener(
                "load",
                () => {
                    if (
                        !window.XLSX ||
                        typeof window.XLSX.read !== "function" ||
                        typeof window.XLSX.write !== "function"
                    ) {
                        reject(
                            new Error(
                                "The XLSX library is unavailable."
                            )
                        );

                        return;
                    }


                    resolve(
                        window.XLSX
                    );
                },
                {
                    once: true,
                }
            );


            script.addEventListener(
                "error",
                () => {
                    reject(
                        new Error(
                            "Unable to load the local XLSX library."
                        )
                    );
                },
                {
                    once: true,
                }
            );


            document.head.appendChild(
                script
            );
        });


    return xlsxLibraryPromise;
}


/*
|--------------------------------------------------------------------------
| Utility helpers
|--------------------------------------------------------------------------
*/

function cloneSimpleValue(value) {
    if (
        value === null ||
        value === undefined
    ) {
        return value;
    }


    if (value instanceof Date) {
        return new Date(
            value.getTime()
        );
    }


    if (Array.isArray(value)) {
        return value.map(
            cloneSimpleValue
        );
    }


    if (typeof value === "object") {
        const result = {};

        for (
            const [key, item]
            of Object.entries(value)
        ) {
            result[key] =
                cloneSimpleValue(item);
        }

        return result;
    }


    return value;
}


function normalizeSheetName(name) {
    let normalized =
        String(name ?? "")
            .trim();


    normalized =
        normalized.replace(
            /[\\/*?:[\]]/g,
            " "
        );


    normalized =
        normalized.replace(
            /\s+/g,
            " "
        );


    if (normalized === "") {
        normalized = "Sheet";
    }


    return normalized.slice(
        0,
        31
    );
}


function columnIndexToName(index) {
    let value =
        Number(index);

    if (
        !Number.isInteger(value) ||
        value < 0
    ) {
        throw new Error(
            "Invalid column index."
        );
    }


    let name = "";

    value += 1;


    while (value > 0) {
        const remainder =
            (value - 1) % 26;

        name =
            String.fromCharCode(
                65 + remainder
            ) + name;

        value =
            Math.floor(
                (value - 1) / 26
            );
    }


    return name;
}


function cellAddress(
    rowIndex,
    columnIndex
) {
    return (
        columnIndexToName(
            columnIndex
        )
        +
        String(
            rowIndex + 1
        )
    );
}


function parseCellInput(value) {
    const text =
        String(
            value ?? ""
        );


    if (
        text.startsWith("=") &&
        text.length > 1
    ) {
        return {
            type: "formula",
            formula:
                text.slice(1),
        };
    }


    const trimmed =
        text.trim();


    if (trimmed === "") {
        return {
            type: "blank",
            value: "",
        };
    }


    if (
        trimmed === "TRUE" ||
        trimmed === "FALSE"
    ) {
        return {
            type: "boolean",
            value:
                trimmed === "TRUE",
        };
    }


    /*
     * Only treat a value as numeric when the entire string
     * represents a normal number.
     *
     * Values such as phone numbers, IDs with leading zeros,
     * dates and mixed strings remain text.
     */
    if (
        /^-?(?:0|[1-9]\d*)(?:\.\d+)?$/.test(
            trimmed
        ) &&
        !(
            /^0\d+/.test(trimmed) &&
            !/^0\./.test(trimmed)
        )
    ) {
        const numericValue =
            Number(trimmed);

        if (
            Number.isFinite(
                numericValue
            )
        ) {
            return {
                type: "number",
                value:
                    numericValue,
            };
        }
    }


    return {
        type: "string",
        value: text,
    };
}


/*
|--------------------------------------------------------------------------
| Engine
|--------------------------------------------------------------------------
*/

export class AlliancesXlsxEngine {
    constructor() {
        this.XLSX = null;

        this.workbook = null;

        this.originalName =
            "Workbook.xlsx";

        this.activeSheetName =
            null;

        this.dirty = false;

        this.changeListeners =
            new Set();
    }


    /*
    |--------------------------------------------------------------------------
    | Initialize
    |--------------------------------------------------------------------------
    */

    async initialize() {
        if (!this.XLSX) {
            this.XLSX =
                await loadXlsxLibrary();
        }

        return this;
    }


    /*
    |--------------------------------------------------------------------------
    | Change events
    |--------------------------------------------------------------------------
    */

    onChange(listener) {
        if (
            typeof listener !==
            "function"
        ) {
            return () => {};
        }


        this.changeListeners.add(
            listener
        );


        return () => {
            this.changeListeners.delete(
                listener
            );
        };
    }


    emitChange(detail = {}) {
        this.dirty = true;


        for (
            const listener
            of this.changeListeners
        ) {
            try {
                listener({
                    ...detail,
                    engine: this,
                });
            } catch (error) {
                console.error(
                    "XLSX change listener failed:",
                    error
                );
            }
        }
    }


    markSaved() {
        this.dirty = false;
    }


    isDirty() {
        return this.dirty;
    }


    /*
    |--------------------------------------------------------------------------
    | Load existing workbook
    |--------------------------------------------------------------------------
    */

    async loadBlob(
        blob,
        originalName = "Workbook.xlsx"
    ) {
        await this.initialize();


        if (!(blob instanceof Blob)) {
            throw new Error(
                "A workbook Blob is required."
            );
        }


        const arrayBuffer =
            await blob.arrayBuffer();


        try {
            this.workbook =
                this.XLSX.read(
                    arrayBuffer,
                    {
                        type: "array",

                        cellDates: true,

                        cellFormula: true,

                        cellStyles: true,

                        cellNF: true,

                        cellText: true,

                        dense: false,
                    }
                );
        } catch (error) {
            console.error(
                "Unable to parse XLSX workbook:",
                error
            );

            throw new Error(
                "This XLSX workbook could not be opened."
            );
        }


        if (
            !this.workbook ||
            !Array.isArray(
                this.workbook.SheetNames
            )
        ) {
            throw new Error(
                "The workbook structure is invalid."
            );
        }


        if (
            this.workbook.SheetNames.length ===
            0
        ) {
            const sheet =
                this.XLSX.utils.aoa_to_sheet([
                    [""],
                ]);

            this.XLSX.utils.book_append_sheet(
                this.workbook,
                sheet,
                "Sheet1"
            );
        }


        this.originalName =
            String(
                originalName ||
                "Workbook.xlsx"
            );


        this.activeSheetName =
            this.workbook
                .SheetNames[0];


        this.dirty = false;


        return this;
    }


    /*
    |--------------------------------------------------------------------------
    | Create blank workbook
    |--------------------------------------------------------------------------
    */

    async createBlank(
        originalName = "Workbook.xlsx"
    ) {
        await this.initialize();


        this.workbook =
            this.XLSX.utils.book_new();


        const sheet =
            this.XLSX.utils.aoa_to_sheet([
                [""],
            ]);


        this.XLSX.utils.book_append_sheet(
            this.workbook,
            sheet,
            "Sheet1"
        );


        this.originalName =
            String(
                originalName ||
                "Workbook.xlsx"
            );


        this.activeSheetName =
            "Sheet1";

        this.dirty = true;


        return this;
    }


    /*
    |--------------------------------------------------------------------------
    | Workbook state
    |--------------------------------------------------------------------------
    */

    requireWorkbook() {
        if (!this.workbook) {
            throw new Error(
                "No XLSX workbook is currently loaded."
            );
        }


        return this.workbook;
    }


    getWorkbook() {
        return this.requireWorkbook();
    }


    getSheetNames() {
        return [
            ...this
                .requireWorkbook()
                .SheetNames,
        ];
    }


    getActiveSheetName() {
        this.requireWorkbook();

        return this.activeSheetName;
    }


    setActiveSheet(
        sheetName
    ) {
        const workbook =
            this.requireWorkbook();


        if (
            !workbook.Sheets[
                sheetName
            ]
        ) {
            throw new Error(
                "Worksheet not found."
            );
        }


        this.activeSheetName =
            sheetName;


        return sheetName;
    }


    getSheet(
        sheetName =
            this.activeSheetName
    ) {
        const workbook =
            this.requireWorkbook();


        const sheet =
            workbook.Sheets[
                sheetName
            ];


        if (!sheet) {
            throw new Error(
                "Worksheet not found."
            );
        }


        return sheet;
    }


    /*
    |--------------------------------------------------------------------------
    | Worksheet dimensions
    |--------------------------------------------------------------------------
    */

    getSheetRange(
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        if (!sheet["!ref"]) {
            return {
                startRow: 0,
                startColumn: 0,
                endRow: 0,
                endColumn: 0,
            };
        }


        const decoded =
            this.XLSX.utils.decode_range(
                sheet["!ref"]
            );


        return {
            startRow:
                decoded.s.r,

            startColumn:
                decoded.s.c,

            endRow:
                decoded.e.r,

            endColumn:
                decoded.e.c,
        };
    }


    ensureRangeIncludes(
        sheet,
        rowIndex,
        columnIndex
    ) {
        let range;


        if (sheet["!ref"]) {
            range =
                this.XLSX.utils.decode_range(
                    sheet["!ref"]
                );
        } else {
            range = {
                s: {
                    r: rowIndex,
                    c: columnIndex,
                },

                e: {
                    r: rowIndex,
                    c: columnIndex,
                },
            };
        }


        range.s.r =
            Math.min(
                range.s.r,
                rowIndex
            );

        range.s.c =
            Math.min(
                range.s.c,
                columnIndex
            );

        range.e.r =
            Math.max(
                range.e.r,
                rowIndex
            );

        range.e.c =
            Math.max(
                range.e.c,
                columnIndex
            );


        sheet["!ref"] =
            this.XLSX.utils.encode_range(
                range
            );
    }


    /*
    |--------------------------------------------------------------------------
    | Cell access
    |--------------------------------------------------------------------------
    */

    getCell(
        rowIndex,
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        const address =
            cellAddress(
                rowIndex,
                columnIndex
            );


        return (
            sheet[address] ||
            null
        );
    }


    getCellDisplayValue(
        rowIndex,
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const cell =
            this.getCell(
                rowIndex,
                columnIndex,
                sheetName
            );


        if (!cell) {
            return "";
        }


        if (
            typeof cell.f ===
            "string"
        ) {
            return (
                "=" +
                cell.f
            );
        }


        if (
            cell.v === null ||
            cell.v === undefined
        ) {
            return "";
        }


        if (
            cell.v instanceof Date
        ) {
            return cell.v
                .toISOString()
                .slice(0, 10);
        }


        return String(
            cell.v
        );
    }


    getCellFormattedValue(
        rowIndex,
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const cell =
            this.getCell(
                rowIndex,
                columnIndex,
                sheetName
            );


        if (!cell) {
            return "";
        }


        try {
            return this.XLSX.utils.format_cell(
                cell
            );
        } catch {
            if (
                cell.v === null ||
                cell.v === undefined
            ) {
                return "";
            }

            return String(
                cell.v
            );
        }
    }


    getCellFormula(
        rowIndex,
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const cell =
            this.getCell(
                rowIndex,
                columnIndex,
                sheetName
            );


        if (
            !cell ||
            typeof cell.f !==
            "string"
        ) {
            return "";
        }


        return cell.f;
    }


    setCellValue(
        rowIndex,
        columnIndex,
        inputValue,
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        const address =
            cellAddress(
                rowIndex,
                columnIndex
            );


        const existingCell =
            sheet[address] || {};


        const existingStyle =
            existingCell.s
                ? cloneSimpleValue(
                    existingCell.s
                )
                : undefined;


        const existingNumberFormat =
            existingCell.z;


        const parsed =
            parseCellInput(
                inputValue
            );


        if (
            parsed.type ===
            "blank"
        ) {
            /*
             * Keep the cell when it has formatting.
             */
            if (
                existingStyle ||
                existingNumberFormat
            ) {
                sheet[address] = {
                    t: "s",
                    v: "",
                };

                if (existingStyle) {
                    sheet[address].s =
                        existingStyle;
                }

                if (
                    existingNumberFormat
                ) {
                    sheet[address].z =
                        existingNumberFormat;
                }
            } else {
                delete sheet[address];
            }
        } else if (
            parsed.type ===
            "formula"
        ) {
            sheet[address] = {
                t: "n",
                f:
                    parsed.formula,
            };


            if (
                existingCell.v !==
                undefined
            ) {
                sheet[address].v =
                    existingCell.v;
            }


            if (existingStyle) {
                sheet[address].s =
                    existingStyle;
            }


            if (
                existingNumberFormat
            ) {
                sheet[address].z =
                    existingNumberFormat;
            }
        } else {
            const cell = {};


            if (
                parsed.type ===
                "number"
            ) {
                cell.t = "n";
                cell.v =
                    parsed.value;
            } else if (
                parsed.type ===
                "boolean"
            ) {
                cell.t = "b";
                cell.v =
                    parsed.value;
            } else {
                cell.t = "s";
                cell.v =
                    parsed.value;
            }


            if (existingStyle) {
                cell.s =
                    existingStyle;
            }


            if (
                existingNumberFormat
            ) {
                cell.z =
                    existingNumberFormat;
            }


            sheet[address] =
                cell;
        }


        this.ensureRangeIncludes(
            sheet,
            rowIndex,
            columnIndex
        );


        this.emitChange({
            type: "cell",
            sheetName,
            rowIndex,
            columnIndex,
        });


        return this.getCell(
            rowIndex,
            columnIndex,
            sheetName
        );
    }


    /*
    |--------------------------------------------------------------------------
    | Cell style
    |--------------------------------------------------------------------------
    */

    getCellStyle(
        rowIndex,
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const cell =
            this.getCell(
                rowIndex,
                columnIndex,
                sheetName
            );


        return cloneSimpleValue(
            cell?.s || {}
        );
    }


    setCellStyle(
        rowIndex,
        columnIndex,
        style,
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        const address =
            cellAddress(
                rowIndex,
                columnIndex
            );


        if (!sheet[address]) {
            sheet[address] = {
                t: "s",
                v: "",
            };
        }


        sheet[address].s =
            cloneSimpleValue(
                style || {}
            );


        this.ensureRangeIncludes(
            sheet,
            rowIndex,
            columnIndex
        );


        this.emitChange({
            type: "style",
            sheetName,
            rowIndex,
            columnIndex,
        });
    }


    patchCellStyle(
        rowIndex,
        columnIndex,
        patch,
        sheetName =
            this.activeSheetName
    ) {
        const current =
            this.getCellStyle(
                rowIndex,
                columnIndex,
                sheetName
            );


        const next = {
            ...current,
            ...cloneSimpleValue(
                patch || {}
            ),
        };


        this.setCellStyle(
            rowIndex,
            columnIndex,
            next,
            sheetName
        );


        return next;
    }


    /*
    |--------------------------------------------------------------------------
    | Column widths
    |--------------------------------------------------------------------------
    */

    getColumnWidth(
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        const columns =
            sheet["!cols"] || [];


        const column =
            columns[
                columnIndex
            ];


        if (!column) {
            return 100;
        }


        if (
            Number.isFinite(
                column.wpx
            )
        ) {
            return Math.max(
                40,
                column.wpx
            );
        }


        if (
            Number.isFinite(
                column.wch
            )
        ) {
            return Math.max(
                40,
                Math.round(
                    column.wch * 8
                )
            );
        }


        return 100;
    }


    setColumnWidth(
        columnIndex,
        widthPixels,
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        if (
            !Array.isArray(
                sheet["!cols"]
            )
        ) {
            sheet["!cols"] = [];
        }


        const width =
            Math.max(
                40,
                Math.min(
                    600,
                    Math.round(
                        Number(
                            widthPixels
                        ) || 100
                    )
                )
            );


        sheet["!cols"][
            columnIndex
        ] = {
            ...(
                sheet["!cols"][
                    columnIndex
                ] || {}
            ),

            wpx: width,
            wch:
                Math.max(
                    1,
                    width / 8
                ),
        };


        this.emitChange({
            type: "column-width",
            sheetName,
            columnIndex,
            width,
        });
    }


    /*
    |--------------------------------------------------------------------------
    | Worksheet management
    |--------------------------------------------------------------------------
    */

    makeUniqueSheetName(
        requestedName,
        ignoredName = null
    ) {
        const workbook =
            this.requireWorkbook();


        const base =
            normalizeSheetName(
                requestedName
            );


        const existing =
            new Set(
                workbook
                    .SheetNames
                    .filter(
                        (name) =>
                            name !==
                            ignoredName
                    )
                    .map(
                        (name) =>
                            name.toLowerCase()
                    )
            );


        if (
            !existing.has(
                base.toLowerCase()
            )
        ) {
            return base;
        }


        let number = 2;


        while (number < 10000) {
            const suffix =
                ` ${number}`;

            const candidate =
                base
                    .slice(
                        0,
                        Math.max(
                            1,
                            31 -
                            suffix.length
                        )
                    )
                +
                suffix;


            if (
                !existing.has(
                    candidate.toLowerCase()
                )
            ) {
                return candidate;
            }


            number += 1;
        }


        throw new Error(
            "Unable to create a unique worksheet name."
        );
    }


    addSheet(
        requestedName = "Sheet"
    ) {
        const workbook =
            this.requireWorkbook();


        const sheetName =
            this.makeUniqueSheetName(
                requestedName
            );


        const sheet =
            this.XLSX.utils.aoa_to_sheet([
                [""],
            ]);


        this.XLSX.utils.book_append_sheet(
            workbook,
            sheet,
            sheetName
        );


        this.activeSheetName =
            sheetName;


        this.emitChange({
            type: "sheet-add",
            sheetName,
        });


        return sheetName;
    }


    renameSheet(
        oldName,
        requestedName
    ) {
        const workbook =
            this.requireWorkbook();


        if (
            !workbook.Sheets[
                oldName
            ]
        ) {
            throw new Error(
                "Worksheet not found."
            );
        }


        const newName =
            this.makeUniqueSheetName(
                requestedName,
                oldName
            );


        if (
            newName ===
            oldName
        ) {
            return oldName;
        }


        const sheet =
            workbook.Sheets[
                oldName
            ];


        workbook.Sheets[
            newName
        ] =
            sheet;


        delete workbook.Sheets[
            oldName
        ];


        const index =
            workbook.SheetNames
                .indexOf(
                    oldName
                );


        if (index !== -1) {
            workbook.SheetNames[
                index
            ] =
                newName;
        }


        /*
         * Keep workbook sheet metadata synchronized where present.
         */
        if (
            workbook.Workbook &&
            Array.isArray(
                workbook.Workbook.Sheets
            )
        ) {
            const metadata =
                workbook.Workbook
                    .Sheets[
                        index
                    ];

            if (metadata) {
                metadata.name =
                    newName;
            }
        }


        if (
            this.activeSheetName ===
            oldName
        ) {
            this.activeSheetName =
                newName;
        }


        this.emitChange({
            type: "sheet-rename",
            oldName,
            sheetName:
                newName,
        });


        return newName;
    }


    deleteSheet(
        sheetName
    ) {
        const workbook =
            this.requireWorkbook();


        if (
            workbook
                .SheetNames
                .length <= 1
        ) {
            throw new Error(
                "A workbook must contain at least one worksheet."
            );
        }


        const index =
            workbook
                .SheetNames
                .indexOf(
                    sheetName
                );


        if (index === -1) {
            throw new Error(
                "Worksheet not found."
            );
        }


        delete workbook.Sheets[
            sheetName
        ];


        workbook.SheetNames.splice(
            index,
            1
        );


        if (
            workbook.Workbook &&
            Array.isArray(
                workbook.Workbook.Sheets
            )
        ) {
            workbook.Workbook
                .Sheets
                .splice(
                    index,
                    1
                );
        }


        if (
            this.activeSheetName ===
            sheetName
        ) {
            this.activeSheetName =
                workbook.SheetNames[
                    Math.min(
                        index,
                        workbook
                            .SheetNames
                            .length - 1
                    )
                ];
        }


        this.emitChange({
            type: "sheet-delete",
            sheetName,
        });


        return this.activeSheetName;
    }


    /*
    |--------------------------------------------------------------------------
    | Rows / columns
    |--------------------------------------------------------------------------
    */

    getSheetMatrix(
        sheetName =
            this.activeSheetName
    ) {
        const sheet =
            this.getSheet(
                sheetName
            );


        return this.XLSX.utils
            .sheet_to_json(
                sheet,
                {
                    header: 1,
                    raw: true,
                    defval: "",
                }
            );
    }


    rebuildSheetFromMatrix(
        matrix,
        sheetName =
            this.activeSheetName
    ) {
        const workbook =
            this.requireWorkbook();


        const oldSheet =
            this.getSheet(
                sheetName
            );


        const newSheet =
            this.XLSX.utils
                .aoa_to_sheet(
                    matrix.length
                        ? matrix
                        : [[""]]
                );


        /*
         * Preserve sheet-level metadata that can safely survive
         * a matrix rebuild.
         */
        for (
            const property
            of [
                "!cols",
                "!rows",
                "!margins",
                "!protect",
                "!autofilter",
            ]
        ) {
            if (
                oldSheet[
                    property
                ] !== undefined
            ) {
                newSheet[
                    property
                ] =
                    cloneSimpleValue(
                        oldSheet[
                            property
                        ]
                    );
            }
        }


        workbook.Sheets[
            sheetName
        ] =
            newSheet;


        return newSheet;
    }


    insertRow(
        rowIndex,
        sheetName =
            this.activeSheetName
    ) {
        const matrix =
            this.getSheetMatrix(
                sheetName
            );


        const index =
            Math.max(
                0,
                Math.min(
                    Number(
                        rowIndex
                    ) || 0,
                    matrix.length
                )
            );


        const range =
            this.getSheetRange(
                sheetName
            );


        const columnCount =
            Math.max(
                1,
                range.endColumn + 1
            );


        matrix.splice(
            index,
            0,
            new Array(
                columnCount
            ).fill("")
        );


        this.rebuildSheetFromMatrix(
            matrix,
            sheetName
        );


        this.emitChange({
            type: "row-insert",
            sheetName,
            rowIndex:
                index,
        });
    }


    deleteRow(
        rowIndex,
        sheetName =
            this.activeSheetName
    ) {
        const matrix =
            this.getSheetMatrix(
                sheetName
            );


        if (
            matrix.length <= 1
        ) {
            matrix[0] = [""];
        } else if (
            rowIndex >= 0 &&
            rowIndex <
                matrix.length
        ) {
            matrix.splice(
                rowIndex,
                1
            );
        }


        this.rebuildSheetFromMatrix(
            matrix,
            sheetName
        );


        this.emitChange({
            type: "row-delete",
            sheetName,
            rowIndex,
        });
    }


    insertColumn(
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const matrix =
            this.getSheetMatrix(
                sheetName
            );


        if (
            matrix.length === 0
        ) {
            matrix.push([]);
        }


        const index =
            Math.max(
                0,
                Number(
                    columnIndex
                ) || 0
            );


        for (
            const row
            of matrix
        ) {
            while (
                row.length <
                index
            ) {
                row.push("");
            }

            row.splice(
                index,
                0,
                ""
            );
        }


        this.rebuildSheetFromMatrix(
            matrix,
            sheetName
        );


        this.emitChange({
            type: "column-insert",
            sheetName,
            columnIndex:
                index,
        });
    }


    deleteColumn(
        columnIndex,
        sheetName =
            this.activeSheetName
    ) {
        const matrix =
            this.getSheetMatrix(
                sheetName
            );


        for (
            const row
            of matrix
        ) {
            if (
                columnIndex >= 0 &&
                columnIndex <
                    row.length
            ) {
                row.splice(
                    columnIndex,
                    1
                );
            }


            if (
                row.length === 0
            ) {
                row.push("");
            }
        }


        this.rebuildSheetFromMatrix(
            matrix,
            sheetName
        );


        this.emitChange({
            type: "column-delete",
            sheetName,
            columnIndex,
        });
    }


    /*
    |--------------------------------------------------------------------------
    | Search
    |--------------------------------------------------------------------------
    */

    find(
        query,
        {
            sheetName =
                this.activeSheetName,

            matchCase = false,
        } = {}
    ) {
        const search =
            String(
                query ?? ""
            );


        if (search === "") {
            return [];
        }


        const sheet =
            this.getSheet(
                sheetName
            );


        const range =
            this.getSheetRange(
                sheetName
            );


        const needle =
            matchCase
                ? search
                : search.toLowerCase();


        const matches = [];


        for (
            let row =
                range.startRow;

            row <=
                range.endRow;

            row += 1
        ) {
            for (
                let column =
                    range.startColumn;

                column <=
                    range.endColumn;

                column += 1
            ) {
                const value =
                    this.getCellFormattedValue(
                        row,
                        column,
                        sheetName
                    );


                const haystack =
                    matchCase
                        ? value
                        : value.toLowerCase();


                if (
                    haystack.includes(
                        needle
                    )
                ) {
                    matches.push({
                        sheetName,
                        rowIndex: row,
                        columnIndex:
                            column,

                        address:
                            cellAddress(
                                row,
                                column
                            ),

                        value,
                    });
                }
            }
        }


        return matches;
    }


    /*
    |--------------------------------------------------------------------------
    | Export
    |--------------------------------------------------------------------------
    */

    async toBlob() {
        await this.initialize();


        const workbook =
            this.requireWorkbook();


        let output;


        try {
            output =
                this.XLSX.write(
                    workbook,
                    {
                        bookType:
                            "xlsx",

                        type:
                            "array",

                        compression:
                            true,

                        cellStyles:
                            true,
                    }
                );
        } catch (error) {
            console.error(
                "Unable to write XLSX workbook:",
                error
            );

            throw new Error(
                "The workbook could not be saved as XLSX."
            );
        }


        return new Blob(
            [output],
            {
                type:
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            }
        );
    }


    async getSaveBlob() {
        return this.toBlob();
    }
}


/*
|--------------------------------------------------------------------------
| Exports used by the UI
|--------------------------------------------------------------------------
*/

export {
    cellAddress,
    columnIndexToName,
    loadXlsxLibrary,
    normalizeSheetName,
};