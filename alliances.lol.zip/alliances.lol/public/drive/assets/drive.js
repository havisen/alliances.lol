"use strict";

import {
    createBlankDocx,
    DOCX_MIME,
} from "./drive-docx-engine.js";

import {
    AlliancesXlsxEngine,
} from "./drive-xlsx-engine.js";

import {
    generateFileKey,
    encryptFile,
    wrapFileKeyForUser,
    clearFileKey,
} from "./drive-crypto.js";

import {
    hasActiveVaultSession,
    getOpenPgpIdentity,
} from "./drive-vault.js";

import {
    downloadDriveFile,
    decryptDriveFile,
} from "./drive-download.js";

import {
    loadDriveFileAccess,
    grantDriveFileAccess,
    revokeDriveFileAccess,
    setDriveFileEditPermission,
    setDriveFileExpiry,
    grantDriveTeamAccess,
    revokeDriveTeamAccess,
    setDriveTeamEditPermission,
    setDriveTeamExpiry,
} from "./drive-access.js";


/*
 * ==========================================================================
 * Alliances — Encrypted Drive
 * ==========================================================================
 */

const csrfToken =
    document.querySelector('meta[name="csrf-token"]')?.content ?? "";

const currentUserId = Number(
    document.querySelector('meta[name="alliances-user-id"]')?.content ?? 0
);


/*
 * --------------------------------------------------------------------------
 * Elements
 * --------------------------------------------------------------------------
 */

const driveList =
    document.getElementById("drive-list");

const driveBreadcrumbs =
    document.getElementById("drive-breadcrumbs");

const newFolderButton =
    document.getElementById("drive-new-folder");

const folderBackdrop =
    document.getElementById("drive-folder-backdrop");

const folderCloseButton =
    document.getElementById("drive-folder-close");

const folderCancelButton =
    document.getElementById("drive-folder-cancel");

const folderForm =
    document.getElementById("drive-folder-form");

const folderNameInput =
    document.getElementById("drive-folder-name");

const folderStatus =
    document.getElementById("drive-folder-status");


const newFileButton =
    document.getElementById(
        "drive-new-file"
    );

const newFileBackdrop =
    document.getElementById(
        "drive-new-file-backdrop"
    );

const newFileCloseButton =
    document.getElementById(
        "drive-new-file-close"
    );

const newFileTypeButtons =
    document.querySelectorAll(
        "[data-drive-new-file-type]"
    );


const uploadButton =
    document.getElementById("drive-upload-file");

const emptyUploadButton =
    document.getElementById("drive-empty-upload");

const fileInput =
    document.getElementById("drive-file-input");

const uploadBackdrop =
    document.getElementById("drive-upload-backdrop");

const uploadCloseButton =
    document.getElementById("drive-upload-close");

const uploadCancelButton =
    document.getElementById("drive-upload-cancel");

const selectedFileDisplay =
    document.getElementById("drive-selected-file");

const uploadConfirmButton =
    document.getElementById("drive-upload-confirm");

const uploadStatus =
    document.getElementById("drive-upload-status");

const memberSelect =
    document.getElementById("drive-upload-members");

const searchInput =
    document.getElementById("drive-search-input");

const sortSelect =
    document.getElementById(
        "drive-sort-select"
    );

const sortDirectionButton =
    document.getElementById(
        "drive-sort-direction"
    );

const driveListHeader =
    document.querySelector(
        ".drive-list-header"
    );

const driveViewButtons =
    document.querySelectorAll(
        "[data-drive-view]"
    );

const storageUsage =
    document.getElementById(
        "drive-storage-usage"
    );

const driveSectionButtons =
    document.querySelectorAll(
        "[data-drive-section]"
    );

const accessBackdrop =
    document.getElementById(
        "drive-access-backdrop"
    );

const accessCloseButton =
    document.getElementById(
        "drive-access-close"
    );

const accessDoneButton =
    document.getElementById(
        "drive-access-done"
    );

const accessFilename =
    document.getElementById(
        "drive-access-filename"
    );

const accessMembers =
    document.getElementById(
        "drive-access-members"
    );

const accessStatus =
    document.getElementById(
        "drive-access-status"
    );


let activeAccessFileId = null;

/*
 * --------------------------------------------------------------------------
 * State
 * --------------------------------------------------------------------------
 */

let currentFolderId = null;

let activeDriveSection = "drive";

let folders = [];
let files = [];
let workspaceMembers = [];

let selectedFiles = [];
let selectedUploadFolderId = null;
let creatingDocument = false;
let driveDragDepth = 0;
let driveDropHint = null;

let folderPath = [];

let uploadInProgress = false;
let uploadCancelRequested = false;
let activeUploadController = null;

const thumbnailCache =
    new Map();

const loadingThumbnails =
    new Set();

let thumbnailObserver = null;

if (fileInput) {
    fileInput.multiple = true;
}

/*
 * --------------------------------------------------------------------------
 * Drive search state
 * --------------------------------------------------------------------------
 */

let driveSearchTimer = null;
let driveSearchRequest = null;
let driveSearchSequence = 0;

/*
 * --------------------------------------------------------------------------
 * Drive sorting state
 * --------------------------------------------------------------------------
 */

let driveSortField =
    readDrivePreference(
        "alliances.drive.sort-field"
    ) || "name";

let driveSortDirection =
    readDrivePreference(
        "alliances.drive.sort-direction"
    ) === "desc"
        ? "desc"
        : "asc";

/*
 * --------------------------------------------------------------------------
 * Drive view state
 * --------------------------------------------------------------------------
 */

let driveView =
    readDrivePreference(
        "alliances.drive.view"
    ) === "grid"
        ? "grid"
        : "list";

/*
 * --------------------------------------------------------------------------
 * Helpers
 * --------------------------------------------------------------------------
 */

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function formatBytes(bytes) {
    const size = Number(bytes);

    if (!Number.isFinite(size) || size <= 0) {
        return "0 B";
    }

    const units = [
        "B",
        "KB",
        "MB",
        "GB",
        "TB",
    ];

    const unitIndex = Math.min(
        Math.floor(
            Math.log(size) / Math.log(1024)
        ),
        units.length - 1
    );

    const value =
        size / Math.pow(1024, unitIndex);

    if (unitIndex === 0) {
        return `${Math.round(value)} ${units[unitIndex]}`;
    }

    return `${value.toFixed(value >= 10 ? 1 : 2)} ${units[unitIndex]}`;
}


function formatDate(value) {
    if (!value) {
        return "—";
    }

    const normalized =
        String(value).includes("T")
            ? String(value)
            : `${String(value).replace(" ", "T")}Z`;

    const date =
        new Date(normalized);

    if (Number.isNaN(date.getTime())) {
        return String(value);
    }

    return new Intl.DateTimeFormat(
        undefined,
        {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
        }
    ).format(date);
}

/*
 * --------------------------------------------------------------------------
 * Drive sorting
 * --------------------------------------------------------------------------
 */

function compareDriveText(
    left,
    right
) {
    return String(left ?? "")
        .localeCompare(
            String(right ?? ""),
            undefined,
            {
                numeric: true,
                sensitivity: "base",
            }
        );
}


function compareDriveItems(
    left,
    right,
    type
) {
    let result = 0;

    switch (driveSortField) {
        case "owner":
            result =
                compareDriveText(
                    left.owner_name,
                    right.owner_name
                );
            break;


        case "modified": {
            const leftTime =
                new Date(
                    left.updated_at ??
                    left.created_at ??
                    0
                ).getTime();

            const rightTime =
                new Date(
                    right.updated_at ??
                    right.created_at ??
                    0
                ).getTime();

            result =
                (
                    Number.isFinite(leftTime)
                        ? leftTime
                        : 0
                )
                -
                (
                    Number.isFinite(rightTime)
                        ? rightTime
                        : 0
                );

            break;
        }


        case "size":
            /*
             * Folders do not have a meaningful encrypted
             * byte size, so keep their secondary order by name.
             */
            if (
                type === "file"
            ) {
                result =
                    Number(
                        left.encrypted_size ?? 0
                    )
                    -
                    Number(
                        right.encrypted_size ?? 0
                    );
            } else {
                result =
                    compareDriveText(
                        left.name,
                        right.name
                    );
            }

            break;


        case "name":
        default:
            result =
                compareDriveText(
                    left.name,
                    right.name
                );
            break;
    }


    /*
     * Stable secondary ordering prevents rows with equal
     * values from jumping around between renders.
     */
    if (result === 0) {
        result =
            compareDriveText(
                left.name,
                right.name
            );
    }

    if (result === 0) {
        result =
            Number(left.id ?? 0)
            -
            Number(right.id ?? 0);
    }


    return driveSortDirection === "desc"
        ? -result
        : result;
}


function sortDriveItems(
    items,
    type
) {
    return [...items].sort(
        (left, right) =>
            compareDriveItems(
                left,
                right,
                type
            )
    );
}


function updateDriveSortUi() {
    if (sortSelect) {
        const allowedFields =
            new Set([
                "name",
                "owner",
                "modified",
                "size",
            ]);

        if (
            !allowedFields.has(
                driveSortField
            )
        ) {
            driveSortField =
                "name";
        }

        sortSelect.value =
            driveSortField;
    }


    if (sortDirectionButton) {
        const isDescending =
            driveSortDirection ===
            "desc";

        sortDirectionButton.dataset.direction =
            isDescending
                ? "desc"
                : "asc";

        sortDirectionButton.textContent =
            isDescending
                ? "↓"
                : "↑";

        sortDirectionButton.title =
            isDescending
                ? "Sort descending"
                : "Sort ascending";

        sortDirectionButton.setAttribute(
            "aria-label",
            sortDirectionButton.title
        );
    }
}

/*
 * --------------------------------------------------------------------------
 * Drive view
 * --------------------------------------------------------------------------
 */

function updateDriveViewUi() {
    for (
        const button of
        driveViewButtons
    ) {
        const view =
            String(
                button.dataset.driveView ??
                ""
            );

        const isActive =
            view === driveView;

        button.classList.toggle(
            "is-active",
            isActive
        );

        button.setAttribute(
            "aria-pressed",
            isActive
                ? "true"
                : "false"
        );
    }


    if (driveList) {
        driveList.classList.toggle(
            "is-grid-view",
            driveView === "grid"
        );

        driveList.classList.toggle(
            "is-list-view",
            driveView === "list"
        );
    }


    /*
     * The column headings only apply to list view.
     */
    if (driveListHeader) {
        driveListHeader.hidden =
            driveView === "grid";
    }
}

function fileIcon(file) {
    const mimeType =
        String(file.mime_type ?? "")
            .toLowerCase();

    const name =
        String(file.name ?? "")
            .toLowerCase();

    if (
        mimeType.includes("word") ||
        name.endsWith(".docx")
    ) {
        return "D";
    }

    if (
        mimeType.includes("spreadsheet") ||
        mimeType.includes("excel") ||
        name.endsWith(".xlsx")
    ) {
        return "X";
    }

    if (
        mimeType === "application/pdf" ||
        name.endsWith(".pdf")
    ) {
        return "P";
    }

    if (mimeType.startsWith("image/")) {
        return "I";
    }

    if (mimeType.startsWith("video/")) {
        return "V";
    }

    if (mimeType.startsWith("audio/")) {
        return "A";
    }

    return "F";
}


function isThumbnailImage(file) {
    const mimeType =
        String(file.mime_type ?? "")
            .split(";")[0]
            .trim()
            .toLowerCase();

    const name =
        String(file.name ?? "")
            .toLowerCase();

    return (
        [
            "image/jpeg",
            "image/png",
            "image/webp",
            "image/gif",
        ].includes(mimeType) ||
        name.endsWith(".jpg") ||
        name.endsWith(".jpeg") ||
        name.endsWith(".png") ||
        name.endsWith(".webp") ||
        name.endsWith(".gif")
    );
}


function revokeDriveThumbnails() {
    for (
        const thumbnail
        of thumbnailCache.values()
    ) {
        URL.revokeObjectURL(
            thumbnail.url
        );
    }

    thumbnailCache.clear();
    loadingThumbnails.clear();
}


async function loadDriveThumbnail(
    file,
    iconElement
) {
    const fileId =
        Number(file?.id);

    if (
        !Number.isInteger(fileId) ||
        fileId <= 0 ||
        !iconElement ||
        !isThumbnailImage(file)
    ) {
        return;
    }

    const cached =
        thumbnailCache.get(fileId);

    if (cached) {
        iconElement.innerHTML =
            `<img src="${cached.url}" alt="">`;
        iconElement.classList.add(
            "has-thumbnail"
        );
        return;
    }

    if (
        loadingThumbnails.has(fileId)
    ) {
        return;
    }

    loadingThumbnails.add(fileId);

    try {
        const decrypted =
            await decryptDriveFile(fileId);

        const blob =
            new Blob(
                [
                    decrypted.plaintext,
                ],
                {
                    type:
                        decrypted.mimeType ||
                        file.mime_type ||
                        "application/octet-stream",
                }
            );

        const objectUrl =
            URL.createObjectURL(blob);

        thumbnailCache.set(
            fileId,
            {
                url: objectUrl,
            }
        );

        iconElement.innerHTML =
            `<img src="${objectUrl}" alt="">`;
        iconElement.classList.add(
            "has-thumbnail"
        );
    } catch (error) {
        console.warn(
            "Unable to render Drive thumbnail:",
            error
        );
    } finally {
        loadingThumbnails.delete(
            fileId
        );
    }
}


function observeDriveThumbnail(
    file,
    iconElement
) {
    if (
        !isThumbnailImage(file) ||
        !iconElement
    ) {
        return;
    }

    if (
        !("IntersectionObserver" in window)
    ) {
        void loadDriveThumbnail(
            file,
            iconElement
        );
        return;
    }

    if (!thumbnailObserver) {
        thumbnailObserver =
            new IntersectionObserver(
                (entries) => {
                    for (
                        const entry of entries
                    ) {
                        if (!entry.isIntersecting) {
                            continue;
                        }

                        thumbnailObserver.unobserve(
                            entry.target
                        );

                        const fileId =
                            Number(
                                entry.target.dataset
                                    .thumbnailFileId
                            );

                        const file =
                            files.find(
                                (candidate) =>
                                    Number(candidate.id) ===
                                    fileId
                            );

                        if (file) {
                            void loadDriveThumbnail(
                                file,
                                entry.target
                            );
                        }
                    }
                },
                {
                    root:
                        null,
                    rootMargin:
                        "160px",
                    threshold:
                        0.01,
                }
            );
    }

    iconElement.dataset.thumbnailFileId =
        String(file.id);

    thumbnailObserver.observe(
        iconElement
    );
}


window.addEventListener(
    "beforeunload",
    revokeDriveThumbnails
);


/*
 * --------------------------------------------------------------------------
 * Encrypted image preview + encryption status
 * --------------------------------------------------------------------------
 */

function driveEncryptionStatus() {
    return hasActiveVaultSession()
        ? "Encrypted · Ready to decrypt on this device"
        : "Encrypted · Key Vault locked";
}

function driveDecryptionErrorMessage(error) {
    const message =
        error instanceof Error
            ? error.message
            : String(error ?? "");

    const normalized = message.toLowerCase();

    if (
        normalized.includes("encrypted file key is missing") ||
        normalized.includes("file key is missing") ||
        normalized.includes("no encrypted key") ||
        normalized.includes("missing encrypted key")
    ) {
        return "Encrypted · Your personal decryption key is unavailable for this file";
    }

    if (normalized.includes("key vault") && normalized.includes("locked")) {
        return "Encrypted · Key Vault locked";
    }

    return message || "Unable to decrypt this encrypted file.";
}

function closeImagePreview(backdrop, objectUrl = null) {
    if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
    }

    backdrop.remove();

    if (!document.querySelector(".drive-modal-backdrop")) {
        document.body.classList.remove("drive-modal-open");
    }
}

async function openImagePreview(file, subtitle = null) {
    const backdrop = document.createElement("div");
    backdrop.className = "drive-modal-backdrop drive-image-preview-backdrop";
    backdrop.innerHTML = `
        <section
            class="drive-modal drive-image-preview-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="drive-image-preview-title"
        >
            <header class="drive-modal-header">
                <div>
                    <p class="drive-modal-eyebrow">Encrypted image preview</p>
                    <h2 id="drive-image-preview-title">${escapeHtml(file.name ?? "Image")}</h2>
                </div>
                <button type="button" class="drive-modal-close" aria-label="Close preview" data-image-preview-close>×</button>
            </header>
            <div class="drive-modal-body drive-image-preview-body">
                <div class="drive-image-preview-status" role="status">Decrypting image on this device…</div>
            </div>
        </section>
    `;

    document.body.appendChild(backdrop);
    document.body.classList.add("drive-modal-open");

    let objectUrl = null;
    let closed = false;

    const close = () => {
        if (closed) return;
        closed = true;
        document.removeEventListener("keydown", onKeyDown);
        closeImagePreview(backdrop, objectUrl);
    };

    const onKeyDown = (event) => {
        if (event.key === "Escape") close();
    };

    backdrop.addEventListener("click", (event) => {
        if (event.target === backdrop || event.target.closest("[data-image-preview-close]")) {
            close();
        }
    });
    document.addEventListener("keydown", onKeyDown);

    const body = backdrop.querySelector(".drive-image-preview-body");
    const status = backdrop.querySelector(".drive-image-preview-status");

    try {
        await markDriveFileRecent(file.id);
        const decrypted = await decryptDriveFile(file.id, {
            onStatus(message) {
                if (status) status.textContent = message;
                if (subtitle) subtitle.textContent = message;
            },
        });

        if (closed) return;

        const mimeType = String(decrypted.mimeType || file.mime_type || "image/*").split(";")[0].trim();
        if (!mimeType.startsWith("image/")) {
            throw new Error("This file is not a supported image preview.");
        }

        const blob = new Blob([decrypted.plaintext], { type: mimeType });
        objectUrl = URL.createObjectURL(blob);

        body.innerHTML = `
            <img class="drive-image-preview-image" src="${objectUrl}" alt="${escapeHtml(file.name ?? "Image preview")}">
            <p class="drive-image-preview-security">Encrypted at rest · Decrypted only in this browser session</p>
        `;

        if (subtitle) subtitle.textContent = "Encrypted · Ready to decrypt on this device";
    } catch (error) {
        console.error(error);
        const message = driveDecryptionErrorMessage(error);
        if (status) {
            status.textContent = message;
            status.classList.add("is-error");
        }
        if (subtitle) {
            subtitle.textContent = message;
            subtitle.classList.add("is-error");
        }
    }
}


function setFolderStatus(
    message,
    type = ""
) {
    if (!folderStatus) {
        return;
    }

    folderStatus.textContent = message;

    folderStatus.classList.remove(
        "is-error",
        "is-success"
    );

    if (type === "error") {
        folderStatus.classList.add(
            "is-error"
        );
    }

    if (type === "success") {
        folderStatus.classList.add(
            "is-success"
        );
    }
}


async function loadDriveStorageUsage() {
    if (!storageUsage) {
        return;
    }

    try {
        const response =
            await fetch(
                "/actions/drive/storage-usage.php",
                {
                    method: "GET",
                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );

        const data =
            await response.json();

        if (
            !response.ok ||
            !data.success
        ) {
            throw new Error(
                data.error ||
                "Unable to load storage usage."
            );
        }

        storageUsage.textContent =
            `Storage ${formatBytes(Number(data.used_bytes ?? 0))} used`;
    } catch (error) {
        console.error(error);

        storageUsage.textContent =
            "Storage usage unavailable";
    }
}


function setUploadStatus(
    message,
    type = ""
) {
    if (!uploadStatus) {
        return;
    }

    uploadStatus.textContent = message;

    uploadStatus.classList.remove(
        "is-error",
        "is-success"
    );

    if (type === "error") {
        uploadStatus.classList.add(
            "is-error"
        );
    }

    if (type === "success") {
        uploadStatus.classList.add(
            "is-success"
        );
    }
}


function getSharingMode() {
    const checked =
        document.querySelector(
            'input[name="drive-sharing-mode"]:checked'
        );

    return checked?.value === "workspace"
        ? "workspace"
        : "selected";
}

function setAccessStatus(
    message,
    isError = false
) {
    if (!accessStatus) {
        return;
    }

    accessStatus.textContent =
        message;

    accessStatus.classList.toggle(
        "is-error",
        isError
    );
}


function closeAccessModal() {
    if (!accessBackdrop) {
        return;
    }

    accessBackdrop.hidden =
        true;

    activeAccessFileId =
        null;

    setAccessStatus("");

    if (accessMembers) {
        accessMembers.innerHTML =
            "";
    }
}


function getMemberInitials(
    member
) {
    const name =
        String(
            member.name ||
            member.email ||
            "User"
        ).trim();

    const parts =
        name.split(/\s+/)
            .filter(Boolean);

    if (parts.length === 0) {
        return "?";
    }

    if (parts.length === 1) {
        return parts[0]
            .slice(0, 2)
            .toUpperCase();
    }

    return (
        parts[0][0] +
        parts[
            parts.length - 1
        ][0]
    ).toUpperCase();
}


function expiryInputValue(expiresAt) {
    if (!expiresAt) return "";
    const value = String(expiresAt).replace(" ", "T");
    return value.slice(0, 16);
}

function createExpiryInput(expiresAt) {
    const input = document.createElement("input");
    input.type = "datetime-local";
    input.className = "drive-access-expiry";
    input.value = expiryInputValue(expiresAt);
    input.title = "Leave empty for no expiration";
    return input;
}

function createAccessTeamRow(file, team) {
    const row = document.createElement("div"); row.className = "drive-access-member drive-access-team";
    const avatar = document.createElement("div"); avatar.className = "drive-access-avatar"; avatar.textContent = "T";
    const info = document.createElement("div"); info.className = "drive-access-member-info";
    const name = document.createElement("div"); name.className = "drive-access-member-name"; name.textContent = team.name || "Team";
    const meta = document.createElement("div"); meta.className = "drive-access-member-meta"; meta.textContent = `${team.members?.length || 0} members`;
    info.append(name, meta);
    const controls = document.createElement("div"); controls.className = "drive-access-controls";
    const expiry = createExpiryInput(team.expires_at); controls.appendChild(expiry);
    if (team.has_access) {
        const edit = document.createElement("label"); edit.className = "drive-access-edit";
        const check = document.createElement("input"); check.type="checkbox"; check.checked=Boolean(team.can_edit);
        const txt=document.createElement("span");txt.textContent="Can edit";edit.append(check,txt);controls.appendChild(edit);
        check.addEventListener("change", async()=>{check.disabled=true;try{await setDriveTeamEditPermission(file.id,team.id,check.checked);setAccessStatus("Team permission updated.");}catch(e){check.checked=!check.checked;setAccessStatus(e.message||"Unable to update team permission.",true);}finally{check.disabled=false;}});
        expiry.addEventListener("change", async()=>{expiry.disabled=true;try{await setDriveTeamExpiry(file.id,team.id,expiry.value);setAccessStatus(expiry.value?"Team expiration updated.":"Team expiration removed.");}catch(e){setAccessStatus(e.message||"Unable to update expiration.",true);}finally{expiry.disabled=false;}});
        const remove=document.createElement("button");remove.type="button";remove.className="drive-access-button is-danger";remove.textContent="Remove access";
        remove.addEventListener("click",async()=>{remove.disabled=true;try{await revokeDriveTeamAccess(file.id,team.id);setAccessStatus("Team access removed.");await renderAccessMembers(file.id);}catch(e){remove.disabled=false;setAccessStatus(e.message||"Unable to remove team access.",true);}});controls.appendChild(remove);
    } else {
        const grant=document.createElement("button");grant.type="button";grant.className="drive-access-button";grant.textContent="Share with team";
        grant.addEventListener("click",async()=>{grant.disabled=true;setAccessStatus(`Encrypting file key for ${team.name}…`);try{const r=await grantDriveTeamAccess(file.id,team,false,expiry.value);setAccessStatus(r.missing_count?`Shared with ${team.name}. ${r.granted_count} members received encrypted access; ${r.missing_count} member(s) are missing encryption keys.`:`Shared securely with ${team.name}.`);await renderAccessMembers(file.id);}catch(e){grant.disabled=false;setAccessStatus(e.message||"Unable to share with team.",true);}});controls.appendChild(grant);
    }
    row.append(avatar,info,controls);return row;
}

function createAccessMemberRow(
    file,
    member
) {
    const row =
        document.createElement(
            "div"
        );

    row.className =
        "drive-access-member";


    /*
     * Avatar
     */
    const avatar =
        document.createElement(
            "div"
        );

    avatar.className =
        "drive-access-avatar";


    if (member.avatar_path) {
        const image =
            document.createElement(
                "img"
            );

        image.src =
            member.avatar_path;

        image.alt =
            "";

        avatar.appendChild(
            image
        );
    } else {
        avatar.textContent =
            getMemberInitials(
                member
            );
    }


    /*
     * User information
     */
    const info =
        document.createElement(
            "div"
        );

    info.className =
        "drive-access-member-info";


    const name =
        document.createElement(
            "div"
        );

    name.className =
        "drive-access-member-name";


    const nameText =
        document.createElement(
            "span"
        );

    nameText.textContent =
        member.name ||
        member.email ||
        "User";

    name.appendChild(
        nameText
    );


    if (member.is_uploader) {
        const badge =
            document.createElement(
                "span"
            );

        badge.className =
            "drive-access-badge";

        badge.textContent =
            "Owner";

        name.appendChild(
            badge
        );
    } else if (
        member.is_current_user
    ) {
        const badge =
            document.createElement(
                "span"
            );

        badge.className =
            "drive-access-badge";

        badge.textContent =
            "You";

        name.appendChild(
            badge
        );
    }


    const meta =
        document.createElement(
            "div"
        );

    meta.className =
        "drive-access-member-meta";

    meta.textContent =
        [
            member.email,
            member.job_title,
        ]
            .filter(Boolean)
            .join(" · ");


    info.appendChild(name);
    info.appendChild(meta);


    /*
     * Controls
     */
    const controls =
        document.createElement(
            "div"
        );

    controls.className =
        "drive-access-controls";

    const expiryInput = createExpiryInput(member.expires_at);
    controls.appendChild(expiryInput);

    if (member.has_access) {
        /*
         * Edit permission
         */
        const editLabel =
            document.createElement(
                "label"
            );

        editLabel.className =
            "drive-access-edit";


        const editCheckbox =
            document.createElement(
                "input"
            );

        editCheckbox.type =
            "checkbox";

        editCheckbox.checked =
            Boolean(
                member.can_edit
            );


        if (member.is_uploader) {
            editCheckbox.checked =
                true;

            editCheckbox.disabled =
                true;
        }


        const editText =
            document.createElement(
                "span"
            );

        editText.textContent =
            "Can edit";


        editLabel.appendChild(
            editCheckbox
        );

        editLabel.appendChild(
            editText
        );

        controls.appendChild(
            editLabel
        );


        if (!member.is_uploader) {
            editCheckbox.addEventListener(
                "change",
                async () => {
                    const requestedValue =
                        editCheckbox.checked;

                    editCheckbox.disabled =
                        true;

                    setAccessStatus(
                        "Updating edit permission…"
                    );

                    try {
                        await setDriveFileEditPermission(
                            file.id,
                            member.id,
                            requestedValue
                        );

                        setAccessStatus(
                            "Edit permission updated."
                        );
                    } catch (error) {
                        editCheckbox.checked =
                            !requestedValue;

                        setAccessStatus(
                            error instanceof Error
                                ? error.message
                                : "Unable to update edit permission.",
                            true
                        );
                    } finally {
                        editCheckbox.disabled =
                            false;
                    }
                }
            );


            expiryInput.addEventListener("change", async () => {
                expiryInput.disabled = true;
                try {
                    await setDriveFileExpiry(file.id, member.id, expiryInput.value);
                    setAccessStatus(expiryInput.value ? "Expiration updated." : "Expiration removed.");
                } catch (error) {
                    setAccessStatus(error instanceof Error ? error.message : "Unable to update expiration.", true);
                } finally {
                    expiryInput.disabled = false;
                }
            });

            /*
             * Revoke
             */
            const revokeButton =
                document.createElement(
                    "button"
                );

            revokeButton.type =
                "button";

            revokeButton.className =
                "drive-access-button is-danger";

            revokeButton.textContent =
                "Remove access";


            revokeButton.addEventListener(
                "click",
                async () => {
                    revokeButton.disabled =
                        true;

                    editCheckbox.disabled =
                        true;

                    setAccessStatus(
                        "Removing access…"
                    );

                    try {
                        await revokeDriveFileAccess(
                            file.id,
                            member.id
                        );

                        setAccessStatus(
                            "Access removed."
                        );

                        await renderAccessMembers(
                            file.id
                        );
                    } catch (error) {
                        revokeButton.disabled =
                            false;

                        editCheckbox.disabled =
                            false;

                        setAccessStatus(
                            error instanceof Error
                                ? error.message
                                : "Unable to remove access.",
                            true
                        );
                    }
                }
            );

            controls.appendChild(
                revokeButton
            );
        }
    } else {
        /*
         * Grant access
         */
        const grantButton =
            document.createElement(
                "button"
            );

        grantButton.type =
            "button";

        grantButton.className =
            "drive-access-button";

        grantButton.textContent =
            "Grant access";


        grantButton.addEventListener(
            "click",
            async () => {
                grantButton.disabled =
                    true;

                setAccessStatus(
                    "Encrypting file key for "
                    + (
                        member.name ||
                        member.email ||
                        "user"
                    )
                    + "…"
                );

                try {
                    await grantDriveFileAccess(
                        file.id,
                        member.id,
                        expiryInput.value
                    );

                    setAccessStatus(
                        "Access granted securely."
                    );

                    await renderAccessMembers(
                        file.id
                    );
                } catch (error) {
                    grantButton.disabled =
                        false;

                    setAccessStatus(
                        error instanceof Error
                            ? error.message
                            : "Unable to grant access.",
                        true
                    );
                }
            }
        );

        controls.appendChild(
            grantButton
        );
    }


    row.appendChild(
        avatar
    );

    row.appendChild(
        info
    );

    row.appendChild(
        controls
    );


    return row;
}

/*
 * --------------------------------------------------------------------------
 * Copy encrypted Drive file
 * --------------------------------------------------------------------------
 */

function makeDriveCopyName(
    filename
) {
    const name =
        String(
            filename || "File"
        );

    const lastDot =
        name.lastIndexOf(".");


    if (
        lastDot <= 0 ||
        lastDot === name.length - 1
    ) {
        return `${name} - Copy`;
    }


    const base =
        name.slice(
            0,
            lastDot
        );

    const extension =
        name.slice(
            lastDot
        );


    return `${base} - Copy${extension}`;
}


async function copyDriveFile(
    file
) {
    const fileId =
        Number(
            file?.id
        );


    if (
        !Number.isInteger(fileId) ||
        fileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }


    if (
        !hasActiveVaultSession()
    ) {
        throw new Error(
            "Your Key Vault is locked. Open Key Vault and unlock it before copying encrypted files."
        );
    }


    let newFileKey = null;


    try {
        /*
         * Make sure the current browser has access to the
         * user's OpenPGP identity before starting.
         */
        await getOpenPgpIdentity();


        /*
         * Decrypt the SOURCE file entirely on this device.
         *
         * decryptDriveFile() downloads only ciphertext from PHP,
         * unwraps the existing file key locally and returns the
         * plaintext without triggering a browser download.
         */
        const decrypted =
            await decryptDriveFile(
                fileId
            );


        if (
            !decrypted ||
            !decrypted.plaintext
        ) {
            throw new Error(
                "Unable to decrypt the source file."
            );
        }


        /*
         * The copy receives a completely NEW AES-256 key.
         * It does not reuse the source file's key.
         */
        newFileKey =
            generateFileKey();


        /*
         * Convert the decrypted data into a File so we can reuse
         * the existing Drive encryption implementation.
         */
        const copyName =
            makeDriveCopyName(
                decrypted.filename ||
                file.original_name ||
                file.name ||
                "File"
            );


        const plaintextFile =
            new File(
                [
                    decrypted.plaintext,
                ],
                copyName,
                {
                    type:
                        decrypted.mimeType ||
                        file.mime_type ||
                        "application/octet-stream",
                }
            );


        /*
         * encryptFile() creates a fresh AES-GCM IV internally,
         * exactly like a normal encrypted Drive upload.
         */
        const encryptedBlob =
            await encryptFile(
                plaintextFile,
                newFileKey
            );


        /*
         * A copied file initially belongs only to the user who
         * created the copy.
         *
         * We therefore only need that user's public OpenPGP key.
         */
        const publicKeys =
            await fetchPublicKeys(
                [
                    currentUserId,
                ]
            );


        if (
            publicKeys.length !== 1
        ) {
            throw new Error(
                "Your public encryption key could not be loaded."
            );
        }


        const encryptedKey =
            await wrapFileKeyForUser(
                newFileKey,
                publicKeys[0].public_key
            );


        /*
         * Raw AES key is no longer needed.
         */
        clearFileKey(
            newFileKey
        );

        newFileKey = null;


        /*
         * copy.php expects the encrypted key envelopes as JSON.
         */
        const encryptedKeys = [
            {
                user_id:
                    currentUserId,

                encrypted_key:
                    encryptedKey,
            },
        ];


        const body =
            new FormData();


        body.set(
            "csrf_token",
            csrfToken
        );

        body.set(
            "source_file_id",
            String(fileId)
        );


        /*
         * Copy into the currently displayed folder.
         * Empty folder_id means Drive root.
         */
        body.set(
            "folder_id",
            currentFolderId === null
                ? ""
                : String(
                    currentFolderId
                )
        );


        body.set(
            "original_name",
            copyName
        );

        body.set(
            "mime_type",
            plaintextFile.type || ""
        );


        /*
         * encryptFile() stores the AES-GCM IV inside the encrypted
         * blob used by the current Drive format.
         *
         * copy.php currently requires an iv field as well.
         * Send an explicit marker here; if your endpoint validates
         * this as an actual IV rather than metadata, we will align
         * copy.php with upload.php in the next step.
         */
        body.set(
            "iv",
            "embedded"
        );


        body.set(
            "encrypted_keys",
            JSON.stringify(
                encryptedKeys
            )
        );


        body.set(
            "encrypted_file",
            encryptedBlob,
            "encrypted.bin"
        );


        const response =
            await fetch(
                "/actions/drive/copy.php",
                {
                    method:
                        "POST",

                    credentials:
                        "same-origin",

                    body,

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        let data = null;


        try {
            data =
                await response.json();
        } catch {
            throw new Error(
                "The server returned an invalid response while copying the file."
            );
        }


        if (
            !response.ok ||
            !data?.success
        ) {
            throw new Error(
                data?.error ||
                "Unable to copy file."
            );
        }


        return data.file;
    } finally {
        /*
         * Best-effort cleanup if an error occurred before
         * the normal key cleanup.
         */
        if (newFileKey) {
            clearFileKey(
                newFileKey
            );
        }
    }
}

async function renderAccessMembers(
    fileId
) {
    if (!accessMembers) {
        return;
    }

    accessMembers.innerHTML =
        "";

    setAccessStatus(
        "Loading access…"
    );


    const result =
        await loadDriveFileAccess(
            fileId
        );


    /*
     * Ignore a response belonging to a modal that
     * was closed while the request was running.
     */
    if (
        activeAccessFileId !==
        Number(fileId)
    ) {
        return;
    }


    if (accessFilename) {
        accessFilename.textContent =
            result.file?.name ||
            "Encrypted file";
    }


    if (
        !Array.isArray(
            result.members
        ) ||
        result.members.length === 0
    ) {
        accessMembers.textContent =
            "No workspace members found.";

        setAccessStatus("");

        return;
    }


    const peopleHeading = document.createElement("div");
    peopleHeading.className = "drive-access-section-title";
    peopleHeading.textContent = "People";
    accessMembers.appendChild(peopleHeading);
    for (const member of result.members) {
        accessMembers.appendChild(createAccessMemberRow(result.file, member));
    }

    if (Array.isArray(result.teams) && result.teams.length) {
        const teamsHeading = document.createElement("div");
        teamsHeading.className = "drive-access-section-title";
        teamsHeading.textContent = "Teams";
        accessMembers.appendChild(teamsHeading);
        for (const team of result.teams) {
            accessMembers.appendChild(createAccessTeamRow(result.file, team));
        }
    }

    setAccessStatus("");
}


async function openAccessModal(
    fileId
) {
    if (
        !accessBackdrop ||
        !accessMembers
    ) {
        return;
    }


    activeAccessFileId =
        Number(fileId);

    accessBackdrop.hidden =
        false;

    accessMembers.innerHTML =
        "";

    if (accessFilename) {
        accessFilename.textContent =
            "Encrypted file";
    }


    try {
        await renderAccessMembers(
            activeAccessFileId
        );
    } catch (error) {
        setAccessStatus(
            error instanceof Error
                ? error.message
                : "Unable to load file access.",
            true
        );
    }
}


/*
 * Modal close controls
 */

accessCloseButton?.addEventListener(
    "click",
    closeAccessModal
);

accessDoneButton?.addEventListener(
    "click",
    closeAccessModal
);

accessBackdrop?.addEventListener(
    "click",
    (event) => {
        if (
            event.target ===
            accessBackdrop
        ) {
            closeAccessModal();
        }
    }
);

/*
 * --------------------------------------------------------------------------
 * Drive sections
 * --------------------------------------------------------------------------
 */

function updateDriveSectionUi() {
    for (
        const button
        of driveSectionButtons
    ) {
        const section =
            String(
                button.dataset.driveSection ?? ""
            );

        const isActive =
            section === activeDriveSection;

        button.classList.toggle(
            "is-active",
            isActive
        );

        button.setAttribute(
            "aria-pressed",
            isActive
                ? "true"
                : "false"
        );
    }


    /*
     * Folder creation and uploads belong to My Drive.
     *
     * Trash is intentionally read-only except for restore and
     * permanent-delete actions that we add to its rows.
     */

    const isMyDrive =
        activeDriveSection === "drive";

    if (newFileButton) {
        newFileButton.hidden =
            !isMyDrive;
    }

    if (newFolderButton) {
        newFolderButton.hidden =
            !isMyDrive;
    }

    if (uploadButton) {
        uploadButton.hidden =
            !isMyDrive;
    }


    /*
     * Breadcrumbs only represent the normal folder hierarchy.
     */

    if (driveBreadcrumbs) {
        driveBreadcrumbs.hidden =
            !isMyDrive;
    }
}

/*
 * --------------------------------------------------------------------------
 * Breadcrumbs
 * --------------------------------------------------------------------------
 */

function renderBreadcrumbs() {
    if (!driveBreadcrumbs) {
        return;
    }

    driveBreadcrumbs.innerHTML = "";


    const rootButton =
        document.createElement("button");

    rootButton.type = "button";
    rootButton.className =
        "drive-breadcrumb-button";

    rootButton.textContent = "Drive";

    rootButton.addEventListener(
        "click",
        async () => {
            currentFolderId = null;
            folderPath = [];

            await loadDrive();
        }
    );

    driveBreadcrumbs.appendChild(
        rootButton
    );


    for (
        let index = 0;
        index < folderPath.length;
        index += 1
    ) {
        const folder =
            folderPath[index];

        const separator =
            document.createElement("span");

        separator.textContent = "/";
        separator.style.color = "#4f4f4f";

        driveBreadcrumbs.appendChild(
            separator
        );


        const button =
            document.createElement("button");

        button.type = "button";
        button.className =
            "drive-breadcrumb-button";

        button.textContent =
            folder.name;

        button.addEventListener(
            "click",
            async () => {
                currentFolderId =
                    folder.id;

                folderPath =
                    folderPath.slice(
                        0,
                        index + 1
                    );

                await loadDrive();
            }
        );

        driveBreadcrumbs.appendChild(
            button
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Render Trash
 * --------------------------------------------------------------------------
 */

function renderTrash() {
    if (!driveList) {
        return;
    }

    updateDriveViewUi();

    const searchTerm =
        String(
            searchInput?.value ?? ""
        )
            .trim()
            .toLowerCase();

const visibleFolders =
    sortDriveItems(
        folders.filter((folder) => {
            if (!searchTerm) {
                return true;
            }

            return String(
                folder.name ?? ""
            )
                .toLowerCase()
                .includes(searchTerm);
        }),
        "folder"
    );


const visibleFiles =
    sortDriveItems(
        files.filter((file) => {
            if (!searchTerm) {
                return true;
            }

            return String(
                file.name ?? ""
            )
                .toLowerCase()
                .includes(searchTerm);
        }),
        "file"
    );

    driveList.innerHTML = "";

    if (
        visibleFolders.length === 0 &&
        visibleFiles.length === 0
    ) {
        const empty =
            document.createElement("div");

        empty.className =
            "drive-empty-state";

        if (searchTerm) {
            empty.innerHTML = `
                <div class="drive-empty-icon">⌕</div>

                <h2>No matching Trash items</h2>

                <p>
                    Nothing in Trash matches your search.
                </p>
            `;
        } else {
            empty.innerHTML = `
                <div class="drive-empty-icon">♲</div>

                <h2>Trash is empty</h2>

                <p>
                    Files and folders you move to Trash will appear here.
                </p>
            `;
        }

        driveList.appendChild(
            empty
        );

        return;
    }


    /*
     * ----------------------------------------------------------------------
     * Trashed folders
     * ----------------------------------------------------------------------
     */

    for (
        const folder of visibleFolders
    ) {
        const row =
            document.createElement("div");

        row.className =
            "drive-row";

        row.dataset.type =
            "folder";

        row.dataset.id =
            String(folder.id);

        row.innerHTML = `
            <div class="drive-item-name">
                <div class="drive-item-icon">
                    ▣
                </div>

                <div class="drive-item-details">
                    <div class="drive-item-title">
                        ${escapeHtml(folder.name ?? "Folder")}
                    </div>

                    <div class="drive-item-subtitle">
                        Folder in Trash
                    </div>
                </div>
            </div>

            <div>
                ${escapeHtml(folder.owner_name ?? "—")}
            </div>

            <div>
                ${escapeHtml(
                    formatDate(
                        folder.trashed_at ??
                        folder.updated_at
                    )
                )}
            </div>

            <div>
                —
            </div>

            <div>
                <span class="drive-access-badge">
                    Trash
                </span>
            </div>

            <div class="drive-folder-actions">
            </div>
        `;

        const actions =
            row.querySelector(
                ".drive-folder-actions"
            );

        if (actions) {
            const restoreButton =
                document.createElement(
                    "button"
                );

            restoreButton.type =
                "button";

            restoreButton.className =
                "drive-access-button";

            restoreButton.textContent =
                "Restore";

            restoreButton.title =
                "Restore folder";


            const permanentDeleteButton =
                document.createElement(
                    "button"
                );

            permanentDeleteButton.type =
                "button";

            permanentDeleteButton.className =
                "drive-access-button is-danger";

            permanentDeleteButton.textContent =
                "Delete permanently";

            permanentDeleteButton.title =
                "Permanently delete folder";


            restoreButton.addEventListener(
                "click",
                async () => {
                    if (
                        restoreButton.disabled ||
                        permanentDeleteButton.disabled
                    ) {
                        return;
                    }

                    restoreButton.disabled =
                        true;

                    permanentDeleteButton.disabled =
                        true;

                    try {
                        await restoreDriveFolder(
                            folder
                        );

                        await loadDrive();
                    } catch (error) {
                        console.error(error);

                        window.alert(
                            error instanceof Error
                                ? error.message
                                : "Unable to restore folder."
                        );

                        restoreButton.disabled =
                            false;

                        permanentDeleteButton.disabled =
                            false;
                    }
                }
            );


            permanentDeleteButton.addEventListener(
                "click",
                async () => {
                    if (
                        restoreButton.disabled ||
                        permanentDeleteButton.disabled
                    ) {
                        return;
                    }

                    const deleted =
                        await permanentlyDeleteDriveFolder(
                            folder
                        );

                    if (!deleted) {
                        return;
                    }

                    restoreButton.disabled =
                        true;

                    permanentDeleteButton.disabled =
                        true;

                    await loadDrive();
                }
            );


            actions.appendChild(
                restoreButton
            );

            actions.appendChild(
                permanentDeleteButton
            );
        }

        driveList.appendChild(
            row
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Trashed files
     * ----------------------------------------------------------------------
     */

    for (
        const file of visibleFiles
    ) {
        const row =
            document.createElement("div");

        row.className =
            "drive-row";

        row.dataset.type =
            "file";

        row.dataset.id =
            String(file.id);

        row.innerHTML = `
            <div class="drive-item-name">
                <div class="drive-item-icon">
                    ${escapeHtml(fileIcon(file))}
                </div>

                <div class="drive-item-details">
                    <div class="drive-item-title">
                        ${escapeHtml(file.name ?? "File")}
                    </div>

                    <div class="drive-item-subtitle">
                        Encrypted file in Trash
                    </div>
                </div>
            </div>

            <div>
                ${escapeHtml(file.owner_name ?? "—")}
            </div>

            <div>
                ${escapeHtml(
                    formatDate(
                        file.trashed_at ??
                        file.updated_at
                    )
                )}
            </div>

            <div>
                ${escapeHtml(
                    formatBytes(
                        file.encrypted_size
                    )
                )}
            </div>

            <div>
                <span class="drive-access-badge">
                    Trash
                </span>
            </div>

            <div class="drive-item-actions">
            </div>
        `;

        /*
         * Intentionally do not attach the normal open/download
         * handler while the file is in Trash.
         */

        const actions =
            row.querySelector(
                ".drive-item-actions"
            );

        if (actions) {
            const restoreButton =
                document.createElement(
                    "button"
                );

            restoreButton.type =
                "button";

            restoreButton.className =
                "drive-access-button";

            restoreButton.textContent =
                "Restore";

            restoreButton.title =
                "Restore file";


            const permanentDeleteButton =
                document.createElement(
                    "button"
                );

            permanentDeleteButton.type =
                "button";

            permanentDeleteButton.className =
                "drive-access-button is-danger";

            permanentDeleteButton.textContent =
                "Delete permanently";

            permanentDeleteButton.title =
                "Permanently delete file";


            restoreButton.addEventListener(
                "click",
                async () => {
                    if (
                        restoreButton.disabled ||
                        permanentDeleteButton.disabled
                    ) {
                        return;
                    }

                    restoreButton.disabled =
                        true;

                    permanentDeleteButton.disabled =
                        true;

                    try {
                        await restoreDriveFile(
                            file
                        );

                        await loadDrive();
                    } catch (error) {
                        console.error(error);

                        window.alert(
                            error instanceof Error
                                ? error.message
                                : "Unable to restore file."
                        );

                        restoreButton.disabled =
                            false;

                        permanentDeleteButton.disabled =
                            false;
                    }
                }
            );


            permanentDeleteButton.addEventListener(
                "click",
                async () => {
                    if (
                        restoreButton.disabled ||
                        permanentDeleteButton.disabled
                    ) {
                        return;
                    }

                    const deleted =
                        await permanentlyDeleteDriveFile(
                            file
                        );

                    if (!deleted) {
                        return;
                    }

                    restoreButton.disabled =
                        true;

                    permanentDeleteButton.disabled =
                        true;

                    await loadDrive();
                }
            );


            actions.appendChild(
                restoreButton
            );

            actions.appendChild(
                permanentDeleteButton
            );
        }

        driveList.appendChild(
            row
        );
    }
}

/*
 * --------------------------------------------------------------------------
 * Drive row action menu
 * --------------------------------------------------------------------------
 */

function createDriveActionMenu(actionsArea) {
    if (
        !actionsArea
        || actionsArea.dataset.menuReady === "1"
    ) {
        return;
    }

    actionsArea.dataset.menuReady = "1";

    /*
     * Keep all of the existing action buttons and their
     * existing event listeners. We only move them into
     * the dropdown menu.
     */
    const existingButtons =
        Array.from(
            actionsArea.children
        );

    if (existingButtons.length === 0) {
        return;
    }

    const wrapper =
        document.createElement(
            "div"
        );

    wrapper.className =
        "drive-action-menu";

    const menuButton =
        document.createElement(
            "button"
        );

    menuButton.type =
        "button";

    menuButton.className =
        "drive-action-menu-button";

    menuButton.textContent =
        "⋯";

    menuButton.title =
        "File options";

    menuButton.setAttribute(
        "aria-label",
        "Open options"
    );

    menuButton.setAttribute(
        "aria-haspopup",
        "menu"
    );

    menuButton.setAttribute(
        "aria-expanded",
        "false"
    );


    const menu =
        document.createElement(
            "div"
        );

    menu.className =
        "drive-action-menu-panel";

    menu.hidden =
        true;

    menu.setAttribute(
        "role",
        "menu"
    );


    /*
     * Move the already-created buttons into the menu.
     * Their click handlers remain attached.
     */
    existingButtons.forEach(
        (button) => {
            button.classList.add(
                "drive-action-menu-item"
            );

            button.setAttribute(
                "role",
                "menuitem"
            );

            menu.appendChild(
                button
            );
        }
    );


    /*
     * Add separators before the secondary actions.
     */
    Array.from(
        menu.children
    ).forEach(
        (button) => {
            const text =
                button.textContent
                    ?.trim()
                    .toLowerCase();

            if (
                text === "versions"
                || text === "move to trash"
            ) {
                button.classList.add(
                    "drive-action-menu-separator"
                );
            }
        }
    );


    function closeMenu() {
        menu.hidden =
            true;

        menu.removeAttribute(
            "style"
        );

        wrapper.classList.remove(
            "is-open"
        );

        menuButton.setAttribute(
            "aria-expanded",
            "false"
        );
    }


    function openMenu() {
        /*
         * Only one action menu should be open.
         */
        document
            .querySelectorAll(
                ".drive-action-menu.is-open"
            )
            .forEach(
                (openWrapper) => {
                    if (
                        openWrapper !==
                        wrapper
                    ) {
                        const openPanel =
                            openWrapper.querySelector(
                                ".drive-action-menu-panel"
                            );

                        const openButton =
                            openWrapper.querySelector(
                                ".drive-action-menu-button"
                            );

                        if (openPanel) {
                            openPanel.hidden =
                                true;

                            openPanel.removeAttribute(
                                "style"
                            );
                        }

                        if (openButton) {
                            openButton.setAttribute(
                                "aria-expanded",
                                "false"
                            );
                        }

                        openWrapper.classList.remove(
                            "is-open"
                        );
                    }
                }
            );


        menu.hidden =
            false;

        wrapper.classList.add(
            "is-open"
        );

        menuButton.setAttribute(
            "aria-expanded",
            "true"
        );

        positionMenuPanel();
    }


    function positionMenuPanel() {
        const buttonRect =
            menuButton.getBoundingClientRect();

        const menuRect =
            menu.getBoundingClientRect();

        const viewportWidth =
            document.documentElement.clientWidth ||
            window.innerWidth;

        const viewportHeight =
            document.documentElement.clientHeight ||
            window.innerHeight;

        const margin =
            10;

        const menuWidth =
            menuRect.width || 190;

        const menuHeight =
            menuRect.height || 220;

        let left =
            buttonRect.left +
            (buttonRect.width / 2) -
            (menuWidth / 2);

        left =
            Math.max(
                margin,
                Math.min(
                    left,
                    viewportWidth - menuWidth - margin
                )
            );

        let top =
            buttonRect.bottom + 8;

        if (
            top + menuHeight >
            viewportHeight - margin
        ) {
            top =
                buttonRect.top - menuHeight - 8;
        }

        top =
            Math.max(
                margin,
                Math.min(
                    top,
                    viewportHeight - menuHeight - margin
                )
            );

        menu.style.left =
            `${left}px`;

        menu.style.top =
            `${top}px`;
    }


    menuButton.addEventListener(
        "click",
        (event) => {
            event.preventDefault();
            event.stopPropagation();

            if (
                wrapper.classList.contains(
                    "is-open"
                )
            ) {
                closeMenu();
            } else {
                openMenu();
            }
        }
    );


    /*
     * Prevent menu clicks from triggering the file row.
     */
    menu.addEventListener(
        "click",
        (event) => {
            event.stopPropagation();

            const actionButton =
                event.target.closest(
                    "button"
                );

            if (actionButton) {
                closeMenu();
            }
        }
    );


    wrapper.appendChild(
        menuButton
    );

    wrapper.appendChild(
        menu
    );

    actionsArea.appendChild(
        wrapper
    );
}


/*
 * Close menus when clicking somewhere else.
 */
document.addEventListener(
    "click",
    () => {
        document
            .querySelectorAll(
                ".drive-action-menu.is-open"
            )
            .forEach(
                (wrapper) => {
                    wrapper.classList.remove(
                        "is-open"
                    );

                    const panel =
                        wrapper.querySelector(
                            ".drive-action-menu-panel"
                        );

                    const button =
                        wrapper.querySelector(
                            ".drive-action-menu-button"
                        );

                    if (panel) {
                        panel.hidden =
                            true;

                        panel.removeAttribute(
                            "style"
                        );
                    }

                    if (button) {
                        button.setAttribute(
                            "aria-expanded",
                            "false"
                        );
                    }
                }
            );
    }
);


document.addEventListener(
    "keydown",
    (event) => {
        if (event.key !== "Escape") {
            return;
        }

        document
            .querySelectorAll(
                ".drive-action-menu.is-open"
            )
            .forEach(
                (wrapper) => {
                    wrapper.classList.remove(
                        "is-open"
                    );

                    const panel =
                        wrapper.querySelector(
                            ".drive-action-menu-panel"
                        );

                    const button =
                        wrapper.querySelector(
                            ".drive-action-menu-button"
                        );

                    if (panel) {
                        panel.hidden =
                            true;

                        panel.removeAttribute(
                            "style"
                        );
                    }

                    if (button) {
                        button.setAttribute(
                            "aria-expanded",
                            "false"
                        );
                    }
                }
            );
    }
);

/*
 * --------------------------------------------------------------------------
 * Render Drive
 * --------------------------------------------------------------------------
 */

function renderDrive() {
    if (
        activeDriveSection ===
        "trash"
    ) {
        renderTrash();
        return;
    }
    if (!driveList) {
        return;
    }

        updateDriveViewUi();

    const searchTerm =
        String(
            searchInput?.value ?? ""
        )
            .trim()
            .toLowerCase();


const visibleFolders =
    sortDriveItems(
        folders.filter((folder) => {
            if (!searchTerm) {
                return true;
            }

            return String(
                folder.name ?? ""
            )
                .toLowerCase()
                .includes(searchTerm);
        }),
        "folder"
    );


const visibleFiles =
    sortDriveItems(
        files.filter((file) => {
            if (!searchTerm) {
                return true;
            }

            return String(
                file.name ?? ""
            )
                .toLowerCase()
                .includes(searchTerm);
        }),
        "file"
    );


    driveList.innerHTML = "";


    if (
        visibleFolders.length === 0 &&
        visibleFiles.length === 0
    ) {
        const empty =
            document.createElement("div");

        empty.className =
            "drive-empty-state";

        if (searchTerm) {
            empty.innerHTML = `
                <div class="drive-empty-icon">⌕</div>

                <h2>No matching files</h2>

                <p>
                    No files or folders match your search.
                </p>
            `;
            } else if (
    activeDriveSection ===
    "shared-with-me"
) {
    empty.innerHTML = `
        <div class="drive-empty-icon">
            ⇢
        </div>

        <h2>Nothing shared with you</h2>

        <p>
            Files other people share with you will appear here.
        </p>
    `;
} else if (
    activeDriveSection ===
    "shared-by-me"
) {
    empty.innerHTML = `
        <div class="drive-empty-icon">
            ⇠
        </div>

        <h2>You haven't shared any files</h2>

        <p>
            Files you give other people access to will appear here.
        </p>
    `;
} else if (
    activeDriveSection ===
    "recent"
) {
    empty.innerHTML = `
        <div class="drive-empty-icon">
            ◷
        </div>

        <h2>No recent files</h2>

        <p>
            Files you open will appear here.
        </p>
    `;
} else if (
    activeDriveSection ===
    "favorites"
) {
    empty.innerHTML = `
        <div class="drive-empty-icon">
            ☆
        </div>

        <h2>No favorites yet</h2>

        <p>
            Favorite files and folders to keep them easy to find.
        </p>
    `;
} else {
    empty.innerHTML = `
        <div class="drive-empty-icon">↥</div>

        <h2>This folder is empty</h2>

        <p>
            Upload a file or create a folder to get started.
        </p>

        <button
            type="button"
            class="drive-primary-button"
            id="drive-rendered-empty-upload"
        >
            Upload file
        </button>
    `;
}

        driveList.appendChild(empty);


        document
            .getElementById(
                "drive-rendered-empty-upload"
            )
            ?.addEventListener(
                "click",
                () => {
                    fileInput?.click();
                }
            );

        return;
    }


    /*
     * ----------------------------------------------------------------------
     * Folders
     * ----------------------------------------------------------------------
     */

    for (
        const folder of visibleFolders
    ) {
        const row =
            document.createElement("div");

        row.className =
            "drive-row";

        row.dataset.type =
            "folder";

        row.dataset.id =
            String(folder.id);


        row.innerHTML = `
            <div class="drive-item-name">
                <div class="drive-item-icon">
                    ▣
                </div>

                <div class="drive-item-details">
                    <div class="drive-item-title">
                        ${escapeHtml(folder.name)}
                    </div>

                    <div class="drive-item-subtitle">
                        Folder
                    </div>
                </div>
            </div>

            <div>
                ${escapeHtml(folder.owner_name ?? "—")}
            </div>

            <div>
                ${escapeHtml(formatDate(folder.updated_at))}
            </div>

            <div>
                —
            </div>

            <div>
                <span class="drive-access-badge">
                    Workspace
                </span>
            </div>

<div class="drive-folder-actions">
</div>
        `;


        const nameArea =
            row.querySelector(
                ".drive-item-name"
            );


        if (nameArea) {
            nameArea.style.cursor =
                "pointer";

            nameArea.addEventListener(
                "click",
                async () => {
                    currentFolderId =
                        Number(
                            folder.id
                        );

                    folderPath.push({
                        id:
                            Number(
                                folder.id
                            ),

                        name:
                            String(
                                folder.name
                            ),
                    });

                    await loadDrive();
                }
            );
        }

        /*
         * Folder actions
         */

        const folderActions =
            row.querySelector(
                ".drive-folder-actions"
            );


        if (folderActions) {
            const favoriteButton =
                createFavoriteButton(
                    "folder",
                    folder
                );

            folderActions.appendChild(
                favoriteButton
            );

            if (
                activeDriveSection !==
                "shared-with-me"
            ) {
                /*
                 * Rename
                 */

                const renameButton =
                    document.createElement(
                        "button"
                    );

                renameButton.type =
                    "button";

                renameButton.className =
                    "drive-access-button";

                renameButton.textContent =
                    "Rename";

                renameButton.title =
                    "Rename folder";


                renameButton.addEventListener(
                    "click",
                    async (event) => {
                        event.stopPropagation();


                        if (
                            renameButton.disabled
                        ) {
                            return;
                        }


                        renameButton.disabled =
                            true;


                        try {
                            const renamed =
                                await renameDriveFolder(
                                    folder
                                );


                            if (!renamed) {
                                return;
                            }


                            /*
                             * Reload so sorting, search results,
                             * breadcrumbs and other Drive views
                             * immediately use the new name.
                             */

                            await loadDrive();
                        } catch (error) {
                            console.error(
                                error
                            );


                            window.alert(
                                error instanceof Error
                                    ? error.message
                                    : "Unable to rename folder."
                            );
                        } finally {
                            if (
                                renameButton.isConnected
                            ) {
                                renameButton.disabled =
                                    false;
                            }
                        }
                    }
                );


                folderActions.appendChild(
                    renameButton
                );


                /*
                 * Move
                 */

                const moveButton =
                    document.createElement(
                        "button"
                    );

                moveButton.type =
                    "button";

                moveButton.className =
                    "drive-access-button";

                moveButton.textContent =
                    "Move";

                moveButton.title =
                    "Move folder";


                moveButton.addEventListener(
                    "click",
                    async (event) => {
                        event.stopPropagation();


                        if (
                            moveButton.disabled
                        ) {
                            return;
                        }


                        moveButton.disabled =
                            true;


                        try {
                            const moved =
                                await moveDriveItem(
                                    "folder",
                                    folder
                                );


                            if (!moved) {
                                return;
                            }


                            await loadDrive();
                        } catch (error) {
                            console.error(
                                error
                            );


                            window.alert(
                                error instanceof Error
                                    ? error.message
                                    : "Unable to move folder."
                            );
                        } finally {
                            if (
                                moveButton.isConnected
                            ) {
                                moveButton.disabled =
                                    false;
                            }
                        }
                    }
                );


                folderActions.appendChild(
                    moveButton
                );


                /*
                 * Move to Trash
                 */

                const deleteButton =
                    document.createElement(
                        "button"
                    );


                deleteButton.type =
                    "button";


                deleteButton.className =
                    "drive-access-button is-danger";


                deleteButton.textContent =
                    "Move to Trash";


                deleteButton.title =
                    "Move folder to Trash";


                deleteButton.addEventListener(
                    "click",
                    async (event) => {
                        event.stopPropagation();


                        if (
                            deleteButton.disabled
                        ) {
                            return;
                        }


                        try {
                            const deleted =
                                await deleteDriveFolder(
                                    folder
                                );


                            if (!deleted) {
                                return;
                            }


                            deleteButton.disabled =
                                true;


                            await loadDrive();
                        } catch (error) {
                            console.error(
                                error
                            );


                            window.alert(
                                error instanceof Error
                                    ? error.message
                                    : "Unable to delete folder."
                            );


                            deleteButton.disabled =
                                false;
                        }
                    }
                );


                folderActions.appendChild(
                    deleteButton
                );
            }


            createDriveActionMenu(
                folderActions
            );
        }


        driveList.appendChild(
            row
        );
    }


    /*
     * ----------------------------------------------------------------------
     * Files
     * ----------------------------------------------------------------------
     */

    for (
        const file of visibleFiles
    ) {
        const row =
            document.createElement("div");

        row.className =
            "drive-row";

        row.dataset.type =
            "file";

        row.dataset.id =
            String(file.id);


        const accessText =
            file.sharing_mode ===
            "workspace"
                ? "Workspace"
                : "Selected";


        row.innerHTML = `
            <div class="drive-item-name">
                <div class="drive-item-icon drive-file-thumbnail">
                    ${escapeHtml(fileIcon(file))}
                </div>

                <div class="drive-item-details">
                    <div class="drive-item-title">
                        ${escapeHtml(file.name)}
                    </div>

                    <div class="drive-item-subtitle" title="File contents are end-to-end encrypted">
                        ${escapeHtml(driveEncryptionStatus())}
                    </div>
                </div>
            </div>

            <div>
                ${escapeHtml(file.owner_name ?? "—")}
            </div>

            <div>
                ${escapeHtml(formatDate(file.updated_at))}
            </div>

            <div>
                ${escapeHtml(formatBytes(file.encrypted_size))}
            </div>

            <div>
                <span class="drive-access-badge">
                    ${escapeHtml(accessText)}
                </span>
            </div>

            <div class="drive-item-actions">
            </div>
        `;

        observeDriveThumbnail(
            file,
            row.querySelector(
                ".drive-file-thumbnail"
            )
        );


        /*
         * ------------------------------------------------------------------
         * Open / download encrypted file
         * ------------------------------------------------------------------
         */

                /*
         * ------------------------------------------------------------------
         * Open encrypted file
         * ------------------------------------------------------------------
         *
         * DOCX, XLSX and PDF files open in the built-in encrypted editor.
         *
         * Other file types keep the existing secure download/decrypt
         * behavior.
         */

        const fileNameArea =
            row.querySelector(
                ".drive-item-name"
            );


        if (fileNameArea) {
            fileNameArea.style.cursor =
                "pointer";


            const fileName =
                String(
                    file.name ?? ""
                ).toLowerCase();


            const mimeType =
                String(
                    file.mime_type ?? ""
                ).toLowerCase();


            const isImagePreview =
                isThumbnailImage(file);

            const hasBuiltInEditor =
                fileName.endsWith(".txt") || mimeType.split(";")[0].trim() === "text/plain" ||
                fileName.endsWith(".docx") ||
                fileName.endsWith(".xlsx") ||
                fileName.endsWith(".pdf") ||

                mimeType ===
                    "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ||

                mimeType ===
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||

                mimeType ===
                    "application/pdf";


            if (isImagePreview) {
                fileNameArea.title =
                    "Preview encrypted image";

                fileNameArea.addEventListener(
                    "click",
                    async () => {
                        const subtitle =
                            row.querySelector(
                                ".drive-item-subtitle"
                            );

                        await openImagePreview(
                            file,
                            subtitle
                        );
                    }
                );
            } else if (hasBuiltInEditor) {
                /*
                 * ----------------------------------------------------------
                 * Built-in editor
                 * ----------------------------------------------------------
                 */

                fileNameArea.title =
                    "Open in encrypted editor";


fileNameArea.addEventListener(
    "click",
    async () => {
        await markDriveFileRecent(
            file.id
        );

        window.location.href =
            "/drive/editor.php?file_id="
            + encodeURIComponent(
                String(
                    file.id
                )
            );
    }
);
            } else {
                /*
                 * ----------------------------------------------------------
                 * Normal encrypted download
                 * ----------------------------------------------------------
                 */

                fileNameArea.title =
                    "Download encrypted file";


                fileNameArea.addEventListener(
                    "click",
                    async () => {
                        /*
                         * Prevent multiple simultaneous downloads
                         * of the same file.
                         */
                        if (
                            row.dataset.downloading ===
                            "1"
                        ) {
                            return;
                        }


                        row.dataset.downloading =
                            "1";


                        const subtitle =
                            row.querySelector(
                                ".drive-item-subtitle"
                            );


                        const originalSubtitle =
                            subtitle?.textContent ??
                            "Encrypted file";


                        try {
    await markDriveFileRecent(
        file.id
    );

    await downloadDriveFile(
        file.id,
                                {
                                    onStatus(
                                        message
                                    ) {
                                        if (
                                            subtitle
                                        ) {
                                            subtitle.textContent =
                                                message;
                                        }
                                    },
                                }
                            );


                            if (subtitle) {
                                subtitle.textContent =
                                    "Downloaded securely";
                            }


                            window.setTimeout(
                                () => {
                                    if (
                                        subtitle
                                    ) {
                                        subtitle.textContent =
                                            originalSubtitle;
                                    }
                                },
                                1500
                            );
                        } catch (error) {
                            console.error(
                                error
                            );


                            if (subtitle) {
                                subtitle.textContent =
                                    error instanceof Error
                                        ? error.message
                                        : "Unable to open file.";

                                subtitle.classList.add(
                                    "is-error"
                                );
                            }


                            window.setTimeout(
                                () => {
                                    if (
                                        subtitle
                                    ) {
                                        subtitle.textContent =
                                            originalSubtitle;

                                        subtitle.classList.remove(
                                            "is-error"
                                        );
                                    }
                                },
                                4000
                            );
                        } finally {
                            delete row.dataset
                                .downloading;
                        }
                    }
                );
            }
        }


        /*
         * ------------------------------------------------------------------
         * File actions
         * ------------------------------------------------------------------
         */

        const actionsArea =
            row.querySelector(
                ".drive-item-actions"
            );


if (actionsArea) {
    /*
     * Favorite
     */

    const favoriteButton =
        createFavoriteButton(
            "file",
            file
        );

    actionsArea.appendChild(
        favoriteButton
    );

    if (
    activeDriveSection ===
    "shared-with-me"
) {
    createDriveActionMenu(
        actionsArea
    );

    driveList.appendChild(
        row
    );

    continue;
}

    /*
     * Rename file
     */

    const renameButton =
        document.createElement(
            "button"
        );

    renameButton.type =
        "button";

    renameButton.className =
        "drive-access-button";

    renameButton.textContent =
        "Rename";

    renameButton.title =
        "Rename file";


    renameButton.addEventListener(
        "click",
        async (event) => {
            event.stopPropagation();


            if (
                renameButton.disabled
            ) {
                return;
            }


            renameButton.disabled =
                true;


            try {
                const renamed =
                    await renameDriveFile(
                        file
                    );


                if (!renamed) {
                    return;
                }


                /*
                 * Reload so the new name is reflected
                 * everywhere and the current sort order
                 * is recalculated.
                 */
                await loadDrive();
            } catch (error) {
                console.error(error);


                window.alert(
                    error instanceof Error
                        ? error.message
                        : "Unable to rename file."
                );
            } finally {
                if (
                    renameButton.isConnected
                ) {
                    renameButton.disabled =
                        false;
                }
            }
        }
    );


    actionsArea.appendChild(
        renameButton
    );

    const moveButton = document.createElement("button");
    moveButton.type = "button";
    moveButton.className = "drive-access-button";
    moveButton.textContent = "Move";
    moveButton.title = "Move file";
    moveButton.addEventListener("click", async (event) => {
        event.stopPropagation();
        if (moveButton.disabled) {
            return;
        }
        moveButton.disabled = true;
        try {
            if (await moveDriveItem("file", file)) {
                await loadDrive();
            }
        } catch (error) {
            console.error(error);
            window.alert(error instanceof Error ? error.message : "Unable to move file.");
        } finally {
            moveButton.disabled = false;
        }
    });
    actionsArea.appendChild(moveButton);

        /*
     * Copy file
     */
    const copyButton =
        document.createElement(
            "button"
        );

    copyButton.type =
        "button";

    copyButton.className =
        "drive-access-button";

    copyButton.textContent =
        "Copy";

    copyButton.title =
        "Create an encrypted copy of this file";


    copyButton.addEventListener(
        "click",
        async (event) => {
            event.stopPropagation();

            if (copyButton.disabled) {
                return;
            }

            copyButton.disabled =
                true;

            const originalText =
                copyButton.textContent;

            copyButton.textContent =
                "Copying…";

            try {
                await copyDriveFile(
                    file
                );

                await loadDrive();
            } catch (error) {
                console.error(
                    error
                );

                window.alert(
                    error instanceof Error
                        ? error.message
                        : "Unable to copy file."
                );
            } finally {
                if (
                    copyButton.isConnected
                ) {
                    copyButton.disabled =
                        false;

                    copyButton.textContent =
                        originalText;
                }
            }
        }
    );


    actionsArea.appendChild(
        copyButton
    );

    const versionsButton =
        document.createElement(
            "button"
        );

    versionsButton.type =
        "button";

    versionsButton.className =
        "drive-access-button";

    versionsButton.textContent =
        "Versions";

    versionsButton.title =
        "View file version history";

    versionsButton.addEventListener(
        "click",
        (event) => {
            event.stopPropagation();
            void openVersionModal(
                file
            );
        }
    );

    actionsArea.appendChild(
        versionsButton
    );

    const activityButton =
        document.createElement(
            "button"
        );

    activityButton.type =
        "button";

    activityButton.className =
        "drive-access-button";

    activityButton.textContent =
        "Activity";

    activityButton.title =
        "View file activity";

    activityButton.addEventListener(
        "click",
        (event) => {
            event.stopPropagation();
            void openActivityModal(
                file
            );
        }
    );

    actionsArea.appendChild(
        activityButton
    );
    
    /*
     * Manage access
     */
            const accessButton =
                document.createElement(
                    "button"
                );

            accessButton.type =
                "button";

            accessButton.className =
                "drive-access-button";

            accessButton.textContent =
                "Manage access";

            accessButton.title =
                "Manage file access";


            accessButton.addEventListener(
                "click",
                (event) => {
                    /*
                     * Do not trigger the file download.
                     */
                    event.stopPropagation();


                    openAccessModal(
                        file.id
                    );
                }
            );


            actionsArea.appendChild(
                accessButton
            );

            /*
 * Delete file
 */

const deleteButton =
    document.createElement(
        "button"
    );


deleteButton.type =
    "button";


deleteButton.className =
    "drive-access-button is-danger";


deleteButton.textContent =
    "Move to Trash";


deleteButton.title =
    "Move file to Trash";


deleteButton.addEventListener(
    "click",
    async (event) => {
        event.stopPropagation();


        if (
            deleteButton.disabled
        ) {
            return;
        }


        try {
            const deleted =
                await deleteDriveFile(
                    file
                );


            if (!deleted) {
                return;
            }


            deleteButton.disabled =
                true;

            accessButton.disabled =
                true;


            /*
             * Reload from the server instead of only
             * removing the row locally.
             */
            await loadDrive();
        } catch (error) {
            console.error(
                error
            );


            window.alert(
                error instanceof Error
                    ? error.message
                    : "Unable to delete file."
            );


            deleteButton.disabled =
                false;
        }
    }
);


actionsArea.appendChild(
    deleteButton
);

createDriveActionMenu(
    actionsArea
);
        }


        /*
         * Finally add the completed file row.
         */
        driveList.appendChild(
            row
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Toggle Drive favorite
 * --------------------------------------------------------------------------
 */

async function toggleDriveFavorite(
    type,
    item
) {
    const normalizedType =
        String(type ?? "")
            .trim()
            .toLowerCase();

    const itemId =
        Number(item?.id);

    if (
        !["file", "folder"].includes(
            normalizedType
        ) ||
        !Number.isInteger(itemId) ||
        itemId <= 0
    ) {
        throw new Error(
            "Invalid Drive item."
        );
    }


    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "type",
        normalizedType
    );

    body.set(
        "item_id",
        String(itemId)
    );


    const response =
        await fetch(
            "/actions/drive/toggle-favorite.php",
            {
                method: "POST",

                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    let data = null;

    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while updating the favorite."
        );
    }


    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to update favorite."
        );
    }


    item.is_favorite =
        Boolean(
            data.is_favorite
        );


    return item.is_favorite;
}


/*
 * --------------------------------------------------------------------------
 * Create favorite button
 * --------------------------------------------------------------------------
 */

function createFavoriteButton(
    type,
    item
) {
    const button =
        document.createElement(
            "button"
        );

    button.type =
        "button";

    button.className =
        "drive-access-button";

    const updateButton = () => {
        const isFavorite =
            Boolean(
                item?.is_favorite
            );

        button.textContent =
            isFavorite
                ? "★ Favorite"
                : "☆ Favorite";

        button.title =
            isFavorite
                ? "Remove from Favorites"
                : "Add to Favorites";

        button.setAttribute(
            "aria-pressed",
            isFavorite
                ? "true"
                : "false"
        );
    };


    updateButton();


    button.addEventListener(
        "click",
        async (event) => {
            event.stopPropagation();

            if (button.disabled) {
                return;
            }


            button.disabled =
                true;

            const previousState =
                Boolean(
                    item?.is_favorite
                );


            /*
             * Optimistic update.
             */

            item.is_favorite =
                !previousState;

            updateButton();


            try {
                const isFavorite =
                    await toggleDriveFavorite(
                        type,
                        item
                    );

                item.is_favorite =
                    isFavorite;

                updateButton();


                /*
                 * When removing something from the
                 * Favorites section, remove it from
                 * the current view immediately.
                 */

                if (
                    activeDriveSection ===
                        "favorites" &&
                    !isFavorite
                ) {
                    if (type === "file") {
                        files =
                            files.filter(
                                (file) =>
                                    Number(file.id) !==
                                    Number(item.id)
                            );
                    } else {
                        folders =
                            folders.filter(
                                (folder) =>
                                    Number(folder.id) !==
                                    Number(item.id)
                            );
                    }

                    renderDrive();

                    return;
                }
            } catch (error) {
                /*
                 * Roll the optimistic state back.
                 */

                item.is_favorite =
                    previousState;

                updateButton();

                console.error(error);

                window.alert(
                    error instanceof Error
                        ? error.message
                        : "Unable to update favorite."
                );
            } finally {
                if (
                    button.isConnected
                ) {
                    button.disabled =
                        false;
                }
            }
        }
    );


    return button;
}

/*
 * --------------------------------------------------------------------------
 * Restore Drive file
 * --------------------------------------------------------------------------
 */

async function restoreDriveFile(file) {
    const fileId =
        Number(file?.id);

    if (
        !Number.isInteger(fileId) ||
        fileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }

    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "file_id",
        String(fileId)
    );

    const response =
        await fetch(
            "/actions/drive/restore.php",
            {
                method: "POST",
                credentials: "same-origin",
                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    let data = null;

    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while restoring the file."
        );
    }

    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to restore file."
        );
    }

    return true;
}


/*
 * --------------------------------------------------------------------------
 * Permanently delete Drive file
 * --------------------------------------------------------------------------
 */

async function permanentlyDeleteDriveFile(
    file
) {
    const fileId =
        Number(file?.id);

    const fileName =
        String(
            file?.name ??
            "this file"
        );

    if (
        !Number.isInteger(fileId) ||
        fileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }

const confirmed =
    window.confirm(
        `Permanently delete "${fileName}"?\n\n`
        + "The encrypted file and all of its version history will be permanently deleted.\n\n"
        + "This cannot be undone."
    );

    if (!confirmed) {
        return false;
    }

    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "file_id",
        String(fileId)
    );

    const response =
        await fetch(
            "/actions/drive/permanent-delete.php",
            {
                method: "POST",
                credentials: "same-origin",
                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    let data = null;

    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while permanently deleting the file."
        );
    }

    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to permanently delete file."
        );
    }

    if (
        data.storage_cleanup_complete ===
        false
    ) {
        console.warn(
            "The Drive database entry was deleted, but encrypted storage cleanup was incomplete."
        );
    }

    return true;
}


/*
 * --------------------------------------------------------------------------
 * Restore Drive folder
 * --------------------------------------------------------------------------
 */

async function restoreDriveFolder(
    folder
) {
    const folderId =
        Number(folder?.id);

    if (
        !Number.isInteger(folderId) ||
        folderId <= 0
    ) {
        throw new Error(
            "Invalid Drive folder."
        );
    }

    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "folder_id",
        String(folderId)
    );

    const response =
        await fetch(
            "/actions/drive/restore-folder.php",
            {
                method: "POST",
                credentials: "same-origin",
                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    let data = null;

    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while restoring the folder."
        );
    }

    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to restore folder."
        );
    }

    return true;
}


/*
 * --------------------------------------------------------------------------
 * Permanently delete Drive folder
 * --------------------------------------------------------------------------
 */

async function permanentlyDeleteDriveFolder(
    folder
) {
    const folderId =
        Number(folder?.id);

    const folderName =
        String(
            folder?.name ??
            "this folder"
        );

    if (
        !Number.isInteger(folderId) ||
        folderId <= 0
    ) {
        throw new Error(
            "Invalid Drive folder."
        );
    }

    const confirmed =
        window.confirm(
            `Permanently delete folder "${folderName}"?\n\n`
            + "Everything inside this folder tree will be permanently deleted, including encrypted files and their version history.\n\n"
            + "This cannot be undone."
        );

    if (!confirmed) {
        return false;
    }

    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "folder_id",
        String(folderId)
    );

    const response =
        await fetch(
            "/actions/drive/permanent-delete-folder.php",
            {
                method: "POST",
                credentials: "same-origin",
                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    let data = null;

    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while permanently deleting the folder."
        );
    }

    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to permanently delete folder."
        );
    }

    if (
        data.storage_cleanup_complete ===
        false
    ) {
        console.warn(
            "The folder metadata was deleted, but some encrypted storage cleanup was incomplete."
        );
    }

    return true;
}

/*
 * --------------------------------------------------------------------------
 * Rename Drive item
 * --------------------------------------------------------------------------
 */

function getRenamedDriveItemName(
    item,
    type
) {
    const currentName =
        String(
            item?.name ?? ""
        ).trim();


    const enteredName =
        window.prompt(
            type === "folder"
                ? "Rename folder"
                : "Rename file",
            currentName
        );


    if (enteredName === null) {
        return null;
    }


    const name =
        enteredName.trim();


    if (!name) {
        window.alert(
            type === "folder"
                ? "Enter a folder name."
                : "Enter a file name."
        );

        return null;
    }


    if (
        /[\\/:*?"<>|\x00-\x1f]/.test(
            name
        )
    ) {
        window.alert(
            "The name contains characters that are not allowed."
        );

        return null;
    }


    if (name.length > 200) {
        window.alert(
            "Use a name of 200 characters or fewer."
        );

        return null;
    }


    if (name === currentName) {
        return null;
    }


    return name;
}


async function renameDriveFolder(
    folder
) {
    const folderId =
        Number(folder?.id);


    if (
        !Number.isInteger(folderId) ||
        folderId <= 0
    ) {
        throw new Error(
            "Invalid Drive folder."
        );
    }


    const name =
        getRenamedDriveItemName(
            folder,
            "folder"
        );


    if (name === null) {
        return false;
    }


    const body =
        new FormData();


    body.set(
        "csrf_token",
        csrfToken
    );


body.set(
    "type",
    "folder"
);


body.set(
    "item_id",
    String(folderId)
);


body.set(
    "name",
    name
);


const response =
    await fetch(
        "/actions/drive/rename.php",
            {
                method: "POST",

                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    let data = null;


    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while renaming the folder."
        );
    }


    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to rename folder."
        );
    }


    folder.name =
    String(
        data.name ??
        name
    );


    return true;
}


async function renameDriveFile(
    file
) {
    const fileId =
        Number(file?.id);


    if (
        !Number.isInteger(fileId) ||
        fileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }


    const name =
        getRenamedDriveItemName(
            file,
            "file"
        );


    if (name === null) {
        return false;
    }


    const body =
        new FormData();


    body.set(
        "csrf_token",
        csrfToken
    );


body.set(
    "type",
    "file"
);


body.set(
    "item_id",
    String(fileId)
);


body.set(
    "name",
    name
);


const response =
    await fetch(
        "/actions/drive/rename.php",
            {
                method: "POST",

                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    let data = null;


    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while renaming the file."
        );
    }


    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to rename file."
        );
    }


file.name =
    String(
        data.name ??
        name
    );


    return true;
}

async function moveDriveItem(type, item) {
    const itemId = Number(item?.id ?? 0);

    if (
        !itemId ||
        (type !== "file" && type !== "folder")
    ) {
        return false;
    }

    let data;

    try {
        const params = new URLSearchParams();

        params.set("type", type);
        params.set("item_id", String(itemId));

        const response = await fetch(
            `/actions/drive/move-destinations.php?${params.toString()}`,
            {
                method: "GET",
                credentials: "same-origin",
                cache: "no-store",
            }
        );

        data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(
                data.error ||
                "Unable to load Drive folders."
            );
        }
    } catch (error) {
        console.error(error);

        alert(
            error instanceof Error
                ? error.message
                : "Unable to load Drive folders."
        );

        return false;
    }


    const folders =
        Array.isArray(data.folders)
            ? data.folders
            : [];


    /*
     * For now this uses a compact numbered destination picker.
     *
     * We will replace this with the full Drive dialog UI when we do
     * the remaining Drive interaction/polish requirements.
     */
    const destinations = [
        {
            id: null,
            path: "My Drive",
        },

        ...folders.map((folder) => ({
            id: Number(folder.id),
            path: `My Drive / ${String(folder.path ?? folder.name ?? "Folder")}`,
        })),
    ];


    const currentFolderId =
        type === "file"
            ? (
                item.folder_id === null ||
                item.folder_id === undefined
                    ? null
                    : Number(item.folder_id)
            )
            : (
                item.parent_id === null ||
                item.parent_id === undefined
                    ? null
                    : Number(item.parent_id)
            );


    const choices =
        destinations
            .map((destination, index) => {
                const isCurrent =
                    destination.id === currentFolderId;

                return (
                    `${index + 1}. ${destination.path}` +
                    (isCurrent ? " (current)" : "")
                );
            })
            .join("\n");


    const answer = window.prompt(
        `Move "${String(item.name ?? "Drive item")}" to:\n\n` +
        choices +
        "\n\nEnter the destination number:"
    );


    if (answer === null) {
        return false;
    }


    const choice =
        Number.parseInt(
            answer.trim(),
            10
        );


    if (
        !Number.isInteger(choice) ||
        choice < 1 ||
        choice > destinations.length
    ) {
        alert("Choose a valid destination number.");

        return false;
    }


    const destination =
        destinations[choice - 1];


    if (
        destination.id ===
        currentFolderId
    ) {
        return false;
    }


    const body =
        new URLSearchParams();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "type",
        type
    );

    body.set(
        "item_id",
        String(itemId)
    );


    /*
     * Empty folder_id means My Drive/root.
     */
    body.set(
        "folder_id",
        destination.id === null
            ? ""
            : String(destination.id)
    );


    try {
        const response =
            await fetch(
                "/actions/drive/move.php",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded;charset=UTF-8",
                    },

                    credentials:
                        "same-origin",

                    body:
                        body.toString(),
                }
            );


        const result =
            await response.json();


        if (
            !response.ok ||
            !result.success
        ) {
            throw new Error(
                result.error ||
                "Unable to move the Drive item."
            );
        }


        return true;
    } catch (error) {
        console.error(error);

        alert(
            error instanceof Error
                ? error.message
                : "Unable to move the Drive item."
        );

        return false;
    }
}

/*
 * --------------------------------------------------------------------------
 * Delete Drive folder
 * --------------------------------------------------------------------------
 */

async function deleteDriveFolder(folder) {
    const folderId =
        Number(folder?.id);

    const folderName =
        String(
            folder?.name ??
            "this folder"
        );

    if (
        !Number.isInteger(folderId) ||
        folderId <= 0
    ) {
        throw new Error(
            "Invalid Drive folder."
        );
    }


const confirmed =
    window.confirm(
        `Move folder "${folderName}" to Trash?\n\n`
        + "The folder and everything inside it will be hidden from My Drive. "
        + "You can restore it from Trash."
    );


    if (!confirmed) {
        return false;
    }


    const body =
        new FormData();


    body.set(
        "csrf_token",
        csrfToken
    );


    body.set(
        "folder_id",
        String(folderId)
    );


    const response =
        await fetch(
            "/actions/drive/delete-folder.php",
            {
                method: "POST",

                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    let data = null;


    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while deleting the folder."
        );
    }


    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to delete folder."
        );
    }


    return true;
}

/*
 * --------------------------------------------------------------------------
 * Delete Drive file
 * --------------------------------------------------------------------------
 */

async function deleteDriveFile(file) {
    const fileId =
        Number(file?.id);

    const fileName =
        String(
            file?.name ??
            "this file"
        );

    if (
        !Number.isInteger(fileId) ||
        fileId <= 0
    ) {
        throw new Error(
            "Invalid Drive file."
        );
    }


const confirmed =
    window.confirm(
        `Move "${fileName}" to Trash?\n\n`
        + "The encrypted file and its version history will be kept. "
        + "You can restore it from Trash."
    );


    if (!confirmed) {
        return false;
    }


    const body =
        new FormData();


    body.set(
        "csrf_token",
        csrfToken
    );


    body.set(
        "file_id",
        String(fileId)
    );


    const response =
        await fetch(
            "/actions/drive/delete.php",
            {
                method: "POST",

                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    let data = null;


    try {
        data =
            await response.json();
    } catch {
        throw new Error(
            "The server returned an invalid response while deleting the file."
        );
    }


    if (
        !response.ok ||
        !data?.success
    ) {
        throw new Error(
            data?.error ||
            "Unable to delete file."
        );
    }


    return true;
}

/*
 * --------------------------------------------------------------------------
 * Mark Drive file as recent
 * --------------------------------------------------------------------------
 */

async function markDriveFileRecent(
    fileId
) {
    const normalizedFileId =
        Number(fileId);

    if (
        !Number.isInteger(
            normalizedFileId
        ) ||
        normalizedFileId <= 0
    ) {
        return;
    }


    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "file_id",
        String(normalizedFileId)
    );


    try {
        const response =
            await fetch(
                "/actions/drive/mark-recent.php",
                {
                    method: "POST",

                    credentials:
                        "same-origin",

                    body,

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        /*
         * Recent tracking must never prevent the user
         * from opening an otherwise accessible file.
         */

        if (!response.ok) {
            console.warn(
                "Unable to update Drive Recent."
            );
        }
    } catch (error) {
        console.warn(
            "Unable to update Drive Recent.",
            error
        );
    }
}

/*
 * --------------------------------------------------------------------------
 * Search Drive
 * --------------------------------------------------------------------------
 */

async function searchDrive(
    query
) {
    const searchTerm =
        String(query ?? "")
            .trim();

    /*
     * Empty search means return to the normal
     * contents of the currently selected section.
     */
    if (!searchTerm) {
        if (driveSearchRequest) {
            driveSearchRequest.abort();
            driveSearchRequest = null;
        }

        await loadDrive();

        return;
    }


    /*
     * Workspace-wide search belongs to My Drive.
     *
     * Trash, Recent, Favorites and sharing views
     * keep their own local filtering behavior.
     */
    if (
        activeDriveSection !==
        "drive"
    ) {
        renderDrive();

        return;
    }


    /*
     * Cancel an older search that is still running.
     */
    if (driveSearchRequest) {
        driveSearchRequest.abort();
    }


    const controller =
        new AbortController();

    driveSearchRequest =
        controller;


    /*
     * Sequence numbers protect against an older response
     * replacing the results from a newer search.
     */
    const sequence =
        ++driveSearchSequence;


    try {
        const params =
            new URLSearchParams();

        params.set(
            "q",
            searchTerm
        );


        const response =
            await fetch(
                "/actions/drive/search.php?"
                + params.toString(),
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    signal:
                        controller.signal,

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        let data = null;

        try {
            data =
                await response.json();
        } catch {
            throw new Error(
                "The server returned an invalid response while searching Drive."
            );
        }


        if (
            !response.ok ||
            !data?.success
        ) {
            throw new Error(
                data?.error ||
                "Unable to search Drive."
            );
        }


        /*
         * Ignore stale results.
         */
        if (
            sequence !==
            driveSearchSequence
        ) {
            return;
        }


        /*
         * Ignore results if the user changed sections
         * while this request was running.
         */
        if (
            activeDriveSection !==
            "drive"
        ) {
            return;
        }


        /*
         * Ignore results if the input changed before
         * this response arrived.
         */
        if (
            String(
                searchInput?.value ?? ""
            ).trim() !== searchTerm
        ) {
            return;
        }


        folders =
            Array.isArray(
                data.folders
            )
                ? data.folders
                : [];


        files =
            Array.isArray(
                data.files
            )
                ? data.files
                : [];


        /*
         * Search results are workspace-wide, so the
         * current folder hierarchy no longer describes
         * what is being displayed.
         */
        currentFolderId =
            null;

        folderPath =
            [];


        renderBreadcrumbs();
        renderDrive();
    } catch (error) {
        if (
            error?.name ===
            "AbortError"
        ) {
            return;
        }

        console.error(error);

        folders = [];
        files = [];

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">
                        !
                    </div>

                    <h2>
                        Unable to search Drive
                    </h2>

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}
                    </p>
                </div>
            `;
        }
    } finally {
        if (
            driveSearchRequest ===
            controller
        ) {
            driveSearchRequest =
                null;
        }
    }
}

/*
 * --------------------------------------------------------------------------
 * Load Shared with me
 * --------------------------------------------------------------------------
 */

async function loadSharedWithMe() {
    try {
        const response =
            await fetch(
                "/actions/drive/shared-with-me.php",
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        let data = null;

        try {
            data =
                await response.json();
        } catch {
            throw new Error(
                "The server returned an invalid response while loading files shared with you."
            );
        }


        if (
            !response.ok ||
            !data?.success
        ) {
            throw new Error(
                data?.error ||
                "Unable to load files shared with you."
            );
        }


        folders =
            Array.isArray(data.folders)
                ? data.folders
                : [];

        files =
            Array.isArray(data.files)
                ? data.files
                : [];


        renderDrive();
    } catch (error) {
        console.error(error);

        folders = [];
        files = [];

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">
                        !
                    </div>

                    <h2>
                        Unable to load Shared with me
                    </h2>

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}
                    </p>
                </div>
            `;
        }
    }
}


/*
 * --------------------------------------------------------------------------
 * Load Shared by me
 * --------------------------------------------------------------------------
 */

async function loadSharedByMe() {
    try {
        const response =
            await fetch(
                "/actions/drive/shared-by-me.php",
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        let data = null;

        try {
            data =
                await response.json();
        } catch {
            throw new Error(
                "The server returned an invalid response while loading files shared by you."
            );
        }


        if (
            !response.ok ||
            !data?.success
        ) {
            throw new Error(
                data?.error ||
                "Unable to load files shared by you."
            );
        }


        folders =
            Array.isArray(data.folders)
                ? data.folders
                : [];

        files =
            Array.isArray(data.files)
                ? data.files
                : [];


        renderDrive();
    } catch (error) {
        console.error(error);
        

        folders = [];
        files = [];

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">
                        !
                    </div>

                    <h2>
                        Unable to load Shared by me
                    </h2>
                    
                    

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}

                        
                    </p>
                </div>
            `;
        }
    }
}

/*
 * --------------------------------------------------------------------------
 * Load Recent
 * --------------------------------------------------------------------------
 */

async function loadRecent() {
    try {
        const response =
            await fetch(
                "/actions/drive/recent.php",
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        let data = null;

        try {
            data =
                await response.json();
        } catch {
            throw new Error(
                "The server returned an invalid response while loading Recent."
            );
        }


        if (
            !response.ok ||
            !data?.success
        ) {
            throw new Error(
                data?.error ||
                "Unable to load Recent."
            );
        }


        folders =
            Array.isArray(
                data.folders
            )
                ? data.folders
                : [];


        files =
            Array.isArray(
                data.files
            )
                ? data.files
                : [];


        renderDrive();
    } catch (error) {
        console.error(error);

        folders = [];
        files = [];

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">
                        !
                    </div>

                    <h2>
                        Unable to load Recent
                    </h2>

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}
                    </p>
                </div>
            `;
        }
    }
}

async function loadFavorites() {
    try {
        const response =
            await fetch(
                "/actions/drive/favorites.php",
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        let data = null;

        try {
            data =
                await response.json();
        } catch {
            throw new Error(
                "The server returned an invalid response while loading Favorites."
            );
        }


        if (
            !response.ok ||
            !data?.success
        ) {
            throw new Error(
                data?.error ||
                "Unable to load Favorites."
            );
        }


        folders =
            Array.isArray(
                data.folders
            )
                ? data.folders.map(
                    (folder) => ({
                        ...folder,
                        is_favorite: true,
                    })
                )
                : [];


        files =
            Array.isArray(
                data.files
            )
                ? data.files.map(
                    (file) => ({
                        ...file,
                        is_favorite: true,
                    })
                )
                : [];


        renderDrive();
    } catch (error) {
        console.error(error);

        folders = [];
        files = [];

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">
                        !
                    </div>

                    <h2>
                        Unable to load Favorites
                    </h2>

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}
                    </p>
                </div>
            `;
        }
    }
}

/*
 * --------------------------------------------------------------------------
 * Load Drive
 * --------------------------------------------------------------------------
 */
async function loadTrash() {
    try {
        const response =
            await fetch(
                "/actions/drive/trash.php",
                {
                    method: "GET",

                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        const data =
            await response.json();


        if (
            !response.ok ||
            !data.success
        ) {
            throw new Error(
                data.error ||
                "Unable to load Trash."
            );
        }


        folders =
            Array.isArray(data.folders)
                ? data.folders
                : [];

        files =
            Array.isArray(data.files)
                ? data.files
                : [];


        renderDrive();
    } catch (error) {
        console.error(error);

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">!</div>

                    <h2>Unable to load Trash</h2>

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}
                    </p>
                </div>
            `;
        }
    }
}


async function loadDrive() {
    updateDriveSectionUi();
    void loadDriveStorageUsage();


    /*
     * Trash has its own endpoint.
     */

if (
    activeDriveSection ===
    "trash"
) {
    await loadTrash();
    return;
}

if (
    activeDriveSection ===
    "recent"
) {
    await loadRecent();
    return;
}

if (
    activeDriveSection ===
    "favorites"
) {
    await loadFavorites();
    return;
}

if (
    activeDriveSection ===
    "shared-with-me"
) {
    await loadSharedWithMe();
    return;
}


if (
    activeDriveSection ===
    "shared-by-me"
) {
    await loadSharedByMe();
    return;
}

/*
 * Recent and sharing views are still being connected.
 */

if (
    activeDriveSection !==
    "drive"
) {
        folders = [];
        files = [];

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">◫</div>

                    <h2>Coming next</h2>

                    <p>
                        This Drive section is being connected.
                    </p>
                </div>
            `;
        }

        return;
    }


    try {
        const params =
            new URLSearchParams();

        if (
            currentFolderId !== null
        ) {
            params.set(
                "folder_id",
                String(currentFolderId)
            );
        }


        const url =
            "/actions/drive/list.php" +
            (
                params.toString()
                    ? `?${params.toString()}`
                    : ""
            );


        const response =
            await fetch(
                url,
                {
                    method: "GET",
                    credentials:
                        "same-origin",

                    headers: {
                        Accept:
                            "application/json",
                    },
                }
            );


        const data =
            await response.json();


        if (
            !response.ok ||
            !data.success
        ) {
            throw new Error(
                data.error ||
                "Unable to load Drive."
            );
        }


        folders =
            Array.isArray(data.folders)
                ? data.folders
                : [];

        files =
            Array.isArray(data.files)
                ? data.files
                : [];


        renderBreadcrumbs();
        renderDrive();
    } catch (error) {
        console.error(error);

        if (driveList) {
            driveList.innerHTML = `
                <div class="drive-empty-state">
                    <div class="drive-empty-icon">!</div>

                    <h2>Unable to load Drive</h2>

                    <p>
                        ${escapeHtml(
                            error instanceof Error
                                ? error.message
                                : "An unexpected error occurred."
                        )}
                    </p>
                </div>
            `;
        }
    }
}


/*
 * --------------------------------------------------------------------------
 * Load workspace members
 * --------------------------------------------------------------------------
 */

async function loadWorkspaceMembers() {
    const response =
        await fetch(
            "/actions/drive/members.php",
            {
                method: "GET",
                credentials:
                    "same-origin",

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    const data =
        await response.json();


    if (
        !response.ok ||
        !data.success
    ) {
        throw new Error(
            data.error ||
            "Unable to load workspace members."
        );
    }


    workspaceMembers =
        Array.isArray(data.members)
            ? data.members
            : [];


    renderMemberOptions();
}


function renderMemberOptions() {
    if (!memberSelect) {
        return;
    }

    memberSelect.innerHTML = "";


    for (
        const member of workspaceMembers
    ) {
        /*
         * The uploader is always included automatically.
         * No need to make the user select themselves.
         */
        if (
            Number(member.id) ===
            currentUserId
        ) {
            continue;
        }


        const option =
            document.createElement(
                "option"
            );

        option.value =
            String(member.id);

        option.textContent =
            member.name ||
            member.email ||
            `User ${member.id}`;

        memberSelect.appendChild(
            option
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Folder modal
 * --------------------------------------------------------------------------
 */

function openFolderModal() {
    if (!folderBackdrop) {
        return;
    }

    setFolderStatus("");

    if (folderNameInput) {
        folderNameInput.value = "";
    }

    folderBackdrop.hidden = false;

    document.body.classList.add(
        "drive-modal-open"
    );

    window.setTimeout(
        () => {
            folderNameInput?.focus();
        },
        0
    );
}


function closeFolderModal() {
    if (!folderBackdrop) {
        return;
    }

    folderBackdrop.hidden = true;

    document.body.classList.remove(
        "drive-modal-open"
    );

    setFolderStatus("");
}


async function createFolder(name) {
    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "name",
        name
    );

    if (
        currentFolderId !== null
    ) {
        body.set(
            "parent_id",
            String(currentFolderId)
        );
    }


    const response =
        await fetch(
            "/actions/drive/create-folder.php",
            {
                method: "POST",
                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    const data =
        await response.json();


    if (
        !response.ok ||
        !data.success
    ) {
        throw new Error(
            data.error ||
            "Unable to create folder."
        );
    }


    return data.folder;
}


/*
 * --------------------------------------------------------------------------
 * Upload modal
 * --------------------------------------------------------------------------
 */

function openFilePicker() {
    fileInput?.click();
}


function renderSelectedFilesDisplay() {
    if (!selectedFileDisplay) {
        return;
    }

    if (selectedFiles.length === 0) {
        selectedFileDisplay.textContent =
            "No file selected.";

        return;
    }

    if (selectedFiles.length === 1) {
        const file =
            selectedFiles[0];

        selectedFileDisplay.textContent =
            `${file.name} · ${formatBytes(file.size)}`;

        return;
    }

    selectedFileDisplay.innerHTML = `
        <strong>
            ${selectedFiles.length} files selected
        </strong>

        <div>
            ${selectedFiles
                .slice(0, 5)
                .map(
                    (file) =>
                        `${escapeHtml(file.name)} · ${escapeHtml(formatBytes(file.size))}`
                )
                .join("<br>")}
            ${selectedFiles.length > 5
                ? `<br>${selectedFiles.length - 5} more files`
                : ""}
        </div>
    `;
}


async function fetchDriveVersions(
    fileId
) {
    const params =
        new URLSearchParams();

    params.set(
        "file_id",
        String(fileId)
    );

    const response =
        await fetch(
            "/actions/drive/versions.php?"
            + params.toString(),
            {
                method: "GET",
                credentials:
                    "same-origin",

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    const data =
        await response.json();

    if (
        !response.ok ||
        !data.success
    ) {
        throw new Error(
            data.error ||
            "Unable to load versions."
        );
    }

    return data;
}


async function restoreDriveVersion(
    fileId,
    versionId
) {
    const body =
        new FormData();

    body.set(
        "csrf_token",
        csrfToken
    );

    body.set(
        "file_id",
        String(fileId)
    );

    body.set(
        "version_id",
        String(versionId)
    );

    const response =
        await fetch(
            "/actions/drive/restore-version.php",
            {
                method: "POST",
                credentials:
                    "same-origin",

                body,

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    const data =
        await response.json();

    if (
        !response.ok ||
        !data.success
    ) {
        throw new Error(
            data.error ||
            "Unable to restore version."
        );
    }

    return data;
}


async function fetchDriveActivity(
    fileId
) {
    const params =
        new URLSearchParams();

    params.set(
        "file_id",
        String(fileId)
    );

    const response =
        await fetch(
            "/actions/drive/activity.php?"
            + params.toString(),
            {
                method: "GET",
                credentials:
                    "same-origin",

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );

    const data =
        await response.json();

    if (
        !response.ok ||
        !data.success
    ) {
        throw new Error(
            data.error ||
            "Unable to load activity."
        );
    }

    return Array.isArray(data.activity)
        ? data.activity
        : [];
}


function driveActivityText(
    item
) {
    const actor =
        item.actor_name ||
        "Someone";

    const details =
        item.details || {};

    switch (item.action) {
        case "file_uploaded":
            return `${actor} uploaded this file`;
        case "file_renamed":
            return `${actor} renamed this file`;
        case "file_moved":
            return `${actor} moved this file`;
        case "file_copied":
            return `${actor} copied this file`;
        case "file_trashed":
            return `${actor} moved this file to Trash`;
        case "file_restored":
            return `${actor} restored this file`;
        case "file_permanently_deleted":
            return `${actor} permanently deleted this file`;
        case "version_created":
            return `${actor} created version ${details.version_number ?? ""}`.trim();
        case "version_restored":
            return `${actor} restored version ${details.restored_from_version ?? ""}`.trim();
        default:
            return `${actor} updated this file`;
    }
}


function closeActivityModal(
    backdrop
) {
    backdrop.remove();
    document.body.classList.remove(
        "drive-modal-open"
    );
}


async function openActivityModal(
    file
) {
    const backdrop =
        document.createElement("div");

    backdrop.className =
        "drive-modal-backdrop";

    backdrop.innerHTML = `
        <section
            class="drive-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="drive-activity-title"
        >
            <header class="drive-modal-header">
                <div>
                    <p class="drive-modal-eyebrow">
                        File activity
                    </p>

                    <h2 id="drive-activity-title">
                        ${escapeHtml(file.name ?? "Encrypted file")}
                    </h2>
                </div>

                <button
                    type="button"
                    class="drive-modal-close"
                    aria-label="Close"
                    data-activity-close
                >
                    ×
                </button>
            </header>

            <div class="drive-modal-body">
                <div class="drive-activity-list">
                    Loading activity…
                </div>
            </div>
        </section>
    `;

    document.body.appendChild(
        backdrop
    );

    document.body.classList.add(
        "drive-modal-open"
    );

    backdrop.addEventListener(
        "click",
        (event) => {
            if (
                event.target === backdrop ||
                event.target.closest(
                    "[data-activity-close]"
                )
            ) {
                closeActivityModal(
                    backdrop
                );
            }
        }
    );

    const list =
        backdrop.querySelector(
            ".drive-activity-list"
        );

    try {
        const items =
            await fetchDriveActivity(
                file.id
            );

        if (items.length === 0) {
            list.innerHTML =
                "<p class=\"drive-empty-panel\">No activity yet.</p>";
            return;
        }

        list.innerHTML = "";

        for (
            const item of items
        ) {
            const row =
                document.createElement("div");

            row.className =
                "drive-activity-item";

            row.innerHTML = `
                <div class="drive-access-avatar">
                    ${escapeHtml(
                        String(item.actor_name ?? "?")
                            .trim()
                            .charAt(0)
                            .toUpperCase() || "?"
                    )}
                </div>

                <div>
                    <strong>
                        ${escapeHtml(driveActivityText(item))}
                    </strong>

                    <small>
                        ${escapeHtml(formatDate(item.created_at))}
                    </small>
                </div>
            `;

            list.appendChild(
                row
            );
        }
    } catch (error) {
        console.error(error);

        list.innerHTML = `
            <p class="drive-empty-panel is-error">
                ${escapeHtml(
                    error instanceof Error
                        ? error.message
                        : "Unable to load activity."
                )}
            </p>
        `;
    }
}


function closeVersionModal(
    backdrop
) {
    backdrop.remove();
    document.body.classList.remove(
        "drive-modal-open"
    );
}


async function openVersionModal(
    file
) {
    const backdrop =
        document.createElement("div");

    backdrop.className =
        "drive-modal-backdrop";

    backdrop.innerHTML = `
        <section
            class="drive-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="drive-version-title"
        >
            <header class="drive-modal-header">
                <div>
                    <p class="drive-modal-eyebrow">
                        Version history
                    </p>

                    <h2 id="drive-version-title">
                        ${escapeHtml(file.name ?? "Encrypted file")}
                    </h2>
                </div>

                <button
                    type="button"
                    class="drive-modal-close"
                    aria-label="Close"
                    data-version-close
                >
                    ×
                </button>
            </header>

            <div class="drive-modal-body">
                <div class="drive-version-list">
                    Loading versions…
                </div>
            </div>
        </section>
    `;

    document.body.appendChild(
        backdrop
    );

    document.body.classList.add(
        "drive-modal-open"
    );

    backdrop.addEventListener(
        "click",
        (event) => {
            if (
                event.target === backdrop ||
                event.target.closest(
                    "[data-version-close]"
                )
            ) {
                closeVersionModal(
                    backdrop
                );
            }
        }
    );

    const list =
        backdrop.querySelector(
            ".drive-version-list"
        );

    try {
        const data =
            await fetchDriveVersions(
                file.id
            );

        const versions =
            Array.isArray(data.versions)
                ? data.versions
                : [];

        if (versions.length === 0) {
            list.innerHTML =
                "<p class=\"drive-empty-panel\">No versions yet.</p>";
            return;
        }

        list.innerHTML = "";

        for (
            const version of versions
        ) {
            const item =
                document.createElement("div");

            item.className =
                "drive-version-item";

            item.innerHTML = `
                <div>
                    <strong>
                        Version ${escapeHtml(version.version_number)}
                        ${version.is_current ? " · Current" : ""}
                    </strong>

                    <small>
                        ${escapeHtml(formatBytes(version.encrypted_size))}
                        · ${escapeHtml(formatDate(version.created_at))}
                        · ${escapeHtml(version.created_by_name ?? "Unknown user")}
                    </small>
                </div>
            `;

            if (
                data.file?.can_edit &&
                !data.file?.is_trashed &&
                !version.is_current
            ) {
                const button =
                    document.createElement("button");

                button.type =
                    "button";

                button.className =
                    "drive-access-button";

                button.textContent =
                    "Restore";

                button.addEventListener(
                    "click",
                    async () => {
                        if (
                            !window.confirm(
                                `Restore version ${version.version_number}?\n\nA new current version will be created and existing history will be preserved.`
                            )
                        ) {
                            return;
                        }

                        button.disabled =
                            true;

                        try {
                            await restoreDriveVersion(
                                file.id,
                                version.id
                            );

                            await loadDrive();

                            closeVersionModal(
                                backdrop
                            );
                        } catch (error) {
                            console.error(error);
                            window.alert(
                                error instanceof Error
                                    ? error.message
                                    : "Unable to restore version."
                            );
                            button.disabled =
                                false;
                        }
                    }
                );

                item.appendChild(
                    button
                );
            }

            list.appendChild(
                item
            );
        }
    } catch (error) {
        console.error(error);

        list.innerHTML = `
            <p class="drive-empty-panel is-error">
                ${escapeHtml(
                    error instanceof Error
                        ? error.message
                        : "Unable to load versions."
                )}
            </p>
        `;
    }
}


async function openUploadModal(
    files
) {
    selectedFiles =
        Array.isArray(files)
            ? files.filter(
                (file) =>
                    file instanceof File
            )
            : files instanceof File
                ? [files]
                : [];

    if (selectedFiles.length === 0) {
        return;
    }

    selectedUploadFolderId =
        currentFolderId;

    creatingDocument = false;
    if (uploadConfirmButton) uploadConfirmButton.textContent = "Encrypt and upload";

    setUploadStatus("");


    renderSelectedFilesDisplay();


    if (uploadConfirmButton) {
        uploadConfirmButton.disabled =
            true;
    }


    if (uploadBackdrop) {
        uploadBackdrop.hidden =
            false;
    }


    document.body.classList.add(
        "drive-modal-open"
    );


    try {
        if (
            !hasActiveVaultSession()
        ) {
            throw new Error(
                "Your Key Vault is locked. Open Key Vault and unlock it before uploading encrypted files."
            );
        }


        setUploadStatus(
            "Loading workspace members…"
        );


        await loadWorkspaceMembers();


        setUploadStatus("");


        if (uploadConfirmButton) {
            uploadConfirmButton.disabled =
                false;
        }
    } catch (error) {
        console.error(error);

        setUploadStatus(
            error instanceof Error
                ? error.message
                : "Unable to prepare encrypted upload.",
            "error"
        );
    }
}


function closeUploadModal() {
    if (uploadInProgress) {
        return;
    }

    selectedFiles = [];
    selectedUploadFolderId = null;
    renderSelectedFilesDisplay();

    if (fileInput) {
        fileInput.value = "";
    }

    if (uploadBackdrop) {
        uploadBackdrop.hidden = true;
    }

    document.body.classList.remove(
        "drive-modal-open"
    );

    setUploadStatus("");
}


function isUploadAbortError(
    error
) {
    return (
        error instanceof DOMException &&
        error.name === "AbortError"
    );
}


function createUploadAbortError() {
    return new DOMException(
        "Upload cancelled.",
        "AbortError"
    );
}


function requestUploadCancel() {
    if (!uploadInProgress) {
        closeUploadModal();
        return;
    }

    uploadCancelRequested = true;

    if (activeUploadController) {
        activeUploadController.abort();
    }

    setUploadStatus(
        "Cancelling upload…"
    );

    if (uploadCancelButton) {
        uploadCancelButton.disabled =
            true;
    }
}


/*
 * --------------------------------------------------------------------------
 * Drag-and-drop upload
 * --------------------------------------------------------------------------
 */

function dataTransferHasFiles(
    dataTransfer
) {
    if (!dataTransfer) {
        return false;
    }

    return Array.from(
        dataTransfer.types ?? []
    ).includes("Files");
}


function getDroppedFiles(
    dataTransfer
) {
    if (!dataTransferHasFiles(dataTransfer)) {
        return [];
    }

    return Array.from(
        dataTransfer.files ?? []
    ).filter(
        (file) =>
            file instanceof File
    );
}


function canDropUpload() {
    return (
        activeDriveSection === "drive" &&
        !uploadInProgress &&
        (!uploadBackdrop ||
            uploadBackdrop.hidden)
    );
}


function currentFolderDropLabel() {
    const folderName =
        folderPath.length > 0
            ? folderPath[
                folderPath.length - 1
            ]?.name
            : "Drive";

    return folderName
        ? `Drop to upload into ${folderName}`
        : "Drop to upload into Drive";
}


function ensureDriveDropHint() {
    if (
        driveDropHint ||
        !driveList
    ) {
        return driveDropHint;
    }

    driveDropHint =
        document.createElement("div");

    driveDropHint.className =
        "drive-drop-upload-hint";

    driveDropHint.setAttribute(
        "aria-hidden",
        "true"
    );

    Object.assign(
        driveDropHint.style,
        {
            position: "absolute",
            inset: "8px",
            zIndex: "12",
            display: "none",
            alignItems: "center",
            justifyContent: "center",
            border:
                "1px dashed rgba(96, 165, 250, 0.75)",
            borderRadius: "14px",
            background:
                "rgba(15, 23, 42, 0.78)",
            color: "#dbeafe",
            fontSize: "0.92rem",
            fontWeight: "700",
            letterSpacing: "0",
            pointerEvents: "none",
            boxShadow:
                "inset 0 0 0 1px rgba(15, 23, 42, 0.9)",
        }
    );

    if (
        getComputedStyle(driveList)
            .position === "static"
    ) {
        driveList.style.position =
            "relative";
    }

    driveList.appendChild(
        driveDropHint
    );

    return driveDropHint;
}


function showDriveDropHint() {
    const hint =
        ensureDriveDropHint();

    if (!hint) {
        return;
    }

    hint.textContent =
        currentFolderDropLabel();

    hint.style.display = "flex";

    driveList?.classList.add(
        "is-drive-drop-target"
    );
}


function hideDriveDropHint() {
    driveDragDepth = 0;

    if (driveDropHint) {
        driveDropHint.style.display =
            "none";
    }

    driveList?.classList.remove(
        "is-drive-drop-target"
    );
}


function handleDriveDragEnter(
    event
) {
    if (
        !dataTransferHasFiles(
            event.dataTransfer
        ) ||
        !canDropUpload()
    ) {
        return;
    }

    event.preventDefault();

    driveDragDepth += 1;

    showDriveDropHint();
}


function handleDriveDragOver(
    event
) {
    if (
        !dataTransferHasFiles(
            event.dataTransfer
        ) ||
        !canDropUpload()
    ) {
        return;
    }

    event.preventDefault();

    if (event.dataTransfer) {
        event.dataTransfer.dropEffect =
            "copy";
    }

    showDriveDropHint();
}


function handleDriveDragLeave(
    event
) {
    if (
        !dataTransferHasFiles(
            event.dataTransfer
        )
    ) {
        return;
    }

    event.preventDefault();

    driveDragDepth =
        Math.max(
            0,
            driveDragDepth - 1
        );

    if (driveDragDepth === 0) {
        hideDriveDropHint();
    }
}


async function handleDriveDrop(
    event
) {
    if (
        !dataTransferHasFiles(
            event.dataTransfer
        )
    ) {
        return;
    }

    event.preventDefault();
    event.stopPropagation();

    const files =
        getDroppedFiles(
            event.dataTransfer
        );

    hideDriveDropHint();

    if (
        files.length === 0 ||
        !canDropUpload()
    ) {
        return;
    }

    await openUploadModal(
        files
    );
}


function preventWindowFileDrop(
    event
) {
    if (
        dataTransferHasFiles(
            event.dataTransfer
        )
    ) {
        event.preventDefault();
    }
}


function handleWindowFileDrop(
    event
) {
    preventWindowFileDrop(event);
    hideDriveDropHint();
}


/*
 * --------------------------------------------------------------------------
 * Determine upload recipients
 * --------------------------------------------------------------------------
 */

function getSelectedRecipientIds() {
    const sharingMode =
        getSharingMode();


    /*
     * The uploader must always receive their own file-key envelope.
     */
    const recipientIds =
        new Set([
            currentUserId,
        ]);


    if (
        sharingMode === "workspace"
    ) {
        for (
            const member of workspaceMembers
        ) {
            recipientIds.add(
                Number(member.id)
            );
        }
    } else if (memberSelect) {
        for (
            const option of memberSelect.selectedOptions
        ) {
            recipientIds.add(
                Number(option.value)
            );
        }
    }


    return [
        ...recipientIds,
    ].filter(
        (userId) =>
            Number.isInteger(userId) &&
            userId > 0
    );
}


/*
 * --------------------------------------------------------------------------
 * Fetch recipient OpenPGP keys
 * --------------------------------------------------------------------------
 */

async function fetchPublicKeys(
    userIds
) {
    const params =
        new URLSearchParams();

    params.set(
        "user_ids",
        userIds.join(",")
    );


    const response =
        await fetch(
            `/actions/drive/public-keys.php?${params.toString()}`,
            {
                method: "GET",
                credentials:
                    "same-origin",

                headers: {
                    Accept:
                        "application/json",
                },
            }
        );


    const data =
        await response.json();


    if (
        !response.ok ||
        !data.success
    ) {
        throw new Error(
            data.error ||
            "Unable to load encryption keys."
        );
    }


    const missing =
        Array.isArray(
            data.missing_user_ids
        )
            ? data.missing_user_ids
            : [];


    if (missing.length > 0) {
        throw new Error(
            "One or more selected users have not created their OpenPGP identity yet."
        );
    }


    const keys =
        Array.isArray(data.keys)
            ? data.keys
            : [];


    if (
        keys.length !==
        userIds.length
    ) {
        throw new Error(
            "Encryption keys are missing for one or more recipients."
        );
    }


    return keys;
}


/*
 * --------------------------------------------------------------------------
 * Encrypt + upload
 * --------------------------------------------------------------------------
 */

async function encryptAndUploadFile({
    file,
    publicKeys,
    sharingMode,
    destinationFolderId,
    index,
    total,
}) {
    let fileKey = null;

    try {
        /*
         * Generate a completely new random AES-256 key for this file.
         */
        fileKey =
            generateFileKey();

        if (uploadCancelRequested) {
            throw createUploadAbortError();
        }


        setUploadStatus(
            total > 1
                ? `Encrypting ${index} of ${total}: ${file.name}`
                : "Encrypting file on this device…"
        );


        /*
         * Plaintext is encrypted locally.
         */
        const encryptedBlob =
            await encryptFile(
                file,
                fileKey
            );

        if (uploadCancelRequested) {
            throw createUploadAbortError();
        }


        /*
         * Wrap the AES key independently for every authorized user.
         */
        setUploadStatus(
            total > 1
                ? `Encrypting file key ${index} of ${total}: ${file.name}`
                : "Encrypting file key for authorized users…"
        );


        const keyEnvelopes = [];


        for (
            const keyRecord of publicKeys
        ) {
            const userId =
                Number(
                    keyRecord.user_id
                );

            const encryptedKey =
                await wrapFileKeyForUser(
                    fileKey,
                    keyRecord.public_key
                );


            keyEnvelopes.push({
                user_id: userId,
                encrypted_key:
                    encryptedKey,
            });

            if (uploadCancelRequested) {
                throw createUploadAbortError();
            }
        }


        /*
         * The raw AES key is no longer required after all envelopes
         * have been created.
         */
        clearFileKey(fileKey);
        fileKey = null;

        if (uploadCancelRequested) {
            throw createUploadAbortError();
        }


        setUploadStatus(
            total > 1
                ? `Uploading ${index} of ${total}: ${file.name}`
                : "Uploading encrypted file…"
        );


        const body =
            new FormData();


        body.set(
            "csrf_token",
            csrfToken
        );

        body.set(
            "original_name",
            file.name
        );

        body.set(
            "mime_type",
            file.type || ""
        );

        body.set(
            "sharing_mode",
            sharingMode
        );


        if (
            destinationFolderId !== null
        ) {
            body.set(
                "folder_id",
                String(destinationFolderId)
            );
        }


        body.set(
            "key_envelopes",
            JSON.stringify(
                keyEnvelopes
            )
        );


        body.set(
            "encrypted_file",
            encryptedBlob,
            "encrypted.bin"
        );


        const controller =
            new AbortController();

        activeUploadController =
            controller;

        let response;

        try {
            response =
                await fetch(
                    "/actions/drive/upload.php",
                    {
                        method: "POST",
                        credentials:
                            "same-origin",

                        signal:
                            controller.signal,

                        body,

                        headers: {
                            Accept:
                                "application/json",
                        },
                    }
                );
        } finally {
            if (
                activeUploadController ===
                controller
            ) {
                activeUploadController =
                    null;
            }
        }


        const data =
            await response.json();


        if (
            !response.ok ||
            !data.success
        ) {
            throw new Error(
                data.error ||
                "Unable to upload encrypted file."
            );
        }

        return data;
    } finally {
        if (fileKey) {
            clearFileKey(fileKey);
        }
    }
}


async function encryptAndUpload() {
    if (
        uploadInProgress ||
        selectedFiles.length === 0
    ) {
        return;
    }


    if (
        !hasActiveVaultSession()
    ) {
        setUploadStatus(
            "Your Key Vault is locked. Unlock Key Vault before uploading.",
            "error"
        );

        return;
    }


    uploadInProgress = true;
    uploadCancelRequested = false;
    activeUploadController = null;

    if (uploadConfirmButton) {
        uploadConfirmButton.disabled =
            true;
    }

    if (uploadCancelButton) {
        uploadCancelButton.disabled =
            false;

        uploadCancelButton.textContent =
            "Cancel upload";
    }

    if (uploadCloseButton) {
        uploadCloseButton.disabled =
            true;
    }


    const filesToUpload =
        [...selectedFiles];

    const total =
        filesToUpload.length;

    const destinationFolderId =
        selectedUploadFolderId;

    const sharingMode =
        getSharingMode();

    const uploadedFiles = [];
    const failedFiles = [];


    try {
        /*
         * Make sure this vault really contains the current user's
         * OpenPGP identity before doing any file encryption.
         */
        await getOpenPgpIdentity();


        const recipientIds =
            getSelectedRecipientIds();


        if (
            recipientIds.length === 0
        ) {
            throw new Error(
                "No upload recipients were selected."
            );
        }


        setUploadStatus(
            "Loading recipient encryption keys…"
        );


        const publicKeys =
            await fetchPublicKeys(
                recipientIds
            );


        for (
            let index = 0;
            index < filesToUpload.length;
            index += 1
        ) {
            if (uploadCancelRequested) {
                break;
            }

            const file =
                filesToUpload[index];

            try {
                const data =
                    await encryptAndUploadFile({
                        file,
                        publicKeys,
                        sharingMode,
                        destinationFolderId,
                        index:
                            index + 1,
                        total,
                    });

                uploadedFiles.push({
                    file,
                    data,
                });
            } catch (error) {
                if (
                    isUploadAbortError(error) ||
                    uploadCancelRequested
                ) {
                    uploadCancelRequested = true;
                    break;
                }

                console.error(error);

                failedFiles.push({
                    file,
                    error,
                });
            }
        }

        if (uploadCancelRequested) {
            setUploadStatus(
                `Upload cancelled. ${uploadedFiles.length} of ${total} files uploaded.`,
                uploadedFiles.length > 0
                    ? "success"
                    : "error"
            );

            selectedFiles = [];
            selectedUploadFolderId = null;
            creatingDocument = false;
            renderSelectedFilesDisplay();

            if (fileInput) {
                fileInput.value = "";
            }

            await loadDrive();

            return;
        }


        if (uploadedFiles.length === 0) {
            throw new Error(
                failedFiles.length > 0
                    ? `No files were uploaded. Failed: ${failedFiles
                        .map(
                            (failure) =>
                                failure.file.name
                        )
                        .join(", ")}`
                    : "No files were uploaded."
            );
        }


        setUploadStatus(
            failedFiles.length > 0
                ? `${uploadedFiles.length} of ${total} files uploaded. Failed: ${failedFiles
                    .map(
                        (failure) =>
                            failure.file.name
                    )
                    .join(", ")}`
                : total > 1
                    ? `${uploadedFiles.length} files uploaded successfully.`
                    : "Encrypted upload complete.",
            failedFiles.length > 0
                ? "error"
                : "success"
        );


        /*
         * Give the success message a brief moment to be visible.
         */
        await new Promise(
            (resolve) =>
                window.setTimeout(
                    resolve,
                    350
                )
        );


        const createdFileId =
            creatingDocument &&
            uploadedFiles.length === 1 &&
            failedFiles.length === 0
                ? Number(
                    uploadedFiles[0].data.file?.id
                )
                : null;

        creatingDocument = false;
        selectedFiles =
            failedFiles.map(
                (failure) =>
                    failure.file
            );
        if (selectedFiles.length === 0) {
            selectedUploadFolderId = null;
        }
        renderSelectedFilesDisplay();

        if (
            fileInput &&
            selectedFiles.length === 0
        ) {
            fileInput.value = "";
        }

        if (
            uploadBackdrop &&
            selectedFiles.length === 0
        ) {
            uploadBackdrop.hidden =
                true;

            document.body.classList.remove(
                "drive-modal-open"
            );
        }


        await loadDrive();
        if (createdFileId > 0) window.location.href = `/drive/editor.php?file_id=${createdFileId}`;
    } catch (error) {
        console.error(error);

        setUploadStatus(
            isUploadAbortError(error)
                ? "Upload cancelled."
                : error instanceof Error
                ? error.message
                : "Encrypted upload failed.",
            isUploadAbortError(error)
                ? "success"
                : "error"
        );
    } finally {
        uploadInProgress = false;
        uploadCancelRequested = false;
        activeUploadController = null;


        if (uploadConfirmButton) {
            uploadConfirmButton.disabled =
                selectedFiles.length === 0;
        }

        if (uploadCancelButton) {
            uploadCancelButton.disabled =
                false;

            uploadCancelButton.textContent =
                "Cancel";
        }

        if (uploadCloseButton) {
            uploadCloseButton.disabled =
                false;
        }
    }
}


for (
    const button
    of driveSectionButtons
) {
    button.addEventListener(
        "click",
        async () => {
            const section =
                String(
                    button.dataset
                        .driveSection ?? ""
                )
                    .trim()
                    .toLowerCase();


            const allowedSections =
                new Set([
                    "drive",
                    "recent",
                    "favorites",
                    "shared-with-me",
                    "shared-by-me",
                    "trash",
                ]);


            if (
                !allowedSections.has(
                    section
                )
            ) {
                return;
            }


            if (
                section ===
                activeDriveSection
            ) {
                return;
            }


            activeDriveSection =
                section;


            /*
             * Section views always begin at their root.
             */

            currentFolderId =
                null;

            folderPath =
                [];


            /*
             * Search is section-specific. Clearing it prevents a
             * previous My Drive filter from making Trash appear empty.
             */

            if (searchInput) {
                searchInput.value =
                    "";
            }


            await loadDrive();
        }
    );
}


newFolderButton?.addEventListener(
    "click",
    openFolderModal
);


folderCloseButton?.addEventListener(
    "click",
    closeFolderModal
);


folderCancelButton?.addEventListener(
    "click",
    closeFolderModal
);


folderBackdrop?.addEventListener(
    "click",
    (event) => {
        if (
            event.target ===
            folderBackdrop
        ) {
            closeFolderModal();
        }
    }
);


folderForm?.addEventListener(
    "submit",
    async (event) => {
        event.preventDefault();

        const name =
            String(
                folderNameInput?.value ??
                ""
            ).trim();


        if (!name) {
            setFolderStatus(
                "Enter a folder name.",
                "error"
            );

            return;
        }


        const submitButton =
            folderForm.querySelector(
                'button[type="submit"]'
            );


        if (submitButton) {
            submitButton.disabled =
                true;
        }


        setFolderStatus(
            "Creating folder…"
        );


        try {
            await createFolder(
                name
            );

            closeFolderModal();

            await loadDrive();
        } catch (error) {
            console.error(error);

            setFolderStatus(
                error instanceof Error
                    ? error.message
                    : "Unable to create folder.",
                "error"
            );
        } finally {
            if (submitButton) {
                submitButton.disabled =
                    false;
            }
        }
    }
);


uploadButton?.addEventListener(
    "click",
    openFilePicker
);


emptyUploadButton?.addEventListener(
    "click",
    openFilePicker
);


fileInput?.addEventListener(
    "change",
    async () => {
        const files =
            Array.from(
                fileInput.files ?? []
            ).filter(
                (file) =>
                    file instanceof File
            );

        if (files.length === 0) {
            return;
        }

        await openUploadModal(
            files
        );
    }
);


driveList?.addEventListener(
    "dragenter",
    handleDriveDragEnter
);


driveList?.addEventListener(
    "dragover",
    handleDriveDragOver
);


driveList?.addEventListener(
    "dragleave",
    handleDriveDragLeave
);


driveList?.addEventListener(
    "drop",
    handleDriveDrop
);


window.addEventListener(
    "dragover",
    preventWindowFileDrop
);


window.addEventListener(
    "drop",
    handleWindowFileDrop
);


window.addEventListener(
    "dragend",
    hideDriveDropHint
);


uploadCloseButton?.addEventListener(
    "click",
    closeUploadModal
);


uploadCancelButton?.addEventListener(
    "click",
    requestUploadCancel
);


uploadBackdrop?.addEventListener(
    "click",
    (event) => {
        if (
            event.target ===
            uploadBackdrop
        ) {
            closeUploadModal();
        }
    }
);


uploadConfirmButton?.addEventListener(
    "click",
    encryptAndUpload
);


searchInput?.addEventListener(
    "input",
    () => {
        if (driveSearchTimer) {
            window.clearTimeout(
                driveSearchTimer
            );
        }


        /*
         * Other Drive sections keep their current
         * instant local filtering.
         */
        if (
            activeDriveSection !==
            "drive"
        ) {
            renderDrive();

            return;
        }


        /*
         * Small debounce keeps search responsive without
         * sending a request for every individual keystroke.
         */
        driveSearchTimer =
            window.setTimeout(
                () => {
                    driveSearchTimer =
                        null;

                    void searchDrive(
                        searchInput?.value ?? ""
                    );
                },
                250
            );
    }
);


document.addEventListener(
    "keydown",
    (event) => {
        if (
            event.key !== "Escape"
        ) {
            return;
        }


        if (
            uploadBackdrop &&
            !uploadBackdrop.hidden
        ) {
            closeUploadModal();

            return;
        }


        if (
            folderBackdrop &&
            !folderBackdrop.hidden
        ) {
            closeFolderModal();

            return;
        }


        if (
            newFileBackdrop &&
            !newFileBackdrop.hidden
        ) {
            closeNewFileModal();
        }
    }
);

for (
    const button of
    driveViewButtons
) {
    button.addEventListener(
        "click",
        () => {
            const requestedView =
                String(
                    button.dataset.driveView ??
                    ""
                );

            if (
                requestedView !== "list" &&
                requestedView !== "grid"
            ) {
                return;
            }


            if (
                requestedView ===
                driveView
            ) {
                return;
            }


            driveView =
                requestedView;


            writeDrivePreference(
                "alliances.drive.view",
                driveView
            );


            updateDriveViewUi();
        }
    );
}

sortSelect?.addEventListener(
    "change",
    () => {
        const requestedField =
            String(
                sortSelect.value ?? ""
            );

        const allowedFields =
            new Set([
                "name",
                "owner",
                "modified",
                "size",
            ]);

        driveSortField =
            allowedFields.has(
                requestedField
            )
                ? requestedField
                : "name";

        writeDrivePreference(
            "alliances.drive.sort-field",
            driveSortField
        );

        renderDrive();
    }
);


sortDirectionButton?.addEventListener(
    "click",
    () => {
        driveSortDirection =
            driveSortDirection === "asc"
                ? "desc"
                : "asc";

        writeDrivePreference(
            "alliances.drive.sort-direction",
            driveSortDirection
        );

        updateDriveSortUi();
        renderDrive();
    }
);

/*
 * --------------------------------------------------------------------------
 * New file
 * --------------------------------------------------------------------------
 */

let preparingDocument =
    false;


function openNewFileModal() {
    if (!newFileBackdrop) {
        return;
    }


    newFileBackdrop.hidden =
        false;


    document.body.classList.add(
        "drive-modal-open"
    );
}


function closeNewFileModal() {
    if (!newFileBackdrop) {
        return;
    }


    newFileBackdrop.hidden =
        true;


    /*
     * Only remove the modal-open state if another
     * Drive modal is not currently visible.
     */
    if (
        !uploadBackdrop ||
        uploadBackdrop.hidden
    ) {
        document.body.classList.remove(
            "drive-modal-open"
        );
    }
}


/*
 * --------------------------------------------------------------------------
 * Create blank XLSX locally
 * --------------------------------------------------------------------------
 */

async function createBlankXlsx() {
    const engine =
        new AlliancesXlsxEngine();


    await engine.createBlank(
        "Untitled.xlsx"
    );


    return await engine.getSaveBlob();
}


/*
 * --------------------------------------------------------------------------
 * Create document locally
 * --------------------------------------------------------------------------
 *
 * Nothing is uploaded here.
 *
 * DOCX, TXT and XLSX are first created as plaintext in the browser.
 * They are then passed into the existing Drive upload modal.
 *
 * encryptAndUpload() performs the normal local AES encryption and
 * OpenPGP file-key wrapping before anything reaches PHP.
 */

async function createDocument(
    type
) {
    if (
        preparingDocument ||
        uploadInProgress
    ) {
        return;
    }


    const fileTypes = {
        docx: {
            extension:
                "docx",

            defaultName:
                "Untitled.docx",

            mimeType:
                DOCX_MIME,
        },

        txt: {
            extension:
                "txt",

            defaultName:
                "Untitled.txt",

            mimeType:
                "text/plain",
        },

        xlsx: {
            extension:
                "xlsx",

            defaultName:
                "Untitled.xlsx",

            mimeType:
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        },
    };


    const definition =
        fileTypes[type];


    if (!definition) {
        window.alert(
            "Unsupported document type."
        );

        return;
    }


    /*
     * Close the type selector before asking for the filename.
     */

    closeNewFileModal();


    const entered =
        window.prompt(
            "File name",
            definition.defaultName
        );


    if (entered === null) {
        return;
    }


    let name =
        entered.trim();


    if (
        !name ||
        /[\\/:*?"<>|\x00-\x1f]/.test(
            name
        )
    ) {
        window.alert(
            "Enter a valid file name."
        );

        return;
    }


    const extension =
        `.${definition.extension}`;


    if (
        !name
            .toLowerCase()
            .endsWith(
                extension
            )
    ) {
        name +=
            extension;
    }


    if (name.length > 200) {
        window.alert(
            "Use a file name of 200 characters or fewer."
        );

        return;
    }


    preparingDocument =
        true;


    try {
        let blob;


        /*
         * DOCX
         */
        if (type === "docx") {
            blob =
                await createBlankDocx();
        }


        /*
         * TXT
         */
        else if (type === "txt") {
            blob =
                new Blob(
                    [""],
                    {
                        type:
                            "text/plain",
                    }
                );
        }


        /*
         * XLSX
         */
        else if (type === "xlsx") {
            blob =
                await createBlankXlsx();
        }


        if (
            !(blob instanceof Blob)
        ) {
            throw new Error(
                "Unable to create the document."
            );
        }


        /*
         * Convert the generated Blob into the same File object
         * used by normal Drive uploads.
         */

        const file =
            new File(
                [blob],
                name,
                {
                    type:
                        definition.mimeType,

                    lastModified:
                        Date.now(),
                }
            );


        /*
         * Reuse the normal encrypted upload/share modal.
         */

        await openUploadModal(
            file
        );


        /*
         * Tell encryptAndUpload() that this is a newly created
         * document. After the encrypted upload succeeds it will
         * automatically open the editor.
         */

        creatingDocument =
            true;


        if (uploadConfirmButton) {
            uploadConfirmButton.textContent =
                "Create encrypted file";
        }
    } catch (error) {
        console.error(
            "Unable to create Drive document:",
            error
        );


        window.alert(
            error instanceof Error
                ? error.message
                : "Unable to create document."
        );
    } finally {
        preparingDocument =
            false;
    }
}


/*
 * --------------------------------------------------------------------------
 * New file modal events
 * --------------------------------------------------------------------------
 */

newFileButton?.addEventListener(
    "click",
    openNewFileModal
);


newFileCloseButton?.addEventListener(
    "click",
    closeNewFileModal
);


newFileBackdrop?.addEventListener(
    "click",
    (event) => {
        if (
            event.target ===
            newFileBackdrop
        ) {
            closeNewFileModal();
        }
    }
);


for (
    const button
    of newFileTypeButtons
) {
    button.addEventListener(
        "click",
        () => {
            const type =
                String(
                    button.dataset
                        .driveNewFileType ??
                    ""
                )
                    .trim()
                    .toLowerCase();


            void createDocument(
                type
            );
        }
    );
}

/* Preferences must not prevent Drive from starting when storage is blocked. */
function readDrivePreference(key) {
    try {
        return localStorage.getItem(key);
    } catch {
        return null;
    }
}

function writeDrivePreference(key, value) {
    try {
        localStorage.setItem(key, value);
    } catch {
        // Keep the selected preference in memory for this page.
    }
}

/* Start only after all state and event handlers have been initialized. */
async function startDrive() {
    try {
        if (!csrfToken || !Number.isInteger(currentUserId) || currentUserId <= 0) {
            throw new Error("Drive could not determine the authenticated user. Reload the page or sign in again.");
        }
        updateDriveSortUi();
        updateDriveViewUi();
        await loadDrive();
    } catch (error) {
        console.error("Unable to start Drive:", error);
        if (driveList) {
            driveList.innerHTML = '<div class="drive-empty-state"><h2>Unable to load Drive</h2><p>'
                + escapeHtml(error instanceof Error ? error.message : "An unexpected error occurred.")
                + '</p></div>';
        }
    }
}

void startDrive();
