<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/navigation.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('You do not have access to a workspace.');
}

$fileId = filter_input(
    INPUT_GET,
    'file_id',
    FILTER_VALIDATE_INT
);

if (
    $fileId === false
    || $fileId === null
    || $fileId <= 0
) {
    http_response_code(400);
    exit('A valid Drive file ID is required.');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars(
            csrf_token(),
            ENT_QUOTES,
            'UTF-8'
        ) ?>"
    >

    <meta
        name="alliances-user-id"
        content="<?= (int) $user['id'] ?>"
    >

    <meta
        name="alliances-drive-file-id"
        content="<?= (int) $fileId ?>"
    >

    <title>Drive Editor · Alliances</title>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <link
        rel="stylesheet"
        href="/drive/assets/drive.css"
    >

    <link
        rel="stylesheet"
        href="/drive/assets/drive-editor.css"
    >
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main drive-editor-page">

    <section class="drive-editor-shell">

        <header class="drive-editor-header">

            <div class="drive-editor-header-left">

                <a
                    class="drive-editor-back"
                    href="/drive/"
                    aria-label="Back to Drive"
                    title="Back to Drive"
                >
                    ←
                </a>

                <div class="drive-editor-file-info">

                    <div class="drive-editor-title-row">

                        <h1
                            id="drive-editor-filename"
                            class="drive-editor-filename"
                        >
                            Opening encrypted file…
                        </h1>

                        <span
                            id="drive-editor-type"
                            class="drive-editor-type"
                            hidden
                        ></span>

                        <span
                            id="drive-editor-readonly"
                            class="drive-editor-readonly"
                            hidden
                        >
                            View only
                        </span>

                    </div>

                    <p
                        id="drive-editor-status"
                        class="drive-editor-status"
                        aria-live="polite"
                    >
                        Preparing encrypted editor…
                    </p>

                </div>

            </div>

            <div class="drive-editor-header-actions">

                <button
                    id="drive-editor-download"
                    class="button"
                    type="button"
                    disabled
                >
                    Download
                </button>

                <button
                    id="drive-editor-save"
                    class="button button-primary"
                    type="button"
                    disabled
                >
                    Save
                </button>

            </div>

        </header>


        <div
            id="drive-editor-notice"
            class="drive-editor-notice"
        >
            <div class="drive-editor-notice-icon">
                🔒
            </div>

            <div>
                <strong>
                    End-to-end encrypted
                </strong>

                <span>
                    This document is decrypted and edited on this device.
                    Plaintext document contents are not sent to the Drive server.
                </span>
            </div>
        </div>


        <section
            id="drive-editor-workspace"
            class="drive-editor-workspace"
            aria-label="Document editor"
        >

            <div
                id="drive-editor-loading"
                class="drive-editor-loading"
            >
                <div
                    class="drive-editor-loading-spinner"
                    aria-hidden="true"
                ></div>

                <strong>
                    Opening encrypted document
                </strong>

                <span
                    id="drive-editor-loading-status"
                >
                    Loading…
                </span>
            </div>


            <div
                id="drive-editor-error"
                class="drive-editor-error"
                hidden
            >
                <strong>
                    Unable to open this file
                </strong>

                <p
                    id="drive-editor-error-message"
                ></p>

                <a
                    class="button"
                    href="/drive/"
                >
                    Return to Drive
                </a>
            </div>


            <div
                id="drive-editor-container"
                class="drive-editor-container"
                hidden
            ></div>

        </section>

    </section>

</main>


<script
    type="module"
    src="/drive/assets/drive-editor.js"
></script>

</body>
</html>