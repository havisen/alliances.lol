<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/navigation.php';
require_once dirname(__DIR__, 2) . '/src/drive/drive.php';

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('You do not have access to a workspace.');
}

$workspaceId = (int) $access['workspace_id'];

drive_ensure_storage_directory();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>"
    >

    <meta
        name="alliances-user-id"
        content="<?= (int) $user['id'] ?>"
    >

    <title>Drive · Alliances</title>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <link
        rel="stylesheet"
        href="/drive/assets/drive.css"
    >
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main drive-page">

    <!-- ================================================================
         Drive header
         ================================================================ -->

    <header class="drive-header">

        <div>
            <p class="drive-eyebrow">
                Encrypted storage
            </p>

            <h1>Drive</h1>

            <p class="drive-description">
                Store and share end-to-end encrypted files with your team.
            </p>

            <div
                class="drive-storage-usage"
                id="drive-storage-usage"
                aria-live="polite"
            >
                Storage usage loading…
            </div>
        </div>

<div class="drive-header-actions">

    <button
        type="button"
        class="drive-primary-button"
        id="drive-new-file"
    >
        New file
    </button>

    <button
        type="button"
        class="drive-secondary-button"
        id="drive-new-folder"
    >
        New folder
    </button>

    <button
        type="button"
        class="drive-primary-button"
        id="drive-upload-file"
    >
        Upload file
    </button>

</div>

    </header>

    <!-- ================================================================
     Drive sections
     ================================================================ -->

<nav
    class="drive-section-nav"
    id="drive-section-nav"
    aria-label="Drive sections"
>
    <button
        type="button"
        class="drive-section-button is-active"
        data-drive-section="drive"
        aria-pressed="true"
    >
        <span class="drive-section-icon" aria-hidden="true">
            ◫
        </span>

        <span>
            My Drive
        </span>
    </button>

    <button
        type="button"
        class="drive-section-button"
        data-drive-section="recent"
        aria-pressed="false"
    >
        <span class="drive-section-icon" aria-hidden="true">
            ◷
        </span>

        <span>
            Recent
        </span>
    </button>

    <button
        type="button"
        class="drive-section-button"
        data-drive-section="favorites"
        aria-pressed="false"
    >
        <span class="drive-section-icon" aria-hidden="true">
            ☆
        </span>

        <span>
            Favorites
        </span>
    </button>

    <button
        type="button"
        class="drive-section-button"
        data-drive-section="shared-with-me"
        aria-pressed="false"
    >
        <span class="drive-section-icon" aria-hidden="true">
            ⇢
        </span>

        <span>
            Shared with me
        </span>
    </button>

    <button
        type="button"
        class="drive-section-button"
        data-drive-section="shared-by-me"
        aria-pressed="false"
    >
        <span class="drive-section-icon" aria-hidden="true">
            ⇠
        </span>

        <span>
            Shared by me
        </span>
    </button>

    <button
        type="button"
        class="drive-section-button drive-section-button-danger"
        data-drive-section="trash"
        aria-pressed="false"
    >
        <span class="drive-section-icon" aria-hidden="true">
            ♲
        </span>

        <span>
            Trash
        </span>
    </button>
</nav>

    <!-- ================================================================
         Toolbar
         ================================================================ -->

    <section class="drive-toolbar">

        <nav
            class="drive-breadcrumbs"
            id="drive-breadcrumbs"
            aria-label="Drive folder"
        >
            <button
                type="button"
                class="drive-breadcrumb-button"
                data-folder-id=""
            >
                Drive
            </button>
        </nav>

<div class="drive-toolbar-actions">

    <label
        class="drive-search"
        for="drive-search-input"
    >
        <span class="drive-search-label">
            Search
        </span>

        <input
            type="search"
            id="drive-search-input"
            placeholder="Search files and folders"
            autocomplete="off"
        >
    </label>


    <label
        class="drive-sort-control"
        for="drive-sort-select"
    >
        <span class="sr-only">
            Sort Drive items
        </span>

        <select
            id="drive-sort-select"
            class="drive-sort-select"
            aria-label="Sort Drive items"
        >
            <option value="name">
                Name
            </option>

            <option value="owner">
                Owner
            </option>

            <option value="modified">
                Modified
            </option>

            <option value="size">
                Size
            </option>
        </select>
    </label>


    <button
        type="button"
        class="drive-secondary-button drive-sort-direction"
        id="drive-sort-direction"
        aria-label="Sort ascending"
        title="Sort ascending"
        data-direction="asc"
    >
        ↑
    </button>


    <div
        class="drive-view-switcher"
        role="group"
        aria-label="Drive view"
    >
        <button
            type="button"
            class="drive-view-button is-active"
            id="drive-view-list"
            data-drive-view="list"
            aria-label="List view"
            title="List view"
            aria-pressed="true"
        >
            ☷
        </button>

        <button
            type="button"
            class="drive-view-button"
            id="drive-view-grid"
            data-drive-view="grid"
            aria-label="Grid view"
            title="Grid view"
            aria-pressed="false"
        >
            ▦
        </button>
    </div>

</div>

    </section>


    <!-- ================================================================
         Drive contents
         ================================================================ -->

    <section
        class="drive-content"
        aria-label="Files"
    >

        <div class="drive-list-header">

            <div>
                Name
            </div>

            <div>
                Owner
            </div>

            <div>
                Modified
            </div>

            <div>
                Size
            </div>

            <div>
                Access
            </div>

            <div>
                <span class="sr-only">
                    Actions
                </span>
            </div>

        </div>


        <div
            class="drive-list"
            id="drive-list"
        >

            <div
                class="drive-empty-state"
                id="drive-empty-state"
            >
                <div class="drive-empty-icon">
                    ↥
                </div>

                <h2>
                    Your encrypted Drive is empty
                </h2>

                <p>
                    Upload a file or create a folder to get started.
                </p>

                <button
                    type="button"
                    class="drive-primary-button"
                    id="drive-empty-upload"
                >
                    Upload your first file
                </button>
            </div>

        </div>

    </section>


    <!-- Hidden native file picker -->

    <input
        type="file"
        id="drive-file-input"
        hidden
    >

    <!--
|--------------------------------------------------------------------------
| Manage file access modal
|--------------------------------------------------------------------------
-->

<div
    id="drive-access-backdrop"
    class="drive-modal-backdrop"
    hidden
>
    <section
        class="drive-modal drive-access-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="drive-access-title"
    >
        <div class="drive-modal-header">
            <div>
                <h2 id="drive-access-title">
                    Manage access
                </h2>

                <p
                    id="drive-access-filename"
                    class="drive-modal-description"
                >
                    Encrypted file
                </p>
            </div>

            <button
                id="drive-access-close"
                class="drive-modal-close"
                type="button"
                aria-label="Close"
            >
                ×
            </button>
        </div>


        <div class="drive-access-notice">
            <strong>
                End-to-end encrypted
            </strong>

            <span>
                New access is granted by encrypting the file key
                for that person on this device.
            </span>
        </div>


        <div
            id="drive-access-members"
            class="drive-access-members"
        >
            <!-- Filled by drive.js -->
        </div>


        <p
            id="drive-access-status"
            class="drive-modal-status"
            aria-live="polite"
        ></p>


        <div class="drive-modal-actions">
            <button
                id="drive-access-done"
                class="button button-primary"
                type="button"
            >
                Done
            </button>
        </div>
    </section>
</div>

</main>


<!-- ====================================================================
     Upload file modal
     ==================================================================== -->

<div
    class="drive-modal-backdrop"
    id="drive-upload-backdrop"
    hidden
>
    <section
        class="drive-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="drive-upload-title"
    >

        <header class="drive-modal-header">

            <div>
                <p class="drive-modal-eyebrow">
                    End-to-end encrypted
                </p>

                <h2 id="drive-upload-title">
                    Upload file
                </h2>
            </div>

            <button
                type="button"
                class="drive-modal-close"
                id="drive-upload-close"
                aria-label="Close"
            >
                ×
            </button>

        </header>


        <div class="drive-modal-body">

            <!-- Selected file -->

            <div
                class="drive-selected-file"
                id="drive-selected-file"
            >
                No file selected.
            </div>


            <!-- Sharing mode -->

            <fieldset class="drive-sharing-options">

                <legend>
                    Who can access this file?
                </legend>


                <label class="drive-radio-option">

                    <input
                        type="radio"
                        name="drive-sharing-mode"
                        value="selected"
                        checked
                    >


                        <div class="drive-item-actions">
</div>
                    <span>
                        <strong>
                            Selected people
                        </strong>

                        <small>
                            Choose specific workspace members.
                        </small>
                    </span>

                </label>


                <label class="drive-radio-option">

                    <input
                        type="radio"
                        name="drive-sharing-mode"
                        value="workspace"
                    >

                    <span>
                        <strong>
                            Everyone in the workspace
                        </strong>

                        <small>
                            Every current workspace member receives access.
                        </small>
                    </span>

                </label>

            </fieldset>


            <!-- Member selector -->

            <div class="drive-field">

                <label for="drive-upload-members">
                    People with access
                </label>

                <select
                    id="drive-upload-members"
                    multiple
                    size="6"
                ></select>

                <small class="drive-field-help">
                    Hold Ctrl on Windows or Command on Mac to select
                    multiple people. Your own account is always included.
                </small>

            </div>


            <!-- Upload status -->

            <div
                id="drive-upload-status"
                class="drive-upload-status drive-modal-status"
                aria-live="polite"
            ></div>

        </div>


        <footer class="drive-modal-actions">

            <button
                type="button"
                class="drive-secondary-button"
                id="drive-upload-cancel"
            >
                Cancel
            </button>



            <button
                type="button"
                class="drive-primary-button"
                id="drive-upload-confirm"
                disabled
            >
                Encrypt &amp; upload
            </button>

        </footer>

    </section>
</div>


<!-- ====================================================================
     New folder modal
     ==================================================================== -->

<div
    class="drive-modal-backdrop"
    id="drive-folder-backdrop"
    hidden
>
    <section
        class="drive-modal drive-small-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="drive-folder-title"
    >

        <header class="drive-modal-header">

            <h2 id="drive-folder-title">
                New folder
            </h2>

            <button
                type="button"
                class="drive-modal-close"
                id="drive-folder-close"
                aria-label="Close"
            >
                ×
            </button>

        </header>


        <form id="drive-folder-form">

            <div class="drive-modal-body">

                <label
                    class="drive-field"
                    for="drive-folder-name"
                >
                    <span>
                        Folder name
                    </span>

                    <input
                        type="text"
                        id="drive-folder-name"
                        maxlength="150"
                        autocomplete="off"
                        required
                    >
                </label>


                <div
                    class="drive-form-status"
                    id="drive-folder-status"
                    aria-live="polite"
                ></div>

            </div>


            <footer class="drive-modal-actions">

                <button
                    type="button"
                    class="drive-secondary-button"
                    id="drive-folder-cancel"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="drive-primary-button"
                >
                    Create folder
                </button>

            </footer>

        </form>

    </section>
</div>

<!-- ====================================================================
     New file modal
     ==================================================================== -->

<div
    class="drive-modal-backdrop"
    id="drive-new-file-backdrop"
    hidden
>
    <section
        class="drive-modal drive-small-modal drive-new-file-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="drive-new-file-title"
    >

        <header class="drive-modal-header">

            <div>
                <p class="drive-modal-eyebrow">
                    Create document
                </p>

                <h2 id="drive-new-file-title">
                    New file
                </h2>

                <p class="drive-modal-description">
                    Choose the type of file you want to create.
                </p>
            </div>

            <button
                type="button"
                class="drive-modal-close"
                id="drive-new-file-close"
                aria-label="Close"
            >
                ×
            </button>

        </header>


        <div class="drive-modal-body">

            <div class="drive-new-file-options">

                <button
                    type="button"
                    class="drive-new-file-option"
                    data-drive-new-file-type="docx"
                >
                    <span class="drive-new-file-icon">
                        W
                    </span>

                    <span class="drive-new-file-option-text">
                        <strong>
                            DOCX document
                        </strong>

                        <small>
                            Create a new editable Word document.
                        </small>
                    </span>

                    <span class="drive-new-file-arrow">
                        ›
                    </span>
                </button>


                <button
                    type="button"
                    class="drive-new-file-option"
                    data-drive-new-file-type="txt"
                >
                    <span class="drive-new-file-icon">
                        T
                    </span>

                    <span class="drive-new-file-option-text">
                        <strong>
                            TXT document
                        </strong>

                        <small>
                            Create a new plain text document.
                        </small>
                    </span>

                    <span class="drive-new-file-arrow">
                        ›
                    </span>
                </button>


                <button
                    type="button"
                    class="drive-new-file-option"
                    data-drive-new-file-type="xlsx"
                >
                    <span class="drive-new-file-icon">
                        X
                    </span>

                    <span class="drive-new-file-option-text">
                        <strong>
                            XLSX spreadsheet
                        </strong>

                        <small>
                            Create a new editable spreadsheet.
                        </small>
                    </span>

                    <span class="drive-new-file-arrow">
                        ›
                    </span>
                </button>

            </div>

        </div>

    </section>
</div>

<script
    type="module"
    src="/drive/assets/drive.js?v=<?= urlencode((string) filemtime(__DIR__ . '/assets/drive.js')) ?>"
></script>

</body>
</html>
