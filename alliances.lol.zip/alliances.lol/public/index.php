<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/auth.php';

$user = require_login();
$connection = db();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$canAccessAdministration =
    $access['is_admin']
    || $access['is_team_lead'];

/*
|--------------------------------------------------------------------------
| Workspace
|--------------------------------------------------------------------------
*/

$workspaceStatement = $connection->prepare(
    'SELECT id, name
     FROM workspaces
     WHERE id = ?
     LIMIT 1'
);

$workspaceStatement->execute([
    $workspaceId,
]);

$workspace = $workspaceStatement->fetch();

$workspaceName =
    $workspace
        ? (string) $workspace['name']
        : 'Workspace';

/*
|--------------------------------------------------------------------------
| User summary
|--------------------------------------------------------------------------
*/

$profileStatement = $connection->prepare(
    'SELECT
        display_name,
        email,
        job_title,
        avatar_path
     FROM users
     WHERE id = ?
     LIMIT 1'
);

$profileStatement->execute([
    $user['id'],
]);

$profile = $profileStatement->fetch();

if (!$profile) {
    http_response_code(404);
    exit('User not found.');
}

/*
|--------------------------------------------------------------------------
| Task summary
|--------------------------------------------------------------------------
*/

$taskSummaryStatement = $connection->prepare(
    'SELECT
        COUNT(*) AS total_tasks,

        SUM(
            CASE
                WHEN t.status = \'completed\'
                THEN 1
                ELSE 0
            END
        ) AS completed_tasks,

        SUM(
            CASE
                WHEN t.status != \'completed\'
                THEN 1
                ELSE 0
            END
        ) AS open_tasks

     FROM tasks t

     INNER JOIN task_lists tl
         ON tl.id = t.task_list_id

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     WHERE tl.workspace_id = ?

       AND (
            t.assigned_to IS NULL
            OR t.assigned_to = ?
       )'
);

$taskSummaryStatement->execute([
    $user['id'],
    $workspaceId,
    $user['id'],
]);

$taskSummary =
    $taskSummaryStatement->fetch()
    ?: [];

$openTaskCount =
    (int) ($taskSummary['open_tasks'] ?? 0);

$completedTaskCount =
    (int) ($taskSummary['completed_tasks'] ?? 0);

/*
|--------------------------------------------------------------------------
| Active task lists
|--------------------------------------------------------------------------
*/

$listCountStatement = $connection->prepare(
    'SELECT COUNT(DISTINCT tl.id)

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     WHERE tl.workspace_id = ?
       AND tl.status != \'completed\''
);

$listCountStatement->execute([
    $user['id'],
    $workspaceId,
]);

$activeListCount =
    (int) $listCountStatement->fetchColumn();

/*
|--------------------------------------------------------------------------
| Upcoming deadlines
|--------------------------------------------------------------------------
*/

$deadlineStatement = $connection->prepare(
    'SELECT
        tl.id,
        tl.name,
        tl.deadline,
        tl.team_id,
        team.name AS team_name

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     LEFT JOIN teams team
         ON team.id = tl.team_id
        AND team.workspace_id = tl.workspace_id

     WHERE tl.workspace_id = ?
       AND tl.status != \'completed\'
       AND tl.deadline IS NOT NULL
       AND tl.deadline >= ?

     ORDER BY
        tl.deadline ASC,
        tl.id ASC

     LIMIT 4'
);

$deadlineStatement->execute([
    $user['id'],
    $workspaceId,
    date('Y-m-d'),
]);

$upcomingDeadlines =
    $deadlineStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$teamsStatement = $connection->prepare(
    'SELECT DISTINCT
        t.id,
        t.name,
        t.team_lead_id,

        lead.display_name AS team_lead_name,
        lead.avatar_path AS team_lead_avatar

     FROM teams t

     LEFT JOIN users lead
         ON lead.id = t.team_lead_id

     LEFT JOIN team_members tm
         ON tm.team_id = t.id

     WHERE t.workspace_id = ?
       AND (
            t.team_lead_id = ?
            OR tm.user_id = ?
       )

     ORDER BY t.name ASC

     LIMIT 4'
);

$teamsStatement->execute([
    $workspaceId,
    $user['id'],
    $user['id'],
]);

$userTeams =
    $teamsStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Workspace member count
|--------------------------------------------------------------------------
*/

$memberCountStatement = $connection->prepare(
    'SELECT COUNT(*)
     FROM workspace_members
     WHERE workspace_id = ?'
);

$memberCountStatement->execute([
    $workspaceId,
]);

$workspaceMemberCount =
    (int) $memberCountStatement->fetchColumn();

/*
|--------------------------------------------------------------------------
| Greeting
|--------------------------------------------------------------------------
*/

$hour = (int) date('G');

if ($hour < 12) {
    $greeting = 'Good morning';
} elseif ($hour < 18) {
    $greeting = 'Good afternoon';
} else {
    $greeting = 'Good evening';
}

/*
|--------------------------------------------------------------------------
| Date helper
|--------------------------------------------------------------------------
*/

function home_format_date(?string $date): string
{
    if (!$date) {
        return 'No deadline';
    }

    try {
        return (new DateTimeImmutable($date))
            ->format('M j');
    } catch (Exception $exception) {
        return $date;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="/assets/css/app.css">

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Home | Alliances</title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main home-page">

    <header class="page-header home-page-header">

        <div class="page-header-content">

            <span class="page-eyebrow">
                <?= htmlspecialchars(
                    $workspaceName,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </span>

            <h1>
                <?= htmlspecialchars(
                    $greeting,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>,
                <?= htmlspecialchars(
                    $profile['display_name'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h1>

            <p class="page-description">
                Here's an overview of your workspace and the things
                that need your attention.
            </p>

        </div>

        <div class="page-header-actions">

            <a
                class="secondary-action"
                href="/calendar.php"
            >
                Calendar
            </a>

            <a
                class="primary-action"
                href="/tasks/index.php"
            >
                View my work
            </a>

        </div>

    </header>

    <!-- ================================================================
         SUMMARY
         ================================================================ -->

    <section
        class="home-summary-grid"
        aria-label="Workspace summary"
    >

        <a
            class="home-summary-card"
            href="/tasks/index.php"
        >
            <div class="home-summary-card-top">
                <span>Open tasks</span>

                <span
                    class="home-summary-arrow"
                    aria-hidden="true"
                >
                    →
                </span>
            </div>

            <strong>
                <?= $openTaskCount ?>
            </strong>

            <p>
                Tasks currently assigned to you or everyone.
            </p>
        </a>

        <a
            class="home-summary-card"
            href="/tasks/tasks.php"
        >
            <div class="home-summary-card-top">
                <span>Active lists</span>

                <span
                    class="home-summary-arrow"
                    aria-hidden="true"
                >
                    →
                </span>
            </div>

            <strong>
                <?= $activeListCount ?>
            </strong>

            <p>
                Task lists you're currently participating in.
            </p>
        </a>

        <a
            class="home-summary-card"
            href="/tasks/completed.php"
        >
            <div class="home-summary-card-top">
                <span>Completed tasks</span>

                <span
                    class="home-summary-arrow"
                    aria-hidden="true"
                >
                    →
                </span>
            </div>

            <strong>
                <?= $completedTaskCount ?>
            </strong>

            <p>
                Tasks you've already completed.
            </p>
        </a>

        <a
            class="home-summary-card"
            href="/profile/?id=<?= (int) $user['id'] ?>"
        >
            <div class="home-summary-card-top">
                <span>Workspace members</span>

                <span
                    class="home-summary-arrow"
                    aria-hidden="true"
                >
                    →
                </span>
            </div>

            <strong>
                <?= $workspaceMemberCount ?>
            </strong>

            <p>
                People currently belonging to this workspace.
            </p>
        </a>

    </section>

    <!-- ================================================================
         MAIN DASHBOARD
         ================================================================ -->

    <div class="home-dashboard-grid">

        <div class="home-dashboard-main">

            <!-- UPCOMING -->

            <section class="home-panel">

                <div class="home-panel-header">

                    <div>
                        <span class="page-eyebrow">
                            Schedule
                        </span>

                        <h2>
                            Upcoming deadlines
                        </h2>
                    </div>

                    <a href="/calendar.php">
                        Open calendar
                        <span aria-hidden="true">→</span>
                    </a>

                </div>

                <?php if ($upcomingDeadlines === []): ?>

                    <div class="home-empty-state">

                        <div
                            class="home-empty-icon"
                            aria-hidden="true"
                        >
                            ✓
                        </div>

                        <div>
                            <strong>
                                Nothing coming up
                            </strong>

                            <p>
                                You don't have any upcoming task-list
                                deadlines.
                            </p>
                        </div>

                    </div>

                <?php else: ?>

                    <div class="home-deadline-list">

                        <?php foreach ($upcomingDeadlines as $deadline): ?>

                            <a
                                class="home-deadline-item"
                                href="/tasks/task-list.php?id=<?= (int) $deadline['id'] ?>"
                            >

                                <div class="home-deadline-date">

                                    <span>
                                        <?= htmlspecialchars(
                                            home_format_date(
                                                $deadline['deadline']
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                </div>

                                <div class="home-deadline-content">

                                    <strong>
                                        <?= htmlspecialchars(
                                            $deadline['name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </strong>

                                    <?php if (!empty($deadline['team_name'])): ?>

                                        <span>
                                            <?= alliances_team_link(
                                                (int) $deadline['team_id'],
                                                (string) $deadline['team_name']
                                            ) ?>
                                        </span>

                                    <?php else: ?>

                                        <span>
                                            Personal task list
                                        </span>

                                    <?php endif; ?>

                                </div>

                                <span
                                    class="home-deadline-arrow"
                                    aria-hidden="true"
                                >
                                    →
                                </span>

                            </a>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </section>

            <!-- QUICK ACCESS -->

            <section class="home-panel">

                <div class="home-panel-header">

                    <div>
                        <span class="page-eyebrow">
                            Work
                        </span>

                        <h2>
                            Quick access
                        </h2>
                    </div>

                </div>

                <div class="home-quick-grid">

                    <a
                        class="home-quick-card"
                        href="/tasks/index.php"
                    >
                        <span
                            class="home-quick-icon"
                            aria-hidden="true"
                        >
                            ✓
                        </span>

                        <div>
                            <strong>My work</strong>

                            <p>
                                See the tasks currently requiring
                                your attention.
                            </p>
                        </div>

                        <span
                            class="home-quick-arrow"
                            aria-hidden="true"
                        >
                            →
                        </span>
                    </a>

                    <a
                        class="home-quick-card"
                        href="/tasks/tasks.php"
                    >
                        <span
                            class="home-quick-icon"
                            aria-hidden="true"
                        >
                            ≡
                        </span>

                        <div>
                            <strong>Task lists</strong>

                            <p>
                                Create and manage your workspace
                                task lists.
                            </p>
                        </div>

                        <span
                            class="home-quick-arrow"
                            aria-hidden="true"
                        >
                            →
                        </span>
                    </a>

                    <a
                        class="home-quick-card"
                        href="/tasks/daily.php"
                    >
                        <span
                            class="home-quick-icon"
                            aria-hidden="true"
                        >
                            ↻
                        </span>

                        <div>
                            <strong>Daily tasks</strong>

                            <p>
                                Manage your personal recurring
                                daily routine.
                            </p>
                        </div>

                        <span
                            class="home-quick-arrow"
                            aria-hidden="true"
                        >
                            →
                        </span>
                    </a>

                    <a
                        class="home-quick-card"
                        href="/calendar.php"
                    >
                        <span
                            class="home-quick-icon"
                            aria-hidden="true"
                        >
                            □
                        </span>

                        <div>
                            <strong>Calendar</strong>

                            <p>
                                See shared events and upcoming
                                deadlines.
                            </p>
                        </div>

                        <span
                            class="home-quick-arrow"
                            aria-hidden="true"
                        >
                            →
                        </span>
                    </a>

                </div>

            </section>

        </div>

        <!-- ============================================================
             SIDEBAR
             ============================================================ -->

        <aside class="home-dashboard-sidebar">

            <!-- PROFILE -->

            <section class="home-profile-card">

                <a
                    class="home-profile-main"
                    href="/profile/?id=<?= (int) $user['id'] ?>"
                >

                    <?php if (!empty($profile['avatar_path'])): ?>

                        <img
                            class="home-profile-avatar"
                            src="<?= htmlspecialchars(
                                $profile['avatar_path'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt=""
                        >

                    <?php else: ?>

                        <div
                            class="home-profile-avatar home-profile-placeholder"
                        >
                            <?= htmlspecialchars(
                                strtoupper(
                                    substr(
                                        $profile['display_name'],
                                        0,
                                        1
                                    )
                                ),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </div>

                    <?php endif; ?>

                    <div class="home-profile-info">

                        <strong>
                            <?= htmlspecialchars(
                                $profile['display_name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </strong>

                        <span>
                            <?= htmlspecialchars(
                                $profile['job_title']
                                    ?: $profile['email'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>

                    </div>

                    <span
                        class="home-profile-arrow"
                        aria-hidden="true"
                    >
                        →
                    </span>

                </a>

            </section>

            <!-- TEAMS -->

            <section class="home-panel home-teams-panel">

                <div class="home-panel-header">

                    <div>
                        <span class="page-eyebrow">
                            Organization
                        </span>

                        <h2>
                            Your teams
                        </h2>
                    </div>

                </div>

                <?php if ($userTeams === []): ?>

                    <div class="home-sidebar-empty">
                        You're not currently assigned to a team.
                    </div>

                <?php else: ?>

                    <div class="home-team-list">

                        <?php foreach ($userTeams as $team): ?>

                            <div class="home-team-item">

                                <?php if (!empty($team['team_lead_avatar'])): ?>

                                    <img
                                        class="home-team-avatar"
                                        src="<?= htmlspecialchars(
                                            $team['team_lead_avatar'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        alt=""
                                    >

                                <?php else: ?>

                                    <div
                                        class="home-team-avatar home-team-avatar-placeholder"
                                    >
                                        <?= htmlspecialchars(
                                            strtoupper(
                                                substr(
                                                    $team['team_lead_name']
                                                        ?? $team['name'],
                                                    0,
                                                    1
                                                )
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </div>

                                <?php endif; ?>

                                <div class="home-team-info">

                                    <strong>
                                        <?= alliances_team_link(
                                            (int) $team['id'],
                                            (string) $team['name']
                                        ) ?>
                                    </strong>

                                    <span>
                                        <?php if (
                                            (int) $team['team_lead_id']
                                            === (int) $user['id']
                                        ): ?>

                                            You are Team Lead

                                        <?php elseif (!empty($team['team_lead_name'])): ?>

                                            Led by
                                            <?= htmlspecialchars(
                                                $team['team_lead_name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        <?php else: ?>

                                            Team

                                        <?php endif; ?>
                                    </span>

                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </section>

            <?php if ($canAccessAdministration): ?>

                <a
                    class="home-admin-card"
                    href="/admin/admin.php"
                >
                    <div>
                        <span class="page-eyebrow">
                            Management
                        </span>

                        <strong>
                            Administration
                        </strong>

                        <p>
                            <?= $access['is_admin']
                                ? 'Manage workspace users and teams.'
                                : 'Manage the people in your teams.' ?>
                        </p>
                    </div>

                    <span
                        class="home-admin-arrow"
                        aria-hidden="true"
                    >
                        →
                    </span>
                </a>

            <?php endif; ?>

        </aside>

    </div>

</main>

</body>
</html>
