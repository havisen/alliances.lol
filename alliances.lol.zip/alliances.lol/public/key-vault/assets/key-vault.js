'use strict';

import {
    generateOpenPgpIdentity,
    validateOpenPgpPublicKey,
    validateOpenPgpPrivateKey,
    getOpenPgpFingerprint
} from './openpgp-identity.js';

/*
 * Alliances Key Vault
 * Format v1
 *
 * The Key Vault password and decrypted vault
 * must never be sent to PHP.
 */

const KEY_VAULT_FORMAT = 'alliances-key-vault';
const KEY_VAULT_DATA_FORMAT = 'alliances-key-vault-data';

const KEY_VAULT_VERSION = 1;

const PBKDF2_ITERATIONS = 600000;
const SALT_LENGTH = 16;
const IV_LENGTH = 12;
const GCM_TAG_LENGTH = 128;

/*
|--------------------------------------------------------------------------
| Workday Key Vault session
|--------------------------------------------------------------------------
|
| Keeps the vault available across page navigation for up to 8 hours.
|
| The Key Vault password is NEVER stored.
|
*/

const VAULT_SESSION_DATA_KEY =
    'alliances.key-vault.session-data';

const VAULT_SESSION_KEY_KEY =
    'alliances.key-vault.session-key';

const VAULT_SESSION_EXPIRES_KEY =
    'alliances.key-vault.expires-at';

const VAULT_SESSION_USER_KEY =
    'alliances.key-vault.user-id';

const VAULT_SESSION_DURATION =
    8 * 60 * 60 * 1000;

const textEncoder = new TextEncoder();
const textDecoder = new TextDecoder();

const statusElement =
    document.getElementById('vault-status');

const createButton =
    document.getElementById('create-vault');

const unlockButton =
    document.getElementById('unlock-vault');

const csrfElement =
    document.querySelector(
        'meta[name="csrf-token"]'
    );

const userIdElement =
    document.querySelector(
        'meta[name="alliances-user-id"]'
    );

    const userNameElement =
    document.querySelector(
        'meta[name="alliances-user-name"]'
    );

const userEmailElement =
    document.querySelector(
        'meta[name="alliances-user-email"]'
    );

    const currentUserId =
    userIdElement?.getAttribute(
        'content'
    ) ?? '';


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

function getCsrfToken() {
    if (!csrfElement) {
        throw new Error(
            'CSRF token is missing.'
        );
    }

    const token =
        csrfElement.getAttribute('content');

    if (!token) {
        throw new Error(
            'CSRF token is missing.'
        );
    }

    return token;
}


/*
|--------------------------------------------------------------------------
| Status
|--------------------------------------------------------------------------
*/

function setVaultStatus(message) {
    if (statusElement) {
        statusElement.textContent = message;
    }
}


/*
|--------------------------------------------------------------------------
| Base64 helpers
|--------------------------------------------------------------------------
*/

function bytesToBase64(bytes) {
    let binary = '';

    for (let i = 0; i < bytes.length; i++) {
        binary += String.fromCharCode(
            bytes[i]
        );
    }

    return btoa(binary);
}


function base64ToBytes(base64) {
    const binary = atob(base64);

    const bytes =
        new Uint8Array(binary.length);

    for (
        let i = 0;
        i < binary.length;
        i++
    ) {
        bytes[i] =
            binary.charCodeAt(i);
    }

    return bytes;
}

/*
|--------------------------------------------------------------------------
| Workday Key Vault session
|--------------------------------------------------------------------------
*/

function clearVaultSession() {
    localStorage.removeItem(
        VAULT_SESSION_DATA_KEY
    );

    localStorage.removeItem(
        VAULT_SESSION_KEY_KEY
    );

    localStorage.removeItem(
        VAULT_SESSION_EXPIRES_KEY
    );

    localStorage.removeItem(
        VAULT_SESSION_USER_KEY
    );
}


async function saveVaultSession(vaultData) {
    /*
     * Generate a fresh random AES-256 key.
     *
     * The Key Vault password is never stored.
     */
    const sessionKeyBytes =
        crypto.getRandomValues(
            new Uint8Array(32)
        );

    const iv =
        crypto.getRandomValues(
            new Uint8Array(IV_LENGTH)
        );

    const sessionKey =
        await crypto.subtle.importKey(
            'raw',
            sessionKeyBytes,
            {
                name: 'AES-GCM'
            },
            false,
            [
                'encrypt'
            ]
        );

    const plaintext =
        textEncoder.encode(
            JSON.stringify(vaultData)
        );

    const encrypted =
        await crypto.subtle.encrypt(
            {
                name: 'AES-GCM',
                iv: iv,
                tagLength: GCM_TAG_LENGTH
            },
            sessionKey,
            plaintext
        );

    const sessionData = {
        version: 1,

        iv:
            bytesToBase64(iv),

        ciphertext:
            bytesToBase64(
                new Uint8Array(encrypted)
            )
    };

    const expiresAt =
        Date.now()
        + VAULT_SESSION_DURATION;

    localStorage.setItem(
        VAULT_SESSION_DATA_KEY,
        JSON.stringify(sessionData)
    );

    localStorage.setItem(
        VAULT_SESSION_KEY_KEY,
        bytesToBase64(sessionKeyBytes)
    );

    localStorage.setItem(
        VAULT_SESSION_EXPIRES_KEY,
        String(expiresAt)
    );

    localStorage.setItem(
    VAULT_SESSION_USER_KEY,
    currentUserId
);

    /*
     * Best-effort overwrite of our temporary
     * byte-array copy.
     */
    sessionKeyBytes.fill(0);
}


async function restoreVaultSession() {
    const expiresAt =
        Number(
            localStorage.getItem(
                VAULT_SESSION_EXPIRES_KEY
            )
        );

        const sessionUserId =
    localStorage.getItem(
        VAULT_SESSION_USER_KEY
    );

/*
 * A Key Vault workday session belongs only
 * to the Alliances account that created it.
 *
 * If another user has logged in on this
 * browser, discard the previous user's
 * session before decrypting anything.
 */
if (
    currentUserId === ''
    || sessionUserId !== currentUserId
) {
    clearVaultSession();

    return null;
}

    if (
        !Number.isFinite(expiresAt)
        || expiresAt <= Date.now()
    ) {
        clearVaultSession();
        return null;
    }

    const storedData =
        localStorage.getItem(
            VAULT_SESSION_DATA_KEY
        );

    const storedKey =
        localStorage.getItem(
            VAULT_SESSION_KEY_KEY
        );

    if (!storedData || !storedKey) {
        clearVaultSession();
        return null;
    }

    try {
        const sessionData =
            JSON.parse(storedData);

        if (
            !sessionData
            || sessionData.version !== 1
            || typeof sessionData.iv !== 'string'
            || typeof sessionData.ciphertext !== 'string'
        ) {
            throw new Error(
                'Invalid Key Vault session.'
            );
        }

        const keyBytes =
            base64ToBytes(storedKey);

        const iv =
            base64ToBytes(
                sessionData.iv
            );

        const ciphertext =
            base64ToBytes(
                sessionData.ciphertext
            );

        if (
            keyBytes.length !== 32
            || iv.length !== IV_LENGTH
        ) {
            throw new Error(
                'Invalid Key Vault session.'
            );
        }

        const sessionKey =
            await crypto.subtle.importKey(
                'raw',
                keyBytes,
                {
                    name: 'AES-GCM'
                },
                false,
                [
                    'decrypt'
                ]
            );

        const decrypted =
            await crypto.subtle.decrypt(
                {
                    name: 'AES-GCM',
                    iv: iv,
                    tagLength:
                        GCM_TAG_LENGTH
                },
                sessionKey,
                ciphertext
            );

        keyBytes.fill(0);

        const vaultData =
            JSON.parse(
                textDecoder.decode(
                    decrypted
                )
            );

        if (
            !vaultData
            || vaultData.format !==
                KEY_VAULT_DATA_FORMAT
            || vaultData.version !==
                KEY_VAULT_VERSION
        ) {
            throw new Error(
                'Invalid Key Vault session data.'
            );
        }

        return vaultData;
    } catch (error) {
        console.error(
            'Could not restore Key Vault session:',
            error
        );

        clearVaultSession();

        return null;
    }
}

/*
|--------------------------------------------------------------------------
| Empty Key Vault
|--------------------------------------------------------------------------
|
| This object exists only in the browser.
|
*/

function createEmptyVaultData() {
    return {
        format: KEY_VAULT_DATA_FORMAT,
        version: KEY_VAULT_VERSION,

        identity: {
            openpgp: {
                publicKey: null,
                privateKey: null,
                fingerprint: null
            }
        },

        messaging: {
            groupKeys: {}
        },

        drive: {
            keys: {}
        },

        credentials: {
            keys: {}
        }
    };
}


/*
|--------------------------------------------------------------------------
| Password key
|--------------------------------------------------------------------------
*/

async function importPassword(password) {
    return crypto.subtle.importKey(
        'raw',

        textEncoder.encode(password),

        {
            name: 'PBKDF2'
        },

        false,

        [
            'deriveKey'
        ]
    );
}


/*
|--------------------------------------------------------------------------
| Derive AES key
|--------------------------------------------------------------------------
*/

async function deriveVaultKey(
    password,
    salt,
    iterations
) {
    const passwordKey =
        await importPassword(password);

    return crypto.subtle.deriveKey(
        {
            name: 'PBKDF2',

            salt: salt,

            iterations: iterations,

            hash: 'SHA-256'
        },

        passwordKey,

        {
            name: 'AES-GCM',
            length: 256
        },

        false,

        [
            'encrypt',
            'decrypt'
        ]
    );
}


/*
|--------------------------------------------------------------------------
| Encrypt Key Vault
|--------------------------------------------------------------------------
*/

async function encryptVault(
    vaultData,
    password
) {
    const salt =
        crypto.getRandomValues(
            new Uint8Array(
                SALT_LENGTH
            )
        );

    const iv =
        crypto.getRandomValues(
            new Uint8Array(
                IV_LENGTH
            )
        );

    const vaultKey =
        await deriveVaultKey(
            password,
            salt,
            PBKDF2_ITERATIONS
        );

    const plaintext =
        textEncoder.encode(
            JSON.stringify(vaultData)
        );

    const encrypted =
        await crypto.subtle.encrypt(
            {
                name: 'AES-GCM',
                iv: iv,
                tagLength: GCM_TAG_LENGTH
            },

            vaultKey,

            plaintext
        );

    return {
        format: KEY_VAULT_FORMAT,

        version: KEY_VAULT_VERSION,

        kdf: {
            algorithm: 'PBKDF2',

            hash: 'SHA-256',

            iterations:
                PBKDF2_ITERATIONS,

            salt:
                bytesToBase64(salt)
        },

encryption: {
    algorithm: 'AES-GCM',

    keyLength: 256,

    tagLength: GCM_TAG_LENGTH,

    iv:
        bytesToBase64(iv),

    ciphertext:
        bytesToBase64(
            new Uint8Array(
                encrypted
            )
        )
}
    };
}


/*
|--------------------------------------------------------------------------
| Decrypt Key Vault
|--------------------------------------------------------------------------
*/

async function decryptVault(
    envelope,
    password
) {
    if (
        !envelope
        || envelope.format !==
            KEY_VAULT_FORMAT
        || envelope.version !==
            KEY_VAULT_VERSION
    ) {
        throw new Error(
            'Unsupported Key Vault format.'
        );
    }

    if (
        !envelope.kdf
        || envelope.kdf.algorithm !==
            'PBKDF2'
        || envelope.kdf.hash !==
            'SHA-256'
        || envelope.kdf.iterations !==
            PBKDF2_ITERATIONS
    ) {
        throw new Error(
            'Unsupported Key Vault KDF.'
        );
    }

    if (
        !envelope.encryption
        || envelope.encryption.algorithm !==
            'AES-GCM'
        || envelope.encryption.keyLength !==
            256
    ) {
        throw new Error(
            'Unsupported Key Vault encryption.'
        );
    }

    let salt;
    let iv;
    let ciphertext;

    try {
        salt =
            base64ToBytes(
                envelope.kdf.salt
            );

        iv =
            base64ToBytes(
                envelope.encryption.iv
            );

        ciphertext =
            base64ToBytes(
                envelope.encryption.ciphertext
            );
    } catch (error) {
        throw new Error(
            'Invalid Key Vault encoding.'
        );
    }

    if (
        salt.length !==
        SALT_LENGTH
    ) {
        throw new Error(
            'Invalid Key Vault salt.'
        );
    }

    if (
        iv.length !==
        IV_LENGTH
    ) {
        throw new Error(
            'Invalid Key Vault IV.'
        );
    }

    const vaultKey =
        await deriveVaultKey(
            password,
            salt,
            envelope.kdf.iterations
        );

    let decrypted;

    try {
        decrypted =
            await crypto.subtle.decrypt(
{
    name: 'AES-GCM',
    iv: iv,

    tagLength:
        envelope.encryption.tagLength
        ?? GCM_TAG_LENGTH
},

                vaultKey,

                ciphertext
            );
    } catch (error) {
        throw new Error(
            'Incorrect Key Vault password or corrupted Key Vault.'
        );
    }

    let vaultData;

    try {
        vaultData =
            JSON.parse(
                textDecoder.decode(
                    decrypted
                )
            );
    } catch (error) {
        throw new Error(
            'Invalid Key Vault contents.'
        );
    }

    if (
        !vaultData
        || vaultData.format !==
            KEY_VAULT_DATA_FORMAT
        || vaultData.version !==
            KEY_VAULT_VERSION
    ) {
        throw new Error(
            'Unsupported Key Vault data.'
        );
    }

    return vaultData;
}


/*
|--------------------------------------------------------------------------
| Send encrypted vault
|--------------------------------------------------------------------------
|
| The encrypted envelope is converted to JSON,
| then placed inside ordinary POST form data.
|
| This allows the existing PHP CSRF protection
| to read:
|
| $_POST['csrf_token']
|
| The Key Vault password is NOT included.
|
*/

async function sendVault(
    url,
    envelope
) {
    const formData =
        new FormData();

    formData.append(
        'csrf_token',
        getCsrfToken()
    );

    formData.append(
        'vault',
        JSON.stringify(envelope)
    );

    const response =
        await fetch(
            url,
            {
                method: 'POST',

                credentials:
                    'same-origin',

                body: formData
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid response from server.'
        );
    }

    if (!response.ok) {
        throw new Error(
            result.error
            || 'Key Vault request failed.'
        );
    }

    return result;
}


/*
|--------------------------------------------------------------------------
| Create encrypted vault
|--------------------------------------------------------------------------
*/

async function uploadNewVault(
    envelope
) {
    return sendVault(
        '/actions/key-vault/create.php',
        envelope
    );
}


/*
|--------------------------------------------------------------------------
| Update encrypted vault
|--------------------------------------------------------------------------
|
| This will be used when encrypted Key Vault
| contents change later.
|
*/

async function uploadUpdatedVault(
    envelope
) {
    return sendVault(
        '/actions/key-vault/update.php',
        envelope
    );
}

/*
|--------------------------------------------------------------------------
| Save unlocked Key Vault
|--------------------------------------------------------------------------
|
| Re-encrypts the currently unlocked plaintext Key Vault and replaces
| the encrypted envelope stored on the server.
|
| The password and plaintext Key Vault remain in the browser.
|
*/

async function saveUnlockedVault(password) {
    if (!unlockedVault) {
        throw new Error(
            'Key Vault is not unlocked.'
        );
    }

    if (
        typeof password !== 'string'
        || password === ''
    ) {
        throw new Error(
            'Key Vault password is required.'
        );
    }

    /*
     * Generate a completely new salt and IV and
     * encrypt the current plaintext vault.
     */

    const envelope =
        await encryptVault(
            unlockedVault,
            password
        );

    /*
     * Only the encrypted envelope is sent to PHP.
     */

await uploadUpdatedVault(
    envelope
);

/*
 * The permanent encrypted vault has been
 * updated successfully.
 *
 * Refresh the 8-hour workday session so it
 * contains the same current vault data.
 */
await saveVaultSession(
    unlockedVault
);

return envelope;
}

/*
|--------------------------------------------------------------------------
| Publish OpenPGP public key
|--------------------------------------------------------------------------
|
| Publishes only the user's PUBLIC OpenPGP key.
|
| The private key and Key Vault password must never be included in this
| request.
|
*/

async function publishOpenPgpPublicKey() {
    if (!unlockedVault) {
        throw new Error(
            'Key Vault is not unlocked.'
        );
    }

    const identity =
        unlockedVault.identity?.openpgp;

    if (
        !identity
        || typeof identity.publicKey !== 'string'
        || identity.publicKey === ''
        || typeof identity.fingerprint !== 'string'
        || identity.fingerprint === ''
    ) {
        throw new Error(
            'OpenPGP identity is not configured.'
        );
    }

    /*
     * Parse the public key using OpenPGP.js.
     */

    const publicKeyValid =
        await validateOpenPgpPublicKey(
            identity.publicKey
        );

    if (
        !publicKeyValid
        || !identity.publicKey.trim().startsWith(
            '-----BEGIN PGP PUBLIC KEY BLOCK-----'
        )
        || identity.publicKey.includes(
            '-----BEGIN PGP PRIVATE KEY BLOCK-----'
        )
    ) {
        throw new Error(
            'OpenPGP public key is invalid.'
        );
    }

    /*
     * Derive the fingerprint directly from the
     * public key instead of trusting stored text.
     */

    const derivedFingerprint =
        (
            await getOpenPgpFingerprint(
                identity.publicKey
            )
        ).toLowerCase();

    const storedFingerprint =
        identity.fingerprint
            .trim()
            .toLowerCase();

    if (
        derivedFingerprint
        !== storedFingerprint
    ) {
        throw new Error(
            'OpenPGP fingerprint verification failed.'
        );
    }

    /*
     * Send PUBLIC information only.
     */

    const formData =
        new FormData();

    formData.append(
        'csrf_token',
        getCsrfToken()
    );

    formData.append(
        'public_key',
        identity.publicKey
    );

    formData.append(
        'fingerprint',
        derivedFingerprint
    );

    const response =
        await fetch(
            '/actions/messaging/publish-public-key.php',
            {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid response while publishing public key.'
        );
    }

    if (!response.ok) {
        throw new Error(
            result?.error
            || 'Could not publish OpenPGP public key.'
        );
    }

    return result;
}

/*
|--------------------------------------------------------------------------
| Download encrypted vault
|--------------------------------------------------------------------------
*/

async function downloadVault() {
    const response =
        await fetch(
            '/actions/key-vault/load.php',
            {
                method: 'GET',

                credentials:
                    'same-origin',

                cache:
                    'no-store'
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid response from server.'
        );
    }

    if (!response.ok) {
        throw new Error(
            result.error
            || 'Could not load Key Vault.'
        );
    }

    return result;
}


/*
|--------------------------------------------------------------------------
| UI
|--------------------------------------------------------------------------
*/

function showServicesUnlocked() {
    /*
     * Update protected service badges.
     */
    const serviceStatuses =
        document.querySelectorAll(
            '.service-status'
        );

    serviceStatuses.forEach(
        function (status) {
            status.textContent =
                'Unlocked';
        }
    );

    /*
     * Update the main Key Vault state.
     */
    const vaultTitle =
        document.getElementById(
            'vault-state-title'
        );

    const vaultDescription =
        document.getElementById(
            'vault-state-description'
        );

    const vaultLock =
        document.querySelector(
            '#vault-unlock .key-vault-lock'
        );

    if (vaultTitle) {
        vaultTitle.textContent =
            'Key Vault unlocked';
    }

    if (vaultDescription) {
        vaultDescription.textContent =
            'Your encryption keys are available for this workday session.';
    }

    if (vaultLock) {
        vaultLock.textContent = '🔓';
    }

    /*
     * The vault is already unlocked, so the main
     * password controls should no longer ask the
     * user to unlock it again.
     */
const passwordInput =
    document.getElementById(
        'vault-password'
    );

const passwordField =
    passwordInput?.closest(
        '.key-vault-field'
    );

const confirmInput =
    document.getElementById(
        'vault-password-confirm'
    );

const confirmField =
    confirmInput?.closest(
        '.key-vault-field'
    );

if (passwordInput) {
    passwordInput.value = '';
}

if (passwordField) {
    passwordField.hidden = true;
}

if (confirmInput) {
    confirmInput.value = '';
}

if (confirmField) {
    confirmField.hidden = true;
}

if (unlockButton) {
    unlockButton.hidden = true;
}

if (createButton) {
    createButton.hidden = true;
}

    showOpenPgpIdentityPanel();
}
/*
|--------------------------------------------------------------------------
| OpenPGP identity UI
|--------------------------------------------------------------------------
*/

function showOpenPgpIdentityPanel() {
    const panel =
        document.getElementById(
            'openpgp-identity-panel'
        );

    const identityStatus =
        document.getElementById(
            'openpgp-identity-status'
        );

    const createIdentityButton =
        document.getElementById(
            'create-openpgp-identity'
        );

    const passwordField =
        document.getElementById(
        'openpgp-password-field'
        );

if (
    !panel
    || !identityStatus
    || !createIdentityButton
    || !passwordField
) {
    return;
}

    if (!unlockedVault) {
        panel.hidden = true;
        return;
    }

    panel.hidden = false;

    const openPgpIdentity =
        unlockedVault.identity?.openpgp;

    const hasIdentity =
        openPgpIdentity
        && typeof openPgpIdentity.publicKey ===
            'string'
        && openPgpIdentity.publicKey !== ''
        && typeof openPgpIdentity.privateKey ===
            'string'
        && openPgpIdentity.privateKey !== ''
        && typeof openPgpIdentity.fingerprint ===
            'string'
        && openPgpIdentity.fingerprint !== '';

    const openPgpServiceStatus =
    document.getElementById(
        'openpgp-status'
    );

if (hasIdentity) {
    identityStatus.textContent =
        'OpenPGP identity: '
        + openPgpIdentity.fingerprint;

    if (openPgpServiceStatus) {
        openPgpServiceStatus.textContent =
            'Ready';
    }

    createIdentityButton.hidden =
        true;

    passwordField.hidden =
        true;

    return;
}

identityStatus.textContent =
    'No OpenPGP identity has been created yet.';

if (openPgpServiceStatus) {
    openPgpServiceStatus.textContent =
        'Not configured';
}

createIdentityButton.hidden =
    false;

passwordField.hidden =
    false;
}

function clearPasswordFields() {
    const passwordFields =
        document.querySelectorAll(
            'input[type="password"]'
        );

    passwordFields.forEach(
        function (field) {
            field.value = '';
        }
    );
}


/*
|--------------------------------------------------------------------------
| Unlocked Key Vault
|--------------------------------------------------------------------------
|
| Plaintext Key Vault data is deliberately kept
| only in JavaScript memory.
|
| It is NOT written to:
|
| - localStorage
| - sessionStorage
| - IndexedDB
| - cookies
|
*/

let unlockedVault = null;


/*
|--------------------------------------------------------------------------
| Create Key Vault
|--------------------------------------------------------------------------
*/

if (createButton) {
    createButton.addEventListener(
        'click',

        async function () {
            const passwordInput =
                document.getElementById(
                    'vault-password'
                );

            const confirmInput =
                document.getElementById(
                    'vault-password-confirm'
                );

            if (
                !passwordInput
                || !confirmInput
            ) {
                return;
            }

            const password =
                passwordInput.value;

            const confirmation =
                confirmInput.value;

            if (
                password.length < 12
            ) {
                setVaultStatus(
                    'Your Key Vault password must be at least 12 characters.'
                );

                return;
            }

            if (
                password !==
                confirmation
            ) {
                setVaultStatus(
                    'The Key Vault passwords do not match.'
                );

                return;
            }

            createButton.disabled =
                true;

            setVaultStatus(
                'Creating encrypted Key Vault...'
            );

            try {
                /*
                 * Plaintext vault is created
                 * locally.
                 */

                const vaultData =
                    createEmptyVaultData();

                /*
                 * Encrypt locally before any
                 * server request occurs.
                 */

                const envelope =
                    await encryptVault(
                        vaultData,
                        password
                    );

                /*
                 * Only the encrypted envelope
                 * is uploaded.
                 */

                await uploadNewVault(
                    envelope
                );

                /*
                 * Keep plaintext in memory for
                 * this page only.
                 */

unlockedVault =
    vaultData;

/*
 * Create/update the 8-hour encrypted
 * workday Key Vault session.
 */
await saveVaultSession(
    unlockedVault
);

clearPasswordFields();

showServicesUnlocked();

                setVaultStatus(
                    'Key Vault created and unlocked.'
                );
            } catch (error) {
                console.error(error);

                setVaultStatus(
                    error.message
                    || 'Could not create Key Vault.'
                );

                createButton.disabled =
                    false;
            }
        }
    );
}


/*
|--------------------------------------------------------------------------
| Unlock Key Vault
|--------------------------------------------------------------------------
*/

if (unlockButton) {
    unlockButton.addEventListener(
        'click',

        async function () {
            const passwordInput =
                document.getElementById(
                    'vault-password'
                );

            if (!passwordInput) {
                return;
            }

            const password =
                passwordInput.value;

            if (password === '') {
                setVaultStatus(
                    'Enter your Key Vault password.'
                );

                return;
            }

            unlockButton.disabled =
                true;

            setVaultStatus(
                'Unlocking Key Vault...'
            );

            try {
                /*
                 * Server returns only the
                 * encrypted envelope.
                 */

                const result =
                    await downloadVault();

                if (
                    !result.exists
                    || !result.vault
                ) {
                    throw new Error(
                        'Key Vault does not exist.'
                    );
                }

                /*
                 * Decrypt locally.
                 */

                const vaultData =
                    await decryptVault(
                        result.vault,
                        password
                    );

                /*
                 * Keep plaintext only in
                 * page memory.
                 */

unlockedVault =
    vaultData;

/*
 * Keep this successfully unlocked vault available
 * for the 8-hour workday session.
 */
await saveVaultSession(
    unlockedVault
);

clearPasswordFields();

showServicesUnlocked();

                /*
                 * Synchronize the PUBLIC OpenPGP
                 * key with Messaging.
                 */

                if (
                    unlockedVault.identity?.openpgp?.publicKey
                    && unlockedVault.identity?.openpgp?.fingerprint
                ) {
                    try {
                        await publishOpenPgpPublicKey();
                    } catch (error) {
                        console.error(
                            'Could not publish Messaging public key:',
                            error
                        );
                    }
                }

                setVaultStatus(
                    'Key Vault unlocked.'
                );
            } catch (error) {
                console.error(error);

                setVaultStatus(
                    error.message
                    || 'Could not unlock Key Vault.'
                );

                unlockButton.disabled =
                    false;
            }
        }
    );
}

/*
|--------------------------------------------------------------------------
| Create OpenPGP identity
|--------------------------------------------------------------------------
*/

const createOpenPgpIdentityButton =
    document.getElementById(
        'create-openpgp-identity'
    );

if (createOpenPgpIdentityButton) {
    createOpenPgpIdentityButton.addEventListener(
        'click',

        async function () {
            const passwordInput =
                document.getElementById(
                    'openpgp-vault-password'
                );

            const identityStatus =
                document.getElementById(
                    'openpgp-identity-status'
                );

            if (
                !passwordInput
                || !identityStatus
            ) {
                return;
            }

            if (!unlockedVault) {
                identityStatus.textContent =
                    'Unlock your Key Vault first.';

                return;
            }

            const existingIdentity =
                unlockedVault.identity?.openpgp;

            if (
                existingIdentity
                && typeof existingIdentity.privateKey ===
                    'string'
                && existingIdentity.privateKey !== ''
            ) {
                identityStatus.textContent =
                    'An OpenPGP identity already exists.';

                return;
            }

            const password =
                passwordInput.value;

            if (password === '') {
                identityStatus.textContent =
                    'Enter your Key Vault password.';

                return;
            }

            const userName =
                userNameElement?.getAttribute(
                    'content'
                ) ?? '';

            const userEmail =
                userEmailElement?.getAttribute(
                    'content'
                ) ?? '';

            if (
                userName === ''
                || userEmail === ''
            ) {
                identityStatus.textContent =
                    'Your profile name or email address is missing.';

                return;
            }

            createOpenPgpIdentityButton.disabled =
                true;

            identityStatus.textContent =
                'Verifying Key Vault password...';

            let previousIdentity = null;

            try {
                /*
                 * Verify the password against the
                 * encrypted vault stored on the server.
                 */

                const storedVault =
                    await downloadVault();

                if (
                    !storedVault.exists
                    || !storedVault.vault
                ) {
                    throw new Error(
                        'Key Vault does not exist.'
                    );
                }

                await decryptVault(
                    storedVault.vault,
                    password
                );

                /*
                 * Generate the user's OpenPGP
                 * identity entirely in the browser.
                 */

                identityStatus.textContent =
                    'Generating OpenPGP identity...';

                const identity =
                    await generateOpenPgpIdentity(
                        userName,
                        userEmail
                    );

                /*
                 * Validate the generated keys.
                 */

                const publicKeyValid =
                    await validateOpenPgpPublicKey(
                        identity.publicKey
                    );

                const privateKeyValid =
                    await validateOpenPgpPrivateKey(
                        identity.privateKey
                    );

                if (
                    !publicKeyValid
                    || !privateKeyValid
                ) {
                    throw new Error(
                        'Generated OpenPGP identity is invalid.'
                    );
                }

                const fingerprint =
                    await getOpenPgpFingerprint(
                        identity.publicKey
                    );

                /*
                 * Remember the old value so that
                 * an unsuccessful server update
                 * can be rolled back in memory.
                 */

                previousIdentity =
                    unlockedVault.identity.openpgp;

                /*
                 * Store the private identity only
                 * inside the plaintext vault
                 * currently held in browser memory.
                 */

                unlockedVault.identity.openpgp = {
                    publicKey:
                        identity.publicKey,

                    privateKey:
                        identity.privateKey,

                    fingerprint:
                        fingerprint
                };

                /*
                 * Re-encrypt the complete vault
                 * before sending anything to PHP.
                 */

                identityStatus.textContent =
                    'Encrypting and saving OpenPGP identity...';

                try {
                    await saveUnlockedVault(
                        password
                    );
                } catch (error) {
                    /*
                     * The server did not accept the
                     * updated encrypted vault.
                     *
                     * Restore the in-memory state so
                     * the UI does not claim an
                     * unsaved identity exists.
                     */

                    unlockedVault.identity.openpgp =
                        previousIdentity;

                    throw error;
                }

                /*
                 * Publishing is separate from saving the encrypted identity.
                 * A Messaging failure must not roll back the saved identity.
                 */
                try {
                    await publishOpenPgpPublicKey();
                } catch (error) {
                    console.error(
                        'Could not publish Messaging public key:',
                        error
                    );
                }

                /*
                 * Password is no longer needed.
                 */

                passwordInput.value = '';

                showOpenPgpIdentityPanel();

                identityStatus.textContent =
                    'OpenPGP identity: '
                    + fingerprint;
            } catch (error) {
                console.error(error);

                passwordInput.value = '';

                identityStatus.textContent =
                    error.message
                    || 'Could not create OpenPGP identity.';

                createOpenPgpIdentityButton.disabled =
                    false;
            }
        }
    );
}

/*
|--------------------------------------------------------------------------
| Restore workday Key Vault session
|--------------------------------------------------------------------------
|
| If the user unlocked the Key Vault earlier during this
| 8-hour workday session, restore it without asking for
| the Key Vault password again.
|
*/

async function restoreWorkdayVault() {
    try {
        const restoredVault =
            await restoreVaultSession();

        if (!restoredVault) {
            return;
        }

        unlockedVault =
            restoredVault;

        clearPasswordFields();

        showServicesUnlocked();

        /*
         * Keep the public Messaging key synchronized.
         */
        if (
            unlockedVault.identity?.openpgp?.publicKey
            && unlockedVault.identity?.openpgp?.fingerprint
        ) {
            try {
                await publishOpenPgpPublicKey();
            } catch (error) {
                console.error(
                    'Could not publish Messaging public key:',
                    error
                );
            }
        }

        setVaultStatus(
            'Key Vault unlocked for this workday session.'
        );
    } catch (error) {
        console.error(
            'Could not restore Key Vault workday session:',
            error
        );

        clearVaultSession();
    }
}


/*
 * Try restoring immediately when the Key Vault page loads.
 */
restoreWorkdayVault();

/*
|--------------------------------------------------------------------------
| Discard unlocked vault
|--------------------------------------------------------------------------
*/

window.addEventListener(
    'pagehide',

    function () {
        unlockedVault = null;
    }
);