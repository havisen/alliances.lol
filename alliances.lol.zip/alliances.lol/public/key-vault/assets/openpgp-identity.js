'use strict';

import * as openpgp from
    '/assets/vendor/openpgp/openpgp.min.mjs';

/*
|--------------------------------------------------------------------------
| Alliances OpenPGP identity
|--------------------------------------------------------------------------
|
| OpenPGP identities are generated in the browser.
|
| The private key returned by this module must only be placed inside the
| unlocked Key Vault. It must never be sent to PHP in plaintext.
|
*/

/*
|--------------------------------------------------------------------------
| Generate identity
|--------------------------------------------------------------------------
*/

export async function generateOpenPgpIdentity(
    name,
    email
) {
    if (
        typeof name !== 'string'
        || name.trim() === ''
    ) {
        throw new Error(
            'A name is required to generate an OpenPGP identity.'
        );
    }

    if (
        typeof email !== 'string'
        || email.trim() === ''
    ) {
        throw new Error(
            'An email address is required to generate an OpenPGP identity.'
        );
    }

const result =
    await openpgp.generateKey({
        type: 'ecc',

        curve: 'curve25519',

        userIDs: [
            {
                name: name.trim(),
                email: email.trim()
            }
        ],

        format: 'armored'
    });

    const publicKey =
        await openpgp.readKey({
            armoredKey: result.publicKey
        });

    return {
        publicKey:
            result.publicKey,

        privateKey:
            result.privateKey,

        fingerprint:
            publicKey.getFingerprint()
    };
}


/*
|--------------------------------------------------------------------------
| Validate public key
|--------------------------------------------------------------------------
*/

export async function validateOpenPgpPublicKey(
    armoredPublicKey
) {
    if (
        typeof armoredPublicKey !== 'string'
        || armoredPublicKey === ''
    ) {
        return false;
    }

    try {
        await openpgp.readKey({
            armoredKey:
                armoredPublicKey
        });

        return true;
    } catch (error) {
        return false;
    }
}


/*
|--------------------------------------------------------------------------
| Validate private key
|--------------------------------------------------------------------------
*/

export async function validateOpenPgpPrivateKey(
    armoredPrivateKey
) {
    if (
        typeof armoredPrivateKey !== 'string'
        || armoredPrivateKey === ''
    ) {
        return false;
    }

    try {
        await openpgp.readPrivateKey({
            armoredKey:
                armoredPrivateKey
        });

        return true;
    } catch (error) {
        return false;
    }
}


/*
|--------------------------------------------------------------------------
| Fingerprint
|--------------------------------------------------------------------------
*/

export async function getOpenPgpFingerprint(
    armoredPublicKey
) {
    const publicKey =
        await openpgp.readKey({
            armoredKey:
                armoredPublicKey
        });

    return publicKey.getFingerprint();
}