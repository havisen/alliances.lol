<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/key-vault/vault.php';

$currentUser = require_login();

$vaultExists = key_vault_exists(
    (int) $currentUser['id']
);

$csrfToken = csrf_token();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars(
            $csrfToken,
            ENT_QUOTES,
            'UTF-8'
        ) ?>"
    >

<meta
    name="alliances-user-name"
    content="<?= htmlspecialchars(
        (string) $currentUser['display_name'],
        ENT_QUOTES,
        'UTF-8'
    ) ?>"
>

<meta
    name="alliances-user-id"
    content="<?= (int) $currentUser['id'] ?>"
>

<meta
    name="alliances-user-email"
    content="<?= htmlspecialchars(
        (string) $currentUser['email'],
        ENT_QUOTES,
        'UTF-8'
    ) ?>"
>

    <title>Key Vault - Alliances</title>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <link
        rel="stylesheet"
        href="/key-vault/assets/key-vault.css"
    >
</head>

<body>

<?php render_navigation($currentUser); ?>

<main class="app-main">

    <div class="key-vault-page">

        <header class="key-vault-header">
            <div>
                <h1>Key Vault</h1>

                <p>
                    Your Key Vault protects the encryption keys
                    used by Alliances.
                </p>
            </div>
        </header>

        <section class="key-vault-card">

            <?php if (!$vaultExists): ?>

                <div id="vault-setup">

                    <div class="key-vault-lock">
                        🔐
                    </div>

                    <h2>Create your Key Vault</h2>

                    <p class="key-vault-description">
                        Create a separate Key Vault password.
                        This password is used locally on your
                        device to protect your encryption keys.
                    </p>

                    <div class="key-vault-warning">
                        <strong>Important:</strong>

                        Your Key Vault password is not your
                        Alliances login password.

                        Alliances cannot recover your Key Vault
                        password if you forget it.
                    </div>

                    <div class="key-vault-field">
                        <label for="vault-password">
                            Key Vault password
                        </label>

                        <input
                            id="vault-password"
                            type="password"
                            autocomplete="new-password"
                            minlength="12"
                        >
                    </div>

                    <div class="key-vault-field">
                        <label for="vault-password-confirm">
                            Confirm Key Vault password
                        </label>

                        <input
                            id="vault-password-confirm"
                            type="password"
                            autocomplete="new-password"
                            minlength="12"
                        >
                    </div>

                    <button
                        type="button"
                        id="create-vault"
                        class="key-vault-button"
                    >
                        Create Key Vault
                    </button>

                </div>

            <?php else: ?>

                <div id="vault-unlock">

                    <div class="key-vault-lock">
                        🔒
                    </div>

<h2 id="vault-state-title">
    Key Vault locked
</h2>

<p
    id="vault-state-description"
    class="key-vault-description"
>
    Enter your Key Vault password to unlock
    encrypted Alliances services on this device.
</p>

                    <div class="key-vault-field">
                        <label for="vault-password">
                            Key Vault password
                        </label>

                        <input
                            id="vault-password"
                            type="password"
                            autocomplete="current-password"
                        >
                    </div>

                    <button
                        type="button"
                        id="unlock-vault"
                        class="key-vault-button"
                    >
                        Unlock Key Vault
                    </button>

                </div>

            <?php endif; ?>

            <p
                id="vault-status"
                class="key-vault-status"
                aria-live="polite"
            ></p>

        </section>

        <section class="key-vault-services">

            <h2>Protected services</h2>

            <div class="key-vault-service-list">

                <div class="key-vault-service">
                    <div>
                        <strong>Messaging</strong>

                        <span>
                            End-to-end encrypted conversations
                        </span>
                    </div>

                    <span class="service-status">
                        Locked
                    </span>
                </div>

                <div class="key-vault-service">
                    <div>
                        <strong>Encrypted Drive</strong>

                        <span>
                            Client-side encrypted files
                        </span>
                    </div>

                    <span class="service-status">
                        Locked
                    </span>
                </div>

                <div class="key-vault-service">
                    <div>
                        <strong>Shared Credentials</strong>

                        <span>
                            Encrypted passwords and secrets
                        </span>
                    </div>

                    <span class="service-status">
                        Locked
                    </span>
                </div>

<div
    class="key-vault-service"
    id="openpgp-service"
>
    <div>
        <strong>PGP Email</strong>

        <span>
            OpenPGP encryption keys
        </span>
    </div>

    <span
        class="service-status"
        id="openpgp-status"
    >
        Locked
    </span>
</div>

<div
    id="openpgp-identity-panel"
    class="key-vault-openpgp"
    hidden
>
    <h3>OpenPGP Identity</h3>

    <p>
        Create your personal OpenPGP identity for
        encrypted email and future secure key exchange.
    </p>

    <p id="openpgp-identity-status">
        No OpenPGP identity has been created yet.
    </p>

<div
    id="openpgp-password-field"
    class="key-vault-field"
>
    <label for="openpgp-vault-password">
        Confirm Key Vault password
    </label>

    <input
        id="openpgp-vault-password"
        type="password"
        autocomplete="current-password"
    >

    <p>
        Your password is used locally to re-encrypt
        your Key Vault after the OpenPGP identity is
        created. It is never sent to the server.
    </p>
</div>

    <button
        type="button"
        id="create-openpgp-identity"
        class="key-vault-button"
    >
        Create OpenPGP Identity
    </button>
</div>

            </div>

        </section>

    </div>

</main>

<script
    type="module"
    src="/key-vault/assets/key-vault.js"
></script>

</body>
</html>