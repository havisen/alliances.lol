<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/auth.php';

if (current_user() !== null) {
    header('Location: /');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (login_user($email, $password)) {
        header('Location: /');
        exit;
    }

    $error = 'Invalid email or password.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in | Alliances</title>
</head>
<body>
    <h1>Log in to Alliances</h1>

    <?php if ($error !== null): ?>
        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <form method="post">
        <label>
            Email
            <input type="email" name="email" required autocomplete="email">
        </label>

        <br>

        <label>
            Password
            <input type="password" name="password" required autocomplete="current-password">
        </label>

        <br>

        <button type="submit">Log in</button>
    </form>
</body>
</html>