<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/auth.php';

logout_user();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Logging out - Alliances</title>
</head>

<body>

<script>
(function () {
    'use strict';

    /*
     * Destroy the temporary Key Vault workday
     * session stored in this browser.
     *
     * The permanent encrypted Key Vault is not
     * affected.
     */
    localStorage.removeItem(
        'alliances.key-vault.session-data'
    );

    localStorage.removeItem(
        'alliances.key-vault.session-key'
    );

    localStorage.removeItem(
        'alliances.key-vault.expires-at'
    );

    localStorage.removeItem(
        'alliances.key-vault.user-id'
    );

    window.location.replace(
        '/login.php'
    );
})();
</script>

<noscript>
    <p>
        You have been logged out.
        <a href="/login.php">Continue to login</a>
    </p>
</noscript>

</body>
</html>