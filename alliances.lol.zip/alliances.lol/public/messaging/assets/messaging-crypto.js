'use strict';

import * as openpgp from
    '/assets/vendor/openpgp/openpgp.min.mjs';

/*
|--------------------------------------------------------------------------
| Alliances Messaging crypto
|--------------------------------------------------------------------------
|
| Cryptographic operations in this file happen in the browser.
|
| Raw conversation keys must never be sent to PHP.
|
*/

const CONVERSATION_KEY_LENGTH = 32;

const CONVERSATION_KEY_FORMAT =
    'alliances-conversation-key';

const CONVERSATION_KEY_FORMAT_VERSION = 1;


/*
|--------------------------------------------------------------------------
| Base64
|--------------------------------------------------------------------------
*/

function bytesToBase64(bytes) {
    let binary = '';

    for (
        let index = 0;
        index < bytes.length;
        index++
    ) {
        binary +=
            String.fromCharCode(
                bytes[index]
            );
    }

    return btoa(binary);
}


/*
|--------------------------------------------------------------------------
| Generate conversation key
|--------------------------------------------------------------------------
|
| Creates a random 256-bit key for AES-GCM.
|
| This raw key exists only in browser memory.
|
*/

export function generateConversationKey() {
    return crypto.getRandomValues(
        new Uint8Array(
            CONVERSATION_KEY_LENGTH
        )
    );
}


/*
|--------------------------------------------------------------------------
| Validate public key
|--------------------------------------------------------------------------
*/

export async function readMessagingPublicKey(
    armoredPublicKey,
    expectedFingerprint
) {
    if (
        typeof armoredPublicKey !== 'string'
        || armoredPublicKey === ''
    ) {
        throw new Error(
            'Messaging public key is missing.'
        );
    }

    if (
        typeof expectedFingerprint !== 'string'
        || expectedFingerprint === ''
    ) {
        throw new Error(
            'Messaging public-key fingerprint is missing.'
        );
    }

    let publicKey;

    try {
        publicKey =
            await openpgp.readKey({
                armoredKey:
                    armoredPublicKey
            });
    } catch (error) {
        throw new Error(
            'Messaging public key is invalid.'
        );
    }

    const derivedFingerprint =
        publicKey
            .getFingerprint()
            .toLowerCase();

    const storedFingerprint =
        expectedFingerprint
            .trim()
            .toLowerCase();

    if (
        derivedFingerprint
        !== storedFingerprint
    ) {
        throw new Error(
            'Messaging public-key fingerprint does not match.'
        );
    }

    return publicKey;
}


/*
|--------------------------------------------------------------------------
| Wrap conversation key
|--------------------------------------------------------------------------
|
| The raw AES conversation key is placed in a versioned payload and then
| encrypted to ONE member's OpenPGP public key.
|
| The returned armored message is safe to store on the server.
|
*/

export async function wrapConversationKey(
    conversationKey,
    armoredPublicKey,
    expectedFingerprint,
    keyVersion = 1
) {
    if (
        !(conversationKey instanceof Uint8Array)
        || conversationKey.length !==
            CONVERSATION_KEY_LENGTH
    ) {
        throw new Error(
            'Invalid conversation key.'
        );
    }

    if (
        !Number.isInteger(keyVersion)
        || keyVersion < 1
    ) {
        throw new Error(
            'Invalid conversation key version.'
        );
    }

    const publicKey =
        await readMessagingPublicKey(
            armoredPublicKey,
            expectedFingerprint
        );

    const payload = {
        format:
            CONVERSATION_KEY_FORMAT,

        version:
            CONVERSATION_KEY_FORMAT_VERSION,

        keyVersion:
            keyVersion,

        key:
            bytesToBase64(
                conversationKey
            )
    };

    const message =
        await openpgp.createMessage({
            text:
                JSON.stringify(payload)
        });

    const encrypted =
        await openpgp.encrypt({
            message:
                message,

            encryptionKeys:
                publicKey,

            format:
                'armored'
        });

    if (
        typeof encrypted !== 'string'
        || !encrypted.includes(
            '-----BEGIN PGP MESSAGE-----'
        )
    ) {
        throw new Error(
            'Could not encrypt conversation key.'
        );
    }

    return encrypted;
}


/*
|--------------------------------------------------------------------------
| Wrap key for conversation members
|--------------------------------------------------------------------------
|
| Every member receives their own OpenPGP-encrypted copy of the SAME
| conversation AES key.
|
| Example input:
|
| [
|     {
|         user_id: 1,
|         public_key: '-----BEGIN PGP PUBLIC KEY BLOCK-----...',
|         fingerprint: '...'
|     }
| ]
|
*/

export async function createConversationKeyEnvelopes(
    publicKeys,
    keyVersion = 1
) {
    if (
        !Array.isArray(publicKeys)
        || publicKeys.length === 0
    ) {
        throw new Error(
            'Conversation members have no public keys.'
        );
    }

    const conversationKey =
        generateConversationKey();

    const envelopes = [];

    const seenUserIds =
        new Set();

    for (const entry of publicKeys) {
        const userId =
            Number(entry?.user_id);

        if (
            !Number.isInteger(userId)
            || userId <= 0
        ) {
            throw new Error(
                'Invalid conversation member.'
            );
        }

        if (seenUserIds.has(userId)) {
            throw new Error(
                'Duplicate conversation member.'
            );
        }

        seenUserIds.add(userId);

        const encryptedKey =
            await wrapConversationKey(
                conversationKey,
                entry.public_key,
                entry.fingerprint,
                keyVersion
            );

        envelopes.push({
            user_id:
                userId,

            key_version:
                keyVersion,

            encrypted_key:
                encryptedKey
        });
    }

    return {
        conversationKey:
            conversationKey,

        keyVersion:
            keyVersion,

        envelopes:
            envelopes
    };
}

/*
|--------------------------------------------------------------------------
| Base64 to bytes
|--------------------------------------------------------------------------
*/

function base64ToBytes(base64) {
    if (
        typeof base64 !== 'string'
        || base64 === ''
    ) {
        throw new Error(
            'Invalid conversation key encoding.'
        );
    }

    let binary;

    try {
        binary = atob(base64);
    } catch (error) {
        throw new Error(
            'Invalid conversation key encoding.'
        );
    }

    const bytes =
        new Uint8Array(
            binary.length
        );

    for (
        let index = 0;
        index < binary.length;
        index++
    ) {
        bytes[index] =
            binary.charCodeAt(index);
    }

    return bytes;
}


/*
|--------------------------------------------------------------------------
| Unwrap conversation key
|--------------------------------------------------------------------------
|
| Decrypts the current user's OpenPGP-encrypted conversation-key envelope.
|
| The OpenPGP private key is supplied from the locally decrypted Key Vault.
| It must never be sent to PHP.
|
*/

export async function unwrapConversationKey(
    encryptedKey,
    armoredPrivateKey,
    expectedKeyVersion
) {
    if (
        typeof encryptedKey !== 'string'
        || encryptedKey === ''
        || !encryptedKey.includes(
            '-----BEGIN PGP MESSAGE-----'
        )
    ) {
        throw new Error(
            'Encrypted conversation key is invalid.'
        );
    }

    if (
        typeof armoredPrivateKey !== 'string'
        || armoredPrivateKey === ''
        || !armoredPrivateKey.includes(
            '-----BEGIN PGP PRIVATE KEY BLOCK-----'
        )
    ) {
        throw new Error(
            'OpenPGP private key is unavailable.'
        );
    }

    if (
        !Number.isInteger(
            expectedKeyVersion
        )
        || expectedKeyVersion < 1
    ) {
        throw new Error(
            'Invalid conversation key version.'
        );
    }

    let privateKey;

    try {
        privateKey =
            await openpgp.readPrivateKey({
                armoredKey:
                    armoredPrivateKey
            });
    } catch (error) {
        throw new Error(
            'OpenPGP private key is invalid.'
        );
    }

    let message;

    try {
        message =
            await openpgp.readMessage({
                armoredMessage:
                    encryptedKey
            });
    } catch (error) {
        throw new Error(
            'Encrypted conversation key is invalid.'
        );
    }

    let decrypted;

    try {
        decrypted =
            await openpgp.decrypt({
                message:
                    message,

                decryptionKeys:
                    privateKey,

                format:
                    'utf8'
            });
    } catch (error) {
        throw new Error(
            'Could not decrypt conversation key.'
        );
    }

    if (
        !decrypted
        || typeof decrypted.data !==
            'string'
    ) {
        throw new Error(
            'Invalid decrypted conversation key.'
        );
    }

    let payload;

    try {
        payload =
            JSON.parse(
                decrypted.data
            );
    } catch (error) {
        throw new Error(
            'Invalid conversation-key payload.'
        );
    }

    if (
        !payload
        || payload.format !==
            CONVERSATION_KEY_FORMAT
        || payload.version !==
            CONVERSATION_KEY_FORMAT_VERSION
        || payload.keyVersion !==
            expectedKeyVersion
        || typeof payload.key !==
            'string'
    ) {
        throw new Error(
            'Unsupported conversation-key payload.'
        );
    }

    const conversationKey =
        base64ToBytes(
            payload.key
        );

    if (
        conversationKey.length !==
        CONVERSATION_KEY_LENGTH
    ) {
        conversationKey.fill(0);

        throw new Error(
            'Invalid conversation key length.'
        );
    }

    return conversationKey;
}

/*
|--------------------------------------------------------------------------
| Message encryption
|--------------------------------------------------------------------------
|
| Encrypts plaintext using the conversation's random 256-bit AES key.
|
| Plaintext and the raw conversation key never leave the browser.
|
*/

export async function encryptMessage(
    plaintext,
    conversationKey
) {
    if (
        typeof plaintext !== 'string'
        || plaintext.trim() === ''
    ) {
        throw new Error(
            'Message cannot be empty.'
        );
    }

    if (
        !(conversationKey instanceof Uint8Array)
        || conversationKey.length !==
            CONVERSATION_KEY_LENGTH
    ) {
        throw new Error(
            'Conversation encryption key is invalid.'
        );
    }

    /*
     * Every message gets a fresh random
     * 96-bit IV.
     */

    const iv =
        crypto.getRandomValues(
            new Uint8Array(12)
        );

    /*
     * Import the raw 256-bit conversation key
     * into Web Crypto.
     */

    const cryptoKey =
        await crypto.subtle.importKey(
            'raw',

            conversationKey,

            {
                name: 'AES-GCM'
            },

            false,

            [
                'encrypt'
            ]
        );

    /*
     * AES-GCM performs authenticated encryption.
     *
     * Web Crypto includes the authentication tag
     * in the returned ciphertext.
     */

    const encrypted =
        await crypto.subtle.encrypt(
            {
                name:
                    'AES-GCM',

                iv:
                    iv,

                tagLength:
                    128
            },

            cryptoKey,

            new TextEncoder().encode(
                plaintext
            )
        );

    return {
        ciphertext:
            bytesToBase64(
                new Uint8Array(
                    encrypted
                )
            ),

        iv:
            bytesToBase64(
                iv
            )
    };
}


/*
|--------------------------------------------------------------------------
| Message decryption
|--------------------------------------------------------------------------
*/

export async function decryptMessage(
    ciphertext,
    iv,
    conversationKey
) {
    if (
        typeof ciphertext !== 'string'
        || ciphertext === ''
        || typeof iv !== 'string'
        || iv === ''
    ) {
        throw new Error(
            'Encrypted message is invalid.'
        );
    }

    if (
        !(conversationKey instanceof Uint8Array)
        || conversationKey.length !==
            CONVERSATION_KEY_LENGTH
    ) {
        throw new Error(
            'Conversation encryption key is invalid.'
        );
    }

    const ciphertextBytes =
        base64ToBytes(
            ciphertext
        );

    const ivBytes =
        base64ToBytes(
            iv
        );

    if (ivBytes.length !== 12) {
        throw new Error(
            'Encrypted message IV is invalid.'
        );
    }

    const cryptoKey =
        await crypto.subtle.importKey(
            'raw',

            conversationKey,

            {
                name: 'AES-GCM'
            },

            false,

            [
                'decrypt'
            ]
        );

    let decrypted;

    try {
        decrypted =
            await crypto.subtle.decrypt(
                {
                    name:
                        'AES-GCM',

                    iv:
                        ivBytes,

                    tagLength:
                        128
                },

                cryptoKey,

                ciphertextBytes
            );
    } catch (error) {
        throw new Error(
            'Message authentication or decryption failed.'
        );
    }

    try {
        return new TextDecoder(
            'utf-8',
            {
                fatal: true
            }
        ).decode(
            decrypted
        );
    } catch (error) {
        throw new Error(
            'Decrypted message contains invalid text.'
        );
    }
}