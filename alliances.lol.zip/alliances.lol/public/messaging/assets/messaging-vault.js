'use strict';

/*
|--------------------------------------------------------------------------
| Alliances Messaging - Key Vault access
|--------------------------------------------------------------------------
|
| This module downloads the user's encrypted Key Vault and decrypts it
| locally in the browser.
|
| The Key Vault password and decrypted vault are NEVER sent to PHP.
|
*/

const KEY_VAULT_FORMAT =
    'alliances-key-vault';

const KEY_VAULT_DATA_FORMAT =
    'alliances-key-vault-data';

const KEY_VAULT_VERSION = 1;

const PBKDF2_ITERATIONS = 600000;

const SALT_LENGTH = 16;

const IV_LENGTH = 12;

const GCM_TAG_LENGTH = 128;

/*
|--------------------------------------------------------------------------
| Workday Key Vault session
|--------------------------------------------------------------------------
|
| These names must match key-vault.js.
|
| Messaging can use the already-unlocked Key Vault without asking
| for the Key Vault password again.
|
*/

const VAULT_SESSION_DATA_KEY =
    'alliances.key-vault.session-data';

const VAULT_SESSION_KEY_KEY =
    'alliances.key-vault.session-key';

const VAULT_SESSION_EXPIRES_KEY =
    'alliances.key-vault.expires-at';

const VAULT_SESSION_USER_KEY =
    'alliances.key-vault.user-id';

const VAULT_SESSION_DURATION =
    8 * 60 * 60 * 1000;

const userIdElement =
    document.querySelector(
        'meta[name="alliances-user-id"]'
    );

const currentUserId =
    userIdElement?.getAttribute(
        'content'
    ) ?? '';

const textEncoder =
    new TextEncoder();

const textDecoder =
    new TextDecoder();


/*
|--------------------------------------------------------------------------
| Base64
|--------------------------------------------------------------------------
*/

function base64ToBytes(base64) {
    if (
        typeof base64 !== 'string'
        || base64 === ''
    ) {
        throw new Error(
            'Invalid Key Vault encoding.'
        );
    }

    let binary;

    try {
        binary =
            atob(base64);
    } catch (error) {
        throw new Error(
            'Invalid Key Vault encoding.'
        );
    }

    const bytes =
        new Uint8Array(
            binary.length
        );

    for (
        let index = 0;
        index < binary.length;
        index++
    ) {
        bytes[index] =
            binary.charCodeAt(index);
    }

    return bytes;
}

function bytesToBase64(bytes) {
    let binary = '';

    for (
        let index = 0;
        index < bytes.length;
        index++
    ) {
        binary += String.fromCharCode(
            bytes[index]
        );
    }

    return btoa(binary);
}

function clearUnlockedVaultSession() {
    localStorage.removeItem(
        VAULT_SESSION_DATA_KEY
    );

    localStorage.removeItem(
        VAULT_SESSION_KEY_KEY
    );

    localStorage.removeItem(
        VAULT_SESSION_EXPIRES_KEY
    );

    localStorage.removeItem(
        VAULT_SESSION_USER_KEY
    );
}

async function saveUnlockedVaultSession(
    vaultData
) {
    const sessionKeyBytes =
        crypto.getRandomValues(
            new Uint8Array(32)
        );

    const iv =
        crypto.getRandomValues(
            new Uint8Array(IV_LENGTH)
        );

    try {
        const sessionKey =
            await crypto.subtle.importKey(
                'raw',

                sessionKeyBytes,

                {
                    name: 'AES-GCM'
                },

                false,

                [
                    'encrypt'
                ]
            );

        const plaintext =
            textEncoder.encode(
                JSON.stringify(
                    vaultData
                )
            );

        const encrypted =
            await crypto.subtle.encrypt(
                {
                    name: 'AES-GCM',
                    iv: iv,
                    tagLength: GCM_TAG_LENGTH
                },

                sessionKey,

                plaintext
            );

        const sessionData = {
            version: 1,

            iv:
                bytesToBase64(iv),

            ciphertext:
                bytesToBase64(
                    new Uint8Array(
                        encrypted
                    )
                )
        };

        const expiresAt =
            Date.now()
            + VAULT_SESSION_DURATION;

        localStorage.setItem(
            VAULT_SESSION_DATA_KEY,
            JSON.stringify(
                sessionData
            )
        );

        localStorage.setItem(
            VAULT_SESSION_KEY_KEY,
            bytesToBase64(
                sessionKeyBytes
            )
        );

        localStorage.setItem(
            VAULT_SESSION_EXPIRES_KEY,
            String(expiresAt)
        );

        localStorage.setItem(
    VAULT_SESSION_USER_KEY,
    currentUserId
);
    } finally {
        sessionKeyBytes.fill(0);
    }
}

/*
|--------------------------------------------------------------------------
| Restore workday Key Vault session
|--------------------------------------------------------------------------
*/

async function loadUnlockedVaultSession() {
    let sessionDataText;
    let sessionKeyText;
    let expiresAt;
    let sessionUserId;

    try {
        sessionDataText =
            localStorage.getItem(
                VAULT_SESSION_DATA_KEY
            );

        sessionKeyText =
            localStorage.getItem(
                VAULT_SESSION_KEY_KEY
            );

        expiresAt =
            Number(
                localStorage.getItem(
                    VAULT_SESSION_EXPIRES_KEY
                )
            );
            sessionUserId =
    localStorage.getItem(
        VAULT_SESSION_USER_KEY
    );
    } catch (error) {
        return null;
    }

    /*
     * No complete active session exists.
     */
    /*
 * The workday Key Vault session may only
 * be restored by the Alliances account
 * that originally created it.
 *
 * Missing ownership information also
 * invalidates legacy sessions.
 */
if (
    currentUserId === ''
    || sessionUserId !== currentUserId
) {
    clearUnlockedVaultSession();

    return null;
}

if (
    typeof sessionDataText !== 'string'
    || sessionDataText === ''
    || typeof sessionKeyText !== 'string'
    || sessionKeyText === ''
    || !Number.isFinite(expiresAt)
    || expiresAt <= Date.now()
) {
    clearUnlockedVaultSession();

    return null;
}

    let sessionData;
    let sessionKeyBytes;
    let iv;
    let ciphertext;

    try {
        sessionData =
            JSON.parse(
                sessionDataText
            );

        if (
            !sessionData
            || sessionData.version !== 1
            || typeof sessionData.iv !== 'string'
            || typeof sessionData.ciphertext !== 'string'
        ) {
            return null;
        }

        sessionKeyBytes =
            base64ToBytes(
                sessionKeyText
            );

        iv =
            base64ToBytes(
                sessionData.iv
            );

        ciphertext =
            base64ToBytes(
                sessionData.ciphertext
            );

        if (
            sessionKeyBytes.length !== 32
            || iv.length !== IV_LENGTH
        ) {
            return null;
        }

        const sessionKey =
            await crypto.subtle.importKey(
                'raw',

                sessionKeyBytes,

                {
                    name: 'AES-GCM'
                },

                false,

                [
                    'decrypt'
                ]
            );

        const decrypted =
            await crypto.subtle.decrypt(
                {
                    name: 'AES-GCM',
                    iv: iv,
                    tagLength: GCM_TAG_LENGTH
                },

                sessionKey,

                ciphertext
            );

        const vaultData =
            JSON.parse(
                textDecoder.decode(
                    decrypted
                )
            );

        if (
            !vaultData
            || vaultData.format !==
                KEY_VAULT_DATA_FORMAT
            || vaultData.version !==
                KEY_VAULT_VERSION
        ) {
            return null;
        }

        return vaultData;
    } catch (error) {
        console.warn(
            'Could not restore the unlocked Key Vault session.',
            error
        );

        return null;
    } finally {
        /*
         * Remove our temporary copy of the raw
         * session AES key from this Uint8Array.
         */
        if (
            sessionKeyBytes
            instanceof Uint8Array
        ) {
            sessionKeyBytes.fill(0);
        }
    }
}

/*
|--------------------------------------------------------------------------
| Password key
|--------------------------------------------------------------------------
*/

async function importPassword(
    password
) {
    return crypto.subtle.importKey(
        'raw',

        textEncoder.encode(
            password
        ),

        {
            name: 'PBKDF2'
        },

        false,

        [
            'deriveKey'
        ]
    );
}


/*
|--------------------------------------------------------------------------
| Derive Key Vault encryption key
|--------------------------------------------------------------------------
*/

async function deriveVaultKey(
    password,
    salt,
    iterations
) {
    const passwordKey =
        await importPassword(
            password
        );

    return crypto.subtle.deriveKey(
        {
            name: 'PBKDF2',

            salt:
                salt,

            iterations:
                iterations,

            hash:
                'SHA-256'
        },

        passwordKey,

        {
            name: 'AES-GCM',
            length: 256
        },

        false,

        [
            'decrypt'
        ]
    );
}


/*
|--------------------------------------------------------------------------
| Download encrypted Key Vault
|--------------------------------------------------------------------------
*/

async function downloadEncryptedVault() {
    const response =
        await fetch(
            '/actions/key-vault/load.php',
            {
                method: 'GET',

                credentials:
                    'same-origin',

                cache:
                    'no-store',

                headers: {
                    Accept:
                        'application/json'
                }
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid response while loading Key Vault.'
        );
    }

    if (!response.ok) {
        throw new Error(
            result?.error
            || 'Could not load Key Vault.'
        );
    }

    if (
        !result.exists
        || !result.vault
    ) {
        throw new Error(
            'Key Vault does not exist.'
        );
    }

    return result.vault;
}


/*
|--------------------------------------------------------------------------
| Decrypt Key Vault
|--------------------------------------------------------------------------
|
| This intentionally matches the Key Vault format used by key-vault.js.
|
*/

async function decryptVault(
    envelope,
    password
) {
    if (
        typeof password !== 'string'
        || password === ''
    ) {
        throw new Error(
            'Enter your Key Vault password.'
        );
    }

    if (
        !envelope
        || envelope.format !==
            KEY_VAULT_FORMAT
        || envelope.version !==
            KEY_VAULT_VERSION
    ) {
        throw new Error(
            'Unsupported Key Vault format.'
        );
    }

    if (
        !envelope.kdf
        || envelope.kdf.algorithm !==
            'PBKDF2'
        || envelope.kdf.hash !==
            'SHA-256'
        || envelope.kdf.iterations !==
            PBKDF2_ITERATIONS
    ) {
        throw new Error(
            'Unsupported Key Vault KDF.'
        );
    }

    if (
        !envelope.encryption
        || envelope.encryption.algorithm !==
            'AES-GCM'
        || envelope.encryption.keyLength !==
            256
    ) {
        throw new Error(
            'Unsupported Key Vault encryption.'
        );
    }

    let salt;
    let iv;
    let ciphertext;

    try {
        salt =
            base64ToBytes(
                envelope.kdf.salt
            );

        iv =
            base64ToBytes(
                envelope.encryption.iv
            );

        ciphertext =
            base64ToBytes(
                envelope.encryption.ciphertext
            );
    } catch (error) {
        throw new Error(
            'Invalid Key Vault encoding.'
        );
    }

    if (
        salt.length !==
        SALT_LENGTH
    ) {
        throw new Error(
            'Invalid Key Vault salt.'
        );
    }

    if (
        iv.length !==
        IV_LENGTH
    ) {
        throw new Error(
            'Invalid Key Vault IV.'
        );
    }

    const vaultKey =
        await deriveVaultKey(
            password,
            salt,
            envelope.kdf.iterations
        );

    let decrypted;

    try {
        decrypted =
            await crypto.subtle.decrypt(
                {
                    name:
                        'AES-GCM',

                    iv:
                        iv,

                    tagLength:
                        envelope
                            .encryption
                            .tagLength
                        ?? GCM_TAG_LENGTH
                },

                vaultKey,

                ciphertext
            );
    } catch (error) {
        throw new Error(
            'Incorrect Key Vault password or corrupted Key Vault.'
        );
    }

    let vaultData;

    try {
        vaultData =
            JSON.parse(
                textDecoder.decode(
                    decrypted
                )
            );
    } catch (error) {
        throw new Error(
            'Invalid Key Vault contents.'
        );
    }

    if (
        !vaultData
        || vaultData.format !==
            KEY_VAULT_DATA_FORMAT
        || vaultData.version !==
            KEY_VAULT_VERSION
    ) {
        throw new Error(
            'Unsupported Key Vault data.'
        );
    }

    return vaultData;
}


/*
|--------------------------------------------------------------------------
| Load OpenPGP private key
|--------------------------------------------------------------------------
|
| This is the ONLY exported operation.
|
| Password:
| - remains in the caller/browser
| - is never sent to PHP
|
| Private key:
| - comes from the locally decrypted vault
| - is returned only to browser-side Messaging code
|
*/

export async function loadMessagingPrivateKey(
    password = null
) {
    let vaultData = null;

    try {
        /*
         * First try the active 8-hour Key Vault
         * workday session.
         */
        vaultData =
            await loadUnlockedVaultSession();

        /*
         * If the Key Vault is not already unlocked,
         * fall back to the normal password-based
         * decryption.
         */
        if (!vaultData) {
            if (
                typeof password !== 'string'
                || password === ''
            ) {
                throw new Error(
                    'KEY_VAULT_PASSWORD_REQUIRED'
                );
            }

            const envelope =
                await downloadEncryptedVault();

            vaultData =
                await decryptVault(
                    envelope,
                    password
                );

                /*
 * The user successfully unlocked the real
 * Key Vault from Messaging.
 *
 * Create/refresh the same 8-hour workday
 * session used by the Key Vault page.
 */
await saveUnlockedVaultSession(
    vaultData
);
        }

        const identity =
            vaultData
                ?.identity
                ?.openpgp;

        if (
            !identity
            || typeof identity.privateKey !==
                'string'
            || identity.privateKey === ''
        ) {
            throw new Error(
                'Your Key Vault does not contain an OpenPGP identity.'
            );
        }

        if (
            !identity.privateKey.includes(
                '-----BEGIN PGP PRIVATE KEY BLOCK-----'
            )
        ) {
            throw new Error(
                'Your OpenPGP private key is invalid.'
            );
        }

        return identity.privateKey;
    } finally {
        /*
         * Release our reference to the complete
         * decrypted vault as soon as possible.
         */
        vaultData = null;
    }
}