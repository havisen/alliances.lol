'use strict';

import {
    createConversationKeyEnvelopes,
    unwrapConversationKey,
    encryptMessage,
    decryptMessage
} from './messaging-crypto.js';

import {
    loadMessagingPrivateKey
} from './messaging-vault.js';

/*
|--------------------------------------------------------------------------
| Page security data
|--------------------------------------------------------------------------
*/

const csrfToken =
    document
        .querySelector(
            'meta[name="csrf-token"]'
        )
        ?.getAttribute(
            'content'
        )
        ?? '';

if (csrfToken === '') {
    console.error(
        'Messaging CSRF token is unavailable.'
    );
}

/*
|--------------------------------------------------------------------------
| Elements
|--------------------------------------------------------------------------
*/

const newButton =
    document.getElementById(
        'messaging-new-conversation'
    );

const backdrop =
    document.getElementById(
        'messaging-new-backdrop'
    );

const closeButton =
    document.getElementById(
        'messaging-new-close'
    );

const cancelButton =
    document.getElementById(
        'messaging-new-cancel'
    );

const form =
    document.getElementById(
        'messaging-new-form'
    );

const typeInput =
    document.getElementById(
        'messaging-conversation-type'
    );

const nameInput =
    document.getElementById(
        'messaging-conversation-name'
    );

const descriptionInput =
    document.getElementById(
        'messaging-conversation-description'
    );

    const nameField =
    document.getElementById(
        'messaging-name-field'
    );

const descriptionField =
    document.getElementById(
        'messaging-description-field'
    );

const membersLabel =
    document.getElementById(
        'messaging-members-label'
    );

const memberList =
    document.getElementById(
        'messaging-member-list'
    );

const memberStatus =
    document.getElementById(
        'messaging-member-status'
    );

const memberCount =
    document.getElementById(
        'messaging-member-count'
    );

const formMessage =
    document.getElementById(
        'messaging-form-message'
    );

const createButton =
    document.getElementById(
        'messaging-create-conversation'
    );

const csrfMeta =
    document.querySelector(
        'meta[name="csrf-token"]'
    );

const currentUserMeta =
    document.querySelector(
        'meta[name="alliances-user-id"]'
    );

    /*
|--------------------------------------------------------------------------
| Conversation unlock elements
|--------------------------------------------------------------------------
*/

const vaultBackdrop =
    document.getElementById(
        'messaging-vault-backdrop'
    );

const vaultCloseButton =
    document.getElementById(
        'messaging-vault-close'
    );

const vaultCancelButton =
    document.getElementById(
        'messaging-vault-cancel'
    );

const vaultForm =
    document.getElementById(
        'messaging-vault-form'
    );

const vaultPasswordInput =
    document.getElementById(
        'messaging-vault-password'
    );

const vaultMessage =
    document.getElementById(
        'messaging-vault-message'
    );

const vaultUnlockButton =
    document.getElementById(
        'messaging-vault-unlock'
    );

/*
|--------------------------------------------------------------------------
| Conversation view elements
|--------------------------------------------------------------------------
*/

const emptyState =
    document.getElementById(
        'messaging-empty-state'
    );

const activeConversation =
    document.getElementById(
        'messaging-active-conversation'
    );

const activeConversationAvatar =
    document.getElementById(
        'messaging-active-avatar'
    );

const activeConversationName =
    document.getElementById(
        'messaging-active-name'
    );

const activeConversationDetails =
    document.getElementById(
        'messaging-active-details'
    );

const activeConversationDescription =
    document.getElementById(
        'messaging-active-description'
    );

const messageArea =
    document.getElementById(
        'messaging-message-area'
    );

const messageEmpty =
    document.getElementById(
        'messaging-message-empty'
    );

const messageComposer =
    document.getElementById(
        'messaging-composer'
    );

const adminOnlyNotice =
    document.getElementById(
        'messaging-composer-notice'
    );

const messageInput =
    document.getElementById(
        'messaging-message-input'
    );

const sendButton =
    document.getElementById(
        'messaging-send-button'
    );

/*
|--------------------------------------------------------------------------
| Conversation members elements
|--------------------------------------------------------------------------
*/

const manageMembersButton =
    document.getElementById(
        'messaging-manage-members'
    );

const membersBackdrop =
    document.getElementById(
        'messaging-members-backdrop'
    );

const membersCloseButton =
    document.getElementById(
        'messaging-members-close'
    );

const membersDoneButton =
    document.getElementById(
        'messaging-members-done'
    );

const activeMemberList =
    document.getElementById(
        'messaging-active-member-list'
    );

const membersMessage =
    document.getElementById(
        'messaging-members-message'
    );

const addMemberSection =
    document.getElementById(
        'messaging-add-member-section'
    );

const addMemberSelect =
    document.getElementById(
        'messaging-add-member-select'
    );

const addMemberButton =
    document.getElementById(
        'messaging-add-member-button'
    );

const leaveConversationButton =
    document.getElementById(
        'messaging-leave-conversation'
    );

const deleteConversationButton =
    document.getElementById(
        'messaging-delete-conversation'
    );

/*
|--------------------------------------------------------------------------
| State
|--------------------------------------------------------------------------
*/

let workspaceMembers = [];

let membersLoaded = false;

let loadingMembers = false;

/*
|--------------------------------------------------------------------------
| Encrypted conversation state
|--------------------------------------------------------------------------
|
| The raw AES conversation key exists only in memory.
|
*/

let pendingConversationId = null;

let activeConversationId = null;

/*
 * Metadata for the currently unlocked
 * conversation.
 *
 * This includes the member list and the
 * current user's conversation role.
 */
let activeConversationData = null;

/*
 * All decrypted AES keys available to the
 * current user for the active conversation.
 *
 * Map:
 * key_version => Uint8Array
 *
 * These keys exist only in JavaScript memory.
 */
let activeConversationKeys =
    new Map();

let activeConversationKey = null;

let activeConversationKeyVersion = null;

/*
|--------------------------------------------------------------------------
| Automatic message refresh
|--------------------------------------------------------------------------
*/

const MESSAGE_POLL_INTERVAL = 3000;

let messagePollTimer = null;
let messagePollInFlight = false;
let lastMessageSnapshot = null;

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function getCsrfToken() {
    const token =
        csrfMeta?.getAttribute(
            'content'
        );

    if (!token) {
        throw new Error(
            'CSRF token is unavailable.'
        );
    }

    return token;
}


function getCurrentUserId() {
    const value =
        Number(
            currentUserMeta?.getAttribute(
                'content'
            )
        );

    if (
        !Number.isInteger(value)
        || value <= 0
    ) {
        throw new Error(
            'Current user is unavailable.'
        );
    }

    return value;
}

function renderAvatarInto(
    element,
    avatarPath,
    fallbackText
) {
    if (!element) {
        return;
    }

    element.replaceChildren();

    const path =
        typeof avatarPath === 'string'
            ? avatarPath.trim()
            : '';

    if (path !== '') {
        const image =
            document.createElement('img');

        image.className =
            'messaging-avatar-image';

        image.src =
            path;

        image.alt =
            '';

        element.appendChild(
            image
        );

        return;
    }

    const label =
        typeof fallbackText === 'string'
            ? fallbackText.trim()
            : '';

    element.textContent =
        label !== ''
            ? label.charAt(0).toUpperCase()
            : '?';
}

function isActiveConversationChannelReadOnly() {
    return (
        activeConversationData?.type === 'channel'
        && activeConversationData.is_workspace_admin
            !== true
    );
}

function updateComposerState() {
    const readOnly =
        isActiveConversationChannelReadOnly();

    if (adminOnlyNotice) {
        adminOnlyNotice.hidden =
            !readOnly;
    }

    if (messageComposer) {
        messageComposer.hidden =
            readOnly;
    }

    if (readOnly) {
        return;
    }

    const unlocked =
        activeConversationId !== null
        && activeConversationKeys.size > 0
        && activeConversationKey
            instanceof Uint8Array
        && Number.isInteger(
            activeConversationKeyVersion
        )
        && activeConversationKeyVersion > 0;

    if (messageInput) {
        messageInput.disabled =
            !unlocked;
    }

    if (sendButton) {
        sendButton.disabled =
            !unlocked;
    }
}

/*
|--------------------------------------------------------------------------
| Conversation members dialog
|--------------------------------------------------------------------------
*/

function setMembersMessage(
    message,
    type = ''
) {
    if (!membersMessage) {
        return;
    }

    membersMessage.textContent =
        message;

    membersMessage.dataset.type =
        type;
}


function closeMembersDialog() {
    if (!membersBackdrop) {
        return;
    }

    membersBackdrop.hidden = true;

    setMembersMessage('');

    document.body.classList.remove(
        'messaging-modal-open'
    );
}


function canRemoveConversationMember(
    member
) {
    if (
        !activeConversationData
        || activeConversationData.type
            === 'direct'
    ) {
        return false;
    }

    const currentUserId =
        getCurrentUserId();

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    const memberUserId =
        Number(
            member?.user_id
        );

    const memberRole =
        String(
            member?.role
            ?? ''
        );

    /*
     * This endpoint deliberately does not
     * implement leaving the conversation.
     */
    if (
        memberUserId === currentUserId
    ) {
        return false;
    }

    /*
     * Nobody can remove the owner.
     */
    if (memberRole === 'owner') {
        return false;
    }

    /*
     * Owner can remove admins and members.
     */
    if (currentUserRole === 'owner') {
        return true;
    }

    /*
     * Admin can remove ordinary members,
     * but not another admin.
     */
    if (
        currentUserRole === 'admin'
        && memberRole === 'member'
    ) {
        return true;
    }

    return false;
}


function renderActiveMembers() {
    if (!activeMemberList) {
        return;
    }

    activeMemberList.replaceChildren();

    if (!activeConversationData) {
        return;
    }

    const members =
        Array.isArray(
            activeConversationData.members
        )
            ? activeConversationData.members
            : [];

    const currentUserId =
        getCurrentUserId();

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    for (const member of members) {
        const userId =
            Number(
                member?.user_id
            );

        if (
            !Number.isInteger(userId)
            || userId <= 0
        ) {
            continue;
        }

        const row =
            document.createElement(
                'div'
            );

        row.className =
            'messaging-member-option';

        const details =
            document.createElement(
                'span'
            );

        details.className =
            'messaging-member-details';

        const name =
            document.createElement(
                'strong'
            );

        const displayName =
            typeof member.display_name
                === 'string'
                ? member.display_name.trim()
                : '';

        name.textContent =
            displayName !== ''
                ? displayName
                : `User ${userId}`;

        const secondary =
            document.createElement(
                'span'
            );

        const memberRole =
            String(
                member.role
                ?? 'member'
            );

        const roleLabel =
            memberRole === 'owner'
                ? 'Owner'
                : memberRole === 'admin'
                    ? 'Admin'
                    : 'Member';

        secondary.textContent =
            userId === currentUserId
                ? `${roleLabel} · You`
                : roleLabel;

        details.append(
            name,
            secondary
        );

        row.appendChild(
            details
        );

        /*
         * Keep member-management buttons together
         * on the right side of the member row.
         */
        const actions =
            document.createElement(
                'div'
            );

        actions.className =
            'messaging-member-actions';

        /*
        |--------------------------------------------------------------------------
        | Promote / demote
        |--------------------------------------------------------------------------
        |
        | Only the conversation owner sees these controls.
        |
        | Owners cannot change their own role.
        | Direct messages do not have role management.
        |
        */

        if (
            activeConversationData.type
                !== 'direct'
            && currentUserRole
                === 'owner'
            && userId
                !== currentUserId
            && (
                memberRole === 'member'
                || memberRole === 'admin'
            )
        ) {
            const roleButton =
                document.createElement(
                    'button'
                );

            roleButton.type =
                'button';

            roleButton.className =
                'messaging-secondary-button';

            roleButton.dataset.roleUserId =
                String(userId);

            const newRole =
                memberRole === 'admin'
                    ? 'member'
                    : 'admin';

            roleButton.textContent =
                memberRole === 'admin'
                    ? 'Demote'
                    : 'Promote';

            roleButton.addEventListener(
                'click',
                async () => {
                    const memberName =
                        displayName !== ''
                            ? displayName
                            : `User ${userId}`;

                    const actionLabel =
                        newRole === 'admin'
                            ? 'promote'
                            : 'demote';

                    const confirmationText =
                        newRole === 'admin'
                            ? `Promote ${memberName} to conversation Admin?\n\n`
                                + 'Admins can add and remove ordinary members.'
                            : `Demote ${memberName} back to Member?\n\n`
                                + 'They will keep access to the conversation but lose admin permissions.';

                    const confirmed =
                        window.confirm(
                            confirmationText
                        );

                    if (!confirmed) {
                        return;
                    }

                    const managementButtons =
                        activeMemberList
                            ?.querySelectorAll(
                                'button'
                            )
                        ?? [];

                    for (
                        const button
                        of managementButtons
                    ) {
                        button.disabled =
                            true;
                    }

                    if (addMemberButton) {
                        addMemberButton.disabled =
                            true;
                    }

                    if (addMemberSelect) {
                        addMemberSelect.disabled =
                            true;
                    }

                    setMembersMessage(
                        newRole === 'admin'
                            ? `Promoting ${memberName} to Admin...`
                            : `Demoting ${memberName} to Member...`
                    );

                    try {
                        await updateConversationMemberRole(
                            userId,
                            newRole
                        );

                        setMembersMessage(
                            newRole === 'admin'
                                ? `${memberName} is now a conversation Admin.`
                                : `${memberName} is now a conversation Member.`,
                            'success'
                        );

                        /*
                         * updateConversationMemberRole()
                         * refreshed activeConversationData
                         * from the server.
                         */
                        renderActiveMembers();

                        showConversation(
                            activeConversationData
                        );

                        await renderAddMemberControls();
                    } catch (error) {
                        console.error(
                            `Could not ${actionLabel} conversation member.`,
                            error
                        );

                        setMembersMessage(
                            error instanceof Error
                                ? error.message
                                : 'Could not change the conversation member role.',
                            'error'
                        );

                        renderActiveMembers();

                        try {
                            await renderAddMemberControls();
                        } catch (
                            refreshError
                        ) {
                            console.error(
                                'Could not refresh member controls.',
                                refreshError
                            );
                        }
                    }
                }
            );

            actions.appendChild(
                roleButton
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Remove member
        |--------------------------------------------------------------------------
        |
        | canRemoveConversationMember() contains the
        | browser-side permission rules.
        |
        | The PHP endpoint independently checks them.
        |
        */

        if (
            canRemoveConversationMember(
                member
            )
        ) {
            const removeButton =
                document.createElement(
                    'button'
                );

            removeButton.type =
                'button';

            removeButton.className =
                'messaging-secondary-button';

            removeButton.textContent =
                'Remove';

            removeButton.dataset.userId =
                String(userId);

            removeButton.addEventListener(
                'click',
                async () => {
                    const memberName =
                        displayName !== ''
                            ? displayName
                            : `User ${userId}`;

                    const confirmed =
                        window.confirm(
                            `Remove ${memberName} from this conversation?\n\n`
                            + 'Their access to future messages will be removed '
                            + 'and the conversation encryption key will be rotated.'
                        );

                    if (!confirmed) {
                        return;
                    }

                    const managementButtons =
                        activeMemberList
                            ?.querySelectorAll(
                                'button'
                            )
                        ?? [];

                    for (
                        const button
                        of managementButtons
                    ) {
                        button.disabled =
                            true;
                    }

                    if (addMemberButton) {
                        addMemberButton.disabled =
                            true;
                    }

                    if (addMemberSelect) {
                        addMemberSelect.disabled =
                            true;
                    }

                    setMembersMessage(
                        `Removing ${memberName} and rotating encryption key...`
                    );

                    try {
                        await removeConversationMember(
                            userId
                        );

                        setMembersMessage(
                            `${memberName} was removed. Encryption key rotated successfully.`,
                            'success'
                        );

                        renderActiveMembers();

                        showConversation(
                            activeConversationData
                        );

                        /*
                         * The removed person should now
                         * become available in the Add
                         * member dropdown again.
                         */
                        await renderAddMemberControls();
                    } catch (error) {
                        console.error(
                            'Conversation member removal failed.',
                            error
                        );

                        setMembersMessage(
                            error instanceof Error
                                ? error.message
                                : 'Could not remove conversation member.',
                            'error'
                        );

                        renderActiveMembers();

                        try {
                            await renderAddMemberControls();
                        } catch (
                            refreshError
                        ) {
                            console.error(
                                'Could not refresh member controls.',
                                refreshError
                            );
                        }
                    }
                }
            );

            actions.appendChild(
                removeButton
            );
        }

        if (
            actions.childElementCount
            > 0
        ) {
            row.appendChild(
                actions
            );
        }

        activeMemberList.appendChild(
            row
        );
    }
}

function renderConversationManagementControls() {
    if (leaveConversationButton) {
        leaveConversationButton.hidden =
            true;

        leaveConversationButton.disabled =
            false;
    }

    if (deleteConversationButton) {
        deleteConversationButton.hidden =
            true;

        deleteConversationButton.disabled =
            false;
    }

    if (!activeConversationData) {
        return;
    }

    const conversationType =
        String(
            activeConversationData.type
            ?? ''
        );

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    /*
     * The Owner permanently deletes the
     * conversation instead of leaving it.
     */
    if (
        currentUserRole === 'owner'
    ) {
        if (deleteConversationButton) {
            deleteConversationButton.hidden =
                false;
        }

        return;
    }

    /*
     * Direct messages currently cannot be
     * left. Only group/channel members and
     * admins receive the Leave button.
     */
    if (
        conversationType !== 'direct'
        && (
            currentUserRole === 'admin'
            || currentUserRole === 'member'
        )
    ) {
        if (leaveConversationButton) {
            leaveConversationButton.hidden =
                false;
        }
    }
}

async function renderAddMemberControls() {
    if (
        !addMemberSection
        || !addMemberSelect
        || !addMemberButton
    ) {
        return;
    }

    /*
     * Start hidden. We only expose this control
     * after checking the active conversation.
     */
    addMemberSection.hidden = true;

    addMemberSelect.replaceChildren();

    const placeholder =
        document.createElement(
            'option'
        );

    placeholder.value = '';

    placeholder.textContent =
        'Select a workspace member';

    addMemberSelect.appendChild(
        placeholder
    );

    if (!activeConversationData) {
        return;
    }

    /*
     * Direct messages always remain two-person
     * conversations.
     */
    if (
        activeConversationData.type
        === 'direct'
    ) {
        return;
    }

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    /*
     * Only owners/admins may add people.
     *
     * PHP independently enforces this again.
     */
    if (
        currentUserRole !== 'owner'
        && currentUserRole !== 'admin'
    ) {
        return;
    }

    /*
     * Make sure we have the current workspace
     * member directory available.
     */
    if (!membersLoaded) {
        await loadWorkspaceMembers();
    }

    if (!membersLoaded) {
        throw new Error(
            'Workspace members could not be loaded.'
        );
    }

    const conversationMembers =
        Array.isArray(
            activeConversationData.members
        )
            ? activeConversationData.members
            : [];

    const existingMemberIds =
        new Set(
            conversationMembers
                .map(
                    (member) =>
                        Number(
                            member?.user_id
                        )
                )
                .filter(
                    (userId) =>
                        Number.isInteger(
                            userId
                        )
                        && userId > 0
                )
        );

    /*
     * Only show workspace users who are not
     * already members of this conversation.
     */
    const availableMembers =
        workspaceMembers.filter(
            (member) => {
                const userId =
                    Number(
                        member?.id
                    );

                return (
                    Number.isInteger(
                        userId
                    )
                    && userId > 0
                    && !existingMemberIds.has(
                        userId
                    )
                );
            }
        );

    for (
        const member
        of availableMembers
    ) {
        const userId =
            Number(member.id);

        const option =
            document.createElement(
                'option'
            );

        option.value =
            String(userId);

        const memberName =
            typeof member.name === 'string'
                ? member.name.trim()
                : '';

        const memberEmail =
            typeof member.email === 'string'
                ? member.email.trim()
                : '';

        if (
            memberName !== ''
            && memberEmail !== ''
        ) {
            option.textContent =
                `${memberName} · ${memberEmail}`;
        } else {
            option.textContent =
                memberName
                || memberEmail
                || `User ${userId}`;
        }

        addMemberSelect.appendChild(
            option
        );
    }

    if (
        availableMembers.length === 0
    ) {
        placeholder.textContent =
            'No workspace members available';

        addMemberSelect.disabled =
            true;

        addMemberButton.disabled =
            true;
    } else {
        addMemberSelect.disabled =
            false;

        addMemberButton.disabled =
            false;
    }

    addMemberSection.hidden = false;
}

async function openMembersDialog() {
    if (
        !membersBackdrop
        || !activeConversationData
    ) {
        return;
    }

setMembersMessage('');

renderActiveMembers();

renderConversationManagementControls();

    /*
     * Show the dialog immediately, then load
     * the available workspace members.
     */
    membersBackdrop.hidden = false;

    document.body.classList.add(
        'messaging-modal-open'
    );

    try {
        await renderAddMemberControls();
    } catch (error) {
        console.error(
            'Could not prepare add-member controls.',
            error
        );

        setMembersMessage(
            error instanceof Error
                ? error.message
                : 'Could not load available workspace members.',
            'error'
        );
    }
}

addMemberButton?.addEventListener(
    'click',
    async () => {
        const userId =
            Number(
                addMemberSelect?.value
            );

        if (
            !Number.isInteger(userId)
            || userId <= 0
        ) {
            setMembersMessage(
                'Select a workspace member to add.',
                'error'
            );

            return;
        }

        const selectedOption =
            addMemberSelect
                ?.selectedOptions?.[0];

        const memberName =
            selectedOption
                ?.textContent
                ?.trim()
            || `User ${userId}`;

        const confirmed =
            window.confirm(
                `Add ${memberName} to this conversation?\n\n`
                + 'A new encryption key will be created. '
                + 'They will only be able to decrypt messages sent after they join.'
            );

        if (!confirmed) {
            return;
        }

        if (addMemberSelect) {
            addMemberSelect.disabled =
                true;
        }

        addMemberButton.disabled =
            true;

        setMembersMessage(
            `Adding ${memberName} and rotating encryption key...`
        );

        try {
            await addConversationMember(
                userId
            );

            setMembersMessage(
                `${memberName} was added. Encryption key rotated successfully.`,
                'success'
            );

            /*
             * activeConversationData was refreshed
             * by addConversationMember().
             */
            renderActiveMembers();

            showConversation(
                activeConversationData
            );

            /*
             * Rebuild the dropdown so the newly
             * added person disappears from the
             * available choices.
             */
            await renderAddMemberControls();
        } catch (error) {
            console.error(
                'Conversation member addition failed.',
                error
            );

            setMembersMessage(
                error instanceof Error
                    ? error.message
                    : 'Could not add conversation member.',
                'error'
            );

            /*
             * Restore the controls after failure.
             */
            try {
                await renderAddMemberControls();
            } catch (refreshError) {
                console.error(
                    'Could not refresh add-member controls.',
                    refreshError
                );
            }
        }
    }
);

leaveConversationButton?.addEventListener(
    'click',
    async () => {
        if (!activeConversationData) {
            return;
        }

        const conversationName =
            typeof activeConversationData.name
                === 'string'
                && activeConversationData.name.trim() !== ''
                ? activeConversationData.name.trim()
                : 'this conversation';

        const confirmed =
            window.confirm(
                `Leave ${conversationName}?\n\n`
                + 'You will lose access to this conversation. '
                + 'A new encryption key will be created for the remaining members.'
            );

        if (!confirmed) {
            return;
        }

        leaveConversationButton.disabled =
            true;

        if (deleteConversationButton) {
            deleteConversationButton.disabled =
                true;
        }

        setMembersMessage(
            'Leaving conversation and rotating encryption key...'
        );

        try {
            await leaveConversation();

            /*
             * Our server membership is now gone.
             *
             * Close this dialog before clearing
             * the active conversation.
             */
            closeMembersDialog();

            /*
             * Destroy all locally held keys for
             * the conversation we just left.
             */
            clearActiveConversationKey();

            /*
             * Reload the page so the server renders
             * a fresh conversation sidebar without
             * the conversation we just left.
             *
             * This also guarantees no stale message
             * DOM or conversation metadata remains.
             */
            window.location.reload();
        } catch (error) {
            console.error(
                'Leave conversation failed.',
                error
            );

            setMembersMessage(
                error instanceof Error
                    ? error.message
                    : 'Could not leave conversation.',
                'error'
            );

            renderConversationManagementControls();
        }
    }
);

deleteConversationButton?.addEventListener(
    'click',
    async () => {
        if (!activeConversationData) {
            return;
        }

        const conversationName =
            typeof activeConversationData.name
                === 'string'
                && activeConversationData.name.trim() !== ''
                ? activeConversationData.name.trim()
                : 'this conversation';

        /*
         * Deletion is intentionally much more
         * explicit than the Leave confirmation.
         *
         * This removes the conversation for every
         * member, not only the current user.
         */
        const confirmed =
            window.confirm(
                `Permanently delete ${conversationName}?\n\n`
                + 'This will delete the conversation for EVERY member, '
                + 'including all encrypted messages and stored conversation-key envelopes.\n\n'
                + 'This cannot be undone.'
            );

        if (!confirmed) {
            return;
        }

        const confirmedAgain =
            window.confirm(
                'Are you sure?\n\n'
                + 'The entire conversation will be permanently deleted for everyone.'
            );

        if (!confirmedAgain) {
            return;
        }

        deleteConversationButton.disabled =
            true;

        if (leaveConversationButton) {
            leaveConversationButton.disabled =
                true;
        }

        setMembersMessage(
            'Permanently deleting conversation...'
        );

        try {
            await deleteConversation();

            closeMembersDialog();

            /*
             * Zero the active conversation keys
             * held by this browser.
             */
            clearActiveConversationKey();

            /*
             * Reload from the server so the deleted
             * conversation disappears from the
             * sidebar and no stale chat state remains.
             */
            window.location.reload();
        } catch (error) {
            console.error(
                'Delete conversation failed.',
                error
            );

            setMembersMessage(
                error instanceof Error
                    ? error.message
                    : 'Could not delete conversation.',
                'error'
            );

            renderConversationManagementControls();
        }
    }
);

function setFormMessage(
    message,
    type = ''
) {
    if (!formMessage) {
        return;
    }

    formMessage.textContent =
        message;

    formMessage.dataset.type =
        type;
}


function setSubmitting(
    submitting
) {
    if (!createButton) {
        return;
    }

    createButton.disabled =
        submitting;

    createButton.textContent =
        submitting
            ? 'Creating...'
            : 'Create conversation';
}

/*
|--------------------------------------------------------------------------
| Conversation unlock dialog
|--------------------------------------------------------------------------
*/

function setVaultMessage(
    message,
    isError = false
) {
    if (!vaultMessage) {
        return;
    }

    vaultMessage.textContent =
        message;

    vaultMessage.classList.toggle(
        'is-error',
        isError
    );
}


function setVaultSubmitting(
    submitting
) {
    if (!vaultUnlockButton) {
        return;
    }

    vaultUnlockButton.disabled =
        submitting;

    vaultUnlockButton.textContent =
        submitting
            ? 'Unlocking...'
            : 'Unlock conversation';
}


function clearActiveConversationKey() {
    stopMessagePolling();

    lastMessageSnapshot = null;

    /*
     * Zero every historical/current AES key
     * before releasing our references.
     */
    for (
        const conversationKey
        of activeConversationKeys.values()
    ) {
        if (
            conversationKey
            instanceof Uint8Array
        ) {
            conversationKey.fill(0);
        }
    }

    activeConversationKeys.clear();

activeConversationKey = null;

activeConversationId = null;

activeConversationData = null;

activeConversationKeyVersion = null;
}


function closeVaultDialog() {
    if (!vaultBackdrop) {
        return;
    }

    vaultBackdrop.hidden = true;

    pendingConversationId = null;

    setVaultMessage('');

    if (vaultPasswordInput) {
        vaultPasswordInput.value = '';
    }

    document.body.classList.remove(
        'messaging-modal-open'
    );
}


function openVaultDialog(
    conversationId
) {
    if (
        !Number.isInteger(conversationId)
        || conversationId <= 0
    ) {
        return;
    }

    if (!vaultBackdrop) {
        return;
    }

    pendingConversationId =
        conversationId;

    setVaultMessage('');

    vaultBackdrop.hidden = false;

    document.body.classList.add(
        'messaging-modal-open'
    );

    vaultPasswordInput?.focus();
}


/*
|--------------------------------------------------------------------------
| Load current user's encrypted conversation-key envelope
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Load conversation metadata
|--------------------------------------------------------------------------
*/

async function loadConversation(
    conversationId
) {
    const parameters =
        new URLSearchParams({
            conversation_id:
                String(conversationId)
        });

    const response =
        await fetch(
            '/actions/messaging/conversation.php?'
            + parameters.toString(),
            {
                method: 'GET',

                credentials:
                    'same-origin',

                cache:
                    'no-store',

                headers: {
                    Accept:
                        'application/json'
                }
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid conversation response.'
        );
    }

    if (
        !response.ok
        || !result.success
        || !result.conversation
    ) {
        throw new Error(
            result?.error
            || 'Could not load conversation.'
        );
    }

    const conversation =
        result.conversation;

    if (
        Number(conversation.id)
        !== conversationId
    ) {
        throw new Error(
            'Conversation response does not match the selected conversation.'
        );
    }

    return conversation;
}


/*
|--------------------------------------------------------------------------
| Show unlocked conversation
|--------------------------------------------------------------------------
*/

function showConversation(
    conversation
) {
    if (
        !conversation
        || !activeConversation
        || !emptyState
    ) {
        return;
    }

    const name =
        typeof conversation.name ===
            'string'
            ? conversation.name.trim()
            : '';

    const description =
        typeof conversation.description ===
            'string'
            ? conversation.description.trim()
            : '';

    const members =
        Array.isArray(
            conversation.members
        )
            ? conversation.members
            : [];

const typeLabel =
    conversation.type === 'channel'
        ? 'Channel'
        : conversation.type === 'direct'
            ? 'Direct message'
            : 'Group chat';

    const memberLabel =
        members.length === 1
            ? '1 member'
            : `${members.length} members`;

    if (activeConversationName) {
        activeConversationName.textContent =
            name !== ''
                ? name
                : 'Conversation';
    }

    if (activeConversationAvatar) {
        if (conversation.type === 'direct') {
            const otherMember =
                members.find(
                    (member) =>
                        Number(member?.user_id)
                        !== getCurrentUserId()
                );

            renderAvatarInto(
                activeConversationAvatar,
                otherMember?.avatar_path ?? null,
                name
            );
        } else {
            renderAvatarInto(
                activeConversationAvatar,
                null,
                name
            );
        }
    }

    if (activeConversationDetails) {
        activeConversationDetails.textContent =
            `${typeLabel} · ${memberLabel}`;
    }

    if (activeConversationDescription) {
        if (description !== '') {
            activeConversationDescription.textContent =
                description;

            activeConversationDescription.hidden =
                false;
        } else {
            activeConversationDescription.textContent =
                '';

            activeConversationDescription.hidden =
                true;
        }
    }

emptyState.hidden = true;

activeConversation.hidden = false;

if (manageMembersButton) {
    manageMembersButton.hidden =
        conversation.type === 'direct';
}

updateComposerState();
}

manageMembersButton?.addEventListener(
    'click',
    openMembersDialog
);


membersCloseButton?.addEventListener(
    'click',
    closeMembersDialog
);


membersDoneButton?.addEventListener(
    'click',
    closeMembersDialog
);


membersBackdrop?.addEventListener(
    'click',
    (event) => {
        if (
            event.target ===
            membersBackdrop
        ) {
            closeMembersDialog();
        }
    }
);

/*
|--------------------------------------------------------------------------
| Encrypted messages
|--------------------------------------------------------------------------
*/

async function loadEncryptedMessages(
    conversationId
) {
    const parameters =
        new URLSearchParams({
            conversation_id:
                String(conversationId)
        });

    const response =
        await fetch(
            '/actions/messaging/messages.php?'
            + parameters.toString(),
            {
                method: 'GET',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: {
                    Accept: 'application/json'
                }
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid messages response.'
        );
    }

    if (
        !response.ok
        || !result.success
        || !Array.isArray(result.messages)
    ) {
        throw new Error(
            result?.error
            || 'Could not load messages.'
        );
    }

    return result.messages;
}


function createMessageElement(
    message,
    plaintext
) {
    const wrapper =
        document.createElement('div');

    wrapper.className =
        'messaging-message';

    if (message.is_current_user) {
        wrapper.classList.add(
            'messaging-message-own'
        );
    }

    const avatar =
        document.createElement('div');

    avatar.className =
        'messaging-message-avatar';

    renderAvatarInto(
        avatar,
        message.sender?.avatar_path ?? null,
        message.is_current_user
            ? 'You'
            : (
                message.sender?.name
                || 'Member'
            )
    );

    const bubble =
        document.createElement('div');

    bubble.className =
        'messaging-message-bubble';

    const header =
        document.createElement('div');

    header.className =
        'messaging-message-header';

    const sender =
        document.createElement('strong');

    sender.textContent =
        message.is_current_user
            ? 'You'
            : (
                message.sender?.name
                || 'Member'
            );

    const time =
        document.createElement('span');

    time.textContent =
        message.created_at
            || '';

    header.append(
        sender,
        time
    );

    const body =
        document.createElement('div');

    body.className =
        'messaging-message-body';

    /*
     * textContent is intentional.
     *
     * Decrypted messages must never be inserted
     * as HTML.
     */

    body.textContent =
        plaintext;

    bubble.append(
        header,
        body
    );

    wrapper.append(
        avatar,
        bubble
    );

    return wrapper;
}


async function renderEncryptedMessages(
    forceScroll = false
) {
    if (
        !activeConversationId
        || !activeConversationKey
        || !messageArea
    ) {
        return;
    }

    const conversationId =
        activeConversationId;

    const messages =
        await loadEncryptedMessages(
            conversationId
        );

    /*
     * The user may have changed conversations
     * while the request was running.
     */
    if (
        activeConversationId
        !== conversationId
    ) {
        return;
    }

    const lastMessage =
        messages.length > 0
            ? messages[
                messages.length - 1
            ]
            : null;

    /*
     * This lets us avoid decrypting and rebuilding
     * the entire message list when the server
     * returned exactly the same set of messages.
     */
    const snapshot =
        messages.length
        + ':'
        + (
            lastMessage?.id
            ?? 0
        )
        + ':'
        + (
            lastMessage?.edited_at
            ?? ''
        );

    if (
        snapshot === lastMessageSnapshot
    ) {
        return;
    }

    /*
     * Remember whether the user was already near
     * the bottom before new messages arrived.
     *
     * If they are reading older messages, we do
     * not drag them back down.
     */
    const distanceFromBottom =
        messageArea.scrollHeight
        - messageArea.scrollTop
        - messageArea.clientHeight;

    const wasNearBottom =
        distanceFromBottom < 120;

    messageArea
        .querySelectorAll(
            '.messaging-message'
        )
        .forEach(
            (element) =>
                element.remove()
        );

    if (messages.length === 0) {
        if (messageEmpty) {
            messageEmpty.hidden =
                false;
        }

        lastMessageSnapshot =
            snapshot;

        return;
    }

    if (messageEmpty) {
        messageEmpty.hidden =
            true;
    }

    for (const message of messages) {
/*
 * Historical conversation-key versions
 * will be handled when key rotation is
 * implemented.
 */
const messageKeyVersion =
    Number(
        message.key_version
    );

if (
    !Number.isInteger(
        messageKeyVersion
    )
    || messageKeyVersion <= 0
) {
    console.error(
        'Message has an invalid key version.',
        {
            messageId:
                message.id,

            keyVersion:
                message.key_version
        }
    );

    continue;
}

const messageConversationKey =
    activeConversationKeys.get(
        messageKeyVersion
    );

if (
    !(messageConversationKey
        instanceof Uint8Array)
) {
    /*
     * The current user has no envelope for
     * this historical key version.
     */
    console.warn(
        'Conversation key is unavailable for message.',
        {
            messageId:
                message.id,

            keyVersion:
                messageKeyVersion
        }
    );

    continue;
}

try {
    const plaintext =
        await decryptMessage(
            message.ciphertext,
            message.iv,
            messageConversationKey
        );

            /*
             * Make sure we are still displaying
             * the same conversation after the
             * asynchronous decrypt.
             */
            if (
                activeConversationId
                !== conversationId
            ) {
                return;
            }

            messageArea.appendChild(
                createMessageElement(
                    message,
                    plaintext
                )
            );
        } catch (error) {
            console.error(
                'Could not decrypt message.',
                {
                    messageId:
                        message.id,

                    error:
                        error
                }
            );
        }
    }

    lastMessageSnapshot =
        snapshot;

    if (
        forceScroll
        || wasNearBottom
    ) {
        messageArea.scrollTop =
            messageArea.scrollHeight;
    }
}

function stopMessagePolling() {
    if (messagePollTimer !== null) {
        window.clearInterval(
            messagePollTimer
        );

        messagePollTimer = null;
    }

    messagePollInFlight = false;
}


async function pollMessages() {
if (
    messagePollInFlight
    || !activeConversationId
    || activeConversationKeys.size === 0
    || !activeConversationKey
    || document.hidden
) {
    return;
}

    messagePollInFlight = true;

    try {
        await renderEncryptedMessages();
    } catch (error) {
        console.error(
            'Could not refresh encrypted messages.',
            error
        );
    } finally {
        messagePollInFlight = false;
    }
}


function startMessagePolling() {
    stopMessagePolling();

    messagePollTimer =
        window.setInterval(
            pollMessages,
            MESSAGE_POLL_INTERVAL
        );
}

async function sendEncryptedMessage(
    plaintext
) {
    if (
        !activeConversationId
        || !activeConversationKey
        || !activeConversationKeyVersion
    ) {
        throw new Error(
            'Unlock the conversation first.'
        );
    }

    const encrypted =
        await encryptMessage(
            plaintext,
            activeConversationKey
        );

    const formData =
        new FormData();

    formData.set(
        'csrf_token',
        csrfToken
    );

    formData.set(
        'conversation_id',
        String(
            activeConversationId
        )
    );

    formData.set(
        'key_version',
        String(
            activeConversationKeyVersion
        )
    );

    formData.set(
        'ciphertext',
        encrypted.ciphertext
    );

    formData.set(
        'iv',
        encrypted.iv
    );

    const response =
        await fetch(
            '/actions/messaging/send.php',
            {
                method: 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: {
                    Accept:
                        'application/json'
                },
                body:
                    formData
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid send-message response.'
        );
    }

    if (
        !response.ok
        || !result.success
    ) {
        throw new Error(
            result?.error
            || 'Could not send message.'
        );
    }

    return result;
}

async function loadConversationKeyEnvelopes(
    conversationId
) {
    const parameters =
        new URLSearchParams({
            conversation_id:
                String(conversationId)
        });

    const response =
        await fetch(
            '/actions/messaging/key.php?'
            + parameters.toString(),
            {
                method: 'GET',

                credentials:
                    'same-origin',

                cache:
                    'no-store',

                headers: {
                    Accept:
                        'application/json'
                }
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid conversation-key response.'
        );
    }

    if (
        !response.ok
        || !result.success
    ) {
        throw new Error(
            result?.error
            || 'Could not load conversation keys.'
        );
    }

    const returnedConversationId =
        Number(
            result.conversation_id
        );

    if (
        returnedConversationId
        !== conversationId
    ) {
        throw new Error(
            'Conversation-key response does not match this conversation.'
        );
    }

    const currentKeyVersion =
        Number(
            result.current_key_version
        );

    if (
        !Number.isInteger(
            currentKeyVersion
        )
        || currentKeyVersion <= 0
    ) {
        throw new Error(
            'Invalid current conversation key version.'
        );
    }

    if (
        !Array.isArray(result.keys)
        || result.keys.length === 0
    ) {
        throw new Error(
            'No conversation keys are available.'
        );
    }

    const envelopes = [];

    const seenVersions =
        new Set();

    for (const key of result.keys) {
        const keyVersion =
            Number(
                key?.key_version
            );

        const encryptedKey =
            key?.encrypted_key;

        if (
            !Number.isInteger(
                keyVersion
            )
            || keyVersion <= 0
        ) {
            throw new Error(
                'Invalid conversation key version.'
            );
        }

        if (
            typeof encryptedKey
            !== 'string'
            || encryptedKey === ''
        ) {
            throw new Error(
                'Encrypted conversation key is unavailable.'
            );
        }

        if (
            seenVersions.has(
                keyVersion
            )
        ) {
            throw new Error(
                'Duplicate conversation key version.'
            );
        }

        seenVersions.add(
            keyVersion
        );

        envelopes.push({
            keyVersion:
                keyVersion,

            encryptedKey:
                encryptedKey
        });
    }

    if (
        !seenVersions.has(
            currentKeyVersion
        )
    ) {
        throw new Error(
            'Current conversation key is unavailable.'
        );
    }

    return {
        conversationId:
            returnedConversationId,

        currentKeyVersion:
            currentKeyVersion,

        envelopes:
            envelopes
    };
}


/*
|--------------------------------------------------------------------------
| Unlock conversation
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Unlock conversation
|--------------------------------------------------------------------------
*/

async function unlockConversation(
    conversationId,
    password = null
) {
    const conversation =
        await loadConversation(
            conversationId
        );

const keyData =
    await loadConversationKeyEnvelopes(
        conversationId
    );


/*
 * Get the user's OpenPGP private key through
 * the Key Vault.
 *
 * loadMessagingPrivateKey() first checks the
 * active Key Vault workday session.
 *
 * If the Key Vault is not currently unlocked,
 * the supplied Vault password is used instead.
 */
const privateKey =
    await loadMessagingPrivateKey(
        password
    );

    const decryptedKeys =
    new Map();

try {
    /*
     * Unwrap every conversation-key version
     * available to the current user.
     */
    for (
        const envelope
        of keyData.envelopes
    ) {
        const conversationKey =
            await unwrapConversationKey(
                envelope.encryptedKey,
                privateKey,
                envelope.keyVersion
            );

        if (
            !(conversationKey
                instanceof Uint8Array)
        ) {
            throw new Error(
                'Invalid decrypted conversation key.'
            );
        }

        decryptedKeys.set(
            envelope.keyVersion,
            conversationKey
        );
    }

    /*
     * The current key must be available because
     * all new messages are encrypted with it.
     */
    const currentConversationKey =
        decryptedKeys.get(
            keyData.currentKeyVersion
        );

    if (
        !(currentConversationKey
            instanceof Uint8Array)
    ) {
        throw new Error(
            'Current conversation key could not be decrypted.'
        );
    }

    /*
     * Only clear the previously active conversation
     * after every new key has been successfully
     * decrypted.
     */
clearActiveConversationKey();

activeConversationId =
    conversationId;

activeConversationData =
    conversation;

activeConversationKeys =
    decryptedKeys;

activeConversationKey =
    currentConversationKey;

activeConversationKeyVersion =
    keyData.currentKeyVersion;
} catch (error) {
    /*
     * If any envelope fails, zero every key that
     * was already successfully decrypted before
     * abandoning this unlock attempt.
     */
    for (
        const conversationKey
        of decryptedKeys.values()
    ) {
        if (
            conversationKey
            instanceof Uint8Array
        ) {
            conversationKey.fill(0);
        }
    }

    decryptedKeys.clear();

    throw error;
}

    showConversation(
        conversation
    );

    await renderEncryptedMessages(
        true
    );

    startMessagePolling();

    updateComposerState();

    if (!isActiveConversationChannelReadOnly()) {
        messageInput?.focus();
    }

    return {
        conversationId:
            activeConversationId,

        keyVersion:
            activeConversationKeyVersion
    };
}

vaultCloseButton?.addEventListener(
    'click',
    closeVaultDialog
);


vaultCancelButton?.addEventListener(
    'click',
    closeVaultDialog
);


vaultBackdrop?.addEventListener(
    'click',
    (event) => {
        if (
            event.target ===
            vaultBackdrop
        ) {
            closeVaultDialog();
        }
    }
);


vaultForm?.addEventListener(
    'submit',

    async (event) => {
        event.preventDefault();

        const conversationId =
            pendingConversationId;

        const password =
            vaultPasswordInput?.value
            ?? '';

        if (
            !Number.isInteger(
                conversationId
            )
            || conversationId <= 0
        ) {
            setVaultMessage(
                'No conversation is selected.',
                true
            );

            return;
        }

        if (password === '') {
            setVaultMessage(
                'Enter your Key Vault password.',
                true
            );

            vaultPasswordInput?.focus();

            return;
        }

        setVaultSubmitting(true);

        setVaultMessage(
            'Decrypting conversation...'
        );

        try {
            await unlockConversation(
                conversationId,
                password
            );

            /*
             * Remove the password from the
             * input as soon as it is no
             * longer needed.
             */

            if (vaultPasswordInput) {
                vaultPasswordInput.value =
                    '';
            }

            setVaultMessage(
                'Conversation unlocked.'
            );

            /*
             * We deliberately do not redirect.
             *
             * The AES key now exists only in
             * this page's JavaScript memory.
             */

            closeVaultDialog();

            console.info(
                'Encrypted conversation unlocked.',
                {
                    conversationId:
                        activeConversationId,

                    keyVersion:
                        activeConversationKeyVersion
                }
            );
        } catch (error) {
            console.error(error);

            if (vaultPasswordInput) {
                vaultPasswordInput.value =
                    '';
            }

            setVaultMessage(
                error instanceof Error
                    ? error.message
                    : 'Could not unlock conversation.',
                true
            );

            vaultPasswordInput?.focus();
        } finally {
            setVaultSubmitting(false);
        }
    }
);

/*
|--------------------------------------------------------------------------
| Dialog
|--------------------------------------------------------------------------
*/

function openDialog(options = {}) {
    if (!backdrop) {
        return;
    }

    backdrop.hidden = false;

    document.body.classList.add(
        'messaging-modal-open'
    );

    setFormMessage('');

    nameInput?.focus();

    if (options.skipMemberLoad !== true) {
        loadWorkspaceMembers();
    }
}

async function openPrefilledConversationDialog() {
    const parameters =
        new URLSearchParams(
            window.location.search
        );

    const directUserParameter =
        parameters.get('start_direct');

    const directUserId =
        directUserParameter !== null
            ? Number(directUserParameter)
            : null;

    const groupMembers =
        parameters.get('start_group_members');

    const teamParameter =
        parameters.get('start_team');

    const teamId =
        teamParameter !== null
            ? Number(teamParameter)
            : null;

    let prefillName =
        parameters.get('name') ?? '';

    let prefilledGroupMembers =
        groupMembers;

    if (
        (
            directUserId === null
            || !Number.isInteger(directUserId)
            || directUserId <= 0
        )
        && !groupMembers
        && (
            teamId === null
            || !Number.isInteger(teamId)
            || teamId <= 0
        )
    ) {
        return;
    }

    if (
        directUserId !== null
        && Number.isInteger(directUserId)
        && directUserId > 0
    ) {
        try {
            const response =
                await fetch(
                    '/actions/messaging/find-direct.php?'
                    + new URLSearchParams({
                        user_id:
                            String(directUserId)
                    }).toString(),
                    {
                        method: 'GET',
                        credentials:
                            'same-origin',
                        headers: {
                            Accept:
                                'application/json'
                        }
                    }
                );

            const result =
                await response.json();

            if (
                response.ok
                && result.success
                && Number.isInteger(
                    Number(result.conversation_id)
                )
                && Number(result.conversation_id) > 0
            ) {
                window.location.href =
                    '/messaging/?conversation='
                    + encodeURIComponent(
                        String(result.conversation_id)
                    );

                return;
            }
        } catch (error) {
            console.warn(
                'Direct-message lookup failed.',
                error
            );
        }
    }

    if (
        teamId !== null
        && Number.isInteger(teamId)
        && teamId > 0
    ) {
        try {
            const response =
                await fetch(
                    '/actions/messaging/find-team-conversation.php?'
                    + new URLSearchParams({
                        team_id:
                            String(teamId)
                    }).toString(),
                    {
                        method: 'GET',
                        credentials:
                            'same-origin',
                        headers: {
                            Accept:
                                'application/json'
                        }
                    }
                );

            const result =
                await response.json();

            if (
                response.ok
                && result.success
                && Number.isInteger(
                    Number(result.conversation_id)
                )
                && Number(result.conversation_id) > 0
            ) {
                window.location.href =
                    '/messaging/?conversation='
                    + encodeURIComponent(
                        String(result.conversation_id)
                    );

                return;
            }

            if (
                response.ok
                && result.success
                && Array.isArray(result.member_ids)
            ) {
                prefilledGroupMembers =
                    result.member_ids.join(',');

                if (
                    typeof result.name === 'string'
                    && result.name.trim() !== ''
                ) {
                    prefillName =
                        result.name.trim();
                }
            }
        } catch (error) {
            console.warn(
                'Team conversation lookup failed.',
                error
            );
        }
    }

    openDialog({
        skipMemberLoad:
            true
    });

    await loadWorkspaceMembers();

    if (typeInput) {
        typeInput.value =
            directUserId !== null
            && Number.isInteger(directUserId)
            && directUserId > 0
                ? 'direct'
                : 'group';
    }

    if (
        nameInput
        && prefillName !== ''
    ) {
        nameInput.value =
            prefillName.slice(0, 120);
    }

    updateConversationTypeUi();

    const selectedIds =
        new Set();

    if (
        directUserId !== null
        && Number.isInteger(directUserId)
        && directUserId > 0
    ) {
        selectedIds.add(directUserId);
    }

    if (prefilledGroupMembers) {
        for (const memberId of prefilledGroupMembers.split(',')) {
            const parsedMemberId =
                Number(memberId);

            if (
                Number.isInteger(parsedMemberId)
                && parsedMemberId > 0
            ) {
                selectedIds.add(parsedMemberId);
            }
        }
    }

    const checkboxes =
        memberList?.querySelectorAll(
            'input[type="checkbox"]'
        ) ?? [];

    const currentUserId =
        getCurrentUserId();

    for (const checkbox of checkboxes) {
        const userId =
            Number(checkbox.dataset.userId);

        checkbox.checked =
            selectedIds.has(userId)
            || (
                typeInput?.value !== 'direct'
                && userId === currentUserId
            );
    }

    updateMemberCount();
}


function closeDialog() {
    if (!backdrop) {
        return;
    }

    backdrop.hidden = true;

    document.body.classList.remove(
        'messaging-modal-open'
    );

    setFormMessage('');
}


newButton?.addEventListener(
    'click',
    openDialog
);

openPrefilledConversationDialog();


closeButton?.addEventListener(
    'click',
    closeDialog
);


cancelButton?.addEventListener(
    'click',
    closeDialog
);


backdrop?.addEventListener(
    'click',
    (event) => {
        if (event.target === backdrop) {
            closeDialog();
        }
    }
);


document.addEventListener(
    'keydown',
    (event) => {
        if (
            event.key === 'Escape'
            && backdrop
            && !backdrop.hidden
        ) {
            closeDialog();
        }
    if (
    event.key === 'Escape'
    && vaultBackdrop
    && !vaultBackdrop.hidden
) {
    closeVaultDialog();
}
    }
);


/*
|--------------------------------------------------------------------------
| Workspace members
|--------------------------------------------------------------------------
*/

async function loadWorkspaceMembers() {
    if (
        membersLoaded
        || loadingMembers
    ) {
        return;
    }

    loadingMembers = true;

    if (memberStatus) {
        memberStatus.textContent =
            'Loading members...';
    }

    try {
        const response =
            await fetch(
                '/actions/messaging/members.php',
                {
                    method: 'GET',
                    credentials:
                        'same-origin',
                    headers: {
                        Accept:
                            'application/json'
                    }
                }
            );

        const result =
            await response.json();

        if (
            !response.ok
            || !result.success
        ) {
            throw new Error(
                result.error
                || 'Could not load workspace members.'
            );
        }

        if (
            !Array.isArray(
                result.members
            )
        ) {
            throw new Error(
                'Invalid workspace-member response.'
            );
        }

        workspaceMembers =
            result.members;

        membersLoaded = true;

        renderMembers();
    } catch (error) {
        console.error(error);

        if (memberStatus) {
            memberStatus.textContent =
                error instanceof Error
                    ? error.message
                    : 'Could not load workspace members.';
        }
    } finally {
        loadingMembers = false;
    }
}

/*
|--------------------------------------------------------------------------
| Conversation type UI
|--------------------------------------------------------------------------
*/

function updateConversationTypeUi() {
    const type =
        typeInput?.value
        ?? 'group';

    const isDirect =
        type === 'direct';

    if (nameField) {
        nameField.hidden =
            isDirect;
    }

    if (descriptionField) {
        descriptionField.hidden =
            isDirect;
    }

    if (nameInput) {
        nameInput.required =
            !isDirect;

        if (isDirect) {
            nameInput.value = '';
        }
    }

    if (
        descriptionInput
        && isDirect
    ) {
        descriptionInput.value = '';
    }

    if (membersLabel) {
        membersLabel.textContent =
            isDirect
                ? 'Person'
                : 'Members';
    }

    /*
     * If the user changes an existing group/channel
     * form to Direct message, keep only the current
     * user selected. They can then choose one person.
     */
    if (
        isDirect
        && memberList
    ) {
        const currentUserId =
            getCurrentUserId();

        const checkboxes =
            memberList.querySelectorAll(
                'input[type="checkbox"]'
            );

        for (
            const checkbox
            of checkboxes
        ) {
            const userId =
                Number(
                    checkbox.dataset.userId
                );

            checkbox.checked =
                userId === currentUserId;
        }
    }

    renderMembers();
}

/*
|--------------------------------------------------------------------------
| Render member selection
|--------------------------------------------------------------------------
*/

function renderMembers() {
    if (!memberList) {
        return;
    }

    /*
     * Preserve the current selection while rebuilding
     * the list.
     */
    const previousSelection =
        new Set(
            getSelectedMemberIds()
        );

    memberList.replaceChildren();

    if (
        workspaceMembers.length === 0
    ) {
        if (memberStatus) {
            memberStatus.textContent =
                'No workspace members are available.';
        }

        updateMemberCount();

        return;
    }

    const currentUserId =
        getCurrentUserId();

    const isDirect =
        typeInput?.value === 'direct';

    if (memberStatus) {
        memberStatus.textContent =
            isDirect
                ? 'Select one person to message privately.'
                : 'Select the people who should have access to this conversation.';
    }

    for (
        const member
        of workspaceMembers
    ) {
        const userId =
            Number(member.id);

        if (
            !Number.isInteger(userId)
            || userId <= 0
        ) {
            continue;
        }

        /*
         * For a DM the current user is implicit.
         * We do not need to show "You" as a selectable
         * person in the list.
         */
        if (
            isDirect
            && userId === currentUserId
        ) {
            continue;
        }

        const label =
            document.createElement(
                'label'
            );

        label.className =
            'messaging-member-option';

        const checkbox =
            document.createElement(
                'input'
            );

        checkbox.type =
            'checkbox';

        checkbox.value =
            String(userId);

        checkbox.dataset.userId =
            String(userId);

        if (isDirect) {
            checkbox.checked =
                previousSelection.has(
                    userId
                );

            checkbox.addEventListener(
                'change',
                () => {
                    /*
                     * A DM may contain only one other
                     * person. Selecting somebody new
                     * deselects everybody else.
                     */
                    if (checkbox.checked) {
                        const checkboxes =
                            memberList.querySelectorAll(
                                'input[type="checkbox"]'
                            );

                        for (
                            const otherCheckbox
                            of checkboxes
                        ) {
                            if (
                                otherCheckbox
                                !== checkbox
                            ) {
                                otherCheckbox.checked =
                                    false;
                            }
                        }
                    }

                    updateMemberCount();
                }
            );
        } else {
            /*
             * Group/channel creator is always included.
             */
            if (
                userId === currentUserId
            ) {
                checkbox.checked = true;
                checkbox.disabled = true;
            } else {
                checkbox.checked =
                    previousSelection.has(
                        userId
                    );
            }

            checkbox.addEventListener(
                'change',
                updateMemberCount
            );
        }

        const details =
            document.createElement(
                'span'
            );

        details.className =
            'messaging-member-details';

        const name =
            document.createElement(
                'strong'
            );

        const memberName =
            typeof member.name === 'string'
                ? member.name.trim()
                : '';

        const memberEmail =
            typeof member.email === 'string'
                ? member.email.trim()
                : '';

        name.textContent =
            memberName !== ''
                ? memberName
                : memberEmail;

        const secondary =
            document.createElement(
                'span'
            );

        if (
            userId === currentUserId
        ) {
            secondary.textContent =
                memberEmail !== ''
                    ? `${memberEmail} · You`
                    : 'You';
        } else {
            secondary.textContent =
                memberEmail;
        }

        details.append(
            name,
            secondary
        );

        label.append(
            checkbox,
            details
        );

        memberList.append(
            label
        );
    }

    updateMemberCount();
}


/*
|--------------------------------------------------------------------------
| Selected members
|--------------------------------------------------------------------------
*/

function getSelectedMemberIds() {
    if (!memberList) {
        return [];
    }

    const checkboxes =
        memberList.querySelectorAll(
            'input[type="checkbox"]'
        );

    const selected = [];

    for (
        const checkbox
        of checkboxes
    ) {
        if (!checkbox.checked) {
            continue;
        }

        const userId =
            Number(
                checkbox.dataset.userId
            );

        if (
            Number.isInteger(userId)
            && userId > 0
        ) {
            selected.push(userId);
        }
    }

    /*
     * The current user is hidden from the DM picker,
     * but must still be included in the encrypted
     * conversation and receive a key envelope.
     */
    if (
        typeInput?.value === 'direct'
    ) {
        const currentUserId =
            getCurrentUserId();

        if (
            Number.isInteger(
                currentUserId
            )
            && currentUserId > 0
        ) {
            selected.push(
                currentUserId
            );
        }
    }

    return Array.from(
        new Set(selected)
    );
}


function updateMemberCount() {
    if (!memberCount) {
        return;
    }

    const count =
        getSelectedMemberIds()
            .length;

    if (
        typeInput?.value === 'direct'
    ) {
        const otherPeople =
            Math.max(
                0,
                count - 1
            );

        memberCount.textContent =
            otherPeople === 1
                ? '1 person selected'
                : 'Select 1 person';

        return;
    }

    memberCount.textContent =
        count === 1
            ? '1 selected'
            : `${count} selected`;
}

typeInput?.addEventListener(
    'change',
    updateConversationTypeUi
);

/*
|--------------------------------------------------------------------------
| Load public keys
|--------------------------------------------------------------------------
*/

async function loadPublicKeys(
    userIds
) {
    if (
        !Array.isArray(userIds)
        || userIds.length === 0
    ) {
        throw new Error(
            'Select at least one conversation member.'
        );
    }

    const parameters =
        new URLSearchParams();

    for (const userId of userIds) {
        parameters.append(
            'user_ids[]',
            String(userId)
        );
    }

    const response =
        await fetch(
            '/actions/messaging/public-keys.php?'
            + parameters.toString(),
            {
                method: 'GET',
                credentials:
                    'same-origin',
                headers: {
                    Accept:
                        'application/json'
                }
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid public-key response.'
        );
    }

    if (
        !response.ok
        || !result.success
    ) {
        throw new Error(
            result.error
            || 'Could not load Messaging public keys.'
        );
    }

    if (!Array.isArray(result.keys)) {
        throw new Error(
            'Invalid Messaging public-key response.'
        );
    }

    const missingUserIds =
        Array.isArray(
            result.missing_user_ids
        )
            ? result.missing_user_ids
                .map(Number)
                .filter(
                    (userId) =>
                        Number.isInteger(
                            userId
                        )
                        && userId > 0
                )
            : [];

    if (
        missingUserIds.length > 0
    ) {
        const names =
            missingUserIds.map(
                (userId) => {
                    const member =
                        workspaceMembers.find(
                            (candidate) =>
                                Number(
                                    candidate.id
                                ) === userId
                        );

                    if (!member) {
                        return `User ${userId}`;
                    }

                    return (
                        member.name
                        || member.email
                        || `User ${userId}`
                    );
                }
            );

        throw new Error(
            'These members have not set up their Messaging encryption key: '
            + names.join(', ')
            + '. They must unlock their Key Vault and have an OpenPGP identity first.'
        );
    }

    if (
        result.keys.length
        !== userIds.length
    ) {
        throw new Error(
            'Not every conversation member has a published Messaging key.'
        );
    }

    return result.keys;
}

/*
|--------------------------------------------------------------------------
| Remove conversation member + rotate key
|--------------------------------------------------------------------------
|
| Removing a member requires a new conversation AES key.
|
| The browser:
|
| 1. determines which members will remain
| 2. loads their published OpenPGP public keys
| 3. generates a fresh random AES-256 conversation key
| 4. wraps it separately for every remaining member
| 5. sends only those encrypted envelopes to PHP
|
| The raw replacement AES key never leaves the browser.
|
*/

async function removeConversationMember(
    userId
) {
    if (
        !activeConversationData
        || !activeConversationId
        || !Number.isInteger(
            activeConversationKeyVersion
        )
        || activeConversationKeyVersion <= 0
    ) {
        throw new Error(
            'Unlock the conversation first.'
        );
    }

    const removeUserId =
        Number(userId);

    if (
        !Number.isInteger(removeUserId)
        || removeUserId <= 0
    ) {
        throw new Error(
            'Invalid conversation member.'
        );
    }

    const currentUserId =
        getCurrentUserId();

    if (removeUserId === currentUserId) {
        throw new Error(
            'You cannot remove yourself with this action.'
        );
    }

    if (
        activeConversationData.type
        === 'direct'
    ) {
        throw new Error(
            'Direct-message members cannot be removed.'
        );
    }

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    if (
        currentUserRole !== 'owner'
        && currentUserRole !== 'admin'
    ) {
        throw new Error(
            'You cannot remove members from this conversation.'
        );
    }

    const members =
        Array.isArray(
            activeConversationData.members
        )
            ? activeConversationData.members
            : [];

    const targetMember =
        members.find(
            (member) =>
                Number(member?.user_id)
                === removeUserId
        );

    if (!targetMember) {
        throw new Error(
            'Conversation member is unavailable.'
        );
    }

    const targetRole =
        String(
            targetMember.role
            ?? ''
        );

    if (targetRole === 'owner') {
        throw new Error(
            'The conversation owner cannot be removed.'
        );
    }

    if (
        currentUserRole === 'admin'
        && targetRole === 'admin'
    ) {
        throw new Error(
            'Only the conversation owner can remove an administrator.'
        );
    }

    /*
     * Determine the exact membership that should
     * receive the replacement key.
     */

    const remainingUserIds =
        members
            .map(
                (member) =>
                    Number(member?.user_id)
            )
            .filter(
                (memberUserId) =>
                    Number.isInteger(
                        memberUserId
                    )
                    && memberUserId > 0
                    && memberUserId
                        !== removeUserId
            );

    const uniqueRemainingUserIds =
        Array.from(
            new Set(
                remainingUserIds
            )
        );

    if (
        uniqueRemainingUserIds.length
        !== members.length - 1
    ) {
        throw new Error(
            'Conversation membership is invalid. Reload and try again.'
        );
    }

    if (
        !uniqueRemainingUserIds.includes(
            currentUserId
        )
    ) {
        throw new Error(
            'Current user is missing from the remaining conversation members.'
        );
    }

    /*
     * The next version must be exactly one above
     * the currently unlocked version.
     *
     * PHP independently checks this again.
     */

    const nextKeyVersion =
        activeConversationKeyVersion + 1;

    /*
     * Load only the remaining members' public
     * keys. The removed member deliberately gets
     * no replacement key envelope.
     */

    const publicKeys =
        await loadPublicKeys(
            uniqueRemainingUserIds
        );

    let keyData = null;

    try {
        /*
         * Generate a brand-new AES-256 key and
         * OpenPGP-wrap it for every remaining
         * member.
         */

        keyData =
            await createConversationKeyEnvelopes(
                publicKeys,
                nextKeyVersion
            );

        const formData =
            new FormData();

        formData.set(
            'csrf_token',
            getCsrfToken()
        );

        formData.set(
            'conversation_id',
            String(
                activeConversationId
            )
        );

        formData.set(
            'user_id',
            String(
                removeUserId
            )
        );

        formData.set(
            'key_version',
            String(
                nextKeyVersion
            )
        );

        formData.set(
            'key_envelopes',
            JSON.stringify(
                keyData.envelopes
            )
        );

        const response =
            await fetch(
                '/actions/messaging/remove-member.php',
                {
                    method: 'POST',

                    credentials:
                        'same-origin',

                    cache:
                        'no-store',

                    headers: {
                        Accept:
                            'application/json'
                    },

                    body:
                        formData
                }
            );

        let result;

        try {
            result =
                await response.json();
        } catch (error) {
            throw new Error(
                'Invalid member-removal response.'
            );
        }

        if (
            !response.ok
            || !result.success
        ) {
            throw new Error(
                result?.error
                || 'Could not remove conversation member.'
            );
        }

        if (
            Number(result.conversation_id)
            !== activeConversationId
        ) {
            throw new Error(
                'Member-removal response does not match this conversation.'
            );
        }

        if (
            Number(result.removed_user_id)
            !== removeUserId
        ) {
            throw new Error(
                'Member-removal response does not match the removed member.'
            );
        }

        if (
            Number(result.key_version)
            !== nextKeyVersion
        ) {
            throw new Error(
                'Member-removal response returned an unexpected key version.'
            );
        }

        /*
         * The server has now committed the new
         * membership and key version.
         *
         * Keep the freshly generated replacement
         * key in memory as the new active key.
         */

        activeConversationKeys.set(
            nextKeyVersion,
            keyData.conversationKey
        );

        activeConversationKey =
            keyData.conversationKey;

        activeConversationKeyVersion =
            nextKeyVersion;

        /*
         * Update our local metadata so another
         * operation cannot accidentally use the
         * removed member.
         */

        activeConversationData.members =
            members.filter(
                (member) =>
                    Number(member?.user_id)
                    !== removeUserId
            );

        activeConversationData.key_version =
            nextKeyVersion;

        /*
         * Ownership of conversationKey has now
         * transferred into activeConversationKeys.
         *
         * Do NOT zero it in the finally block.
         */

        keyData = null;

lastMessageSnapshot = null;

return {
            conversationId:
                activeConversationId,

            removedUserId:
                removeUserId,

            keyVersion:
                nextKeyVersion
        };
    } finally {
        /*
         * If anything failed before the new key
         * became active, destroy the unused raw
         * replacement key.
         */

        if (
            keyData?.conversationKey
            instanceof Uint8Array
        ) {
            keyData.conversationKey.fill(0);
        }
    }
}

/*
|--------------------------------------------------------------------------
| Add conversation member + rotate key
|--------------------------------------------------------------------------
|
| Adding a member creates a new conversation AES key.
|
| The new member receives only the new key version.
| They do not receive historical conversation keys, so messages sent
| before they joined remain unavailable to them.
|
*/

async function addConversationMember(
    userId
) {
    if (
        !activeConversationData
        || !activeConversationId
        || !Number.isInteger(
            activeConversationKeyVersion
        )
        || activeConversationKeyVersion <= 0
    ) {
        throw new Error(
            'Unlock the conversation first.'
        );
    }

    const addUserId =
        Number(userId);

    if (
        !Number.isInteger(addUserId)
        || addUserId <= 0
    ) {
        throw new Error(
            'Invalid workspace member.'
        );
    }

    if (
        activeConversationData.type
        === 'direct'
    ) {
        throw new Error(
            'Members cannot be added to direct messages.'
        );
    }

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    if (
        currentUserRole !== 'owner'
        && currentUserRole !== 'admin'
    ) {
        throw new Error(
            'You cannot add members to this conversation.'
        );
    }

    const members =
        Array.isArray(
            activeConversationData.members
        )
            ? activeConversationData.members
            : [];

    /*
     * Refuse to add somebody who is already
     * present in our current membership data.
     */
    const alreadyMember =
        members.some(
            (member) =>
                Number(member?.user_id)
                === addUserId
        );

    if (alreadyMember) {
        throw new Error(
            'This user is already a conversation member.'
        );
    }

    /*
     * Build the exact membership that should
     * receive the new key:
     *
     * existing members + newly added member.
     */
    const resultingUserIds =
        members
            .map(
                (member) =>
                    Number(member?.user_id)
            )
            .filter(
                (memberUserId) =>
                    Number.isInteger(
                        memberUserId
                    )
                    && memberUserId > 0
            );

    resultingUserIds.push(
        addUserId
    );

    const uniqueResultingUserIds =
        Array.from(
            new Set(
                resultingUserIds
            )
        );

    if (
        uniqueResultingUserIds.length
        !== members.length + 1
    ) {
        throw new Error(
            'Conversation membership is invalid. Reload and try again.'
        );
    }

    const currentUserId =
        getCurrentUserId();

    if (
        !uniqueResultingUserIds.includes(
            currentUserId
        )
    ) {
        throw new Error(
            'Current user is missing from the conversation membership.'
        );
    }

    const nextKeyVersion =
        activeConversationKeyVersion + 1;

    /*
     * Every resulting member must have a
     * published OpenPGP public key.
     */
    const publicKeys =
        await loadPublicKeys(
            uniqueResultingUserIds
        );

    let keyData = null;

    try {
        /*
         * Generate one brand-new random AES-256
         * key and wrap it separately for every
         * resulting conversation member.
         */
        keyData =
            await createConversationKeyEnvelopes(
                publicKeys,
                nextKeyVersion
            );

        const formData =
            new FormData();

        formData.set(
            'csrf_token',
            getCsrfToken()
        );

        formData.set(
            'conversation_id',
            String(
                activeConversationId
            )
        );

        formData.set(
            'user_id',
            String(
                addUserId
            )
        );

        formData.set(
            'key_version',
            String(
                nextKeyVersion
            )
        );

        formData.set(
            'key_envelopes',
            JSON.stringify(
                keyData.envelopes
            )
        );

        const response =
            await fetch(
                '/actions/messaging/add-member.php',
                {
                    method: 'POST',
                    credentials:
                        'same-origin',
                    cache:
                        'no-store',
                    headers: {
                        Accept:
                            'application/json'
                    },
                    body:
                        formData
                }
            );

        let result;

        try {
            result =
                await response.json();
        } catch (error) {
            throw new Error(
                'Invalid add-member response.'
            );
        }

        if (
            !response.ok
            || !result.success
        ) {
            throw new Error(
                result?.error
                || 'Could not add conversation member.'
            );
        }

        if (
            Number(
                result.conversation_id
            )
            !== activeConversationId
        ) {
            throw new Error(
                'Add-member response does not match this conversation.'
            );
        }

        if (
            Number(
                result.added_user_id
            )
            !== addUserId
        ) {
            throw new Error(
                'Add-member response does not match the added member.'
            );
        }

        if (
            Number(
                result.key_version
            )
            !== nextKeyVersion
        ) {
            throw new Error(
                'Add-member response returned an unexpected key version.'
            );
        }

        /*
         * The server has committed the membership
         * change and new key version.
         *
         * Keep the newly generated key as our
         * current in-memory conversation key.
         */
        activeConversationKeys.set(
            nextKeyVersion,
            keyData.conversationKey
        );

        activeConversationKey =
            keyData.conversationKey;

        activeConversationKeyVersion =
            nextKeyVersion;

        /*
         * Add the new member to our local metadata.
         *
         * workspaceMembers uses:
         *
         *     id
         *     name
         *     email
         *
         * conversation.php uses:
         *
         *     user_id
         *     display_name
         *     job_title
         *     role
         *
         * We'll reload the authoritative conversation
         * metadata immediately afterwards rather than
         * trying to manufacture that full object here.
         */
        const refreshedConversation =
            await loadConversation(
                activeConversationId
            );

        /*
         * Make sure the server actually returned
         * the newly added member.
         */
        const refreshedMembers =
            Array.isArray(
                refreshedConversation.members
            )
                ? refreshedConversation.members
                : [];

        const addedMemberExists =
            refreshedMembers.some(
                (member) =>
                    Number(member?.user_id)
                    === addUserId
            );

        if (!addedMemberExists) {
            throw new Error(
                'The member was added, but refreshed conversation membership is unavailable.'
            );
        }

        activeConversationData =
            refreshedConversation;

        activeConversationData.key_version =
            nextKeyVersion;

        /*
         * Ownership of conversationKey has now
         * transferred to activeConversationKeys.
         *
         * Do not zero it in finally.
         */
        keyData = null;

        lastMessageSnapshot = null;

        return {
            conversationId:
                activeConversationId,

            addedUserId:
                addUserId,

            keyVersion:
                nextKeyVersion
        };
    } finally {
        /*
         * If the operation failed before ownership
         * of the replacement key transferred to the
         * active conversation state, destroy it.
         */
        if (
            keyData?.conversationKey
            instanceof Uint8Array
        ) {
            keyData.conversationKey.fill(0);
        }
    }
}

/*
|--------------------------------------------------------------------------
| Update conversation member role
|--------------------------------------------------------------------------
|
| Conversation roles control administration permissions only.
|
| Changing a role does not change access to encrypted messages, so no
| conversation-key rotation is necessary.
|
| Only the conversation owner may perform this operation. The PHP
| endpoint independently enforces the same permission.
|
*/

async function updateConversationMemberRole(
    userId,
    newRole
) {
    if (
        !activeConversationData
        || !activeConversationId
    ) {
        throw new Error(
            'Open the conversation first.'
        );
    }

    const targetUserId =
        Number(userId);

    if (
        !Number.isInteger(
            targetUserId
        )
        || targetUserId <= 0
    ) {
        throw new Error(
            'Invalid conversation member.'
        );
    }

    if (
        activeConversationData.type
        === 'direct'
    ) {
        throw new Error(
            'Direct-message roles cannot be changed.'
        );
    }

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    if (
        currentUserRole !== 'owner'
    ) {
        throw new Error(
            'Only the conversation owner can change member roles.'
        );
    }

    const normalizedRole =
        String(
            newRole
            ?? ''
        ).trim();

    if (
        normalizedRole !== 'admin'
        && normalizedRole !== 'member'
    ) {
        throw new Error(
            'Invalid conversation role.'
        );
    }

    const members =
        Array.isArray(
            activeConversationData.members
        )
            ? activeConversationData.members
            : [];

    const targetMember =
        members.find(
            (member) =>
                Number(
                    member?.user_id
                )
                === targetUserId
        );

    if (!targetMember) {
        throw new Error(
            'Conversation member not found.'
        );
    }

    const currentTargetRole =
        String(
            targetMember.role
            ?? ''
        );

    if (
        currentTargetRole === 'owner'
    ) {
        throw new Error(
            'The conversation owner role cannot be changed.'
        );
    }

    const currentUserId =
        getCurrentUserId();

    if (
        targetUserId
        === currentUserId
    ) {
        throw new Error(
            'You cannot change your own conversation role.'
        );
    }

    /*
     * Only permit:
     *
     * member -> admin
     * admin  -> member
     */
    const validTransition =
        (
            currentTargetRole
            === 'member'
            && normalizedRole
            === 'admin'
        )
        || (
            currentTargetRole
            === 'admin'
            && normalizedRole
            === 'member'
        );

    if (!validTransition) {
        throw new Error(
            'That role change is not available.'
        );
    }

    const formData =
        new FormData();

    formData.set(
        'csrf_token',
        getCsrfToken()
    );

    formData.set(
        'conversation_id',
        String(
            activeConversationId
        )
    );

    formData.set(
        'user_id',
        String(
            targetUserId
        )
    );

    formData.set(
        'role',
        normalizedRole
    );

    const response =
        await fetch(
            '/actions/messaging/update-member-role.php',
            {
                method: 'POST',
                credentials:
                    'same-origin',
                cache:
                    'no-store',
                headers: {
                    Accept:
                        'application/json'
                },
                body:
                    formData
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid role-update response.'
        );
    }

    if (
        !response.ok
        || !result.success
    ) {
        throw new Error(
            result?.error
            || 'Could not update conversation member role.'
        );
    }

    if (
        Number(
            result.conversation_id
        )
        !== activeConversationId
    ) {
        throw new Error(
            'Role-update response does not match this conversation.'
        );
    }

    if (
        Number(
            result.user_id
        )
        !== targetUserId
    ) {
        throw new Error(
            'Role-update response does not match the conversation member.'
        );
    }

    if (
        String(
            result.role
        )
        !== normalizedRole
    ) {
        throw new Error(
            'Role-update response returned an unexpected role.'
        );
    }

    /*
     * Reload authoritative conversation metadata
     * from PHP instead of relying only on the
     * browser's local copy.
     */
    const refreshedConversation =
        await loadConversation(
            activeConversationId
        );

    const refreshedMembers =
        Array.isArray(
            refreshedConversation.members
        )
            ? refreshedConversation.members
            : [];

    const refreshedTargetMember =
        refreshedMembers.find(
            (member) =>
                Number(
                    member?.user_id
                )
                === targetUserId
        );

    if (
        !refreshedTargetMember
        || String(
            refreshedTargetMember.role
        ) !== normalizedRole
    ) {
        throw new Error(
            'The role was changed, but refreshed conversation data is unavailable.'
        );
    }

    /*
     * Replace our local conversation metadata.
     *
     * Encryption keys stay exactly as they are.
     */
    activeConversationData =
        refreshedConversation;

    lastMessageSnapshot =
        null;

    return {
        conversationId:
            activeConversationId,

        userId:
            targetUserId,

        role:
            normalizedRole
    };
}

/*
|--------------------------------------------------------------------------
| Leave conversation + rotate key
|--------------------------------------------------------------------------
|
| Members and admins may leave a group or channel.
|
| Before membership is removed, the browser creates a brand-new AES-256
| conversation key and wraps it only for the remaining members.
|
| The leaving user receives no envelope for the new key version.
|
| Owners cannot leave. They must delete the conversation or transfer
| ownership once ownership transfer is implemented.
|
*/

async function leaveConversation() {
    if (
        !activeConversationData
        || !activeConversationId
        || !Number.isInteger(
            activeConversationKeyVersion
        )
        || activeConversationKeyVersion <= 0
    ) {
        throw new Error(
            'Unlock the conversation first.'
        );
    }

    if (
        activeConversationData.type
        === 'direct'
    ) {
        throw new Error(
            'Direct messages cannot be left.'
        );
    }

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    if (
        currentUserRole === 'owner'
    ) {
        throw new Error(
            'The conversation owner cannot leave. Delete the conversation instead.'
        );
    }

    if (
        currentUserRole !== 'admin'
        && currentUserRole !== 'member'
    ) {
        throw new Error(
            'You cannot leave this conversation.'
        );
    }

    const currentUserId =
        getCurrentUserId();

    const members =
        Array.isArray(
            activeConversationData.members
        )
            ? activeConversationData.members
            : [];

    /*
     * Build the membership that will remain
     * after the current user leaves.
     */
    const remainingUserIds =
        members
            .map(
                (member) =>
                    Number(
                        member?.user_id
                    )
            )
            .filter(
                (userId) =>
                    Number.isInteger(
                        userId
                    )
                    && userId > 0
                    && userId
                        !== currentUserId
            );

    const uniqueRemainingUserIds =
        Array.from(
            new Set(
                remainingUserIds
            )
        );

    /*
     * Make sure our local membership data did
     * not contain duplicates or invalid entries.
     */
    if (
        uniqueRemainingUserIds.length
        !== members.length - 1
    ) {
        throw new Error(
            'Conversation membership is invalid. Reload and try again.'
        );
    }

    if (
        uniqueRemainingUserIds.length
        === 0
    ) {
        throw new Error(
            'Cannot leave a conversation with no remaining members.'
        );
    }

    const currentUserIsMember =
        members.some(
            (member) =>
                Number(
                    member?.user_id
                )
                === currentUserId
        );

    if (!currentUserIsMember) {
        throw new Error(
            'Current user is missing from the conversation membership.'
        );
    }

    const nextKeyVersion =
        activeConversationKeyVersion + 1;

    /*
     * We need public keys only for the people
     * who will remain in the conversation.
     *
     * The leaving user deliberately receives
     * no new key envelope.
     */
    const publicKeys =
        await loadPublicKeys(
            uniqueRemainingUserIds
        );

    let keyData = null;

    try {
        /*
         * Generate the replacement AES-256 key
         * and OpenPGP-wrap it separately for each
         * remaining member.
         */
        keyData =
            await createConversationKeyEnvelopes(
                publicKeys,
                nextKeyVersion
            );

        const conversationId =
            activeConversationId;

        const formData =
            new FormData();

        formData.set(
            'csrf_token',
            getCsrfToken()
        );

        formData.set(
            'conversation_id',
            String(
                conversationId
            )
        );

        formData.set(
            'key_version',
            String(
                nextKeyVersion
            )
        );

        formData.set(
            'key_envelopes',
            JSON.stringify(
                keyData.envelopes
            )
        );

        const response =
            await fetch(
                '/actions/messaging/leave.php',
                {
                    method: 'POST',
                    credentials:
                        'same-origin',
                    cache:
                        'no-store',
                    headers: {
                        Accept:
                            'application/json'
                    },
                    body:
                        formData
                }
            );

        let result;

        try {
            result =
                await response.json();
        } catch (error) {
            throw new Error(
                'Invalid leave-conversation response.'
            );
        }

        if (
            !response.ok
            || !result.success
        ) {
            throw new Error(
                result?.error
                || 'Could not leave conversation.'
            );
        }

        if (
            Number(
                result.conversation_id
            )
            !== conversationId
        ) {
            throw new Error(
                'Leave-conversation response does not match this conversation.'
            );
        }

        if (
            Number(
                result.left_user_id
            )
            !== currentUserId
        ) {
            throw new Error(
                'Leave-conversation response does not match the current user.'
            );
        }

        if (
            Number(
                result.key_version
            )
            !== nextKeyVersion
        ) {
            throw new Error(
                'Leave-conversation response returned an unexpected key version.'
            );
        }

        /*
         * The server has now:
         *
         * 1. stored the replacement key envelopes
         * 2. removed our membership
         * 3. advanced the conversation key version
         *
         * We are no longer authorized to keep this
         * conversation active locally.
         *
         * Unlike add/remove operations, we DO NOT
         * adopt the newly generated AES key because
         * the current user has left the conversation.
         */

        return {
            conversationId:
                conversationId,

            keyVersion:
                nextKeyVersion
        };
    } finally {
        /*
         * The leaving user must never retain the
         * replacement key generated for the remaining
         * members.
         *
         * Destroy it whether the request succeeds
         * or fails.
         */
        if (
            keyData?.conversationKey
            instanceof Uint8Array
        ) {
            keyData.conversationKey.fill(0);
        }
    }
}

/*
|--------------------------------------------------------------------------
| Delete conversation
|--------------------------------------------------------------------------
|
| Permanently deletes the conversation for every member.
|
| Only the conversation owner may perform this operation.
|
| No key rotation is required because the conversation, messages,
| memberships, and encrypted key envelopes are all being deleted.
|
*/

async function deleteConversation() {
    if (
        !activeConversationData
        || !activeConversationId
    ) {
        throw new Error(
            'Open the conversation first.'
        );
    }

    const currentUserRole =
        String(
            activeConversationData.role
            ?? ''
        );

    if (
        currentUserRole !== 'owner'
    ) {
        throw new Error(
            'Only the conversation owner can delete this conversation.'
        );
    }

    const conversationId =
        activeConversationId;

    const formData =
        new FormData();

    formData.set(
        'csrf_token',
        getCsrfToken()
    );

    formData.set(
        'conversation_id',
        String(
            conversationId
        )
    );

    const response =
        await fetch(
            '/actions/messaging/delete.php',
            {
                method: 'POST',
                credentials:
                    'same-origin',
                cache:
                    'no-store',
                headers: {
                    Accept:
                        'application/json'
                },
                body:
                    formData
            }
        );

    let result;

    try {
        result =
            await response.json();
    } catch (error) {
        throw new Error(
            'Invalid delete-conversation response.'
        );
    }

    if (
        !response.ok
        || !result.success
    ) {
        throw new Error(
            result?.error
            || 'Could not delete conversation.'
        );
    }

    if (
        Number(
            result.conversation_id
        )
        !== conversationId
    ) {
        throw new Error(
            'Delete-conversation response does not match this conversation.'
        );
    }

    /*
     * The server has permanently deleted the
     * conversation.
     *
     * The UI will clear the active conversation
     * and refresh the sidebar when we connect the
     * Delete button in the next step.
     */

    return {
        conversationId:
            conversationId
    };
}

/*
|--------------------------------------------------------------------------
| Create conversation
|--------------------------------------------------------------------------
*/

form?.addEventListener(
    'submit',
    async (event) => {
        event.preventDefault();

        setFormMessage('');

        const type =
            typeInput?.value
            ?? '';

        const name =
            nameInput?.value
                .trim()
            ?? '';

        const description =
            descriptionInput?.value
                .trim()
            ?? '';

if (
    type !== 'group'
    && type !== 'channel'
    && type !== 'direct'
) {
            setFormMessage(
                'Select a valid conversation type.',
                'error'
            );

            return;
        }

if (
    type !== 'direct'
    && name === ''
) {
    setFormMessage(
        'Enter a conversation name.',
        'error'
    );

    nameInput?.focus();

    return;
}

        const memberIds =
            getSelectedMemberIds();

        if (
    type === 'direct'
    && memberIds.length !== 2
) {
    setFormMessage(
        'Select exactly one person for the direct message.',
        'error'
    );

    return;
}

        if (
            memberIds.length === 0
        ) {
            setFormMessage(
                'Select at least one member.',
                'error'
            );

            return;
        }

        setSubmitting(true);

let keyData = null;

try {
            /*
             * Retrieve the selected members'
             * published OpenPGP public keys.
             */

            setFormMessage(
                'Checking encryption keys...'
            );

            const publicKeys =
                await loadPublicKeys(
                    memberIds
                );

            /*
             * Generate one random 256-bit
             * conversation key and encrypt a
             * separate copy for every member.
             *
             * The raw key remains in this
             * browser and is never submitted.
             */

            setFormMessage(
                'Preparing encrypted conversation...'
            );

keyData =
    await createConversationKeyEnvelopes(
        publicKeys,
        1
    );

            /*
             * Submit metadata, members and
             * encrypted key envelopes.
             */

            const formData =
                new FormData();

            formData.append(
                'csrf_token',
                getCsrfToken()
            );

            formData.append(
                'type',
                type
            );

let conversationName =
    name;

if (type === 'direct') {
    const currentUserId =
        getCurrentUserId();

    const otherUserId =
        memberIds.find(
            (userId) =>
                userId !== currentUserId
        );

    const otherMember =
        workspaceMembers.find(
            (member) =>
                Number(member.id)
                === otherUserId
        );

    const otherMemberName =
        typeof otherMember?.name === 'string'
            ? otherMember.name.trim()
            : '';

    const otherMemberEmail =
        typeof otherMember?.email === 'string'
            ? otherMember.email.trim()
            : '';

    conversationName =
        otherMemberName
        || otherMemberEmail
        || 'Direct message';
}

formData.append(
    'name',
    conversationName
);

            formData.append(
                'description',
                description
            );

            formData.append(
                'members',
                JSON.stringify(
                    memberIds
                )
            );

            formData.append(
                'key_envelopes',
                JSON.stringify(
                    keyData.envelopes
                )
            );

            setFormMessage(
                'Creating conversation...'
            );

            const response =
                await fetch(
                    '/actions/messaging/create.php',
                    {
                        method: 'POST',
                        body: formData,
                        credentials:
                            'same-origin',
                        headers: {
                            Accept:
                                'application/json'
                        }
                    }
                );

            let result;

            try {
                result =
                    await response.json();
            } catch (error) {
                throw new Error(
                    'Invalid response while creating conversation.'
                );
            }

            if (
                !response.ok
                || !result.success
            ) {
                throw new Error(
                    result.error
                    || 'Could not create conversation.'
                );
            }

            const conversationId =
                Number(
                    result.conversation_id
                );

            if (
                !Number.isInteger(
                    conversationId
                )
                || conversationId <= 0
            ) {
                throw new Error(
                    'Conversation was created but no valid conversation ID was returned.'
                );
            }

/*
 * If this DM already existed, the AES key we just
 * generated belongs to no conversation and must
 * never be used.
 *
 * The existing conversation already has its own
 * encrypted key envelope stored on the server.
 */
if (
    type === 'direct'
    && result.existing === true
) {
    if (keyData) {
    keyData.conversationKey.fill(
        0
    );

    keyData = null;
}

    window.location.href =
        '/messaging/?conversation='
        + encodeURIComponent(
            String(
                conversationId
            )
        );

    return;
}


            /*
             * Do not persist the raw conversation
             * key here.
             *
             * The user's encrypted envelope in
             * conversation_keys is the durable
             * copy.
             */

            keyData.conversationKey.fill(
                0
            );

            window.location.href =
                '/messaging/?conversation='
                + encodeURIComponent(
                    String(
                        conversationId
                    )
                );
        } catch (error) {
            if (keyData) {
    keyData.conversationKey.fill(
        0
    );

    keyData = null;
}
            console.error(error);

            setFormMessage(
                error instanceof Error
                    ? error.message
                    : 'Could not create conversation.',
                'error'
            );
        } finally {
            setSubmitting(false);
        }
    }
);

/*
|--------------------------------------------------------------------------
| Send encrypted message
|--------------------------------------------------------------------------
*/

messageComposer?.addEventListener(
    'submit',
    async (event) => {
        event.preventDefault();

        if (
            !messageInput
            || !sendButton
        ) {
            return;
        }

        const plaintext =
            messageInput.value.trim();

        if (plaintext === '') {
            return;
        }

        messageInput.disabled =
            true;

        sendButton.disabled =
            true;

        try {
            await sendEncryptedMessage(
                plaintext
            );

            /*
             * Clear plaintext from the input as
             * soon as the encrypted message has
             * been accepted.
             */

            messageInput.value =
                '';

            await renderEncryptedMessages(
                true
                );
        } catch (error) {
            console.error(
                'Encrypted message send failed.',
                error
            );

            alert(
                error instanceof Error
                    ? error.message
                    : 'Could not send message.'
            );
        } finally {
            /*
             * Only re-enable the composer if this
             * conversation is still unlocked and the
             * current user is allowed to post here.
             */

            updateComposerState();

            if (!isActiveConversationChannelReadOnly()) {
                messageInput?.focus();
            }
        }
    }
);

updateConversationTypeUi();

const conversationParameter =
    new URLSearchParams(
        window.location.search
    ).get(
        'conversation'
    );

const selectedConversationId =
    conversationParameter !== null
        ? Number(conversationParameter)
        : null;


/*
 * Only attempt to open a conversation when
 * the URL actually contains a valid positive ID.
 *
 * /messaging/
 * must NOT become conversation ID 0.
 */

if (
    Number.isInteger(
        selectedConversationId
    )
    && selectedConversationId > 0
) {
/*
 * Try to unlock automatically using the
 * active Key Vault workday session.
 *
 * If the Key Vault is not currently unlocked,
 * show the password dialog.
 */
    unlockConversation(
        selectedConversationId
    ).then(
        () => {
            console.info(
                'Encrypted conversation unlocked automatically.',
                {
                    conversationId:
                        activeConversationId,

                    keyVersion:
                        activeConversationKeyVersion
                }
            );
        }
    ).catch(
        (error) => {
            if (
                error instanceof Error
                && error.message ===
                    'KEY_VAULT_PASSWORD_REQUIRED'
            ) {
                openVaultDialog(
                    selectedConversationId
                );

                return;
            }

            console.error(
                'Automatic conversation unlock failed.',
                error
            );

            openVaultDialog(
                selectedConversationId
            );
        }
    );
}
