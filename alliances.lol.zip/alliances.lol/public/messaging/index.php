<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/messaging/messaging.php';

$currentUser = require_login();

$access = workspace_access(
    (int) $currentUser['id']
);

if ($access === null) {
    http_response_code(403);

    exit(
        'Workspace access required.'
    );
}

$workspaceId =
    (int) $access['workspace_id'];

$conversations =
    messaging_conversations_for_user(
        $workspaceId,
        (int) $currentUser['id']
    );

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <meta
        name="csrf-token"
        content="<?= htmlspecialchars(
            csrf_token(),
            ENT_QUOTES,
            'UTF-8'
        ) ?>"
    >

    <meta
        name="alliances-user-id"
        content="<?= (int) $currentUser['id'] ?>"
    >

    <title>Messaging - Alliances</title>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <link
        rel="stylesheet"
        href="/messaging/assets/messaging.css"
    >
</head>

<body>

<?php render_navigation($currentUser); ?>

<main class="app-main messaging-page">

    <section class="messaging-layout">

        <aside class="messaging-sidebar">

            <div class="messaging-sidebar-header">
                <h2>Messages</h2>
            

                    <button
            type="button"
            class="messaging-new-button"
            id="messaging-new-conversation"
        >
            New message
        </button>

            </div>

            <div class="messaging-conversations">

                <?php if ($conversations === []): ?>

                    <div class="messaging-empty">
                        <strong>
                            No conversations yet
                        </strong>

                        <span>
    Your direct messages, group chats,
    and channels will appear here.
</span>
                    </div>

                <?php else: ?>

                    <?php foreach ($conversations as $conversation): ?>

                        <a
                            class="messaging-conversation"
                            href="/messaging/?conversation=<?= (int) $conversation['id'] ?>"
                        >
<div class="messaging-conversation-icon">
    <?php if (
        $conversation['type'] === 'direct'
        && !empty($conversation['other_avatar_path'])
    ): ?>
        <img
            class="messaging-avatar-image"
            src="<?= htmlspecialchars(
                (string) $conversation['other_avatar_path'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
            alt=""
        >
    <?php elseif ($conversation['type'] === 'channel'): ?>
        #
    <?php elseif ($conversation['type'] === 'direct'): ?>
        D
    <?php else: ?>
        G
    <?php endif; ?>
</div>

                            <div class="messaging-conversation-info">
                                <strong>
                                    <?= htmlspecialchars(
                                        (string) $conversation['name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </strong>

<span>
    <?php if ($conversation['type'] === 'channel'): ?>
        Channel
    <?php elseif ($conversation['type'] === 'direct'): ?>
        Direct message
    <?php else: ?>
        Group chat
    <?php endif; ?>
</span>
                            </div>
                        </a>

                    <?php endforeach; ?>

                <?php endif; ?>

            </div>

        </aside>

<div
    class="messaging-conversation-view"
    id="messaging-conversation-view"
>
    <!--
        Default state shown when no conversation
        has been selected.
    -->
    <div
        class="messaging-empty-state"
        id="messaging-empty-state"
    >
        <div class="messaging-empty-icon">
            🔐
        </div>

        <h2>
            Alliances Messaging
        </h2>

        <p>
            Select a conversation to view encrypted messages.
        </p>
    </div>


    <!--
        Selected conversation.

        JavaScript fills this after:
        1. Metadata is loaded.
        2. The Key Vault is unlocked.
        3. The conversation AES key is unwrapped.
    -->
    <section
        class="messaging-active-conversation"
        id="messaging-active-conversation"
        hidden
    >
        <header class="messaging-conversation-header">
            <div class="messaging-conversation-heading">
                <div
                    class="messaging-conversation-avatar"
                    id="messaging-active-avatar"
                >
                    G
                </div>

                <div>
                    <h2 id="messaging-active-name">
                        Conversation
                    </h2>

                    <p id="messaging-active-details">
                        Encrypted conversation
                    </p>
                </div>
            </div>

<div class="messaging-conversation-header-actions">

    <button
        type="button"
        class="messaging-members-button"
        id="messaging-manage-members"
        hidden
    >
        Members
    </button>

    <div class="messaging-encryption-status">
        <span
            class="messaging-encryption-indicator"
            aria-hidden="true"
        ></span>

        <span>
            Encrypted
        </span>
    </div>

</div>
        </header>


        <div
            class="messaging-conversation-description"
            id="messaging-active-description"
            hidden
        ></div>


        <div
            class="messaging-message-area"
            id="messaging-message-area"
        >
            <div
                class="messaging-message-empty"
                id="messaging-message-empty"
            >
                <div>
                    🔐
                </div>

                <strong>
                    Conversation unlocked
                </strong>

                <p>
                    Messages in this conversation are
                    end-to-end encrypted.
                </p>
            </div>
        </div>


        <div
            class="messaging-composer-notice"
            id="messaging-composer-notice"
            hidden
        >
            Only workspace administrators can post in this channel.
        </div>

        <form
            class="messaging-composer"
            id="messaging-composer"
        >
            <textarea
                id="messaging-message-input"
                rows="1"
                maxlength="10000"
                placeholder="Write an encrypted message..."
                aria-label="Message"
                disabled
            ></textarea>

            <button
                type="submit"
                id="messaging-send-button"
                disabled
            >
                Send
            </button>
        </form>
    </section>
</div>

    </section>

</main>

<!--
|--------------------------------------------------------------------------
| New conversation dialog
|--------------------------------------------------------------------------
-->

<div
    class="messaging-modal-backdrop"
    id="messaging-new-backdrop"
    hidden
>
    <div
        class="messaging-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="messaging-new-title"
    >
        <div class="messaging-modal-header">
            <div>
                <h2 id="messaging-new-title">
                    New conversation
                </h2>

<p>
    Start an encrypted direct message,
    group chat, or channel.
</p>
            </div>

            <button
                type="button"
                class="messaging-modal-close"
                id="messaging-new-close"
                aria-label="Close"
            >
                &times;
            </button>
        </div>

        <form
            id="messaging-new-form"
            autocomplete="off"
        >
            <div class="messaging-form-field">
                <label for="messaging-conversation-type">
                    Type
                </label>

<select
    id="messaging-conversation-type"
    name="type"
    required
>
    <option value="direct">
        Direct message
    </option>

    <option value="group">
        Group chat
    </option>

    <option value="channel">
        Channel
    </option>
</select>
            </div>

<div
    class="messaging-form-field"
    id="messaging-name-field"
>
    <label for="messaging-conversation-name">
        Name
    </label>

    <input
        type="text"
        id="messaging-conversation-name"
        name="name"
        maxlength="120"
        required
    >
</div>

<div
    class="messaging-form-field"
    id="messaging-description-field"
>
    <label for="messaging-conversation-description">
        Description
    </label>

    <textarea
        id="messaging-conversation-description"
        name="description"
        maxlength="2000"
        rows="3"
    ></textarea>
</div>

            <div class="messaging-form-field">
                <div class="messaging-members-heading">
<label id="messaging-members-label">
    Members
</label>

                    <span id="messaging-member-count">
                        0 selected
                    </span>
                </div>

                <div
                    class="messaging-member-status"
                    id="messaging-member-status"
                >
                    Members will load when you open
                    this window.
                </div>

                <div
                    class="messaging-member-list"
                    id="messaging-member-list"
                ></div>
            </div>

            <div
                class="messaging-form-message"
                id="messaging-form-message"
                role="status"
                aria-live="polite"
            ></div>

            <div class="messaging-modal-actions">
                <button
                    type="button"
                    class="messaging-secondary-button"
                    id="messaging-new-cancel"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="messaging-create-button"
                    id="messaging-create-conversation"
                >
                    Create conversation
                </button>
            </div>
        </form>
    </div>
</div>

<div
    class="messaging-vault-backdrop"
    id="messaging-vault-backdrop"
    hidden
>
    <section
        class="messaging-vault-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="messaging-vault-title"
    >
        <div class="messaging-vault-header">
            <div>
                <h2 id="messaging-vault-title">
                    Unlock encrypted conversation
                </h2>

                <p>
                    Enter your Key Vault password to decrypt
                    this conversation on this device.
                </p>
            </div>

            <button
                type="button"
                class="messaging-vault-close"
                id="messaging-vault-close"
                aria-label="Close"
            >
                &times;
            </button>
        </div>

        <form id="messaging-vault-form">
            <label for="messaging-vault-password">
                Key Vault password
            </label>

            <input
                type="password"
                id="messaging-vault-password"
                autocomplete="current-password"
                required
            >

            <p
                class="messaging-vault-message"
                id="messaging-vault-message"
                aria-live="polite"
            ></p>

            <div class="messaging-vault-actions">
                <button
                    type="button"
                    class="secondary-button"
                    id="messaging-vault-cancel"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="primary-button"
                    id="messaging-vault-unlock"
                >
                    Unlock conversation
                </button>
            </div>
        </form>
    </section>
</div>

<!--
|--------------------------------------------------------------------------
| Conversation members dialog
|--------------------------------------------------------------------------
-->

<div
    class="messaging-modal-backdrop"
    id="messaging-members-backdrop"
    hidden
>
    <div
        class="messaging-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="messaging-members-title"
    >
        <div class="messaging-modal-header">
            <div>
                <h2 id="messaging-members-title">
                    Conversation members
                </h2>

                <p>
                    People who currently have access
                    to this encrypted conversation.
                </p>
            </div>

            <button
                type="button"
                class="messaging-modal-close"
                id="messaging-members-close"
                aria-label="Close"
            >
                &times;
            </button>
        </div>

<div
    class="messaging-member-list"
    id="messaging-active-member-list"
></div>

<!--
|--------------------------------------------------------------------------
| Add conversation member
|--------------------------------------------------------------------------
|
| This section is shown by JavaScript only when:
|
| - the conversation is a group or channel
| - the current user is an owner or admin
|
-->

<div
    id="messaging-add-member-section"
    hidden
>
    <div class="messaging-form-field">
        <label for="messaging-add-member-select">
            Add member
        </label>

        <select
            id="messaging-add-member-select"
            class="messaging-form-input"
        >
            <option value="">
                Select a workspace member
            </option>
        </select>
    </div>

    <button
        type="button"
        class="messaging-secondary-button"
        id="messaging-add-member-button"
    >
        Add member
    </button>
</div>

<div
    class="messaging-form-message"
    id="messaging-members-message"
    role="status"
    aria-live="polite"
></div>

<div class="messaging-modal-actions">

    <button
        type="button"
        class="messaging-secondary-button"
        id="messaging-leave-conversation"
        hidden
    >
        Leave conversation
    </button>

    <button
        type="button"
        class="messaging-secondary-button"
        id="messaging-delete-conversation"
        hidden
    >
        Delete conversation
    </button>

    <button
        type="button"
        class="messaging-secondary-button"
        id="messaging-members-done"
    >
        Done
    </button>

</div>
    </div>
</div>

<script
    type="module"
    src="/messaging/assets/messaging.js"
></script>

</body>
</html>