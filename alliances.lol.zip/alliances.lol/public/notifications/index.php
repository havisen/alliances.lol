<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/notifications.php';

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$userId = (int) $user['id'];

$filter = (string) ($_GET['filter'] ?? 'all');
$category = (string) ($_GET['category'] ?? '');
$page = max(1, (int) ($_GET['page'] ?? 1));
$limit = 50;
$offset = ($page - 1) * $limit;

$allowedCategories = [
    '',
    'tasks',
    'calendar',
    'messaging',
    'teams',
    'drive',
    'security',
    'general',
];

if (!in_array($category, $allowedCategories, true)) {
    $category = '';
}

$unreadOnly = $filter === 'unread';

$notifications = notifications_for_user(
    $workspaceId,
    $userId,
    $category !== '' ? $category : null,
    $unreadOnly,
    $limit,
    $offset
);

$unreadCount = unread_notification_count($workspaceId, $userId);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Notifications | Alliances</title>
</head>
<body>
<?php render_navigation($user); ?>

<main class="admin-page">
    <header class="admin-page-heading">
        <div>
            <p class="profile-eyebrow">Notifications</p>
            <h1>Notifications</h1>
            <p class="admin-page-description">
                Recent activity from tasks, calendar, messaging, teams, Drive, and security.
            </p>
        </div>

        <form method="post" action="/actions/notifications/mark-all-read.php">
            <?= csrf_input() ?>
            <button type="submit">Mark all as read</button>
        </form>
    </header>

    <section class="profile-section">
        <div class="profile-section-heading admin-section-heading">
            <div>
                <h2>Inbox</h2>
                <p>
                    <?= (int) $unreadCount ?> unread
                </p>
            </div>

            <a class="admin-text-action" href="/settings/?section=notifications">
                Notification settings
            </a>
        </div>

        <form class="profile-edit-form" method="get">
            <div class="profile-form-row">
                <div class="profile-form-label">
                    <label for="filter">View</label>
                    <p>Show all notifications or only unread notifications.</p>
                </div>

                <div class="profile-form-control">
                    <select id="filter" name="filter">
                        <option value="all" <?= !$unreadOnly ? 'selected' : '' ?>>All</option>
                        <option value="unread" <?= $unreadOnly ? 'selected' : '' ?>>Unread</option>
                    </select>
                </div>
            </div>

            <div class="profile-form-row">
                <div class="profile-form-label">
                    <label for="category">Category</label>
                    <p>Optional activity type filter.</p>
                </div>

                <div class="profile-form-control">
                    <select id="category" name="category">
                        <option value="">Any category</option>
                        <?php foreach (array_slice($allowedCategories, 1) as $allowedCategory): ?>
                            <option value="<?= htmlspecialchars($allowedCategory, ENT_QUOTES, 'UTF-8') ?>" <?= $category === $allowedCategory ? 'selected' : '' ?>>
                                <?= htmlspecialchars(ucfirst($allowedCategory), ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="profile-form-actions">
                <button type="submit">Apply filters</button>
            </div>
        </form>

        <?php if ($notifications === []): ?>
            <div class="profile-empty-state">
                No notifications yet.
            </div>
        <?php else: ?>
            <div class="admin-user-list">
                <?php foreach ($notifications as $notification): ?>
                    <?php
                    $isUnread = (int) $notification['is_read'] === 0;
                    $targetUrl = notification_safe_target_url($notification['target_url'] ?? null);
                    $openUrl = '/actions/notifications/open.php?id=' . (int) $notification['id'];
                    ?>
                    <article class="admin-user-row <?= $isUnread ? 'is-unread' : '' ?>">
                        <a
                            class="admin-user-profile"
                            href="<?= htmlspecialchars($targetUrl !== null ? $openUrl : '#', ENT_QUOTES, 'UTF-8') ?>"
                        >
                            <span class="admin-user-details">
                                <span class="admin-user-name">
                                    <?= htmlspecialchars($notification['title'], ENT_QUOTES, 'UTF-8') ?>

                                    <?php if ($isUnread): ?>
                                        <span class="admin-role-badge">Unread</span>
                                    <?php endif; ?>
                                </span>

                                <?php if (!empty($notification['body'])): ?>
                                    <span class="admin-user-job">
                                        <?= htmlspecialchars($notification['body'], ENT_QUOTES, 'UTF-8') ?>
                                    </span>
                                <?php endif; ?>

                                <span class="admin-user-email">
                                    <?= htmlspecialchars(
                                        ucfirst((string) $notification['category'])
                                        . ' - '
                                        . ($notification['actor_name'] ?: 'System')
                                        . ' - '
                                        . $notification['created_at'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>
                            </span>
                        </a>

                        <?php if ($isUnread): ?>
                            <form method="post" action="/actions/notifications/mark-read.php">
                                <?= csrf_input() ?>
                                <input type="hidden" name="id" value="<?= (int) $notification['id'] ?>">
                                <button type="submit">Mark read</button>
                            </form>
                        <?php endif; ?>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>
