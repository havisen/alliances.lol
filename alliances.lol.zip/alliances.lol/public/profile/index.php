<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

$currentUser = require_login();
$connection = db();

/*
|--------------------------------------------------------------------------
| Profile user
|--------------------------------------------------------------------------
*/

$userId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$userId) {
    $userId = (int) $currentUser['id'];
}

/*
|--------------------------------------------------------------------------
| Current workspace
|--------------------------------------------------------------------------
*/

$workspaceStatement = $connection->prepare(
    'SELECT workspace_id
     FROM workspace_members
     WHERE user_id = ?
     LIMIT 1'
);

$workspaceStatement->execute([
    $currentUser['id'],
]);

$workspaceId = $workspaceStatement->fetchColumn();

if ($workspaceId === false) {
    exit('No workspace is assigned to this user.');
}

$workspaceId = (int) $workspaceId;

/*
|--------------------------------------------------------------------------
| Load profile
|--------------------------------------------------------------------------
*/

$profileStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.email,
        u.avatar_path,
        u.description,
        u.job_title,
        u.time_zone,
        u.working_hours,
        u.current_status,
        u.out_of_office,
        u.out_of_office_until
     FROM users u
     INNER JOIN workspace_members wm
        ON wm.user_id = u.id
       AND wm.workspace_id = ?
     WHERE u.id = ?'
);

$profileStatement->execute([
    $workspaceId,
    $userId,
]);

$profile = $profileStatement->fetch();

if (!$profile) {
    http_response_code(404);
    exit('Profile not found.');
}

$isOwnProfile =
    (int) $profile['id']
    === (int) $currentUser['id'];

/*
|--------------------------------------------------------------------------
| Teams for this profile
|--------------------------------------------------------------------------
*/

$teamsStatement = $connection->prepare(
    'SELECT
        t.id,
        t.name,
        t.team_lead_id,
        lead.display_name AS team_lead_name,
        lead.job_title AS team_lead_job_title,
        lead.avatar_path AS team_lead_avatar
     FROM teams t
     LEFT JOIN users lead
        ON lead.id = t.team_lead_id
     WHERE t.workspace_id = ?
       AND (
            t.team_lead_id = ?
            OR EXISTS (
                SELECT 1
                FROM team_members tm
                WHERE tm.team_id = t.id
                  AND tm.user_id = ?
            )
       )
     ORDER BY t.name ASC'
);

$teamsStatement->execute([
    $workspaceId,
    $profile['id'],
    $profile['id'],
]);

$profileTeams = $teamsStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Members for each team
|--------------------------------------------------------------------------
*/

$teamMembersStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.job_title,
        u.avatar_path
     FROM users u
     INNER JOIN workspace_members wm
        ON wm.user_id = u.id
       AND wm.workspace_id = ?
     WHERE u.id = ?
        OR EXISTS (
            SELECT 1
            FROM team_members tm
            WHERE tm.team_id = ?
              AND tm.user_id = u.id
        )
     ORDER BY
        CASE
            WHEN u.id = ? THEN 0
            ELSE 1
        END,
        u.display_name ASC'
);

foreach ($profileTeams as &$team) {
    $teamMembersStatement->execute([
        $workspaceId,
        $team['team_lead_id'],
        $team['id'],
        $team['team_lead_id'],
    ]);

    $team['members'] =
        $teamMembersStatement->fetchAll();
}

unset($team);

$statusLabels = [
    'available' => 'Available',
    'busy' => 'Busy',
    'dnd' => 'Do Not Disturb',
];

$profileStatus =
    $statusLabels[(string) ($profile['current_status'] ?? 'available')]
    ?? 'Available';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>
        <?= htmlspecialchars(
            $profile['display_name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?>
        | Alliances
    </title>
</head>
<body>
<?php render_navigation($currentUser); ?>

    <main class="profile-page">
        <header class="profile-page-heading">
            <div>
                <p class="profile-eyebrow">
                    <?= $isOwnProfile ? 'Your profile' : 'Team member' ?>
                </p>

                <h1>
                    <?= $isOwnProfile
                        ? 'Profile'
                        : htmlspecialchars(
                            $profile['display_name'],
                            ENT_QUOTES,
                            'UTF-8'
                        )
                    ?>
                </h1>

                <p class="profile-page-description">
                    <?= $isOwnProfile
                        ? 'This is the profile other people in your workspace see.'
                        : 'View this team member\'s profile and organization details.'
                    ?>
                </p>
            </div>
            <?php if ($isOwnProfile): ?>
                <a class="secondary-action" href="/settings/?section=profile">
                    Profile settings
                </a>
            <?php else: ?>
                <a
                    class="primary-action"
                    href="/messaging/?start_direct=<?= (int) $profile['id'] ?>"
                >
                    Message
                </a>
            <?php endif; ?>
        </header>

        <section class="profile-summary-card">
            <div class="profile-summary-avatar">
                <?php if (!empty($profile['avatar_path'])): ?>
                    <img
                        class="profile-avatar"
                        src="<?= htmlspecialchars(
                            $profile['avatar_path'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        alt=""
                    >
                <?php else: ?>
                    <div class="profile-avatar profile-avatar-placeholder">
                        <?= htmlspecialchars(
                            strtoupper(
                                substr($profile['display_name'], 0, 1)
                            ),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="profile-summary-details">
                <h2>
                    <?= htmlspecialchars(
                        $profile['display_name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h2>

                <?php if (!empty($profile['job_title'])): ?>
                    <p class="profile-job-title">
                        <?= htmlspecialchars(
                            $profile['job_title'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </p>
                <?php endif; ?>

                <a
                    class="profile-email"
                    href="mailto:<?= htmlspecialchars(
                        $profile['email'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                >
                    <?= htmlspecialchars(
                        $profile['email'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </a>
            </div>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Work profile</h2>
                    <p>
                        Public organization details for this workspace.
                    </p>
                </div>
            </div>

            <div class="profile-detail-grid">
                <div class="profile-detail-card">
                    <span>Status</span>
                    <strong><?= htmlspecialchars($profileStatus, ENT_QUOTES, 'UTF-8') ?></strong>
                </div>

                <div class="profile-detail-card">
                    <span>Time zone</span>
                    <strong><?= htmlspecialchars((string) ($profile['time_zone'] ?: 'UTC'), ENT_QUOTES, 'UTF-8') ?></strong>
                </div>

                <div class="profile-detail-card">
                    <span>Working hours</span>
                    <strong><?= htmlspecialchars((string) ($profile['working_hours'] ?: 'Not set'), ENT_QUOTES, 'UTF-8') ?></strong>
                </div>

                <div class="profile-detail-card">
                    <span>Out of Office</span>
                    <strong>
                        <?= (int) ($profile['out_of_office'] ?? 0) === 1
                            ? 'Yes'
                            : 'No'
                        ?>
                    </strong>
                    <?php if ((int) ($profile['out_of_office'] ?? 0) === 1 && !empty($profile['out_of_office_until'])): ?>
                        <small>
                            Until <?= htmlspecialchars((string) $profile['out_of_office_until'], ENT_QUOTES, 'UTF-8') ?>
                        </small>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <?php if (!empty($profile['description'])): ?>
            <section class="profile-section">
                <div class="profile-section-heading">
                    <div>
                        <h2>About</h2>
                    </div>
                </div>

                <div class="profile-about">
                    <?= nl2br(htmlspecialchars(
                        $profile['description'],
                        ENT_QUOTES,
                        'UTF-8'
                    )) ?>
                </div>
            </section>
        <?php endif; ?>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Teams</h2>
                    <p>
                        Teams and organization structure for this profile.
                    </p>
                </div>
            </div>

            <?php if ($profileTeams === []): ?>
                <div class="profile-empty-state">
                    This user is not currently assigned to a team.
                </div>
            <?php else: ?>
                <div class="profile-teams">
                    <?php foreach ($profileTeams as $team): ?>
                        <article class="profile-team-card">
                            <div class="profile-team-heading">
                                <div>
                                    <span class="profile-team-label">Team</span>
                                    <h3>
                                        <?= htmlspecialchars(
                                            $team['name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </h3>
                                </div>
                            </div>

                            <?php if ($team['team_lead_id']): ?>
                                <div class="profile-team-lead">
                                    <p class="profile-team-role">
                                        Team Lead
                                    </p>

                                    <a
                                        class="profile-person"
                                        href="/profile/?id=<?= (int) $team['team_lead_id'] ?>"
                                    >
                                        <?php if (!empty($team['team_lead_avatar'])): ?>
                                            <img
                                                class="org-avatar"
                                                src="<?= htmlspecialchars(
                                                    $team['team_lead_avatar'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>"
                                                alt=""
                                            >
                                        <?php else: ?>
                                            <span class="org-avatar org-avatar-placeholder">
                                                <?= htmlspecialchars(
                                                    strtoupper(
                                                        substr(
                                                            $team['team_lead_name']
                                                                ?? '?',
                                                            0,
                                                            1
                                                        )
                                                    ),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </span>
                                        <?php endif; ?>

                                        <span class="profile-person-details">
                                            <strong>
                                                <?= htmlspecialchars(
                                                    $team['team_lead_name']
                                                        ?? 'Unknown user',
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                            <?php if (!empty($team['team_lead_job_title'])): ?>
                                                <small>
                                                    <?= htmlspecialchars(
                                                        $team['team_lead_job_title'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </small>
                                            <?php endif; ?>
                                        </span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <div class="profile-team-members">
                                <p class="profile-team-role">
                                    Team members
                                </p>

                                <div class="profile-member-grid">
                                    <?php foreach ($team['members'] as $member): ?>
                                        <a
                                            class="profile-person profile-member"
                                            href="/profile/?id=<?= (int) $member['id'] ?>"
                                        >
                                            <?php if (!empty($member['avatar_path'])): ?>
                                                <img
                                                    class="org-avatar"
                                                    src="<?= htmlspecialchars(
                                                        $member['avatar_path'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>"
                                                    alt=""
                                                >
                                            <?php else: ?>
                                                <span class="org-avatar org-avatar-placeholder">
                                                    <?= htmlspecialchars(
                                                        strtoupper(
                                                            substr(
                                                                $member['display_name'],
                                                                0,
                                                                1
                                                            )
                                                        ),
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </span>
                                            <?php endif; ?>

                                            <span class="profile-person-details">
                                                <strong>
                                                    <?= htmlspecialchars(
                                                        $member['display_name'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </strong>

                                                <?php if (!empty($member['job_title'])): ?>
                                                    <small>
                                                        <?= htmlspecialchars(
                                                            $member['job_title'],
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>
                                                    </small>
                                                <?php endif; ?>
                                            </span>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>
