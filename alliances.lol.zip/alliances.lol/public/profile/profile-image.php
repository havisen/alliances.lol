<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

require_login();

$requestedFile = (string) ($_GET['file'] ?? '');

if ($requestedFile === '') {
    http_response_code(404);
    exit;
}

/*
|--------------------------------------------------------------------------
| Resolve requested profile image
|--------------------------------------------------------------------------
|
| Two kinds of profile images are supported:
|
| 1. Uploaded avatars
|       abc123.png
|
| 2. Built-in avatars
|       basic/1.png
|       ...
|       basic/8.png
|
| Never allow arbitrary paths from the request.
|
*/

if (
    preg_match(
        '#^basic/([1-8])\.png$#',
        $requestedFile,
        $matches
    ) === 1
) {
    /*
     * Explicitly approved built-in avatar.
     */
    $filename =
        'basic/'
        . $matches[1]
        . '.png';
} else {
    /*
     * User-uploaded avatars must be plain filenames.
     *
     * basename() prevents directory traversal.
     */
    $filename = basename($requestedFile);

    if (
        $filename === ''
        || $filename !== $requestedFile
    ) {
        http_response_code(404);
        exit;
    }
}

$file =
    dirname(__DIR__, 2)
    . '/storage/profile-images/'
    . $filename;

if (!is_file($file)) {
    http_response_code(404);
    exit;
}

$mime = mime_content_type($file);

$allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/webp',
];

if (!in_array($mime, $allowedTypes, true)) {
    http_response_code(403);
    exit;
}

header('Content-Type: ' . $mime);

header(
    'Cache-Control: private, max-age=3600'
);

header(
    'X-Content-Type-Options: nosniff'
);

readfile($file);