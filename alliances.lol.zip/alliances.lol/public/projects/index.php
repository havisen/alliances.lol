<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/projects.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];
$isAdmin = !empty($access['is_admin']);

$showArchived =
    isset($_GET['archived'])
    && $_GET['archived'] === '1';

/*
|--------------------------------------------------------------------------
| Projects visible to the current user
|--------------------------------------------------------------------------
|
| - Workspace Admins see every Project in the workspace.
| - Everyone else sees only the Projects where they have effective
|   membership (direct project_members or a synchronized attached team).
|
| These rules live in src/projects.php, so this page never duplicates the
| authorization SQL.
*/

$projects = $isAdmin
    ? projects_for_workspace($workspaceId, $showArchived)
    : projects_for_user($workspaceId, (int) $user['id'], $showArchived);

/*
|--------------------------------------------------------------------------
| Date helper
|--------------------------------------------------------------------------
*/

function projects_page_date(?string $value): string
{
    if ($value === null || trim($value) === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date('M j, Y', $timestamp);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Projects | Alliances</title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main projects-page">
    <div class="page-container">

        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">Projects</h1>
                <p class="page-description">Work delivered as focused, shared efforts.</p>
            </div>
        </header>

    <?php if ($isAdmin): ?>

        <!-- CREATE PROJECT -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Create project</h2>
            </div>

            <form
                method="post"
                action="/actions/projects/create.php"
                class="form"
            >
                <?= csrf_input() ?>

                <div class="form-group">
                    <label class="form-label" for="project-name">
                        Project name
                    </label>
                    <input
                        type="text"
                        id="project-name"
                        name="name"
                        maxlength="150"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="project-description">
                        Description (optional)
                    </label>
                    <textarea
                        id="project-description"
                        name="description"
                        rows="3"
                    ></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="project-start-date">
                            Start date (optional)
                        </label>
                        <input
                            type="date"
                            id="project-start-date"
                            name="start_date"
                        >
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="project-target-date">
                            Target date (optional)
                        </label>
                        <input
                            type="date"
                            id="project-target-date"
                            name="target_date"
                        >
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="primary-action">
                        Create project
                    </button>
                </div>
            </form>
        </section>

    <?php endif; ?>

    <!-- PROJECT LIST -->

    <section class="section">
        <div class="section-header">
            <h2 class="section-title"><?= $showArchived ? 'All projects' : 'Projects' ?></h2>

            <div class="section-actions">
                <a
                    href="/projects/index.php<?= $showArchived ? '' : '?archived=1' ?>"
                    class="secondary-action"
                >
                    <?= $showArchived ? 'Hide archived' : 'Show archived' ?>
                </a>
            </div>
        </div>

        <?php if ($projects === []): ?>

            <p class="empty-state">
                <?= $showArchived
                    ? 'No archived projects.'
                    : 'No projects yet.' ?>
            </p>

        <?php else: ?>

            <div class="record-list">

                <?php foreach ($projects as $project): ?>

                    <?php
                    $projectStartDate = projects_page_date(
                        $project['start_date'] ?? null
                    );
                    $projectTargetDate = projects_page_date(
                        $project['target_date'] ?? null
                    );
                    $projectStatus = (string) ($project['status'] ?? '');
                    ?>

                    <article class="record">
                        <h3 class="record-title">
                            <a href="/projects/project.php?id=<?= (int) $project['id'] ?>">
                                <?= htmlspecialchars(
                                    (string) $project['name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </a>
                        </h3>

                        <?php if (!empty($project['description'])): ?>

                            <p class="record-description">
                                <?= nl2br(
                                    htmlspecialchars(
                                        (string) $project['description'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    )
                                ) ?>
                            </p>

                        <?php endif; ?>

                        <div class="record-meta">
                            <div class="record-meta-item">
                                <span>Status</span>
                                <strong>
                                    <?= htmlspecialchars(
                                        $projectStatus,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </strong>
                            </div>

                            <div class="record-meta-item">
                                <span>Start</span>
                                <strong>
                                    <?= $projectStartDate !== ''
                                        ? htmlspecialchars(
                                            $projectStartDate,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        )
                                        : 'Not set' ?>
                                </strong>
                            </div>

                            <div class="record-meta-item">
                                <span>Target</span>
                                <strong>
                                    <?= $projectTargetDate !== ''
                                        ? htmlspecialchars(
                                            $projectTargetDate,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        )
                                        : 'Not set' ?>
                                </strong>
                            </div>
                        </div>
                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>
    </section>

    </div>

</main>

</body>
</html>