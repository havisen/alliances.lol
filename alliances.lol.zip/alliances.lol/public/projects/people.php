<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/projects.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Project lookup (workspace-scoped)
|--------------------------------------------------------------------------
|
| The id comes straight from the query string and is treated as untrusted.
| The Project is always resolved against the authenticated user's current
| workspace via project_by_id(), so a Project in another workspace simply
| appears as not found.
*/

$projectId = (int) filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

$project = project_by_id($projectId, $workspaceId);

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
|
| View and management permission are delegated to src/projects.php so the
| membership rules are never duplicated on this page.
*/

$userId = (int) $user['id'];
$projectId = (int) $project['id'];

if (!project_user_can_view($access, $userId, $projectId)) {
    http_response_code(403);
    exit('You do not have access to this project.');
}

$canManage = project_user_can_manage($access, $userId, $projectId);

/*
|--------------------------------------------------------------------------
| Membership data
|--------------------------------------------------------------------------
*/

$projectLeads = project_leads($projectId, $workspaceId);
$directMembers = project_direct_members($projectId, $workspaceId);
$attachedTeams = project_attached_teams($projectId, $workspaceId);
$effectiveMembers = project_effective_members($projectId, $workspaceId);

$errorMessage = '';

if (isset($_GET['error']) && is_string($_GET['error'])) {
    $errorMessage = trim($_GET['error']);
}

/*
|--------------------------------------------------------------------------
| Management selectors
|--------------------------------------------------------------------------
|
| Read-only workspace queries only. All project membership rules and
| validation remain in src/projects.php.
*/

$eligibleUsers = [];
$eligibleTeams = [];

if ($canManage) {
    $connection = db();

    $usersStatement = $connection->prepare(
        'SELECT
            u.id,
            u.display_name
         FROM users u
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id
         WHERE wm.workspace_id = ?
           AND u.account_status = "active"
         ORDER BY u.display_name COLLATE NOCASE ASC, u.id ASC'
    );

    $usersStatement->execute([$workspaceId]);

    $eligibleUsers = $usersStatement->fetchAll();

    $teamsStatement = $connection->prepare(
        'SELECT
            t.id,
            t.name
         FROM teams t
         WHERE t.workspace_id = ?
           AND t.status = "active"
         ORDER BY t.name COLLATE NOCASE ASC, t.id ASC'
    );

    $teamsStatement->execute([$workspaceId]);

    $eligibleTeams = $teamsStatement->fetchAll();
}

$attachedTeamIds = array_map(
    static function (array $team): int {
        return (int) $team['team_id'];
    },
    $attachedTeams
);

$eligibleTeams = array_values(array_filter(
    $eligibleTeams,
    static function (array $team) use ($attachedTeamIds): bool {
        return !in_array((int) $team['id'], $attachedTeamIds, true);
    }
));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        People | <?= htmlspecialchars(
            (string) $project['name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?> | Alliances
    </title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main projects-page">
    <div class="page-container">

        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">People</h1>

                <p class="page-description">
                    <?= htmlspecialchars(
                        (string) $project['name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </p>
            </div>

            <div class="page-header-actions">
                <a
                    class="secondary-action"
                    href="/projects/project.php?id=<?= $projectId ?>"
                >
                    &larr; Back to Project
                </a>
            </div>
        </header>

        <?php if ($errorMessage !== ''): ?>

            <p class="form-message form-message-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php endif; ?>

<!-- PROJECT LEADS -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Project Leads</h2>
            </div>

            <?php if ($projectLeads === []): ?>

                <p class="empty-state">No project leads.</p>

            <?php else: ?>

                <ul class="stack">
                    <?php foreach ($projectLeads as $lead): ?>

                        <li>
                            <?= alliances_profile_link(
                                (int) $lead['user_id'],
                                (string) $lead['display_name'],
                                'profile-link'
                            ) ?>

                            <span>Project Lead</span>
                        </li>

                    <?php endforeach; ?>
                </ul>

            <?php endif; ?>
        </section>

        <!-- DIRECT MEMBERS -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Direct Members</h2>
            </div>

            <?php if ($directMembers === []): ?>

                <p class="empty-state">No direct members.</p>

            <?php else: ?>

                <ul class="stack">
                    <?php foreach ($directMembers as $member): ?>

                        <?php $memberRole = (string) ($member['role'] ?? 'member'); ?>

                        <li>
                            <div>
                                <?= alliances_profile_link(
                                    (int) $member['user_id'],
                                    (string) $member['display_name'],
                                    'profile-link'
                                ) ?>

                                <span>
                                    <?= $memberRole === 'lead'
                                        ? 'Project Lead'
                                        : 'Member' ?>
                                </span>
                            </div>

                            <?php if ($canManage): ?>

                                <form
                                    method="post"
                                    action="/actions/projects/update-member-role.php"
                                    class="form"
                                >
                                    <?= csrf_input() ?>

                                    <input
                                        type="hidden"
                                        name="project_id"
                                        value="<?= $projectId ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="user_id"
                                        value="<?= (int) $member['user_id'] ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="role"
                                        value="<?= $memberRole === 'lead'
                                            ? 'member'
                                            : 'lead' ?>"
                                    >

                                    <button class="secondary-action" type="submit">
                                        <?= $memberRole === 'lead'
                                            ? 'Make Member'
                                            : 'Make Project Lead' ?>
                                    </button>
                                </form>

                                <form
                                    method="post"
                                    action="/actions/projects/remove-member.php"
                                    class="form"
                                >
                                    <?= csrf_input() ?>

                                    <input
                                        type="hidden"
                                        name="project_id"
                                        value="<?= $projectId ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="user_id"
                                        value="<?= (int) $member['user_id'] ?>"
                                    >

                                    <button class="secondary-action" type="submit">
                                        Remove
                                    </button>
                                </form>

                            <?php endif; ?>
                        </li>

                    <?php endforeach; ?>
                </ul>

            <?php endif; ?>
        </section>

        <!-- ATTACHED TEAMS -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Attached Teams</h2>
            </div>

            <?php if ($attachedTeams === []): ?>

                <p class="empty-state">No teams attached.</p>

            <?php else: ?>

                <ul class="stack">
                    <?php foreach ($attachedTeams as $team): ?>

                        <li>
                            <div>
                                <?= alliances_team_link(
                                    (int) $team['team_id'],
                                    (string) $team['team_name'],
                                    'team-link'
                                ) ?>

                                <span>Synchronized</span>
                            </div>

                            <?php if ($canManage): ?>

                                <form
                                    method="post"
                                    action="/actions/projects/detach-team.php"
                                    class="form"
                                >
                                    <?= csrf_input() ?>

                                    <input
                                        type="hidden"
                                        name="project_id"
                                        value="<?= $projectId ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="team_id"
                                        value="<?= (int) $team['team_id'] ?>"
                                    >

                                    <button class="secondary-action" type="submit">
                                        Detach
                                    </button>
                                </form>

                            <?php endif; ?>
                        </li>

                    <?php endforeach; ?>
                </ul>

            <?php endif; ?>
        </section>

        <!-- EFFECTIVE MEMBERS -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Effective Members</h2>
            </div>

            <?php if ($effectiveMembers === []): ?>

                <p class="empty-state">No effective members.</p>

            <?php else: ?>

                <ul class="stack">
                    <?php foreach ($effectiveMembers as $member): ?>

                        <li>
                            <?= alliances_profile_link(
                                (int) $member['user_id'],
                                (string) $member['display_name'],
                                'profile-link'
                            ) ?>

                            <?php if (!empty($member['is_lead'])): ?>

                                <span>Project Lead</span>

                            <?php endif; ?>

                            <?php if (!empty($member['team_memberships'])): ?>

                                <?php $teamNames = array_map(
                                    static function (array $team): string {
                                        return (string) $team['team_name'];
                                    },
                                    $member['team_memberships']
                                ); ?>

                                <span>
                                    via <?= htmlspecialchars(
                                        implode(', ', $teamNames),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>

                            <?php endif; ?>
                        </li>

                    <?php endforeach; ?>
                </ul>

            <?php endif; ?>
        </section>

        <?php if ($canManage): ?>

            <!-- ADD DIRECT MEMBER -->

            <section class="section">
                <div class="section-header">
                    <h2 class="section-title">Add Project Member</h2>
                </div>

                <?php if ($eligibleUsers === []): ?>

                    <p class="empty-state">
                        No active workspace members available.
                    </p>

                <?php else: ?>

                    <form
                        method="post"
                        action="/actions/projects/add-member.php"
                        class="form"
                    >
                        <?= csrf_input() ?>

                        <input
                            type="hidden"
                            name="project_id"
                            value="<?= $projectId ?>"
                        >

                        <div class="form-row">
                            <div class="form-group">
                                <label
                                    class="form-label"
                                    for="add-member-user"
                                >
                                    Person
                                </label>

                                <select id="add-member-user" name="user_id" required>
                                    <option value="">
                                        Select a workspace member
                                    </option>

                                    <?php foreach ($eligibleUsers as $eligibleUser): ?>

                                        <option value="<?= (int) $eligibleUser['id'] ?>">
                                            <?= htmlspecialchars(
                                                (string) $eligibleUser['display_name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </option>

                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label
                                    class="form-label"
                                    for="add-member-role"
                                >
                                    Role
                                </label>

                                <select id="add-member-role" name="role">
                                    <option value="member">Member</option>
                                    <option value="lead">Project Lead</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-actions">
                            <button class="primary-action" type="submit">
                                Add member
                            </button>
                        </div>
                    </form>

                <?php endif; ?>
            </section>

            <!-- ATTACH TEAM -->

            <section class="section">
                <div class="section-header">
                    <h2 class="section-title">Attach Team</h2>
                </div>

                <?php if ($eligibleTeams === []): ?>

                    <p class="empty-state">
                        No additional active teams available.
                    </p>

                <?php else: ?>

                    <form
                        method="post"
                        action="/actions/projects/attach-team.php"
                        class="form"
                    >
                        <?= csrf_input() ?>

                        <input
                            type="hidden"
                            name="project_id"
                            value="<?= $projectId ?>"
                        >

                        <div class="form-group">
                            <label
                                class="form-label"
                                for="attach-team-select"
                            >
                                Team
                            </label>

                            <select id="attach-team-select" name="team_id" required>
                                <option value="">
                                    Select an active team
                                </option>

                                <?php foreach ($eligibleTeams as $eligibleTeam): ?>

                                    <option value="<?= (int) $eligibleTeam['id'] ?>">
                                        <?= htmlspecialchars(
                                            (string) $eligibleTeam['name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </option>

                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button class="primary-action" type="submit">
                                Attach team
                            </button>
                        </div>
                    </form>

                <?php endif; ?>
            </section>

        <?php endif; ?>

    </div>
</main>

</body>
</html>