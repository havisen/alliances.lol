<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/projects.php';
require_once dirname(__DIR__, 2) . '/src/tasks/lists.php';
require_once dirname(__DIR__, 2) . '/src/projects/overview.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Project lookup (workspace-scoped)
|--------------------------------------------------------------------------
|
| The id comes straight from the query string and is treated as untrusted.
| We do not query by id alone; the Project is always resolved against the
| authenticated user's current workspace via project_by_id(), so a Project
| in another workspace simply appears as not found.
*/

$projectId = (int) filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

$project = project_by_id($projectId, $workspaceId);

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

/*
|--------------------------------------------------------------------------
| Authorization
|--------------------------------------------------------------------------
|
| View and management permission are delegated to src/projects.php so the
| membership rules are never duplicated on this page.
*/

$userId = (int) $user['id'];
$projectId = (int) $project['id'];

if (!project_user_can_view($access, $userId, $projectId)) {
    http_response_code(403);
    exit('You do not have access to this project.');
}

$canManage = project_user_can_manage($access, $userId, $projectId) && project_is_writable($project);

/*
|--------------------------------------------------------------------------
| Overview bootstrap + active page
|--------------------------------------------------------------------------
*/

// Overview reads never seed or change persisted configuration.

$overviewPageKey = filter_input(INPUT_GET, 'page', FILTER_DEFAULT);
$overviewPageKey = is_string($overviewPageKey) ? $overviewPageKey : null;

$overviewPages = project_overview_pages($projectId);
$activePage = null;

if ($overviewPageKey !== null && trim($overviewPageKey) !== '') {
    foreach ($overviewPages as $candidatePage) {
        if (hash_equals((string) $candidatePage['page_key'], $overviewPageKey)) {
            $activePage = $candidatePage;
            break;
        }
    }
}

if ($activePage === null) {
    $activePage = project_overview_default_page($projectId);
}

if ($activePage !== null) {
    $activePage['modules'] = project_overview_modules($projectId, (int) $activePage['id']);
}

$overviewErrorMessage = (string) filter_input(INPUT_GET, 'error', FILTER_DEFAULT);

/*
|--------------------------------------------------------------------------
| Display helpers
|--------------------------------------------------------------------------
*/

function project_detail_date(?string $value): string
{
    if ($value === null || trim($value) === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date('M j, Y', $timestamp);
}

function project_detail_datetime(?string $value): string
{
    if ($value === null || trim($value) === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date('M j, Y g:i A', $timestamp);
}

function project_detail_status_label(string $status): string
{
    $labels = [
        'planning' => 'Planning',
        'active' => 'Active',
        'on_hold' => 'On Hold',
        'completed' => 'Completed',
        'archived' => 'Archived',
    ];

    return $labels[$status] ?? $status;
}

function project_detail_health_label(string $health): string
{
    $labels = [
        'unknown' => 'Health unknown',
        'on_track' => 'On track',
        'at_risk' => 'At risk',
        'off_track' => 'Off track',
    ];

    return $labels[$health] ?? 'Health unknown';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/project-overview.css">
    <link rel="stylesheet" href="/assets/css/app.css">

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title><?= htmlspecialchars(
        (string) $project['name'],
        ENT_QUOTES,
        'UTF-8'
    ) ?> | Alliances</title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main projects-page">
    <div class="page-container">

        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">
                    <?php if (($project['icon'] ?? null) !== null): ?>
                        <span
                            class="badge"
                            title="Project icon"
                            <?php if (($project['color'] ?? null) !== null): ?>
                                style="border-color: <?= htmlspecialchars((string) $project['color'], ENT_QUOTES, 'UTF-8') ?>"
                            <?php endif; ?>
                        >
                            <?= htmlspecialchars((string) $project['icon'], ENT_QUOTES, 'UTF-8') ?>
                        </span>
                    <?php endif; ?>

                    <?= htmlspecialchars(
                        (string) $project['name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h1>

                <p class="page-description">
                    <?= htmlspecialchars(
                        project_detail_status_label((string) $project['status']),
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                    &middot;
                    <?= htmlspecialchars(
                        project_detail_health_label((string) ($project['health'] ?? 'unknown')),
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </p>
            </div>

            <div class="page-header-actions">
                <a class="secondary-action" href="/projects/">
                    &larr; All projects
                </a>

                <a
                    class="secondary-action"
                    href="/projects/people.php?id=<?= $projectId ?>"
                >
                    Manage people &rarr;
                </a>
            </div>
        </header>
<!-- OVERVIEW PAGES -->

<?php if ($overviewPages === []): ?>

    <section class="section">
        <div class="section-header">
            <h2 class="section-title">Overview</h2>
        </div>

        <p class="empty-state">No overview pages are configured yet.</p>
    </section>

<?php elseif ($activePage !== null): ?>

    <nav class="cluster" aria-label="Project overview pages">
        <?php foreach ($overviewPages as $overviewPage): ?>

            <a
                class="<?= ((string) $overviewPage['page_key'] === (string) $activePage['page_key'])
                    ? 'primary-action'
                    : 'secondary-action' ?>"
                href="/projects/project.php?id=<?= $projectId ?>&page=<?= htmlspecialchars(
                    (string) $overviewPage['page_key'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
            >
                <?= htmlspecialchars(
                    (string) $overviewPage['title'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </a>

        <?php endforeach; ?>
    </nav>

    <?php if ($overviewErrorMessage !== ''): ?>

        <p class="form-message form-message-error">
            <?= htmlspecialchars($overviewErrorMessage, ENT_QUOTES, 'UTF-8') ?>
        </p>

    <?php endif; ?>

    <?php project_overview_render_page(
        $workspaceId,
        $projectId,
        $userId,
        $project,
        $activePage,
        $canManage
    ); ?>

<?php else: ?>

    <section class="section">
        <div class="section-header">
            <h2 class="section-title">Overview</h2>
        </div>
        <p class="empty-state">No active overview page is available.</p>
    </section>

<?php endif; ?>

<?php if ($canManage): ?>

    <?php if ($activePage !== null): ?>
        <?php project_overview_manager($projectId, $workspaceId, $userId, $activePage); ?>
    <?php endif; ?>

        <!-- EDIT PROJECT -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Edit project</h2>
            </div>

            <form
                method="post"
                action="/actions/projects/update.php"
                class="form"
            >
                <?= csrf_input() ?>

                <input
                    type="hidden"
                    name="project_id"
                    value="<?= $projectId ?>"
                >

                <div class="form-group">
                    <label class="form-label" for="project-name">
                        Project name
                    </label>
                    <input
                        type="text"
                        id="project-name"
                        name="name"
                        maxlength="150"
                        value="<?= htmlspecialchars(
                            (string) $project['name'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="project-description">
                        Description (optional)
                    </label>
                    <textarea id="project-description" name="description" rows="3"><?= htmlspecialchars(
                        (string) ($project['description'] ?? ''),
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="project-start-date">
                            Start date (optional)
                        </label>
                        <input
                            type="date"
                            id="project-start-date"
                            name="start_date"
                            value="<?= htmlspecialchars(
                                (string) ($project['start_date'] ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="project-target-date">
                            Target date (optional)
                        </label>
                        <input
                            type="date"
                            id="project-target-date"
                            name="target_date"
                            value="<?= htmlspecialchars(
                                (string) ($project['target_date'] ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="project-icon">Icon (optional)</label>
                        <select id="project-icon" name="icon">
                            <option value="">No icon</option>
                            <?php foreach (project_icon_list() as $icon): ?>
                                <option value="<?= htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') ?>" <?= ((string) ($project['icon'] ?? '') === $icon) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars(ucwords(str_replace('-', ' ', $icon)), ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="project-color">Color (optional)</label>
                        <input
                            type="color"
                            id="project-color"
                            name="color"
                            value="<?= htmlspecialchars((string) ($project['color'] ?? '#64748B'), ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="project-health">Health</label>
                        <select id="project-health" name="health">
                            <?php foreach (project_health_list() as $health): ?>
                                <option value="<?= htmlspecialchars($health, ENT_QUOTES, 'UTF-8') ?>" <?= ((string) ($project['health'] ?? 'unknown') === $health) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars(project_detail_health_label($health), ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="primary-action">
                        Save changes
                    </button>
                </div>
            </form>
        </section>

        <!-- Overview page/module management is rendered by project_overview_manager(). -->

        <!-- CHANGE STATUS -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Change status</h2>
            </div>

            <form
                method="post"
                action="/actions/projects/set-status.php"
                class="form"
            >
                <?= csrf_input() ?>

                <input
                    type="hidden"
                    name="project_id"
                    value="<?= $projectId ?>"
                >

                <div class="form-group">
                    <label class="form-label" for="project-status">
                        Status
                    </label>
                    <select id="project-status" name="status">
                        <?php foreach (project_status_list() as $status): ?>

                            <option
                                value="<?= htmlspecialchars(
                                    $status,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                                <?= ((string) $project['status'] === $status)
                                    ? 'selected'
                                    : '' ?>
                            >
                                <?= htmlspecialchars(
                                    project_detail_status_label($status),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </option>

                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-actions">
                    <button type="submit" class="primary-action">
                        Update status
                    </button>
                </div>
            </form>
        </section>

    <?php endif; ?>

    </div>
</main>

</body>
</html>
