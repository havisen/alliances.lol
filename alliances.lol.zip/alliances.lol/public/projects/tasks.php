<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/projects.php';
require_once dirname(__DIR__, 2) . '/src/tasks/lists.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$projectId = (int) filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

$project = project_by_id($projectId, $workspaceId);

if ($project === null) {
    http_response_code(404);
    exit('Project not found.');
}

$userId = (int) $user['id'];
$projectId = (int) $project['id'];

if (!project_user_can_view($access, $userId, $projectId)) {
    http_response_code(403);
    exit('You do not have access to this project.');
}

$canManage = project_user_can_manage($access, $userId, $projectId);
$isArchived = (string) $project['status'] === 'archived';
$canModify = $canManage && !$isArchived;

$errorMessage = '';

if (isset($_GET['error']) && is_string($_GET['error'])) {
    $errorMessage = trim($_GET['error']);
}

/* Task Lists visible to this user under the existing task_list_members rule. */
$taskLists = project_task_lists_visible($workspaceId, $projectId, $userId);

$attachableLists = [];
$workspaceUsers = [];
$workspaceTeams = [];

if ($canModify) {
    $attachableLists = task_lists_attachable(
        $workspaceId,
        $userId,
        !empty($access['is_admin'])
    );

    $teamsStatement = db()->prepare(
        'SELECT id, name
         FROM teams
         WHERE workspace_id = ?
           AND status = "active"
         ORDER BY name COLLATE NOCASE ASC, id ASC'
    );

    $teamsStatement->execute([$workspaceId]);
    $workspaceTeams = $teamsStatement->fetchAll();

    $usersStatement = db()->prepare(
        'SELECT u.id, u.display_name
         FROM users u
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id
         WHERE wm.workspace_id = ?
           AND u.account_status = "active"
         ORDER BY u.display_name COLLATE NOCASE ASC, u.id ASC'
    );

    $usersStatement->execute([$workspaceId]);
    $workspaceUsers = $usersStatement->fetchAll();
}

function project_task_status_label(string $status): string
{
    return $status === 'completed' ? 'Completed' : 'Active';
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        Task lists | <?= htmlspecialchars(
            (string) $project['name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?> | Alliances
    </title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main projects-page">
    <div class="page-container">

        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">Task lists</h1>

                <p class="page-description">
                    <?= htmlspecialchars(
                        (string) $project['name'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </p>
            </div>

            <div class="page-header-actions">
                <a
                    class="secondary-action"
                    href="/projects/project.php?id=<?= $projectId ?>"
                >
                    &larr; Back to Project
                </a>
            </div>
        </header>

        <?php if ($errorMessage !== ''): ?>

            <p class="form-message form-message-error">
                <?= htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php endif; ?>

        <?php if ($isArchived): ?>

            <p class="form-message form-message-error">
                This project is archived, so its task lists can be viewed
                but not changed.
            </p>

        <?php endif; ?>

        <!-- PROJECT TASK LISTS -->

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">Project task lists</h2>
            </div>

            <?php if ($taskLists === []): ?>

                <p class="empty-state">
                    No task lists linked to this project are visible to you.
                </p>

            <?php else: ?>

                <ul class="stack">
                    <?php foreach ($taskLists as $taskList): ?>

                        <?php
                        $listCanDetach = $canModify
                            && task_list_can_manage(
                                $access,
                                $taskList,
                                $userId
                            );
                        ?>

                        <li>
                            <a
                                class="profile-link"
                                href="/tasks/task-list.php?id=<?= (int) $taskList['id'] ?>"
                            >
                                <?= htmlspecialchars(
                                    (string) $taskList['name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </a>

                            <span>
                                <?= project_task_status_label(
                                    (string) $taskList['status']
                                ) ?>
                            </span>

                            <?php if (!empty($taskList['team_name'])): ?>

                                <span>
                                    <?= htmlspecialchars(
                                        (string) $taskList['team_name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>

                            <?php endif; ?>

                            <span>
                                <?= (int) $taskList['task_count'] ?>
                                task<?= (int) $taskList['task_count'] === 1
                                    ? ''
                                    : 's' ?>
                                /
                                <?= (int) $taskList['member_count'] ?>
                                member<?= (int) $taskList['member_count'] === 1
                                    ? ''
                                    : 's' ?>
                            </span>

                            <?php if ($listCanDetach): ?>

                                <form
                                    method="post"
                                    action="/actions/projects/detach-task-list.php"
                                    onsubmit="return confirm('Detach this task list from the project? The list, its tasks, members, team, and templates are kept.');"
                                >
                                    <?= csrf_input() ?>

                                    <input
                                        type="hidden"
                                        name="project_id"
                                        value="<?= $projectId ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="task_list_id"
                                        value="<?= (int) $taskList['id'] ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="secondary-action"
                                    >
                                        Detach
                                    </button>
                                </form>

                            <?php endif; ?>
                        </li>

                    <?php endforeach; ?>
                </ul>

            <?php endif; ?>
        </section>

        <?php if ($canModify): ?>

            <!-- CREATE TASK LIST -->

            <section class="section">
                <div class="section-header">
                    <h2 class="section-title">Create task list</h2>
                </div>

                <form
                    method="post"
                    action="/actions/projects/create-task-list.php"
                    class="form"
                >
                    <?= csrf_input() ?>

                    <input
                        type="hidden"
                        name="project_id"
                        value="<?= $projectId ?>"
                    >

                    <div class="form-group">
                        <label class="form-label" for="task-list-name">
                            List name
                        </label>

                        <input
                            type="text"
                            id="task-list-name"
                            name="name"
                            maxlength="150"
                            required
                            placeholder="e.g. Website launch"
                        >
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="task-list-start">
                                Start date
                            </label>

                            <input
                                type="datetime-local"
                                id="task-list-start"
                                name="start_date"
                            >
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="task-list-deadline">
                                Deadline
                            </label>

                            <input
                                type="datetime-local"
                                id="task-list-deadline"
                                name="deadline"
                            >
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="task-list-team">
                            Assign to team
                        </label>

                        <p class="form-hint">
                            Optional. Choosing a team also adds its current
                            members to this list.
                        </p>

                        <select id="task-list-team" name="team_id">
                            <option value="">
                                No team &mdash; choose members manually
                            </option>

                            <?php foreach ($workspaceTeams as $team): ?>

                                <option value="<?= (int) $team['id'] ?>">
                                    <?= htmlspecialchars(
                                        (string) $team['name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </option>

                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <span class="form-label">List members</span>

                        <p class="form-hint">
                            You are always added. Project members are not
                            added automatically.
                        </p>

                        <?php foreach ($workspaceUsers as $workspaceUser): ?>

                            <?php $workspaceUserId = (int) $workspaceUser['id']; ?>

                            <label>
                                <input
                                    type="checkbox"
                                    name="member_ids[]"
                                    value="<?= $workspaceUserId ?>"
                                    <?= $workspaceUserId === $userId
                                        ? 'checked disabled'
                                        : '' ?>
                                >

                                <?= htmlspecialchars(
                                    (string) $workspaceUser['display_name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </label>

                            <?php if ($workspaceUserId === $userId): ?>

                                <input
                                    type="hidden"
                                    name="member_ids[]"
                                    value="<?= $workspaceUserId ?>"
                                >

                            <?php endif; ?>

                        <?php endforeach; ?>
                    </div>

                    <div class="form-group">
                        <label>
                            <input
                                type="checkbox"
                                name="members_can_edit"
                                value="1"
                                checked
                            >

                            Members can add and edit tasks
                        </label>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="primary-action">
                            Create task list
                        </button>
                    </div>
                </form>
            </section>

            <!-- ATTACH EXISTING TASK LIST -->

            <section class="section">
                <div class="section-header">
                    <h2 class="section-title">Attach existing task list</h2>
                </div>

                <?php if ($attachableLists === []): ?>

                    <p class="empty-state">
                        No workspace-level task lists are available to attach.
                    </p>

                <?php else: ?>

                    <form
                        method="post"
                        action="/actions/projects/attach-task-list.php"
                        class="form"
                    >
                        <?= csrf_input() ?>

                        <input
                            type="hidden"
                            name="project_id"
                            value="<?= $projectId ?>"
                        >

                        <div class="form-group">
                            <label class="form-label" for="attach-task-list">
                                Task list
                            </label>

                            <select id="attach-task-list" name="task_list_id" required>
                                <option value="">
                                    Select a task list you can manage
                                </option>

                                <?php foreach ($attachableLists as $attachable): ?>

                                    <option value="<?= (int) $attachable['id'] ?>">
                                        <?= htmlspecialchars(
                                            (string) $attachable['name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </option>

                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-actions">
                            <button type="submit" class="primary-action">
                                Attach task list
                            </button>
                        </div>
                    </form>

                <?php endif; ?>
            </section>

        <?php endif; ?>

    </div>
</main>

</body>
</html>