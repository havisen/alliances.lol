<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/key-vault/vault.php';

$currentUser = require_login();
$connection = db();

$userId = (int) $currentUser['id'];

$allowedSections = [
    'profile' => 'Profile',
    'appearance' => 'Appearance',
    'regional' => 'Regional',
    'notifications' => 'Notifications',
    'security' => 'Security',
    'encryption' => 'Encryption & Devices',
    'shortcuts' => 'Keyboard Shortcuts',
    'accessibility' => 'Accessibility',
];

$section = (string) ($_GET['section'] ?? 'profile');

if (!array_key_exists($section, $allowedSections)) {
    $section = 'profile';
}

$success = (string) ($_GET['saved'] ?? '');
$error = null;

$profileStatement = $connection->prepare(
    'SELECT
        id,
        display_name,
        email,
        avatar_path,
        description,
        job_title,
        time_zone,
        working_hours,
        current_status,
        out_of_office,
        out_of_office_until,
        password_hash
     FROM users
     WHERE id = ?
     LIMIT 1'
);

$profileStatement->execute([$userId]);
$profile = $profileStatement->fetch();

if (!$profile) {
    http_response_code(404);
    exit('Profile not found.');
}

$preferences = user_preferences($userId);

$allowedStatuses = [
    'available' => 'Available',
    'busy' => 'Busy',
    'dnd' => 'Do Not Disturb',
];

$dateFormats = [
    'dd_mm_yyyy' => 'DD/MM/YYYY',
    'mm_dd_yyyy' => 'MM/DD/YYYY',
    'yyyy_mm_dd' => 'YYYY-MM-DD',
];

$timeFormats = [
    '24' => '24-hour',
    '12' => '12-hour',
];

$notificationOptions = [
    'notify_messaging' => [
        'label' => 'Messaging',
        'description' => 'Direct messages and group conversation activity.',
    ],
    'notify_mentions' => [
        'label' => 'Mentions and replies',
        'description' => 'Conversation mentions and reply activity when supported.',
    ],
    'notify_tasks' => [
        'label' => 'Tasks',
        'description' => 'Task assignments, updates, and deadline-related activity.',
    ],
    'notify_calendar' => [
        'label' => 'Calendar',
        'description' => 'Calendar events and schedule-related activity.',
    ],
    'notify_teams' => [
        'label' => 'Teams',
        'description' => 'Team membership and team-related activity.',
    ],
    'notify_drive' => [
        'label' => 'Drive',
        'description' => 'Drive sharing and access changes.',
    ],
];

$timezones = DateTimeZone::listIdentifiers();

function settings_redirect(string $section, string $saved): void
{
    header(
        'Location: /settings/?section='
        . rawurlencode($section)
        . '&saved='
        . rawurlencode($saved)
    );

    exit;
}

function settings_uploaded_avatar(array $profile, ?string &$error): ?string
{
    $avatarPath = $profile['avatar_path'] ?? null;

    if (
        !isset($_FILES['avatar'])
        || $_FILES['avatar']['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return $avatarPath;
    }

    if ($_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        $error = 'There was a problem uploading the image.';
        return null;
    }

    $imageInfo = getimagesize($_FILES['avatar']['tmp_name']);

    if ($imageInfo === false) {
        $error = 'Please upload a valid image.';
        return null;
    }

    if ($_FILES['avatar']['size'] > 5 * 1024 * 1024) {
        $error = 'The image must be smaller than 5 MB.';
        return null;
    }

    $allowedTypes = [
        IMAGETYPE_JPEG => 'jpg',
        IMAGETYPE_PNG => 'png',
        IMAGETYPE_WEBP => 'webp',
    ];

    $imageType = $imageInfo[2];

    if (!isset($allowedTypes[$imageType])) {
        $error = 'Use JPG, PNG, or WebP.';
        return null;
    }

    $filename =
        bin2hex(random_bytes(16))
        . '.'
        . $allowedTypes[$imageType];

    $uploadDirectory =
        dirname(__DIR__, 2)
        . '/storage/profile-images';

    if (!is_dir($uploadDirectory)) {
        mkdir($uploadDirectory, 0755, true);
    }

    $destination =
        $uploadDirectory
        . '/'
        . $filename;

    if (
        !move_uploaded_file(
            $_FILES['avatar']['tmp_name'],
            $destination
        )
    ) {
        $error = 'Could not save the image.';
        return null;
    }

    return '/profile/profile-image.php?file='
        . rawurlencode($filename);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $action = (string) ($_POST['settings_action'] ?? '');

    if ($action === 'profile') {
        $section = 'profile';

        $description = trim((string) ($_POST['description'] ?? ''));
        $workingHours = trim((string) ($_POST['working_hours'] ?? ''));
        $currentStatus = trim((string) ($_POST['current_status'] ?? 'available'));
        $outOfOffice = isset($_POST['out_of_office']);
        $outOfOfficeUntil = trim((string) ($_POST['out_of_office_until'] ?? ''));

        if (strlen($description) > 2000) {
            $error = 'Your description can be up to 2,000 characters.';
        } elseif (strlen($workingHours) > 120) {
            $error = 'Your working hours can be up to 120 characters.';
        } elseif (!array_key_exists($currentStatus, $allowedStatuses)) {
            $error = 'Choose a valid current status.';
        } elseif (
            $outOfOfficeUntil !== ''
            && preg_match('/^\d{4}-\d{2}-\d{2}$/', $outOfOfficeUntil) !== 1
        ) {
            $error = 'Use a valid out of office end date.';
        }

        $avatarPath = null;

        if ($error === null) {
            $avatarPath = settings_uploaded_avatar($profile, $error);
        }

        if ($error === null) {
            $update = $connection->prepare(
                'UPDATE users
                 SET description = ?,
                     avatar_path = ?,
                     working_hours = ?,
                     current_status = ?,
                     out_of_office = ?,
                     out_of_office_until = ?
                 WHERE id = ?'
            );

            $update->execute([
                $description !== '' ? $description : null,
                $avatarPath,
                $workingHours !== '' ? $workingHours : null,
                $currentStatus,
                $outOfOffice ? 1 : 0,
                $outOfOfficeUntil !== '' ? $outOfOfficeUntil : null,
                $userId,
            ]);

            settings_redirect('profile', 'profile');
        }
    } elseif ($action === 'appearance') {
        $section = 'appearance';
        $theme = (string) ($_POST['theme'] ?? 'system');

        if (!valid_theme_preference($theme)) {
            $error = 'Choose a valid theme.';
        } else {
            set_user_preference($userId, 'theme', $theme);
            settings_redirect('appearance', 'appearance');
        }
    } elseif ($action === 'regional') {
        $section = 'regional';

        $timezone = (string) ($_POST['time_zone'] ?? '');
        $dateFormat = (string) ($_POST['date_format'] ?? '');
        $timeFormat = (string) ($_POST['time_format'] ?? '');

        if (!in_array($timezone, $timezones, true)) {
            $error = 'Choose a valid time zone.';
        } elseif (!valid_date_format_preference($dateFormat)) {
            $error = 'Choose a valid date format.';
        } elseif (!valid_time_format_preference($timeFormat)) {
            $error = 'Choose a valid time format.';
        } else {
            $update = $connection->prepare(
                'UPDATE users
                 SET time_zone = ?
                 WHERE id = ?'
            );

            $update->execute([
                $timezone,
                $userId,
            ]);

            set_user_preference($userId, 'date_format', $dateFormat);
            set_user_preference($userId, 'time_format', $timeFormat);

            settings_redirect('regional', 'regional');
        }
    } elseif ($action === 'password') {
        $section = 'security';

        $currentPassword = (string) ($_POST['current_password'] ?? '');
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

        if (
            !password_verify(
                $currentPassword,
                (string) $profile['password_hash']
            )
        ) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($newPassword) < 12) {
            $error = 'New password must be at least 12 characters.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'New passwords do not match.';
        } else {
            $update = $connection->prepare(
                'UPDATE users
                 SET password_hash = ?
                 WHERE id = ?'
            );

            $update->execute([
                password_hash($newPassword, PASSWORD_DEFAULT),
                $userId,
            ]);

            session_regenerate_id(true);
            register_current_session($userId);
            settings_redirect('security', 'password');
        }
    } elseif ($action === 'notifications') {
        $section = 'notifications';
        $updates = [];

        foreach (array_keys($notificationOptions) as $preferenceKey) {
            $updates[$preferenceKey] = isset($_POST[$preferenceKey]) ? '1' : '0';
        }

        foreach ($updates as $preferenceValue) {
            if (!valid_notification_preference($preferenceValue)) {
                $error = 'Choose valid notification settings.';
                break;
            }
        }

        if ($error === null) {
            set_user_preferences($userId, $updates);
            settings_redirect('notifications', 'notifications');
        }
    } elseif ($action === 'revoke_session') {
        $section = 'security';
        $sessionRecordId = filter_input(
            INPUT_POST,
            'session_id',
            FILTER_VALIDATE_INT
        );

        if (!$sessionRecordId) {
            $error = 'Choose a valid session.';
        } else {
            revoke_user_session($userId, (int) $sessionRecordId);
            settings_redirect('security', 'session');
        }
    } elseif ($action === 'revoke_other_sessions') {
        $section = 'security';
        revoke_other_user_sessions($userId);
        settings_redirect('security', 'sessions');
    } elseif ($action === 'accessibility') {
        $section = 'accessibility';
        $reducedMotion = (string) ($_POST['reduced_motion'] ?? 'system');
        $highContrast = (string) ($_POST['high_contrast'] ?? 'system');
        $interfaceDensity = (string) ($_POST['interface_density'] ?? 'comfortable');

        if (!valid_reduced_motion_preference($reducedMotion)) {
            $error = 'Choose a valid motion preference.';
        } elseif (!valid_high_contrast_preference($highContrast)) {
            $error = 'Choose a valid contrast preference.';
        } elseif (!valid_interface_density_preference($interfaceDensity)) {
            $error = 'Choose a valid density preference.';
        } else {
            set_user_preferences($userId, [
                'reduced_motion' => $reducedMotion,
                'high_contrast' => $highContrast,
                'interface_density' => $interfaceDensity,
            ]);
            settings_redirect('accessibility', 'accessibility');
        }
    } else {
        $error = 'Choose a valid settings action.';
    }

    $profileStatement->execute([$userId]);
    $profile = $profileStatement->fetch();
    $preferences = user_preferences($userId);
}

$successMessages = [
    'profile' => 'Profile settings updated.',
    'appearance' => 'Appearance updated.',
    'regional' => 'Regional settings updated.',
    'notifications' => 'Notification settings updated.',
    'password' => 'Password changed.',
    'session' => 'Session signed out.',
    'sessions' => 'Other sessions signed out.',
    'accessibility' => 'Accessibility settings updated.',
];

$successMessage = $successMessages[$success] ?? null;

$timezoneValue =
    (string) ($profile['time_zone'] ?? '');

if (!in_array($timezoneValue, $timezones, true)) {
    $timezoneValue = 'UTC';
}

$exampleDate =
    new DateTimeImmutable('2026-10-05 14:30:00');

$vaultExists =
    key_vault_exists($userId);

$activeSessions = active_user_sessions($userId);
$currentSessionHash = current_session_record_hash();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Settings | Alliances</title>
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
<?php render_navigation($currentUser); ?>

<main class="app-main settings-page">
    <header class="settings-header">
        <div>
            <p class="page-eyebrow">Personal settings</p>
            <h1>Settings</h1>
            <p class="page-description">
                Manage your profile, preferences, account security,
                and encryption tools.
            </p>
        </div>
    </header>

    <?php if ($successMessage !== null): ?>
        <div class="settings-message settings-message-success" role="status">
            <?= htmlspecialchars($successMessage, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== null): ?>
        <div class="settings-message settings-message-error" role="alert">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <div class="settings-shell">
        <nav class="settings-nav" aria-label="Settings sections">
            <?php foreach ($allowedSections as $sectionKey => $sectionLabel): ?>
                <a
                    href="/settings/?section=<?= htmlspecialchars($sectionKey, ENT_QUOTES, 'UTF-8') ?>"
                    class="settings-nav-link <?= $section === $sectionKey ? 'is-active' : '' ?>"
                >
                    <?= htmlspecialchars($sectionLabel, ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php endforeach; ?>
        </nav>

        <section class="settings-panel">
            <?php if ($section === 'profile'): ?>
                <div class="settings-section-heading">
                    <h2>Profile</h2>
                    <p>
                        These fields update the same profile used across
                        Profiles, Teams, Messaging, Tasks, and Workspace.
                    </p>
                </div>

                <form method="post" enctype="multipart/form-data" class="settings-form">
                    <?= csrf_input() ?>
                    <input type="hidden" name="settings_action" value="profile">

                    <div class="settings-row">
                        <div>
                            <h3>Identity</h3>
                            <p>
                                Display name, email, and job title are managed
                                by workspace administration.
                            </p>
                        </div>

                        <div class="settings-readonly-grid">
                            <span><?= htmlspecialchars((string) $profile['display_name'], ENT_QUOTES, 'UTF-8') ?></span>
                            <span><?= htmlspecialchars((string) $profile['email'], ENT_QUOTES, 'UTF-8') ?></span>
                            <span><?= htmlspecialchars((string) ($profile['job_title'] ?: 'No job title'), ENT_QUOTES, 'UTF-8') ?></span>
                        </div>
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="avatar">Profile picture</label>
                            <p>JPG, PNG, or WebP. Maximum 5 MB.</p>
                        </div>
                        <input id="avatar" type="file" name="avatar" accept="image/jpeg,image/png,image/webp">
                    </div>

                    <div class="settings-row settings-row-top">
                        <div>
                            <label for="description">About</label>
                            <p>Shown on your profile and team contexts.</p>
                        </div>
                        <textarea id="description" name="description" maxlength="2000" rows="5"><?= htmlspecialchars((string) ($profile['description'] ?? ''), ENT_QUOTES, 'UTF-8') ?></textarea>
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="working_hours">Working hours</label>
                            <p>Example: Mon-Fri, 09:00-17:00.</p>
                        </div>
                        <input id="working_hours" type="text" name="working_hours" maxlength="120" value="<?= htmlspecialchars((string) ($profile['working_hours'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="current_status">Current status</label>
                            <p>Used in profile and team views.</p>
                        </div>
                        <select id="current_status" name="current_status">
                            <?php foreach ($allowedStatuses as $statusValue => $statusLabel): ?>
                                <option value="<?= htmlspecialchars($statusValue, ENT_QUOTES, 'UTF-8') ?>" <?= (string) ($profile['current_status'] ?? 'available') === $statusValue ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="settings-row">
                        <div>
                            <span class="settings-field-title">Out of Office</span>
                            <p>Show when you are away.</p>
                        </div>
                        <div class="settings-stacked-control">
                            <label class="settings-inline-option">
                                <input type="checkbox" name="out_of_office" value="1" <?= (int) ($profile['out_of_office'] ?? 0) === 1 ? 'checked' : '' ?>>
                                <span>Show me as out of office</span>
                            </label>
                            <input type="date" name="out_of_office_until" value="<?= htmlspecialchars((string) ($profile['out_of_office_until'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                        </div>
                    </div>

                    <div class="settings-actions">
                        <button type="submit" class="primary-action">Save profile</button>
                    </div>
                </form>
            <?php elseif ($section === 'appearance'): ?>
                <div class="settings-section-heading">
                    <h2>Appearance</h2>
                    <p>Choose how Alliances should look across this account.</p>
                </div>

                <form method="post" class="settings-form">
                    <?= csrf_input() ?>
                    <input type="hidden" name="settings_action" value="appearance">

                    <fieldset class="settings-choice-group">
                        <legend>Theme</legend>
                        <?php foreach (['system' => 'System', 'dark' => 'Dark', 'light' => 'Light'] as $value => $label): ?>
                            <label class="settings-choice">
                                <input type="radio" name="theme" value="<?= $value ?>" <?= $preferences['theme'] === $value ? 'checked' : '' ?>>
                                <span>
                                    <strong><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></strong>
                                    <small>
                                        <?= $value === 'system'
                                            ? 'Follow your browser or operating system.'
                                            : 'Always use ' . strtolower($label) . ' mode.'
                                        ?>
                                    </small>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </fieldset>

                    <div class="settings-actions">
                        <button type="submit" class="primary-action">Save appearance</button>
                    </div>
                </form>
            <?php elseif ($section === 'regional'): ?>
                <div class="settings-section-heading">
                    <h2>Regional</h2>
                    <p>Time zone is shared with your profile. Date and time formats are stored as personal preferences.</p>
                </div>

                <form method="post" class="settings-form">
                    <?= csrf_input() ?>
                    <input type="hidden" name="settings_action" value="regional">

                    <div class="settings-row">
                        <div>
                            <label for="time_zone">Time zone</label>
                            <p>Use a valid IANA time zone.</p>
                        </div>
                        <select id="time_zone" name="time_zone">
                            <?php foreach ($timezones as $timezone): ?>
                                <option value="<?= htmlspecialchars($timezone, ENT_QUOTES, 'UTF-8') ?>" <?= $timezoneValue === $timezone ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($timezone, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="date_format">Date format</label>
                            <p>Example date: <?= htmlspecialchars(format_user_date($exampleDate, $preferences['date_format']), ENT_QUOTES, 'UTF-8') ?></p>
                        </div>
                        <select id="date_format" name="date_format">
                            <?php foreach ($dateFormats as $value => $label): ?>
                                <option value="<?= $value ?>" <?= $preferences['date_format'] === $value ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="time_format">Time format</label>
                            <p>Example time: <?= htmlspecialchars(format_user_time($exampleDate, $preferences['time_format']), ENT_QUOTES, 'UTF-8') ?></p>
                        </div>
                        <select id="time_format" name="time_format">
                            <?php foreach ($timeFormats as $value => $label): ?>
                                <option value="<?= $value ?>" <?= $preferences['time_format'] === $value ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="settings-actions">
                        <button type="submit" class="primary-action">Save regional settings</button>
                    </div>
                </form>
            <?php elseif ($section === 'notifications'): ?>
                <div class="settings-section-heading">
                    <h2>Notifications</h2>
                    <p>Choose which Alliances notification categories should be enabled for your account. Delivery code can query these preferences without duplicating SQL.</p>
                </div>
                <form method="post" class="settings-form">
                    <?= csrf_input() ?>
                    <input type="hidden" name="settings_action" value="notifications">

                    <fieldset class="settings-choice-group">
                        <legend>Notification categories</legend>
                        <?php foreach ($notificationOptions as $preferenceKey => $option): ?>
                            <label class="settings-choice">
                                <input
                                    type="checkbox"
                                    name="<?= htmlspecialchars($preferenceKey, ENT_QUOTES, 'UTF-8') ?>"
                                    value="1"
                                    <?= ($preferences[$preferenceKey] ?? '1') === '1' ? 'checked' : '' ?>
                                >
                                <span>
                                    <strong><?= htmlspecialchars($option['label'], ENT_QUOTES, 'UTF-8') ?></strong>
                                    <small><?= htmlspecialchars($option['description'], ENT_QUOTES, 'UTF-8') ?></small>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </fieldset>

                    <div class="settings-actions">
                        <button type="submit" class="primary-action">Save notifications</button>
                    </div>
                </form>
            <?php elseif ($section === 'security'): ?>
                <div class="settings-section-heading">
                    <h2>Security</h2>
                    <p>Your Alliances account password is separate from your Key Vault password.</p>
                </div>

                <form method="post" class="settings-form settings-password-form">
                    <?= csrf_input() ?>
                    <input type="hidden" name="settings_action" value="password">

                    <div class="settings-row">
                        <div>
                            <label for="current_password">Current password</label>
                            <p>Verify your existing Alliances account password.</p>
                        </div>
                        <input id="current_password" type="password" name="current_password" autocomplete="current-password" required>
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="new_password">New password</label>
                            <p>Use at least 12 characters.</p>
                        </div>
                        <input id="new_password" type="password" name="new_password" autocomplete="new-password" minlength="12" required>
                    </div>

                    <div class="settings-row">
                        <div>
                            <label for="confirm_password">Confirm new password</label>
                            <p>Repeat the new Alliances account password.</p>
                        </div>
                        <input id="confirm_password" type="password" name="confirm_password" autocomplete="new-password" minlength="12" required>
                    </div>

                    <div class="settings-actions">
                        <button type="submit" class="primary-action">Change password</button>
                    </div>
                </form>

                <div class="settings-section-heading">
                    <h2>Active Sessions</h2>
                    <p>Sign out browser sessions that are no longer in use. The current session is protected from remote sign-out.</p>
                </div>

                <?php if ($activeSessions === []): ?>
                    <div class="settings-info-card">
                        <strong>Current session</strong>
                        <span>This browser session is active. Session details will appear after the session registry migration runs.</span>
                    </div>
                <?php else: ?>
                    <div class="settings-session-list">
                        <?php foreach ($activeSessions as $activeSession): ?>
                            <?php $isCurrentSession = $currentSessionHash !== null && hash_equals($currentSessionHash, (string) $activeSession['session_hash']); ?>
                            <article class="settings-session-card">
                                <div>
                                    <strong><?= $isCurrentSession ? 'Current session' : 'Other session' ?></strong>
                                    <span><?= htmlspecialchars((string) ($activeSession['user_agent'] ?: 'Unknown browser'), ENT_QUOTES, 'UTF-8') ?></span>
                                    <small>
                                        Created <?= htmlspecialchars((string) $activeSession['created_at'], ENT_QUOTES, 'UTF-8') ?>
                                        · Last active <?= htmlspecialchars((string) $activeSession['last_seen_at'], ENT_QUOTES, 'UTF-8') ?>
                                        <?php if (!empty($activeSession['ip_address'])): ?>
                                            · IP <?= htmlspecialchars((string) $activeSession['ip_address'], ENT_QUOTES, 'UTF-8') ?>
                                        <?php endif; ?>
                                    </small>
                                </div>

                                <?php if (!$isCurrentSession): ?>
                                    <form method="post">
                                        <?= csrf_input() ?>
                                        <input type="hidden" name="settings_action" value="revoke_session">
                                        <input type="hidden" name="session_id" value="<?= (int) $activeSession['id'] ?>">
                                        <button type="submit" class="secondary-action">Sign out</button>
                                    </form>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>

                    <form method="post" class="settings-actions">
                        <?= csrf_input() ?>
                        <input type="hidden" name="settings_action" value="revoke_other_sessions">
                        <button type="submit" class="secondary-action">Sign out all other sessions</button>
                    </form>
                <?php endif; ?>

                <div class="settings-info-card">
                    <strong>Two-factor authentication</strong>
                    <span>Not available yet. TOTP setup needs a vetted implementation that can generate secrets, verify codes during login, and store one-time recovery codes securely.</span>
                </div>
            <?php elseif ($section === 'encryption'): ?>
                <div class="settings-section-heading">
                    <h2>Encryption & Devices</h2>
                    <p>Key Vault protects encryption keys locally. Its password is not your Alliances login password.</p>
                </div>
                <div class="settings-info-grid">
                    <div class="settings-info-card">
                        <strong>Key Vault</strong>
                        <span><?= $vaultExists ? 'Created for this account.' : 'Not created yet.' ?></span>
                    </div>
                    <div class="settings-info-card" id="settings-vault-browser-state">
                        <strong>Browser state</strong>
                        <span>Checking this browser...</span>
                    </div>
                    <div class="settings-info-card">
                        <strong>Trusted devices</strong>
                        <span>Device trust management is not implemented yet.</span>
                    </div>
                </div>
                <p>
                    <a class="primary-action" href="/key-vault/">Open Key Vault</a>
                </p>
            <?php elseif ($section === 'shortcuts'): ?>
                <div class="settings-section-heading">
                    <h2>Keyboard Shortcuts</h2>
                    <p>Only currently supported shortcuts are listed as active.</p>
                </div>
                <div class="settings-info-grid">
                    <div class="settings-info-card">
                        <strong>Escape</strong>
                        <span>Closes several open dialogs and modals.</span>
                    </div>
                    <div class="settings-info-card">
                        <strong>Enter</strong>
                        <span>Submits focused forms and message composers where implemented.</span>
                    </div>
                    <div class="settings-info-card">
                        <strong>Command palette</strong>
                        <span>Planned. No global shortcut is active yet.</span>
                    </div>
                </div>
            <?php elseif ($section === 'accessibility'): ?>
                <div class="settings-section-heading">
                    <h2>Accessibility</h2>
                    <p>Reduced motion applies across the interface and also respects your browser setting.</p>
                </div>

                <form method="post" class="settings-form">
                    <?= csrf_input() ?>
                    <input type="hidden" name="settings_action" value="accessibility">

                    <fieldset class="settings-choice-group">
                        <legend>Motion</legend>
                        <label class="settings-choice">
                            <input type="radio" name="reduced_motion" value="system" <?= $preferences['reduced_motion'] === 'system' ? 'checked' : '' ?>>
                            <span>
                                <strong>System</strong>
                                <small>Use your browser or operating system preference.</small>
                            </span>
                        </label>
                        <label class="settings-choice">
                            <input type="radio" name="reduced_motion" value="reduce" <?= $preferences['reduced_motion'] === 'reduce' ? 'checked' : '' ?>>
                            <span>
                                <strong>Reduce motion</strong>
                                <small>Disable nonessential transitions and decorative motion.</small>
                            </span>
                        </label>
                    </fieldset>

                    <fieldset class="settings-choice-group">
                        <legend>Contrast</legend>
                        <label class="settings-choice">
                            <input type="radio" name="high_contrast" value="system" <?= $preferences['high_contrast'] === 'system' ? 'checked' : '' ?>>
                            <span>
                                <strong>System</strong>
                                <small>Use the standard interface contrast.</small>
                            </span>
                        </label>
                        <label class="settings-choice">
                            <input type="radio" name="high_contrast" value="more" <?= $preferences['high_contrast'] === 'more' ? 'checked' : '' ?>>
                            <span>
                                <strong>Higher contrast</strong>
                                <small>Store a preference for stronger contrast when the interface supports it.</small>
                            </span>
                        </label>
                    </fieldset>

                    <fieldset class="settings-choice-group">
                        <legend>Density</legend>
                        <label class="settings-choice">
                            <input type="radio" name="interface_density" value="comfortable" <?= $preferences['interface_density'] === 'comfortable' ? 'checked' : '' ?>>
                            <span>
                                <strong>Comfortable</strong>
                                <small>Use the current default spacing.</small>
                            </span>
                        </label>
                        <label class="settings-choice">
                            <input type="radio" name="interface_density" value="compact" <?= $preferences['interface_density'] === 'compact' ? 'checked' : '' ?>>
                            <span>
                                <strong>Compact</strong>
                                <small>Store a compact layout preference for later interface support.</small>
                            </span>
                        </label>
                    </fieldset>

                    <div class="settings-actions">
                        <button type="submit" class="primary-action">Save accessibility</button>
                    </div>
                </form>
            <?php endif; ?>
        </section>
    </div>
</main>

<?php if ($section === 'encryption'): ?>
    <script>
    (function () {
        var element = document.getElementById('settings-vault-browser-state');

        if (!element) {
            return;
        }

        var userId = <?= json_encode((string) $userId) ?>;
        var sessionData = localStorage.getItem('alliances.key-vault.session-data');
        var sessionKey = localStorage.getItem('alliances.key-vault.session-key');
        var expiresAt = Number(localStorage.getItem('alliances.key-vault.expires-at'));
        var sessionUserId = localStorage.getItem('alliances.key-vault.user-id');
        var unlocked = Boolean(sessionData)
            && Boolean(sessionKey)
            && Number.isFinite(expiresAt)
            && expiresAt > Date.now()
            && sessionUserId === userId;

        element.querySelector('span').textContent = unlocked
            ? 'Unlocked in this browser.'
            : 'Locked in this browser.';
    })();
    </script>
<?php endif; ?>
</body>
</html>
