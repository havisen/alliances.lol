<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/auth.php';

if (current_user() !== null) {
    header('Location: /');
    exit;
}

$errors = [];
$displayName = '';
$email = '';
$workspaceName = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $displayName = trim((string) ($_POST['display_name'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $workspaceName = trim((string) ($_POST['workspace_name'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    if ($displayName === '' || strlen($displayName) > 100) {
        $errors[] = 'Enter a display name between 1 and 100 characters.';
    }

    if (
        $email === ''
        || strlen($email) > 254
        || filter_var($email, FILTER_VALIDATE_EMAIL) === false
    ) {
        $errors[] = 'Enter a valid email address.';
    }

    if (strlen($password) < 12 || strlen($password) > 72) {
        $errors[] = 'Use a password between 12 and 72 characters.';
    }

    if ($workspaceName === '' && $displayName !== '') {
        $workspaceName = $displayName . "'s Workspace";
    }

    if ($workspaceName === '' || strlen($workspaceName) > 100) {
        $errors[] = 'Enter a workspace name up to 100 characters.';
    }

    if ($errors === []) {
        try {
            $connection = db();

            $connection->beginTransaction();

            $existingStatement = $connection->prepare(
                'SELECT id FROM users WHERE email = ? LIMIT 1'
            );

            $existingStatement->execute([$email]);

            if ($existingStatement->fetchColumn() !== false) {
                throw new RuntimeException('duplicate_email');
            }

            $userStatement = $connection->prepare(
                'INSERT INTO users (display_name, email, password_hash)
                 VALUES (?, ?, ?)'
            );

            $userStatement->execute([
                $displayName,
                $email,
                password_hash($password, PASSWORD_DEFAULT),
            ]);

            $userId = (int) $connection->lastInsertId();

            $workspaceStatement = $connection->prepare(
                'INSERT INTO workspaces (name) VALUES (?)'
            );

            $workspaceStatement->execute([$workspaceName]);

            $workspaceId = (int) $connection->lastInsertId();

            $memberStatement = $connection->prepare(
                'INSERT INTO workspace_members (workspace_id, user_id, role)
                 VALUES (?, ?, ?)'
            );

            $memberStatement->execute([$workspaceId, $userId, 'admin']);

            /*
             * Record the initial 1 GiB ceiling. workspace_quotas is added by an
             * additive migration; if it has not been applied yet the default
             * 1 GiB limit is still enforced by src/drive/quota.php.
             */
            try {
                $quotaStatement = $connection->prepare(
                    'INSERT INTO workspace_quotas (workspace_id, storage_limit_bytes)
                     VALUES (?, ?)'
                );

                $quotaStatement->execute([$workspaceId, 1073741824]);
            } catch (Throwable $error) {
                // Table not applied yet — default ceiling still applies.
            }

            $connection->commit();

            start_session();
            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            $_SESSION['active_workspace_id'] = $workspaceId;
            register_current_session($userId);

            header('Location: /');
            exit;
        } catch (Throwable $error) {
            if (
                isset($connection)
                && $connection instanceof PDO
                && $connection->inTransaction()
            ) {
                $connection->rollBack();
            }

            if (
                $error->getMessage() === 'duplicate_email'
                || str_contains($error->getMessage(), 'UNIQUE')
            ) {
                $errors[] = 'An account with this email already exists.';
            } else {
                $errors[] = 'Could not create your account. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create your account | Alliances</title>
</head>
<body>
    <h1>Create your Alliances account</h1>

    <p>This creates your account and your first Workspace. Your password is never stored in plain text, and your Drive files are encrypted before they reach the server.</p>

    <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endforeach; ?>

    <form method="post">
        <?= csrf_input() ?>

        <label>
            Display name
            <input type="text" name="display_name" value="<?= htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8') ?>" required autocomplete="name" maxlength="100">
        </label>

        <br>

        <label>
            Email
            <input type="email" name="email" value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>" required autocomplete="email" maxlength="254">
        </label>

        <br>

        <label>
            Password
            <input type="password" name="password" required autocomplete="new-password" minlength="12" maxlength="72">
        </label>

        <br>

        <label>
            Workspace name <small>(optional)</small>
            <input type="text" name="workspace_name" value="<?= htmlspecialchars($workspaceName, ENT_QUOTES, 'UTF-8') ?>" maxlength="100" placeholder="My Workspace">
        </label>

        <br>

        <button type="submit">Create account</button>
    </form>

    <p>Already have an account? <a href="/login.php">Log in</a>.</p>
</body>
</html>