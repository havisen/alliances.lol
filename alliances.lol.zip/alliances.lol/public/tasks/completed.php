<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

$user = require_login();
$connection = db();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Completed task lists
|--------------------------------------------------------------------------
|
| Only lists that:
|
| - belong to the current workspace
| - are completed
| - contain the current user as a member
|
| are shown.
|
*/

$statement = $connection->prepare(
    'SELECT
        tl.id,
        tl.name,
        tl.start_date,
        tl.deadline,
        tl.completed_at,
        tl.created_by,
        tl.team_id,

        creator.display_name AS creator_name,
        creator.avatar_path AS creator_avatar,

        team.name AS team_name,

        COUNT(t.id) AS task_count,

        SUM(
            CASE
                WHEN t.status = "completed" THEN 1
                ELSE 0
            END
        ) AS completed_task_count

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     INNER JOIN users creator
         ON creator.id = tl.created_by

     LEFT JOIN teams team
         ON team.id = tl.team_id
        AND team.workspace_id = tl.workspace_id

     LEFT JOIN tasks t
         ON t.task_list_id = tl.id

     WHERE tl.workspace_id = ?
       AND tl.status = ?

     GROUP BY
        tl.id,
        tl.name,
        tl.start_date,
        tl.deadline,
        tl.completed_at,
        tl.created_by,
        tl.team_id,
        creator.display_name,
        creator.avatar_path,
        team.name

     ORDER BY
        CASE
            WHEN tl.completed_at IS NULL THEN 1
            ELSE 0
        END,
        tl.completed_at DESC,
        tl.id DESC'
);

$statement->execute([
    $user['id'],
    $workspaceId,
    'completed',
]);

$completedLists = $statement->fetchAll();

/*
|--------------------------------------------------------------------------
| Summary
|--------------------------------------------------------------------------
*/

$completedListCount =
    count($completedLists);

$totalCompletedTasks = 0;

foreach ($completedLists as $list) {
    $totalCompletedTasks +=
        (int) $list['completed_task_count'];
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function completed_page_date(?string $value): string
{
    if ($value === null || $value === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date(
        'M j, Y',
        $timestamp
    );
}

function completed_page_datetime(?string $value): string
{
    if ($value === null || $value === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date(
        'M j, Y · H:i',
        $timestamp
    );
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Completed Tasks | Alliances</title>

</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main completed-page">

    <!-- ================================================================
         HEADER
         ================================================================ -->

    <header class="page-header completed-page-header">

        <div class="page-header-content">

            <span class="page-eyebrow">
                Archive
            </span>

            <h1>
                Completed work
            </h1>

            <p class="page-description">
                Review task lists you've finished and look back at
                completed work.
            </p>

        </div>

        <div class="page-header-actions">

            <a
                href="/tasks/tasks.php"
                class="secondary-action"
            >
                Active task lists
            </a>

        </div>

    </header>

    <!-- ================================================================
         SUMMARY
         ================================================================ -->

    <section
        class="completed-summary"
        aria-label="Completed work summary"
    >

        <div class="completed-summary-item">

            <span>
                Completed lists
            </span>

            <strong>
                <?= $completedListCount ?>
            </strong>

            <small>
                Lists in your archive
            </small>

        </div>

        <div class="completed-summary-item">

            <span>
                Finished tasks
            </span>

            <strong>
                <?= $totalCompletedTasks ?>
            </strong>

            <small>
                Tasks completed across these lists
            </small>

        </div>

    </section>

    <!-- ================================================================
         COMPLETED LISTS
         ================================================================ -->

    <section class="completed-lists-section">

        <div class="completed-section-heading">

            <div>

                <h2>
                    Task list history
                </h2>

                <p>
                    Your completed task lists, newest first.
                </p>

            </div>

            <?php if ($completedLists !== []): ?>

                <span class="completed-list-count">
                    <?= $completedListCount ?>
                    <?= $completedListCount === 1
                        ? 'list'
                        : 'lists' ?>
                </span>

            <?php endif; ?>

        </div>

        <?php if ($completedLists === []): ?>

            <div class="completed-empty-state">

                <div
                    class="completed-empty-icon"
                    aria-hidden="true"
                >
                    ✓
                </div>

                <h3>
                    Nothing completed yet
                </h3>

                <p>
                    Task lists will appear here once all of their
                    tasks have been finished.
                </p>

                <a
                    href="/tasks/tasks.php"
                    class="primary-action"
                >
                    View active tasks
                </a>

            </div>

        <?php else: ?>

            <div class="completed-list-grid">

                <?php foreach (
                    $completedLists as $list
                ): ?>

                    <?php
                    $taskCount =
                        (int) $list['task_count'];

                    $completedTaskCount =
                        (int) $list['completed_task_count'];

                    $creatorInitial = '?';

                    if (
                        !empty($list['creator_name'])
                    ) {
                        $creatorInitial =
                            strtoupper(
                                substr(
                                    $list['creator_name'],
                                    0,
                                    1
                                )
                            );
                    }
                    ?>

                    <article class="completed-list-card">

                        <a
                            href="/tasks/task-list.php?id=<?= (int) $list['id'] ?>"
                            class="completed-list-card-link"
                        >

                            <!-- HEADER -->

                            <div class="completed-list-card-top">

                                <div class="completed-list-badges">

                                    <span class="task-status-badge completed">
                                        Completed
                                    </span>

                                    <?php if (
                                        !empty($list['team_name'])
                                    ): ?>

                                        <span class="task-team-badge">
                                            <?= alliances_team_link(
                                                (int) $list['team_id'],
                                                (string) $list['team_name']
                                            ) ?>
                                        </span>

                                    <?php endif; ?>

                                </div>

                                <span
                                    class="completed-list-arrow"
                                    aria-hidden="true"
                                >
                                    →
                                </span>

                            </div>

                            <!-- BODY -->

                            <div class="completed-list-card-body">

                                <h3>
                                    <?= htmlspecialchars(
                                        $list['name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </h3>

                                <div class="completed-list-meta">

                                    <div class="completed-list-meta-item">

                                        <span class="completed-meta-label">
                                            Tasks
                                        </span>

                                        <strong>
                                            <?= $completedTaskCount ?>
                                            /
                                            <?= $taskCount ?>
                                        </strong>

                                    </div>

                                    <?php if (
                                        !empty(
                                            $list['completed_at']
                                        )
                                    ): ?>

                                        <div class="completed-list-meta-item">

                                            <span class="completed-meta-label">
                                                Completed
                                            </span>

                                            <strong>
                                                <?= htmlspecialchars(
                                                    completed_page_datetime(
                                                        $list['completed_at']
                                                    ),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                        </div>

                                    <?php endif; ?>

                                    <?php if (
                                        !empty($list['deadline'])
                                    ): ?>

                                        <div class="completed-list-meta-item">

                                            <span class="completed-meta-label">
                                                Deadline
                                            </span>

                                            <strong>
                                                <?= htmlspecialchars(
                                                    completed_page_date(
                                                        $list['deadline']
                                                    ),
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                        </div>

                                    <?php endif; ?>

                                </div>

                            </div>

                            <!-- FOOTER -->

                            <div class="completed-list-card-footer">

                                <div class="completed-list-creator">

                                    <?php if (
                                        !empty(
                                            $list['creator_avatar']
                                        )
                                    ): ?>

                                        <img
                                            class="task-list-creator-avatar"
                                            src="<?= htmlspecialchars(
                                                $list['creator_avatar'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>"
                                            alt=""
                                        >

                                    <?php else: ?>

                                        <span
                                            class="task-list-creator-avatar task-list-creator-placeholder"
                                        >
                                            <?= htmlspecialchars(
                                                $creatorInitial,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </span>

                                    <?php endif; ?>

                                    <span>
                                        Created by
                                        <strong>
                                            <?= htmlspecialchars(
                                                $list['creator_name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </strong>
                                    </span>

                                </div>

                                <?php if (
                                    $taskCount > 0
                                ): ?>

                                    <span class="completed-all-done">
                                        <?= $completedTaskCount === $taskCount
                                            ? 'All tasks finished'
                                            : $completedTaskCount . ' finished' ?>
                                    </span>

                                <?php endif; ?>

                            </div>

                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>

</main>

</body>
</html>
