<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/tasks/templates.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';

$user = require_login();
$connection = db();

$listId = filter_input(
    INPUT_GET,
    'list',
    FILTER_VALIDATE_INT
);

if (!$listId) {
    http_response_code(404);
    exit('Task list not found.');
}

$listStatement = $connection->prepare(
    'SELECT
        tl.id,
        tl.workspace_id,
        tl.name,
        tl.created_by,
        tl.default_template_id

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     WHERE tl.id = ?
     LIMIT 1'
);

$listStatement->execute([
    $user['id'],
    $listId,
]);

$list = $listStatement->fetch();

if (!$list) {
    http_response_code(403);
    exit('You do not have access to this task list.');
}

$isCreator =
    (int) $list['created_by']
    === (int) $user['id'];

$access = workspace_access((int) $user['id']);
$isWorkspaceAdmin = $access !== null && !empty($access['is_admin']);
$canConfigureTemplates = $isCreator || $isWorkspaceAdmin;

if (!$canConfigureTemplates) {
    http_response_code(403);
    exit('You do not have permission to configure this task list.');
}

$configurableTemplates = [];

foreach (
    work_templates_for_workspace((int) $list['workspace_id'])
    as $workspaceTemplate
) {
    if ($workspaceTemplate['published_number'] !== null) {
        $configurableTemplates[] = $workspaceTemplate;
    }
}

$allowedTemplateIds = work_template_allowed_template_ids(
    (int) $list['workspace_id'],
    $listId
);

$defaultTemplateId = $list['default_template_id'] !== null
    ? (int) $list['default_template_id']
    : null;

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $submittedTemplateIds = $_POST['template_ids'] ?? [];

    if (!is_array($submittedTemplateIds)) {
        $submittedTemplateIds = [];
    }

    $templateIds = [];

    foreach ($submittedTemplateIds as $submittedTemplateId) {
        $submittedTemplateId = filter_var(
            $submittedTemplateId,
            FILTER_VALIDATE_INT
        );

        if ($submittedTemplateId) {
            $templateIds[] = (int) $submittedTemplateId;
        }
    }

    $submittedDefault = filter_input(
        INPUT_POST,
        'default_template_id',
        FILTER_VALIDATE_INT
    );

    $defaultTemplateIdSelection = $submittedDefault
        ? (int) $submittedDefault
        : null;

    try {
        work_template_set_task_list_templates(
            (int) $list['workspace_id'],
            $listId,
            $templateIds,
            $defaultTemplateIdSelection
        );
    } catch (RuntimeException $exception) {
        $error = $exception->getMessage();
    }

    if ($error === null) {
        header(
            'Location: /tasks/task-list.php?id='
            . $listId
            . '&templates_saved=1'
        );

        exit;
    }
}

$escape = static fn (string $text): string =>
    htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        Configure templates
        | Alliances
    </title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main task-workspace">

    <div class="task-workspace-breadcrumb">

        <a href="/tasks/tasks.php">
            Tasks
        </a>

        <span aria-hidden="true">
            /
        </span>

        <a href="/tasks/task-list.php?id=<?= $listId ?>">
            <?= $escape((string) $list['name']) ?>
        </a>

        <span aria-hidden="true">
            /
        </span>

        <span>
            Configure templates
        </span>

    </div>

    <header class="task-workspace-header">

        <div class="task-workspace-title">

            <h1>
                Configure templates
            </h1>

            <div class="task-workspace-meta">
                <span>
                    Choose which templates this list can use.
                </span>
            </div>

        </div>

    </header>

    <section class="task-add-panel is-open">

        <?php if ($error !== null): ?>

            <div
                class="form-message form-message-error"
                role="alert"
            >
                <?= $escape($error) ?>
            </div>

        <?php endif; ?>

        <form method="post" class="task-template-assign-form">
            <?= csrf_input() ?>

            <?php if ($configurableTemplates === []): ?>
                <p class="task-template-field-value">
                    No published templates are available in this workspace.
                </p>
            <?php else: ?>
                <?php foreach ($configurableTemplates as $availableTemplate): ?>
                    <label class="task-template-checkbox">
                        <input
                            type="checkbox"
                            name="template_ids[]"
                            value="<?= (int) $availableTemplate['id'] ?>"
                            <?= in_array((int) $availableTemplate['id'], $allowedTemplateIds, true)
                                ? 'checked'
                                : '' ?>
                        >
                        <?= $escape((string) $availableTemplate['name']) ?>
                    </label>
                <?php endforeach; ?>
            <?php endif; ?>

            <label class="form-field">
                <span class="form-label">Default template</span>
                <select name="default_template_id">
                    <option value="">No template / Basic task</option>
                    <?php foreach ($configurableTemplates as $availableTemplate): ?>
                        <option
                            value="<?= (int) $availableTemplate['id'] ?>"
                            <?= $defaultTemplateId === (int) $availableTemplate['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= $escape((string) $availableTemplate['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <span class="form-hint">
                    Choosing a default automatically allows that template.
                </span>
            </label>

            <div class="task-create-actions">

                <a
                    class="secondary-action"
                    href="/tasks/task-list.php?id=<?= $listId ?>"
                >
                    Cancel
                </a>

                <button
                    type="submit"
                    class="primary-action"
                >
                    Save templates
                </button>

            </div>
        </form>

    </section>

</main>

<script>
    const defaultTemplateSelect =
        document.querySelector('select[name="default_template_id"]');

    if (defaultTemplateSelect) {
        defaultTemplateSelect.addEventListener('change', () => {
            const selected = defaultTemplateSelect.value;

            if (selected === '') {
                return;
            }

            const allowedCheckbox = document.querySelector(
                'input[name="template_ids[]"][value="' + selected + '"]'
            );

            if (allowedCheckbox && !allowedCheckbox.checked) {
                allowedCheckbox.checked = true;
            }
        });
    }
</script>

</body>
</html>