<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

$user = require_login();
$connection = db();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$error = null;

$formName = '';
$formDescription = '';
$formDeadlineTime = '';

/*
|--------------------------------------------------------------------------
| Create personal daily task
|--------------------------------------------------------------------------
|
| Daily tasks are personal.
|
| Each user creates and manages their own templates. A user must never see
| or modify another user's daily task templates.
|
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $formName =
        trim((string) ($_POST['name'] ?? ''));

    $formDescription =
        trim((string) ($_POST['description'] ?? ''));

    $formDeadlineTime =
        trim((string) ($_POST['deadline_time'] ?? ''));

    if ($formName === '') {
        $error = 'Enter a daily task name.';
    } elseif (strlen($formName) > 200) {
        $error = 'Daily task names can be up to 200 characters.';
    }

    /*
    |--------------------------------------------------------------------------
    | Validate deadline time
    |--------------------------------------------------------------------------
    */

    if (
        $error === null
        && $formDeadlineTime !== ''
    ) {
        $time = DateTimeImmutable::createFromFormat(
            'H:i',
            $formDeadlineTime
        );

        $timeErrors = DateTimeImmutable::getLastErrors();

        $timeIsValid =
            $time !== false
            && (
                $timeErrors === false
                || (
                    $timeErrors['warning_count'] === 0
                    && $timeErrors['error_count'] === 0
                )
            )
            && $time->format('H:i') === $formDeadlineTime;

        if (!$timeIsValid) {
            $error = 'Choose a valid deadline time.';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Insert
    |--------------------------------------------------------------------------
    */

    if ($error === null) {
        $statement = $connection->prepare(
            'INSERT INTO daily_task_templates
                (
                    workspace_id,
                    created_by,
                    assigned_to,
                    name,
                    description,
                    deadline_time
                )
             VALUES (?, ?, ?, ?, ?, ?)'
        );

        $statement->execute([
            $workspaceId,
            $user['id'],
            $user['id'],
            $formName,
            $formDescription !== ''
                ? $formDescription
                : null,
            $formDeadlineTime !== ''
                ? $formDeadlineTime
                : null,
        ]);

        header('Location: /tasks/daily.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Load current user's daily task templates
|--------------------------------------------------------------------------
|
| IMPORTANT:
| We filter by BOTH workspace and created_by.
|
| This prevents one user from seeing another user's personal daily tasks.
|
*/

$templatesStatement = $connection->prepare(
    'SELECT
        id,
        name,
        description,
        deadline_time,
        active
     FROM daily_task_templates
     WHERE workspace_id = ?
       AND created_by = ?
     ORDER BY
        active DESC,
        CASE
            WHEN deadline_time IS NULL
              OR deadline_time = ""
            THEN 1
            ELSE 0
        END,
        deadline_time ASC,
        name ASC'
);

$templatesStatement->execute([
    $workspaceId,
    $user['id'],
]);

$templates = $templatesStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Separate active / inactive
|--------------------------------------------------------------------------
*/

$activeTemplates = [];
$inactiveTemplates = [];

foreach ($templates as $template) {
    if ((int) $template['active'] === 1) {
        $activeTemplates[] = $template;
    } else {
        $inactiveTemplates[] = $template;
    }
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function daily_time_label(?string $time): string
{
    if ($time === null || $time === '') {
        return 'No deadline';
    }

    $timestamp = strtotime($time);

    if ($timestamp === false) {
        return $time;
    }

    return date('H:i', $timestamp);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Daily Tasks | Alliances</title>

</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main daily-page">

    <!-- ================================================================
         HEADER
         ================================================================ -->

    <header class="page-header daily-page-header">

        <div class="page-header-content">

            <span class="page-eyebrow">
                Personal
            </span>

            <h1>
                Daily Tasks
            </h1>

            <p class="page-description">
                Build your personal daily routine. These tasks are only
                visible to you and are recreated for you each day.
            </p>

        </div>

        <div class="page-header-actions">

            <button
                type="button"
                class="primary-action"
                id="open-daily-task"
                aria-expanded="<?= $error !== null
                    ? 'true'
                    : 'false' ?>"
                aria-controls="daily-task-create"
            >
                <span aria-hidden="true">
                    +
                </span>

                Add daily task
            </button>

        </div>

    </header>

    <!-- ================================================================
         SUMMARY
         ================================================================ -->

    <section class="daily-summary">

        <div class="daily-summary-item">

            <span>
                Active
            </span>

            <strong>
                <?= count($activeTemplates) ?>
            </strong>

            <small>
                Daily tasks in your routine
            </small>

        </div>

        <div class="daily-summary-item">

            <span>
                With deadline
            </span>

            <strong>
                <?php
                $withDeadline = 0;

                foreach ($activeTemplates as $template) {
                    if (!empty($template['deadline_time'])) {
                        $withDeadline++;
                    }
                }

                echo $withDeadline;
                ?>
            </strong>

            <small>
                Tasks with a daily due time
            </small>

        </div>

        <div class="daily-summary-item">

            <span>
                Paused
            </span>

            <strong>
                <?= count($inactiveTemplates) ?>
            </strong>

            <small>
                Templates currently inactive
            </small>

        </div>

    </section>

    <!-- ================================================================
         CREATE DAILY TASK
         ================================================================ -->

    <section
        class="daily-create-panel <?= $error !== null
            ? 'is-open'
            : '' ?>"
        id="daily-task-create"
        <?= $error === null
            ? 'hidden'
            : '' ?>
    >

        <div class="task-create-header">

            <div>

                <h2>
                    Add daily task
                </h2>

                <p>
                    This task will be part of your personal daily routine.
                </p>

            </div>

            <button
                type="button"
                class="icon-button"
                id="close-daily-task"
                aria-label="Close"
            >
                ×
            </button>

        </div>

        <?php if ($error !== null): ?>

            <div
                class="form-message form-message-error"
                role="alert"
            >
                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </div>

        <?php endif; ?>

        <form
            method="post"
            class="daily-create-form"
        >

            <?= csrf_input() ?>

            <div class="daily-create-fields">

                <label class="form-field daily-name-field">

                    <span class="form-label">
                        Task
                    </span>

                    <input
                        type="text"
                        name="name"
                        required
                        maxlength="200"
                        placeholder="e.g. Review today's priorities"
                        value="<?= htmlspecialchars(
                            $formName,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >

                </label>

                <label class="form-field daily-time-field">

                    <span class="form-label">
                        Daily deadline
                    </span>

                    <span class="form-hint">
                        Optional
                    </span>

                    <input
                        type="time"
                        name="deadline_time"
                        value="<?= htmlspecialchars(
                            $formDeadlineTime,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >

                </label>

            </div>

            <label class="form-field">

                <span class="form-label">
                    Description
                </span>

                <span class="form-hint">
                    Optional
                </span>

                <textarea
                    name="description"
                    rows="4"
                    placeholder="Add a reminder or some context..."
                ><?= htmlspecialchars(
                    $formDescription,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></textarea>

            </label>

            <div class="task-create-actions">

                <button
                    type="button"
                    class="secondary-action"
                    id="cancel-daily-task"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="primary-action"
                >
                    Add daily task
                </button>

            </div>

        </form>

    </section>

    <!-- ================================================================
         ACTIVE DAILY TASKS
         ================================================================ -->

    <section class="daily-tasks-section">

        <div class="daily-section-heading">

            <div>

                <h2>
                    My daily routine
                </h2>

                <p>
                    Tasks that are generated for you each day.
                </p>

            </div>

            <span class="daily-task-count">
                <?= count($activeTemplates) ?>
                <?= count($activeTemplates) === 1
                    ? 'task'
                    : 'tasks' ?>
            </span>

        </div>

        <?php if ($activeTemplates === []): ?>

            <div class="daily-empty-state">

                <div
                    class="daily-empty-icon"
                    aria-hidden="true"
                >
                    ✓
                </div>

                <h3>
                    No daily tasks yet
                </h3>

                <p>
                    Add tasks you want Alliances to create for you
                    every day.
                </p>

                <button
                    type="button"
                    class="secondary-action"
                    id="empty-add-daily-task"
                >
                    Add your first daily task
                </button>

            </div>

        <?php else: ?>

            <div class="daily-task-list">

                <?php foreach (
                    $activeTemplates as $template
                ): ?>

                    <article class="daily-task-card">

                        <div
                            class="daily-task-status"
                            aria-hidden="true"
                        >
                            <span></span>
                        </div>

                        <div class="daily-task-content">

                            <div class="daily-task-heading">

                                <h3>
                                    <?= htmlspecialchars(
                                        $template['name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </h3>

                                <?php if (
                                    !empty(
                                        $template['deadline_time']
                                    )
                                ): ?>

                                    <span class="daily-deadline-badge">

                                        <svg
                                            viewBox="0 0 24 24"
                                            aria-hidden="true"
                                        >
                                            <circle
                                                cx="12"
                                                cy="12"
                                                r="9"
                                            ></circle>

                                            <path d="M12 7v5l3 2"></path>
                                        </svg>

                                        <?= htmlspecialchars(
                                            daily_time_label(
                                                $template['deadline_time']
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    </span>

                                <?php else: ?>

                                    <span class="daily-no-deadline">
                                        Anytime
                                    </span>

                                <?php endif; ?>

                            </div>

                            <?php if (
                                !empty($template['description'])
                            ): ?>

                                <p class="daily-task-description">
                                    <?= nl2br(
                                        htmlspecialchars(
                                            $template['description'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        )
                                    ) ?>
                                </p>

                            <?php endif; ?>

                            <div class="daily-task-meta">

                                <span>
                                    Repeats every day
                                </span>

                            </div>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>

    <!-- ================================================================
         INACTIVE
         ================================================================ -->

    <?php if ($inactiveTemplates !== []): ?>

        <section class="daily-inactive-section">

            <button
                type="button"
                class="daily-inactive-toggle"
                id="daily-inactive-toggle"
                aria-expanded="false"
                aria-controls="daily-inactive-list"
            >

                <span>
                    Paused daily tasks
                </span>

                <span class="daily-inactive-count">
                    <?= count($inactiveTemplates) ?>
                </span>

                <span
                    class="daily-inactive-chevron"
                    aria-hidden="true"
                >
                    ↓
                </span>

            </button>

            <div
                class="daily-inactive-list"
                id="daily-inactive-list"
                hidden
            >

                <?php foreach (
                    $inactiveTemplates as $template
                ): ?>

                    <article class="daily-task-card is-inactive">

                        <div class="daily-task-content">

                            <div class="daily-task-heading">

                                <h3>
                                    <?= htmlspecialchars(
                                        $template['name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </h3>

                                <span class="daily-paused-badge">
                                    Paused
                                </span>

                            </div>

                            <?php if (
                                !empty($template['description'])
                            ): ?>

                                <p class="daily-task-description">
                                    <?= nl2br(
                                        htmlspecialchars(
                                            $template['description'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        )
                                    ) ?>
                                </p>

                            <?php endif; ?>

                            <?php if (
                                !empty(
                                    $template['deadline_time']
                                )
                            ): ?>

                                <div class="daily-task-meta">

                                    <span>
                                        Daily deadline:
                                        <?= htmlspecialchars(
                                            daily_time_label(
                                                $template['deadline_time']
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                </div>

                            <?php endif; ?>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        </section>

    <?php endif; ?>

</main>

<script>
    const dailyCreatePanel =
        document.getElementById('daily-task-create');

    const openDailyTask =
        document.getElementById('open-daily-task');

    const emptyAddDailyTask =
        document.getElementById('empty-add-daily-task');

    const closeDailyTask =
        document.getElementById('close-daily-task');

    const cancelDailyTask =
        document.getElementById('cancel-daily-task');

    function showDailyTaskPanel() {
        if (!dailyCreatePanel) {
            return;
        }

        dailyCreatePanel.hidden = false;
        dailyCreatePanel.classList.add('is-open');

        if (openDailyTask) {
            openDailyTask.setAttribute(
                'aria-expanded',
                'true'
            );
        }

        const taskName =
            dailyCreatePanel.querySelector(
                'input[name="name"]'
            );

        if (taskName) {
            window.setTimeout(() => {
                taskName.focus();
            }, 50);
        }
    }

    function hideDailyTaskPanel() {
        if (!dailyCreatePanel) {
            return;
        }

        dailyCreatePanel.classList.remove('is-open');
        dailyCreatePanel.hidden = true;

        if (openDailyTask) {
            openDailyTask.setAttribute(
                'aria-expanded',
                'false'
            );
        }
    }

    if (openDailyTask) {
        openDailyTask.addEventListener(
            'click',
            showDailyTaskPanel
        );
    }

    if (emptyAddDailyTask) {
        emptyAddDailyTask.addEventListener(
            'click',
            showDailyTaskPanel
        );
    }

    if (closeDailyTask) {
        closeDailyTask.addEventListener(
            'click',
            hideDailyTaskPanel
        );
    }

    if (cancelDailyTask) {
        cancelDailyTask.addEventListener(
            'click',
            hideDailyTaskPanel
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Paused tasks
    |--------------------------------------------------------------------------
    */

    const inactiveToggle =
        document.getElementById('daily-inactive-toggle');

    const inactiveList =
        document.getElementById('daily-inactive-list');

    if (inactiveToggle && inactiveList) {
        inactiveToggle.addEventListener(
            'click',
            () => {
                const willOpen =
                    inactiveList.hidden;

                inactiveList.hidden =
                    !willOpen;

                inactiveToggle.setAttribute(
                    'aria-expanded',
                    willOpen ? 'true' : 'false'
                );
            }
        );
    }
</script>

</body>
</html>