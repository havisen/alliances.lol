<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';

/*
|--------------------------------------------------------------------------
| Generate daily tasks
|--------------------------------------------------------------------------
*/

ob_start();
require dirname(__DIR__, 2) . '/database/generate-daily.php';
ob_end_clean();

$user = require_login();
$connection = db();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$showCompleted =
    isset($_GET['show_completed'])
    && $_GET['show_completed'] === '1';

/*
|--------------------------------------------------------------------------
| Tasks assigned to current user
|--------------------------------------------------------------------------
|
| assigned_to = NULL means the task is assigned to Everyone.
|
*/

$statement = $connection->prepare(
    <<<SQL
    SELECT
        t.id,
        t.name,
        t.description,
        t.status,
        t.assigned_to,

        tl.id AS task_list_id,
        tl.name AS task_list_name,
        tl.deadline AS task_list_deadline,
        tl.team_id,
        tl.created_by AS task_list_created_by,

        team.name AS team_name

    FROM tasks t

    INNER JOIN task_lists tl
        ON tl.id = t.task_list_id

    INNER JOIN task_list_members tlm
        ON tlm.task_list_id = tl.id
       AND tlm.user_id = ?

    LEFT JOIN teams team
        ON team.id = tl.team_id
       AND team.workspace_id = tl.workspace_id

    WHERE tl.workspace_id = ?
      AND tl.status = ?
      AND (
            t.assigned_to IS NULL
            OR t.assigned_to = ?
      )
      AND (
            t.status = 'pending'
            OR (? = 1 AND t.status = 'completed')
      )

    ORDER BY
        CASE
            WHEN t.status = 'completed' THEN 1
            ELSE 0
        END,
        CASE
            WHEN tl.deadline IS NULL THEN 1
            ELSE 0
        END,
        tl.deadline ASC,
        tl.name ASC,
        t.id ASC
    SQL
);

$statement->execute([
    $user['id'],
    $workspaceId,
    'active',
    $user['id'],
    $showCompleted ? 1 : 0,
]);

$tasks = $statement->fetchAll();

/*
|--------------------------------------------------------------------------
| Active task lists available to current user
|--------------------------------------------------------------------------
*/

$listStatement = $connection->prepare(
    <<<SQL
    SELECT DISTINCT
        tl.id,
        tl.name,
        tl.deadline,
        tl.start_date,
        tl.created_by,
        tl.team_id,

        team.name AS team_name,

        (
            SELECT COUNT(*)
            FROM tasks list_tasks
            WHERE list_tasks.task_list_id = tl.id
        ) AS task_count,

        (
            SELECT COUNT(*)
            FROM tasks completed_tasks
            WHERE completed_tasks.task_list_id = tl.id
              AND completed_tasks.status = 'completed'
        ) AS completed_count

    FROM task_lists tl

    INNER JOIN task_list_members tlm
        ON tlm.task_list_id = tl.id
       AND tlm.user_id = ?

    LEFT JOIN teams team
        ON team.id = tl.team_id
       AND team.workspace_id = tl.workspace_id

    WHERE tl.workspace_id = ?
      AND tl.status = 'active'

    ORDER BY
        CASE
            WHEN tl.deadline IS NULL THEN 1
            ELSE 0
        END,
        tl.deadline ASC,
        tl.name ASC
    SQL
);

$listStatement->execute([
    $user['id'],
    $workspaceId,
]);

$activeLists = $listStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Dashboard calculations
|--------------------------------------------------------------------------
*/

$pendingTasks = [];
$completedTasks = [];

$overdueTaskCount = 0;
$dueSoonTaskCount = 0;
$personalTaskCount = 0;
$everyoneTaskCount = 0;

$now = time();
$nextSevenDays = $now + (7 * 86400);

foreach ($tasks as $task) {
    if ($task['status'] === 'completed') {
        $completedTasks[] = $task;
        continue;
    }

    $pendingTasks[] = $task;

    if ($task['assigned_to'] === null) {
        $everyoneTaskCount++;
    } else {
        $personalTaskCount++;
    }

    if (!empty($task['task_list_deadline'])) {
        $deadlineTimestamp =
            strtotime($task['task_list_deadline']);

        if ($deadlineTimestamp !== false) {
            if ($deadlineTimestamp < $now) {
                $overdueTaskCount++;
            } elseif ($deadlineTimestamp <= $nextSevenDays) {
                $dueSoonTaskCount++;
            }
        }
    }
}

$pendingTaskCount = count($pendingTasks);
$activeListCount = count($activeLists);

/*
|--------------------------------------------------------------------------
| Upcoming task lists
|--------------------------------------------------------------------------
*/

$upcomingLists = [];

foreach ($activeLists as $list) {
    if (empty($list['deadline'])) {
        continue;
    }

    $upcomingLists[] = $list;

    if (count($upcomingLists) >= 5) {
        break;
    }
}

/*
|--------------------------------------------------------------------------
| Date helpers
|--------------------------------------------------------------------------
*/

function overview_deadline_info(?string $deadline): array
{
    if ($deadline === null || $deadline === '') {
        return [
            'label' => 'No deadline',
            'state' => 'none',
        ];
    }

    try {
        $deadlineTime =
            new DateTimeImmutable($deadline);

        $now =
            new DateTimeImmutable();

        $seconds =
            $deadlineTime->getTimestamp()
            - $now->getTimestamp();

        if ($seconds < 0) {
            $absoluteSeconds = abs($seconds);

            if ($absoluteSeconds < 3600) {
                $minutes = max(
                    1,
                    (int) ceil(
                        $absoluteSeconds / 60
                    )
                );

                return [
                    'label' =>
                        'Overdue by '
                        . $minutes
                        . ($minutes === 1
                            ? ' minute'
                            : ' minutes'),
                    'state' => 'overdue',
                ];
            }

            if ($absoluteSeconds < 86400) {
                $hours = max(
                    1,
                    (int) ceil(
                        $absoluteSeconds / 3600
                    )
                );

                return [
                    'label' =>
                        'Overdue by '
                        . $hours
                        . ($hours === 1
                            ? ' hour'
                            : ' hours'),
                    'state' => 'overdue',
                ];
            }

            $days = max(
                1,
                (int) ceil(
                    $absoluteSeconds / 86400
                )
            );

            return [
                'label' =>
                    'Overdue by '
                    . $days
                    . ($days === 1
                        ? ' day'
                        : ' days'),
                'state' => 'overdue',
            ];
        }

        if ($seconds < 3600) {
            $minutes = max(
                1,
                (int) ceil(
                    $seconds / 60
                )
            );

            return [
                'label' =>
                    'Due in '
                    . $minutes
                    . ($minutes === 1
                        ? ' minute'
                        : ' minutes'),
                'state' => 'soon',
            ];
        }

        if ($seconds < 86400) {
            $hours = max(
                1,
                (int) ceil(
                    $seconds / 3600
                )
            );

            return [
                'label' =>
                    'Due in '
                    . $hours
                    . ($hours === 1
                        ? ' hour'
                        : ' hours'),
                'state' => 'soon',
            ];
        }

        if ($seconds <= (7 * 86400)) {
            $days = max(
                1,
                (int) ceil(
                    $seconds / 86400
                )
            );

            return [
                'label' =>
                    'Due in '
                    . $days
                    . ($days === 1
                        ? ' day'
                        : ' days'),
                'state' => 'soon',
            ];
        }

        return [
            'label' =>
                'Due '
                . $deadlineTime->format(
                    'M j, Y'
                ),
            'state' => 'normal',
        ];
    } catch (Exception $exception) {
        return [
            'label' => $deadline,
            'state' => 'normal',
        ];
    }
}

function overview_date(?string $value): string
{
    if ($value === null || $value === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date('M j, Y', $timestamp);
}

/*
|--------------------------------------------------------------------------
| Greeting
|--------------------------------------------------------------------------
*/

$displayName =
    trim((string) ($user['display_name'] ?? ''));

$firstName = $displayName;

if ($displayName !== '') {
    $nameParts = preg_split(
        '/\s+/',
        $displayName
    );

    if (
        is_array($nameParts)
        && isset($nameParts[0])
    ) {
        $firstName = $nameParts[0];
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Tasks | Alliances</title>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main overview-page">

    <!-- ================================================================
         HEADER
         ================================================================ -->

    <header class="page-header overview-header">

        <div class="page-header-content">

            <span class="page-eyebrow">
                Tasks
            </span>

            <h1>
                <?php if ($firstName !== ''): ?>

                    Welcome back,
                    <?= htmlspecialchars(
                        $firstName,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>

                <?php else: ?>

                    Your tasks

                <?php endif; ?>
            </h1>

            <p class="page-description">
                Here's what needs your attention across your active work.
            </p>

        </div>

        <div class="page-header-actions">

            <a
                href="/tasks/daily.php"
                class="primary-action"
            >
                Daily Tasks
            </a>

            <a
                href="/tasks/tasks.php"
                class="primary-action"
            >
                View task lists
            </a>

        </div>

    </header>
    <!-- ================================================================
         SUMMARY
         ================================================================ -->

    <section
        class="overview-summary-grid"
        aria-label="Work summary"
    >

        <a
            href="#my-work"
            class="overview-summary-card"
        >

            <div class="overview-summary-icon">
                <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                >
                    <path d="m9 11 2 2 4-4"></path>
                    <path d="M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"></path>
                </svg>
            </div>

            <div class="overview-summary-content">

                <span>
                    Open tasks
                </span>

                <strong>
                    <?= $pendingTaskCount ?>
                </strong>

                <small>
                    <?= $personalTaskCount ?>
                    assigned directly to you
                </small>

            </div>

        </a>

        <a
            href="/tasks/tasks.php"
            class="overview-summary-card"
        >

            <div class="overview-summary-icon">
                <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                >
                    <rect
                        x="3"
                        y="4"
                        width="18"
                        height="16"
                        rx="2"
                    ></rect>
                    <path d="M8 2v4"></path>
                    <path d="M16 2v4"></path>
                    <path d="M3 9h18"></path>
                </svg>
            </div>

            <div class="overview-summary-content">

                <span>
                    Active lists
                </span>

                <strong>
                    <?= $activeListCount ?>
                </strong>

                <small>
                    Lists you're currently part of
                </small>

            </div>

        </a>

        <div
            class="overview-summary-card <?= $dueSoonTaskCount > 0
                ? 'has-attention'
                : '' ?>"
        >

            <div class="overview-summary-icon">
                <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                >
                    <circle
                        cx="12"
                        cy="12"
                        r="9"
                    ></circle>
                    <path d="M12 7v5l3 2"></path>
                </svg>
            </div>

            <div class="overview-summary-content">

                <span>
                    Due soon
                </span>

                <strong>
                    <?= $dueSoonTaskCount ?>
                </strong>

                <small>
                    Due within the next 7 days
                </small>

            </div>

        </div>

        <div
            class="overview-summary-card <?= $overdueTaskCount > 0
                ? 'has-warning'
                : '' ?>"
        >

            <div class="overview-summary-icon">
                <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                >
                    <path d="M12 3 2.5 20h19L12 3Z"></path>
                    <path d="M12 9v4"></path>
                    <path d="M12 17h.01"></path>
                </svg>
            </div>

            <div class="overview-summary-content">

                <span>
                    Overdue
                </span>

                <strong>
                    <?= $overdueTaskCount ?>
                </strong>

                <small>
                    Tasks needing attention
                </small>

            </div>

        </div>

    </section>

    <!-- ================================================================
         DASHBOARD
         ================================================================ -->

    <div class="overview-dashboard-grid">

        <!-- ============================================================
             MY WORK
             ============================================================ -->

        <section
            class="overview-panel overview-work-panel"
            id="my-work"
        >

            <div class="overview-panel-header">

                <div>

                    <h2>My work</h2>

                    <p>
                        Tasks assigned to you or everyone.
                    </p>

                </div>

                <div class="overview-filter">

                    <?php if ($showCompleted): ?>

                        <a
                            href="/tasks/index.php"
                            class="secondary-action"
                        >
                            Hide completed
                        </a>

                    <?php else: ?>

                        <a
                            href="/tasks/index.php?show_completed=1"
                            class="secondary-action"
                        >
                            Show completed
                        </a>

                    <?php endif; ?>

                </div>

            </div>

            <?php if ($tasks === []): ?>

                <div class="overview-empty-state">

                    <div
                        class="overview-empty-icon"
                        aria-hidden="true"
                    >
                        ✓
                    </div>

                    <h3>You're all caught up</h3>

                    <p>
                        There are no open tasks assigned to you
                        in your active task lists.
                    </p>

                    <a
                        href="/tasks/tasks.php"
                        class="secondary-action"
                    >
                        Browse task lists
                    </a>

                </div>

            <?php else: ?>

                <div class="overview-task-list">

                    <?php foreach ($tasks as $task): ?>

                        <?php
                        $deadlineInfo =
                            overview_deadline_info(
                                $task['task_list_deadline']
                            );

                        $isCompleted =
                            $task['status']
                            === 'completed';

                        $isEveryone =
                            $task['assigned_to']
                            === null;
                        
                        $canDeleteTask =
                            !empty($access['is_admin'])
                            || (int) $task['task_list_created_by']
                            === (int) $user['id'];

                            ?>

                        <article
                            class="overview-task-item <?= $isCompleted
                                ? 'is-completed'
                                : '' ?>"
                        >

                            <div class="overview-task-check">

                                <?php if ($isCompleted): ?>

                                    <span
                                        class="overview-task-completed"
                                        title="Completed"
                                    >
                                        ✓
                                    </span>

                                <?php else: ?>

                                    <form
                                        method="post"
                                        action="/actions/tasks/complete-task.php"
                                    >

                                        <?= csrf_input() ?>

                                        <input
                                            type="hidden"
                                            name="task_id"
                                            value="<?= (int) $task['id'] ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="overview-complete-button"
                                            aria-label="Mark <?= htmlspecialchars(
                                                $task['name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?> as finished"
                                            title="Mark as finished"
                                        >
                                            <span aria-hidden="true">
                                                ✓
                                            </span>
                                        </button>

                                    </form>

                                <?php endif; ?>

                            </div>

                            <div class="overview-task-content">

                                <div class="overview-task-title-row">

                                    <h3>
                                        <a
                                            href="/tasks/task-list.php?id=<?= (int) $task['task_list_id'] ?>"
                                        >
                                            <?= htmlspecialchars(
                                                $task['name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </a>
                                    </h3>

                                    <?php if ($isEveryone): ?>

                                        <span class="overview-everyone-badge">
                                            Everyone
                                        </span>

                                    <?php endif; ?>

                                </div>

                                <?php if (
                                    !empty($task['description'])
                                ): ?>

                                    <p class="overview-task-description">
                                        <?= htmlspecialchars(
                                            $task['description'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </p>

                                <?php endif; ?>

                                <div class="overview-task-meta">

                                    <a
                                        href="/tasks/task-list.php?id=<?= (int) $task['task_list_id'] ?>"
                                        class="overview-task-list-link"
                                    >
                                        <?= htmlspecialchars(
                                            $task['task_list_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </a>

                                    <?php if (
                                        !empty($task['team_name'])
                                    ): ?>

                                        <span
                                            class="overview-meta-divider"
                                            aria-hidden="true"
                                        >
                                            •
                                        </span>

                                        <span>
                                            <?= alliances_team_link(
                                                (int) $task['team_id'],
                                                (string) $task['team_name']
                                            ) ?>
                                        </span>

                                    <?php endif; ?>

                                    <span
                                        class="overview-meta-divider"
                                        aria-hidden="true"
                                    >
                                        •
                                    </span>

                                    <span
                                        class="overview-deadline <?= htmlspecialchars(
                                            'is-' . $deadlineInfo['state'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                    >
                                        <?= htmlspecialchars(
                                            $deadlineInfo['label'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                </div>

                            </div>

                            <div class="overview-task-actions">

    <?php if ($canDeleteTask): ?>

        <form
            method="post"
            action="/actions/tasks/delete-task.php"
            onsubmit="return confirm('Delete this task? This cannot be undone.');"
        >
            <?= csrf_input() ?>

            <input
                type="hidden"
                name="task_id"
                value="<?= (int) $task['id'] ?>"
            >

            <input
                type="hidden"
                name="redirect"
                value="overview"
            >

            <button
                type="submit"
                class="overview-task-delete"
                aria-label="Delete <?= htmlspecialchars(
                    $task['name'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>"
                title="Delete task"
            >
                <svg
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                >
                    <path d="M3 6h18"></path>
                    <path d="M8 6V4h8v2"></path>
                    <path d="M19 6l-1 14H6L5 6"></path>
                    <path d="M10 11v5"></path>
                    <path d="M14 11v5"></path>
                </svg>
            </button>
        </form>

    <?php endif; ?>

    <a
        href="/tasks/task-list.php?id=<?= (int) $task['task_list_id'] ?>"
        class="overview-task-open"
        aria-label="Open task list"
        title="Open task list"
    >
        →
    </a>

</div>

                        </article>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </section>

        <!-- ============================================================
             RIGHT COLUMN
             ============================================================ -->

        <aside class="overview-sidebar">

            <!-- UPCOMING DEADLINES -->

            <section class="overview-panel">

                <div class="overview-panel-header">

                    <div>
                        <h2>Upcoming deadlines</h2>

                        <p>
                            Your active task lists.
                        </p>
                    </div>

                </div>

                <?php if ($upcomingLists === []): ?>

                    <div class="overview-sidebar-empty">
                        <p>
                            No upcoming deadlines.
                        </p>
                    </div>

                <?php else: ?>

                    <div class="overview-deadline-list">

                        <?php foreach (
                            $upcomingLists as $list
                        ): ?>

                            <?php
                            $listDeadline =
                                overview_deadline_info(
                                    $list['deadline']
                                );

                            $listTaskCount =
                                (int) $list['task_count'];

                            $listCompletedCount =
                                (int) $list['completed_count'];

                            $listProgress = 0;

                            if ($listTaskCount > 0) {
                                $listProgress =
                                    (int) round(
                                        (
                                            $listCompletedCount
                                            / $listTaskCount
                                        ) * 100
                                    );
                            }
                            ?>

                            <a
                                href="/tasks/task-list.php?id=<?= (int) $list['id'] ?>"
                                class="overview-deadline-item"
                            >

                                <div class="overview-deadline-item-top">

                                    <div>

                                        <strong>
                                            <?= htmlspecialchars(
                                                $list['name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </strong>

                                        <?php if (
                                            !empty($list['team_name'])
                                        ): ?>

                                            <small>
                                                <?= alliances_team_link(
                                                    (int) $list['team_id'],
                                                    (string) $list['team_name']
                                                ) ?>
                                            </small>

                                        <?php endif; ?>

                                    </div>

                                    <span
                                        class="overview-deadline <?= htmlspecialchars(
                                            'is-' . $listDeadline['state'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                    >
                                        <?= htmlspecialchars(
                                            $listDeadline['label'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                </div>

                                <div class="overview-list-progress">

                                    <div class="overview-list-progress-track">

                                        <span
                                            style="width: <?= $listProgress ?>%"
                                        ></span>

                                    </div>

                                    <small>
                                        <?= $listCompletedCount ?>
                                        /
                                        <?= $listTaskCount ?>
                                        completed
                                    </small>

                                </div>

                            </a>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

                <div class="overview-panel-footer">

                    <a href="/tasks/tasks.php">
                        View all task lists
                        <span aria-hidden="true">
                            →
                        </span>
                    </a>

                </div>

            </section>

            <!-- ASSIGNMENT SUMMARY -->

            <section class="overview-panel">

                <div class="overview-panel-header">

                    <div>
                        <h2>Assignment summary</h2>

                        <p>
                            Where your open work comes from.
                        </p>
                    </div>

                </div>

                <div class="overview-assignment-summary">

                    <div class="overview-assignment-row">

                        <span>
                            Assigned to you
                        </span>

                        <strong>
                            <?= $personalTaskCount ?>
                        </strong>

                    </div>

                    <div class="overview-assignment-row">

                        <span>
                            Assigned to everyone
                        </span>

                        <strong>
                            <?= $everyoneTaskCount ?>
                        </strong>

                    </div>

                    <div class="overview-assignment-row">

                        <span>
                            Total open
                        </span>

                        <strong>
                            <?= $pendingTaskCount ?>
                        </strong>

                    </div>

                </div>

            </section>

        </aside>

    </div>

</main>

</body>
</html>
