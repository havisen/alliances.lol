<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/notifications.php';
require_once dirname(__DIR__, 2) . '/src/tasks/templates.php';
require_once dirname(__DIR__, 2) . '/src/tasks/values.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';

$user = require_login();
$connection = db();

$listId = filter_input(
    INPUT_GET,
    'list',
    FILTER_VALIDATE_INT
);

if (!$listId) {
    http_response_code(404);
    exit('Task list not found.');
}

$listStatement = $connection->prepare(
    'SELECT
        tl.id,
        tl.workspace_id,
        tl.name,
        tl.created_by,
        tl.members_can_edit,
        tl.default_template_id

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     WHERE tl.id = ?
     LIMIT 1'
);

$listStatement->execute([
    $user['id'],
    $listId,
]);

$list = $listStatement->fetch();

if (!$list) {
    http_response_code(403);
    exit('You do not have access to this task list.');
}

$isCreator =
    (int) $list['created_by']
    === (int) $user['id'];

$canEdit =
    $isCreator
    || (int) $list['members_can_edit'] === 1;

if (!$canEdit) {
    http_response_code(403);
    exit('You do not have permission to add tasks to this list.');
}

$personChoices = work_template_person_choices((int) $list['workspace_id']);
$teamChoices = work_template_team_choices((int) $list['workspace_id']);
$projectChoices = work_template_project_choices((int) $list['workspace_id']);

$allowedTemplates = work_template_allowed_templates(
    (int) $list['workspace_id'],
    $listId
);

$selectableTemplates = [];

foreach ($allowedTemplates as $allowedTemplate) {
    if ($allowedTemplate['published_version_id'] !== null) {
        $selectableTemplates[(int) $allowedTemplate['published_version_id']]
            = $allowedTemplate;
    }
}

$defaultTemplateId = $list['default_template_id'] !== null
    ? (int) $list['default_template_id']
    : null;

$membersStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name

     FROM users u

     INNER JOIN task_list_members tlm
         ON tlm.user_id = u.id

     WHERE tlm.task_list_id = ?

     ORDER BY
        CASE
            WHEN u.id = ? THEN 0
            ELSE 1
        END,
        u.display_name ASC'
);

$membersStatement->execute([
    $listId,
    $list['created_by'],
]);

$listMembers = $membersStatement->fetchAll();

$error = null;

$formTaskName = '';
$formTaskDescription = '';
$formAssignedTo = 'all';
$formTemplateVersionId = '';

if ($defaultTemplateId !== null) {
    foreach ($selectableTemplates as $selectableVersionId => $selectableTemplate) {
        if ((int) $selectableTemplate['id'] === $defaultTemplateId) {
            $formTemplateVersionId = (string) $selectableVersionId;
            break;
        }
    }
}

$submittedTemplateValues = [];
$templateValueErrors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $formTaskName =
        trim($_POST['name'] ?? '');

    $formTaskDescription =
        trim($_POST['description'] ?? '');

    $formAssignedTo =
        (string) ($_POST['assigned_to'] ?? 'all');

    $formTemplateVersionId =
        (string) ($_POST['template_version_id'] ?? '');

    $selectedTemplateVersionId = filter_var(
        $formTemplateVersionId,
        FILTER_VALIDATE_INT
    );

    $selectedTemplateVersionId =
        $selectedTemplateVersionId === false
            ? null
            : (int) $selectedTemplateVersionId;

    $submittedTemplateValues = $_POST['values'] ?? [];

    if (!is_array($submittedTemplateValues)) {
        $submittedTemplateValues = [];
    }

    $assignToEveryone =
        $formAssignedTo === 'all';

    $assignedTo = null;

    if (!$assignToEveryone) {
        $assignedTo = filter_var(
            $formAssignedTo,
            FILTER_VALIDATE_INT
        );

        if ($assignedTo === false) {
            $error = 'Choose a valid assignee.';
        }
    }

    if ($error === null && $formTaskName === '') {
        $error = 'Enter a task name.';
    }

    if (
        $error === null
        && strlen($formTaskName) > 200
    ) {
        $error = 'Task names can be up to 200 characters.';
    }

    if (
        $error === null
        && !$assignToEveryone
    ) {
        $memberCheck = $connection->prepare(
            'SELECT 1
             FROM task_list_members
             WHERE task_list_id = ?
               AND user_id = ?
             LIMIT 1'
        );

        $memberCheck->execute([
            $listId,
            $assignedTo,
        ]);

        if ($memberCheck->fetchColumn() === false) {
            $error =
                'That person is not a member of this task list.';
        }
    }

    $templateVersionId = null;
    $templateSections = [];

    if (
        $error === null
        && $selectedTemplateVersionId !== null
    ) {
        if (!array_key_exists($selectedTemplateVersionId, $selectableTemplates)) {
            $error = 'Choose a valid template.';
        } else {
            $templateVersionId = $selectedTemplateVersionId;
            $templateSections = work_template_version_sections($templateVersionId);

            $templateValueErrors = work_template_validate_task_values(
                $templateSections,
                $submittedTemplateValues,
                $personChoices,
                $teamChoices,
                $projectChoices
            );

            if ($templateValueErrors !== []) {
                $error = 'Please fix the highlighted template fields.';
            }
        }
    }

    if ($error === null) {
        $taskId = 0;

        try {
            $statement = $connection->prepare(
                'INSERT INTO tasks
                    (
                        task_list_id,
                        assigned_to,
                        name,
                        description,
                        template_version_id
                    )
                 VALUES (?, ?, ?, ?, ?)'
            );

            $statement->execute([
                $listId,
                $assignToEveryone
                    ? null
                    : $assignedTo,
                $formTaskName,
                $formTaskDescription !== ''
                    ? $formTaskDescription
                    : null,
                $templateVersionId,
            ]);

            $taskId = (int) $connection->lastInsertId();

            if ($templateVersionId !== null) {
                work_template_save_task_values(
                    $taskId,
                    $templateSections,
                    $submittedTemplateValues,
                    $personChoices,
                    $teamChoices,
                    $projectChoices
                );
            }

            if (
                !$assignToEveryone
                && $assignedTo !== null
                && (int) $assignedTo !== (int) $user['id']
            ) {
                create_notification([
                    'workspace_id' => (int) $list['workspace_id'],
                    'user_id' => (int) $assignedTo,
                    'actor_user_id' => (int) $user['id'],
                    'type' => 'task_assigned',
                    'category' => 'tasks',
                    'title' => (string) $user['display_name']
                        . ' assigned you a task',
                    'body' => $formTaskName,
                    'target_type' => 'task',
                    'target_id' => $taskId,
                    'target_url' => '/tasks/task-list.php?id=' . $listId,
                ]);
            }

            header(
                'Location: /tasks/task-list.php?id='
                . $listId
            );

            exit;
        } catch (Throwable $exception) {
            if ($taskId > 0) {
                $cleanup = $connection->prepare(
                    'DELETE FROM tasks WHERE id = ?'
                );
                $cleanup->execute([$taskId]);
            }

            $error = 'Could not create the task. Please try again.';
        }
    }
}

$escape = static fn (string $text): string =>
    htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        New task
        | Alliances
    </title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main task-workspace">

    <div class="task-workspace-breadcrumb">

        <a href="/tasks/tasks.php">
            Tasks
        </a>

        <span aria-hidden="true">
            /
        </span>

        <a href="/tasks/task-list.php?id=<?= $listId ?>">
            <?= $escape((string) $list['name']) ?>
        </a>

        <span aria-hidden="true">
            /
        </span>

        <span>
            New task
        </span>

    </div>

    <header class="task-workspace-header">

        <div class="task-workspace-title">

            <h1>
                Add a task
            </h1>

            <div class="task-workspace-meta">
                <span>
                    Add a clear action and assign responsibility.
                </span>
            </div>

        </div>

    </header>

<section class="task-add-panel is-open">

        <?php if ($error !== null): ?>

            <div
                class="form-message form-message-error"
                role="alert"
            >
                <?= $escape($error) ?>
            </div>

        <?php endif; ?>

        <form
            method="post"
            class="task-add-form"
        >

            <?= csrf_input() ?>

            <label class="form-field">

                <span class="form-label">
                    Task
                </span>

                <input
                    type="text"
                    name="name"
                    maxlength="200"
                    required
                    placeholder="What needs to be done?"
                    value="<?= $escape($formTaskName) ?>"
                >

            </label>

            <label class="form-field">

                <span class="form-label">
                    Description
                </span>

                <span class="form-hint">
                    Optional
                </span>

                <textarea
                    name="description"
                    rows="4"
                    placeholder="Add useful context, instructions, or details..."
                ><?= $escape($formTaskDescription) ?></textarea>

            </label>

            <label class="form-field">

                <span class="form-label">
                    Assign to
                </span>

                <select
                    name="assigned_to"
                    required
                >

                    <option
                        value="all"
                        <?= $formAssignedTo === 'all'
                            ? 'selected'
                            : '' ?>
                    >
                        Everyone
                    </option>

                    <?php foreach ($listMembers as $member): ?>

                        <option
                            value="<?= (int) $member['id'] ?>"
                            <?= $formAssignedTo === (string) $member['id']
                                ? 'selected'
                                : '' ?>
                        >
                            <?= $escape((string) $member['display_name']) ?>

                            <?php if (
                                (int) $member['id']
                                === (int) $user['id']
                            ): ?>
                                (You)
                            <?php endif; ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </label>

            <label class="form-field">
                <span class="form-label">Template</span>
                <select name="template_version_id" id="task-template-select">
                    <option value="">No template / Basic task</option>

                    <?php foreach ($selectableTemplates as $selectableVersionId => $tmpl): ?>
                        <option
                            value="<?= (int) $selectableVersionId ?>"
                            <?= $formTemplateVersionId === (string) $selectableVersionId
                                ? 'selected'
                                : '' ?>
                        >
                            <?= $escape((string) $tmpl['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <?php if ($selectableTemplates === []): ?>
                    <span class="form-hint">
                        No published templates are allowed for this list yet.
                    </span>
                <?php endif; ?>
            </label>

<?php if ($selectableTemplates !== []): ?>
                <?php foreach ($selectableTemplates as $selectableVersionId => $tmpl): ?>
                    <?php $selectableSections = work_template_version_sections((int) $selectableVersionId); ?>
                    <div
                        class="task-template-form-fields"
                        data-template-version="<?= (int) $selectableVersionId ?>"
                        <?= $formTemplateVersionId === (string) $selectableVersionId ? '' : 'hidden' ?>
                    >
                        <?php foreach ($selectableSections as $tplSection): ?>
                            <?php if ($selectableSections !== []) : ?>
                            <p class="task-template-section-title"><?= $escape((string) $tplSection['name']) ?></p>
                            <?php endif; ?>

                            <?php foreach ($tplSection['fields'] as $tplField): ?>
                                <?php
                                $tplRaw = $submittedTemplateValues[(int) $tplField['id']] ?? null;
                                $tplError = $templateValueErrors[(int) $tplField['id']] ?? null;
                                ?>
                                <label class="form-field">
                                    <span class="form-label"><?= $escape((string) $tplField['name']) ?></span>
                                    <?php if (work_template_field_creation_eligible((string) $tplField['field_type'])): ?>
                                        <?= work_template_render_field_input(
                                            $tplField,
                                            $tplRaw,
                                            $personChoices,
                                            $teamChoices,
                                            $tplError,
                                            $projectChoices
                                        ) ?>
                                    <?php else: ?>
                                        <span class="form-hint">Available after the task is created.</span>
                                    <?php endif; ?>
                                </label>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>

            <?php endif; ?>

            <div class="task-create-actions">

                <a
                    class="secondary-action"
                    href="/tasks/task-list.php?id=<?= $listId ?>"
                >
                    Cancel
                </a>

                <button
                    type="submit"
                    class="primary-action"
                >
                    Add task
                </button>

            </div>

        </form>

    </section>

</main>

<script>
    const templateSelect =
        document.getElementById('task-template-select');

    const templateFieldGroups =
        document.querySelectorAll('[data-template-version]');

    if (templateSelect && templateFieldGroups.length) {
        templateSelect.addEventListener('change', () => {
            const selected = templateSelect.value;

            templateFieldGroups.forEach((group) => {
                group.hidden =
                    group.getAttribute('data-template-version') !== selected;
            });
        });
    }
</script>

</body>
</html>