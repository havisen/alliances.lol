<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/notifications.php';
require_once dirname(__DIR__, 2) . '/src/tasks/templates.php';
require_once dirname(__DIR__, 2) . '/src/tasks/values.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';

$user = require_login();
$connection = db();

$listId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$listId) {
    http_response_code(404);
    exit('Task list not found.');
}

/*
|--------------------------------------------------------------------------
| Load task list
|--------------------------------------------------------------------------
|
| Access is granted only when the current user is already a member of
| the task list.
|
*/

$listStatement = $connection->prepare(
    'SELECT
        tl.id,
        tl.workspace_id,
        tl.name,
        tl.status,
        tl.start_date,
        tl.deadline,
        tl.created_by,
        tl.members_can_edit,
        tl.team_id,
        tl.default_template_id,

        creator.display_name AS creator_name,
        creator.avatar_path AS creator_avatar,

        team.name AS team_name

     FROM task_lists tl

     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?

     INNER JOIN users creator
         ON creator.id = tl.created_by

     LEFT JOIN teams team
         ON team.id = tl.team_id
        AND team.workspace_id = tl.workspace_id

     WHERE tl.id = ?
     LIMIT 1'
);

$listStatement->execute([
    $user['id'],
    $listId,
]);

$list = $listStatement->fetch();

if (!$list) {
    http_response_code(403);
    exit('You do not have access to this task list.');
}

/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

$isCreator =
    (int) $list['created_by']
    === (int) $user['id'];

$canEdit =
    $isCreator
    || (int) $list['members_can_edit'] === 1;

/*
|--------------------------------------------------------------------------
| Templates
|--------------------------------------------------------------------------
*/

$access = workspace_access((int) $user['id']);
$isWorkspaceAdmin = $access !== null && !empty($access['is_admin']);
$canConfigureTemplates = $isCreator || $isWorkspaceAdmin;

$personChoices = work_template_person_choices((int) $list['workspace_id']);
$teamChoices = work_template_team_choices((int) $list['workspace_id']);

/*
|--------------------------------------------------------------------------
| Members
|--------------------------------------------------------------------------
*/

$membersStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.email,
        u.job_title,
        u.avatar_path

     FROM users u

     INNER JOIN task_list_members tlm
         ON tlm.user_id = u.id

     WHERE tlm.task_list_id = ?

     ORDER BY
        CASE
            WHEN u.id = ? THEN 0
            ELSE 1
        END,
        u.display_name ASC'
);

$membersStatement->execute([
    $listId,
    $list['created_by'],
]);

$listMembers = $membersStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Workspace users not already in list
|--------------------------------------------------------------------------
*/

$availableMembers = [];

if ($canEdit) {
    $availableMembersStatement = $connection->prepare(
        'SELECT
            u.id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path

         FROM users u

         INNER JOIN workspace_members wm
             ON wm.user_id = u.id

         WHERE wm.workspace_id = ?

           AND u.id NOT IN (
               SELECT user_id
               FROM task_list_members
               WHERE task_list_id = ?
           )

         ORDER BY u.display_name ASC'
    );

    $availableMembersStatement->execute([
        $list['workspace_id'],
        $listId,
    ]);

    $availableMembers =
        $availableMembersStatement->fetchAll();
}

/*
|--------------------------------------------------------------------------
| Tasks
|--------------------------------------------------------------------------
*/

$taskStatement = $connection->prepare(
    'SELECT
        t.id,
        t.name,
        t.description,
        t.status,
        t.assigned_to,
        t.template_version_id,

        u.display_name AS assigned_to_name,
        u.avatar_path AS assigned_to_avatar

     FROM tasks t

     LEFT JOIN users u
         ON u.id = t.assigned_to

     WHERE t.task_list_id = ?

     ORDER BY
        CASE
            WHEN t.status = "completed" THEN 1
            ELSE 0
        END,
        t.id ASC'
);

$taskStatement->execute([$listId]);

$tasks = $taskStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Separate active and completed tasks
|--------------------------------------------------------------------------
*/

$activeTasks = [];
$completedTasks = [];

foreach ($tasks as $task) {
    if ($task['status'] === 'completed') {
        $completedTasks[] = $task;
    } else {
        $activeTasks[] = $task;
    }
}

$totalTasks = count($tasks);
$completedTaskCount = count($completedTasks);
$activeTaskCount = count($activeTasks);

$progressPercent = 0;

if ($totalTasks > 0) {
    $progressPercent = (int) round(
        ($completedTaskCount / $totalTasks) * 100
    );
}

/*
|--------------------------------------------------------------------------
| Date information
|--------------------------------------------------------------------------
*/

function format_task_list_date(?string $value): string
{
    if ($value === null || $value === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date('M j, Y · H:i', $timestamp);
}

function render_task_template_sections(
    array $sections,
    array $values,
    array $personChoices,
    array $teamChoices
): void {
    $escape = static fn (string $text): string =>
        htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    ?>
    <div class="task-template-fields">
        <?php foreach ($sections as $section): ?>
            <div class="task-template-section">
                <?php if ((string) $section['name'] !== ''): ?>
                    <h5><?= $escape((string) $section['name']) ?></h5>
                <?php endif; ?>

                <?php foreach ($section['fields'] as $field): ?>
                    <?php
                    $value = work_template_field_current_value(
                        $field,
                        $values[(int) $field['id']] ?? null
                    );
                    ?>
                    <div class="task-template-field">
                        <span class="task-template-field-name">
                            <?= $escape((string) $field['name']) ?>
                        </span>
                        <span class="task-template-field-value">
                            <?= work_template_render_field_value(
                                $field,
                                $value,
                                $personChoices,
                                $teamChoices
                            ) ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
}

$templateTaskData = [];

foreach ($tasks as $task) {
    if ($task['template_version_id'] !== null) {
        $taskDefinition = work_template_task_definition(
            (int) $list['workspace_id'],
            (int) $task['id']
        );

        if ($taskDefinition !== null) {
            $templateTaskData[(int) $task['id']] = [
                'definition' => $taskDefinition,
                'values' => work_template_task_values((int) $task['id']),
            ];
        }
    }
}

$deadlineTimestamp = !empty($list['deadline'])
    ? strtotime($list['deadline'])
    : false;

$isOverdue =
    $list['status'] !== 'completed'
    && $deadlineTimestamp !== false
    && $deadlineTimestamp < time();

/*
|--------------------------------------------------------------------------
| Creator
|--------------------------------------------------------------------------
*/

$creatorInitial = '?';

if (!empty($list['creator_name'])) {
    $creatorInitial = strtoupper(
        substr(
            $list['creator_name'],
            0,
            1
        )
    );
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?= htmlspecialchars(
            $list['name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?>
        | Alliances
    </title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main task-workspace">

    <!-- ================================================================
         BREADCRUMB
         ================================================================ -->

    <div class="task-workspace-breadcrumb">

        <a href="/tasks/tasks.php">
            Tasks
        </a>

        <span aria-hidden="true">
            /
        </span>

        <span>
            <?= htmlspecialchars(
                $list['name'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>
        </span>

    </div>

    <!-- ================================================================
         HEADER
         ================================================================ -->

    <header class="task-workspace-header">

        <div class="task-workspace-title">

            <div class="task-workspace-badges">

                <?php if (!empty($list['team_name'])): ?>

                    <span class="task-team-badge">
                        <?= alliances_team_link(
                            (int) $list['team_id'],
                            (string) $list['team_name']
                        ) ?>
                    </span>

                <?php endif; ?>

                <?php if ($list['status'] === 'completed'): ?>

                    <span class="task-status-badge completed">
                        Completed
                    </span>

                <?php elseif ($isOverdue): ?>

                    <span class="task-status-badge overdue">
                        Overdue
                    </span>

                <?php else: ?>

                    <span class="task-status-badge active">
                        Active
                    </span>

                <?php endif; ?>

            </div>

            <h1>
                <?= htmlspecialchars(
                    $list['name'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h1>

            <div class="task-workspace-meta">

                <div class="task-workspace-created-by">

                    <?php if (!empty($list['creator_avatar'])): ?>

                        <img
                            class="task-list-creator-avatar"
                            src="<?= htmlspecialchars(
                                $list['creator_avatar'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt=""
                        >

                    <?php else: ?>

                        <span
                            class="task-list-creator-avatar task-list-creator-placeholder"
                        >
                            <?= htmlspecialchars(
                                $creatorInitial,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>

                    <?php endif; ?>

                    <span>
                        Created by

                        <a
                            href="/profile/?id=<?= (int) $list['created_by'] ?>"
                        >
                            <?= htmlspecialchars(
                                $list['creator_name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </a>
                    </span>

                </div>

                <?php if (!empty($list['start_date'])): ?>

                    <span class="task-meta-divider">
                        •
                    </span>

                    <span>
                        Starts
                        <strong>
                            <?= htmlspecialchars(
                                format_task_list_date(
                                    $list['start_date']
                                ),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </strong>
                    </span>

                <?php endif; ?>

                <?php if (!empty($list['deadline'])): ?>

                    <span class="task-meta-divider">
                        •
                    </span>

                    <span
                        class="<?= $isOverdue
                            ? 'task-deadline-overdue'
                            : '' ?>"
                    >
                        Deadline
                        <strong>
                            <?= htmlspecialchars(
                                format_task_list_date(
                                    $list['deadline']
                                ),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </strong>
                    </span>

                <?php endif; ?>

            </div>

        </div>

        <?php if ($canEdit): ?>

            <div class="task-workspace-actions">

                <a
                    class="primary-action"
                    href="/tasks/new-task.php?list=<?= $listId ?>"
                >
                    <span aria-hidden="true">
                        +
                    </span>

                    Add task
                </a>

            </div>

        <?php endif; ?>

    </header>

    <!-- ================================================================
         PROGRESS
         ================================================================ -->

    <section class="task-progress-card">

        <div class="task-progress-copy">

            <div>
                <span class="task-progress-label">
                    Progress
                </span>

                <strong>
                    <?= $progressPercent ?>%
                </strong>
            </div>

            <p>
                <?php if ($totalTasks === 0): ?>

                    No tasks have been added yet.

                <?php elseif ($completedTaskCount === $totalTasks): ?>

                    All <?= $totalTasks ?> tasks are complete.

                <?php else: ?>

                    <?= $completedTaskCount ?>
                    of
                    <?= $totalTasks ?>
                    tasks completed

                <?php endif; ?>
            </p>

        </div>

        <div
            class="task-progress-track"
            role="progressbar"
            aria-valuemin="0"
            aria-valuemax="100"
            aria-valuenow="<?= $progressPercent ?>"
        >
            <span
                class="task-progress-value"
                style="width: <?= $progressPercent ?>%"
            ></span>
        </div>

    </section>

    <!-- Task creation has moved to /tasks/new-task.php. -->

    <!-- ================================================================
         WORKSPACE GRID
         ================================================================ -->

    <div class="task-workspace-grid">

        <!-- ============================================================
             TASKS
             ============================================================ -->

        <section class="task-workspace-main">

            <div class="task-section-heading">

                <div>
                    <h2>Open tasks</h2>

                    <p>
                        <?= $activeTaskCount ?>
                        <?= $activeTaskCount === 1
                            ? 'task'
                            : 'tasks' ?>
                        remaining
                    </p>
                </div>

                <?php if ($canEdit): ?>

                    <a
                        class="secondary-action task-inline-add"
                        href="/tasks/new-task.php?list=<?= $listId ?>"
                    >
                        + Add task
                    </a>

                <?php endif; ?>

            </div>

            <?php if ($activeTasks === []): ?>

                <div class="task-empty-state">

                    <div
                        class="task-empty-icon"
                        aria-hidden="true"
                    >
                        ✓
                    </div>

                    <?php if ($totalTasks === 0): ?>

                        <h3>No tasks yet</h3>

                        <p>
                            Add the first task to get this list moving.
                        </p>

                    <?php else: ?>

                        <h3>Everything is finished</h3>

                        <p>
                            All tasks in this list have been completed.
                        </p>

                    <?php endif; ?>

                </div>

            <?php else: ?>

                <div class="task-items">

                    <?php foreach ($activeTasks as $task): ?>

                        <article class="task-item">

                            <div class="task-item-status">

                                <a
                                    class="task-complete-button"
                                    href="/tasks/task.php?id=<?= (int) $task['id'] ?>"
                                    title="Open task"
                                >
                                    <span aria-hidden="true">✓</span>
                                </a>

                            </div>

                            <div class="task-item-content">

                                <div class="task-item-heading">

                                    <h3>
                                        <a href="/tasks/task.php?id=<?= (int) $task['id'] ?>">
                                            <?= htmlspecialchars(
                                                $task['name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </a>
                                    </h3>

                                </div>

                                <?php if (isset($templateTaskData[(int) $task['id']])): ?>
                                    <?php
                                    render_task_template_sections(
                                        $templateTaskData[(int) $task['id']]['definition']['sections'],
                                        $templateTaskData[(int) $task['id']]['values'],
                                        $personChoices,
                                        $teamChoices
                                    );
                                    ?>
                                <?php endif; ?>

                                <?php if (!empty($task['description'])): ?>

                                    <div class="task-item-description">
                                        <?= nl2br(
                                            htmlspecialchars(
                                                $task['description'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            )
                                        ) ?>
                                    </div>

                                <?php endif; ?>

                                <div class="task-item-footer">

                                    <?php if (
                                        !empty($task['assigned_to_name'])
                                    ): ?>

                                        <a
                                            class="task-assignee"
                                            href="/profile/?id=<?= (int) $task['assigned_to'] ?>"
                                        >

                                            <?php if (
                                                !empty(
                                                    $task['assigned_to_avatar']
                                                )
                                            ): ?>

                                                <img
                                                    class="task-avatar"
                                                    src="<?= htmlspecialchars(
                                                        $task['assigned_to_avatar'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>"
                                                    alt=""
                                                >

                                            <?php else: ?>

                                                <span
                                                    class="task-avatar task-avatar-placeholder"
                                                >
                                                    <?= htmlspecialchars(
                                                        strtoupper(
                                                            substr(
                                                                $task['assigned_to_name'],
                                                                0,
                                                                1
                                                            )
                                                        ),
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </span>

                                            <?php endif; ?>

                                            <span>
                                                <?= htmlspecialchars(
                                                    $task['assigned_to_name'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </span>

                                        </a>

                                    <?php else: ?>

                                        <span class="task-assignee task-assignee-everyone">

                                            <span
                                                class="task-avatar task-avatar-everyone"
                                                aria-hidden="true"
                                            >
                                                👥
                                            </span>

                                            <span>
                                                Everyone
                                            </span>

                                        </span>

                                    <?php endif; ?>

                                </div>

                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

            <!-- ========================================================
                 COMPLETED TASKS
                 ======================================================== -->

            <?php if ($completedTasks !== []): ?>

                <section class="completed-task-section">

                    <button
                        type="button"
                        class="completed-task-toggle"
                        id="completed-task-toggle"
                        aria-expanded="false"
                        aria-controls="completed-task-list"
                    >

                        <span>
                            Completed
                        </span>

                        <span class="completed-task-count">
                            <?= $completedTaskCount ?>
                        </span>

                        <span
                            class="completed-task-chevron"
                            aria-hidden="true"
                        >
                            ↓
                        </span>

                    </button>

                    <div
                        class="completed-task-list"
                        id="completed-task-list"
                        hidden
                    >

                        <?php foreach ($completedTasks as $task): ?>

                            <article class="task-item task-item-completed">

                                <div class="task-item-status">

                                    <span
                                        class="task-completed-indicator"
                                        aria-hidden="true"
                                    >
                                        ✓
                                    </span>

                                </div>

                                <div class="task-item-content">

                                    <h3>
                                        <a href="/tasks/task.php?id=<?= (int) $task['id'] ?>">
                                            <?= htmlspecialchars(
                                                $task['name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </a>
                                    </h3>

                                    <?php if (isset($templateTaskData[(int) $task['id']])): ?>
                                        <?php
                                        render_task_template_sections(
                                            $templateTaskData[(int) $task['id']]['definition']['sections'],
                                            $templateTaskData[(int) $task['id']]['values'],
                                            $personChoices,
                                            $teamChoices
                                        );
                                        ?>
                                    <?php endif; ?>

                                    <?php if (
                                        !empty($task['description'])
                                    ): ?>

                                        <div class="task-item-description">
                                            <?= nl2br(
                                                htmlspecialchars(
                                                    $task['description'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                )
                                            ) ?>
                                        </div>

                                    <?php endif; ?>

                                    <div class="task-item-footer">

                                        <?php if (
                                            !empty(
                                                $task['assigned_to_name']
                                            )
                                        ): ?>

                                            <a
                                                class="task-assignee"
                                                href="/profile/?id=<?= (int) $task['assigned_to'] ?>"
                                            >

                                                <?php if (
                                                    !empty(
                                                        $task['assigned_to_avatar']
                                                    )
                                                ): ?>

                                                    <img
                                                        class="task-avatar"
                                                        src="<?= htmlspecialchars(
                                                            $task['assigned_to_avatar'],
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>"
                                                        alt=""
                                                    >

                                                <?php else: ?>

                                                    <span
                                                        class="task-avatar task-avatar-placeholder"
                                                    >
                                                        <?= htmlspecialchars(
                                                            strtoupper(
                                                                substr(
                                                                    $task['assigned_to_name'],
                                                                    0,
                                                                    1
                                                                )
                                                            ),
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>
                                                    </span>

                                                <?php endif; ?>

                                                <span>
                                                    <?= htmlspecialchars(
                                                        $task['assigned_to_name'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </span>

                                            </a>

                                        <?php else: ?>

                                            <span class="task-assignee">
                                                Everyone
                                            </span>

                                        <?php endif; ?>

                                    </div>

                                </div>

                            </article>

                        <?php endforeach; ?>

                    </div>

                </section>

            <?php endif; ?>

        </section>

        <!-- ============================================================
             SIDEBAR
             ============================================================ -->

        <aside class="task-details-sidebar">

            <?php if ($canConfigureTemplates): ?>

                <!-- TEMPLATES -->

                <section class="task-detail-card">

                    <div class="task-detail-card-heading">
                        <div>
                            <h2>Templates</h2>
                            <span>Allowed for this list</span>
                        </div>
                    </div>

                    <a
                        class="secondary-action"
                        href="/tasks/configure-templates.php?list=<?= $listId ?>"
                    >
                        Configure templates
                    </a>

                </section>

            <?php endif; ?>

            <!-- PEOPLE -->

            <section class="task-detail-card">

                <div class="task-detail-card-heading">

                    <div>
                        <h2>People</h2>

                        <span>
                            <?= count($listMembers) ?>
                            <?= count($listMembers) === 1
                                ? 'member'
                                : 'members' ?>
                        </span>
                    </div>

                    <?php if (
                        $canEdit
                        && $availableMembers !== []
                    ): ?>

                        <button
                            type="button"
                            class="task-detail-add-button"
                            id="open-add-member"
                            aria-expanded="false"
                            aria-controls="add-member-panel"
                            title="Add member"
                        >
                            +
                        </button>

                    <?php endif; ?>

                </div>

                <div class="task-member-list">

                    <?php foreach ($listMembers as $member): ?>

                        <?php
                        $memberIsCreator =
                            (int) $member['id']
                            === (int) $list['created_by'];

                        $memberIsCurrentUser =
                            (int) $member['id']
                            === (int) $user['id'];

                        $memberInitial = strtoupper(
                            substr(
                                $member['display_name'],
                                0,
                                1
                            )
                        );
                        ?>

                        <a
                            class="task-detail-member"
                            href="/profile/?id=<?= (int) $member['id'] ?>"
                        >

                            <?php if (
                                !empty($member['avatar_path'])
                            ): ?>

                                <img
                                    class="task-detail-member-avatar"
                                    src="<?= htmlspecialchars(
                                        $member['avatar_path'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                    alt=""
                                >

                            <?php else: ?>

                                <span
                                    class="task-detail-member-avatar task-detail-member-placeholder"
                                >
                                    <?= htmlspecialchars(
                                        $memberInitial,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>

                            <?php endif; ?>

                            <span class="task-detail-member-info">

                                <strong>
                                    <?= htmlspecialchars(
                                        $member['display_name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                    <?php if ($memberIsCurrentUser): ?>
                                        <span class="task-you-label">
                                            You
                                        </span>
                                    <?php endif; ?>
                                </strong>

                                <small>
                                    <?php if ($memberIsCreator): ?>

                                        List creator

                                    <?php elseif (
                                        !empty($member['job_title'])
                                    ): ?>

                                        <?= htmlspecialchars(
                                            $member['job_title'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    <?php else: ?>

                                        Member

                                    <?php endif; ?>
                                </small>

                            </span>

                        </a>

                    <?php endforeach; ?>

                </div>

                <?php if (
                    $canEdit
                    && $availableMembers !== []
                ): ?>

                    <div
                        class="task-add-member-panel"
                        id="add-member-panel"
                        hidden
                    >

                        <form
                            method="post"
                            action="/actions/tasks/add-list-member.php"
                        >
                            <?= csrf_input() ?>

                            <input
                                type="hidden"
                                name="task_list_id"
                                value="<?= (int) $list['id'] ?>"
                            >

                            <label class="form-field">

                                <span class="form-label">
                                    Add member
                                </span>

                                <select
                                    name="member_id"
                                    required
                                >

                                    <option value="">
                                        Choose a person
                                    </option>

                                    <?php foreach (
                                        $availableMembers as $member
                                    ): ?>

                                        <option
                                            value="<?= (int) $member['id'] ?>"
                                        >
                                            <?= htmlspecialchars(
                                                $member['display_name'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                            <?php if (
                                                !empty(
                                                    $member['job_title']
                                                )
                                            ): ?>
                                                —
                                                <?= htmlspecialchars(
                                                    $member['job_title'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            <?php endif; ?>
                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </label>

                            <div class="task-add-member-actions">

                                <button
                                    type="button"
                                    class="secondary-action"
                                    id="cancel-add-member"
                                >
                                    Cancel
                                </button>

                                <button
                                    type="submit"
                                    class="primary-action"
                                >
                                    Add
                                </button>

                            </div>

                        </form>

                    </div>

                <?php endif; ?>

            </section>

            <!-- LIST INFORMATION -->

            <section class="task-detail-card">

                <div class="task-detail-card-heading">
                    <div>
                        <h2>List details</h2>
                    </div>
                </div>

                <dl class="task-detail-list">

                    <div>
                        <dt>Status</dt>

                        <dd>
                            <?= htmlspecialchars(
                                ucfirst($list['status']),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </dd>
                    </div>

                    <?php if (!empty($list['team_name'])): ?>

                        <div>
                            <dt>Team</dt>

                            <dd>
                                <?= alliances_team_link(
                                    (int) $list['team_id'],
                                    (string) $list['team_name']
                                ) ?>
                            </dd>
                        </div>

                    <?php endif; ?>

                    <div>
                        <dt>Created by</dt>

                        <dd>
                            <?= htmlspecialchars(
                                $list['creator_name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </dd>
                    </div>

                    <?php if (!empty($list['start_date'])): ?>

                        <div>
                            <dt>Starts</dt>

                            <dd>
                                <?= htmlspecialchars(
                                    format_task_list_date(
                                        $list['start_date']
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </dd>
                        </div>

                    <?php endif; ?>

                    <?php if (!empty($list['deadline'])): ?>

                        <div>
                            <dt>Deadline</dt>

                            <dd
                                class="<?= $isOverdue
                                    ? 'task-deadline-overdue'
                                    : '' ?>"
                            >
                                <?= htmlspecialchars(
                                    format_task_list_date(
                                        $list['deadline']
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </dd>
                        </div>

                    <?php endif; ?>

                    <div>
                        <dt>Editing</dt>

                        <dd>
                            <?php if (
                                (int) $list['members_can_edit'] === 1
                            ): ?>

                                Members can edit

                            <?php else: ?>

                                Creator only

                            <?php endif; ?>
                        </dd>
                    </div>

                </dl>

            </section>

            <?php if (!$canEdit): ?>

                <div class="task-readonly-notice">
                    <strong>View only</strong>

                    <p>
                        You can see this list and its tasks, but only
                        permitted members can make changes.
                    </p>
                </div>

            <?php endif; ?>

        </aside>

    </div>

</main>

<script>
    /*
    |--------------------------------------------------------------------------
    | Add member panel
    |--------------------------------------------------------------------------
    */

    const openAddMember =
        document.getElementById('open-add-member');

    const addMemberPanel =
        document.getElementById('add-member-panel');

    const cancelAddMember =
        document.getElementById('cancel-add-member');

    if (openAddMember && addMemberPanel) {
        openAddMember.addEventListener(
            'click',
            () => {
                const willOpen =
                    addMemberPanel.hidden;

                addMemberPanel.hidden =
                    !willOpen;

                openAddMember.setAttribute(
                    'aria-expanded',
                    willOpen ? 'true' : 'false'
                );
            }
        );
    }

    if (cancelAddMember && addMemberPanel) {
        cancelAddMember.addEventListener(
            'click',
            () => {
                addMemberPanel.hidden = true;

                if (openAddMember) {
                    openAddMember.setAttribute(
                        'aria-expanded',
                        'false'
                    );
                }
            }
        );
    }

    /*
    |--------------------------------------------------------------------------
    | Completed tasks
    |--------------------------------------------------------------------------
    */

    const completedToggle =
        document.getElementById('completed-task-toggle');

    const completedList =
        document.getElementById('completed-task-list');

    if (completedToggle && completedList) {
        completedToggle.addEventListener(
            'click',
            () => {
                const willOpen =
                    completedList.hidden;

                completedList.hidden =
                    !willOpen;

                completedToggle.setAttribute(
                    'aria-expanded',
                    willOpen ? 'true' : 'false'
                );
            }
        );
    }
</script>

</body>
</html>
