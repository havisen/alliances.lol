<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/notifications.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';
require_once dirname(__DIR__, 2) . '/src/tasks/lists.php';
require_once dirname(__DIR__, 2) . '/src/tasks/values.php';
require_once dirname(__DIR__, 2) . '/src/projects.php';
require_once dirname(__DIR__, 2) . '/src/tasks/advanced.php';

$user = require_login();
$userId = (int) $user['id'];
$connection = db();
$access = workspace_access($userId);
if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}
$workspaceId = (int) $access['workspace_id'];
$taskId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$task = $taskId && $taskId > 0 ? task_for_member($workspaceId, $userId, $taskId) : null;
if ($task === null) {
    http_response_code(404);
    exit('Task not found or unavailable.');
}

$taskId = (int) $task['id'];
$listId = (int) $task['task_list_id'];
$list = task_list_by_id($listId, $workspaceId);
$canEdit = task_can_edit($task, $userId);
$canComplete = task_can_complete($task, $userId);
$canDelete = !empty($access['is_admin']) || $canEdit;
$assigneeChoices = task_assignee_choices($workspaceId, $listId);
$unavailableAssignee = $task['assigned_to'] !== null
    && !array_key_exists((int) $task['assigned_to'], $assigneeChoices);
$assignedLabel = 'Everyone';
if ($task['assigned_to'] !== null) {
    $assignedLabel = (string) ($task['assigned_to_name'] ?? 'Unavailable member');
    if ($task['assigned_to_status'] !== null && $task['assigned_to_status'] !== 'active') {
        $assignedLabel .= ' (inactive)';
    } elseif ($unavailableAssignee && $task['assigned_to_name'] !== null) {
        $assignedLabel .= ' (no longer a list member)';
    }
}

// Project context never grants Task access. Only link to Projects the viewer may open.
$project = null;
$canViewProject = false;
if (($list['project_id'] ?? null) !== null) {
    $project = project_by_id((int) $list['project_id'], $workspaceId);
    $canViewProject = $project !== null
        && project_user_can_view($access, $userId, (int) $project['id']);
}

$definition = null;
$values = [];
$personChoices = [];
$teamChoices = [];
if ($task['template_version_id'] !== null) {
    $definition = work_template_task_definition($workspaceId, $taskId);
    if ($definition !== null) {
        $values = work_template_task_values($taskId);
        $personChoices = work_template_person_choices($workspaceId);
        $teamChoices = work_template_team_choices($workspaceId);
        $projectChoices = work_template_project_choices($workspaceId);
    }
}

$advanced = [];
$computed = [];
if ($definition !== null) {
    $advanced = work_template_advanced_load($taskId);
    $currentByFieldId = [];
    foreach ($definition['sections'] as $advancedSection) {
        foreach ($advancedSection['fields'] as $advancedField) {
            $currentByFieldId[(int) $advancedField['id']] = work_template_field_current_value(
                $advancedField,
                $values[(int) $advancedField['id']] ?? null
            );
        }
    }
    $computed = work_template_advanced_compute_fields(
        $definition['sections'],
        $currentByFieldId,
        $advanced,
        $workspaceId,
        $userId,
        $access
    );
}

$formName = (string) $task['name'];
$formDescription = (string) ($task['description'] ?? '');
$formAssignee = $unavailableAssignee ? 'keep' : (string) ($task['assigned_to'] ?? 'all');
$detailsError = null;
$workError = null;
$templateValueErrors = [];
$submittedTemplateValues = [];
$valuesSubmitted = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    if (!$canEdit) {
        http_response_code(403);
        exit('You do not have permission to edit this task.');
    }
    $action = $_POST['action'] ?? '';
    if ($action === 'save_details') {
        if (!is_string($_POST['name'] ?? null)
            || !is_string($_POST['description'] ?? null)
            || !is_string($_POST['assigned_to'] ?? null)) {
            $detailsError = 'Enter valid task details.';
        } else {
            $formName = trim($_POST['name']);
            $formDescription = trim($_POST['description']);
            $formAssignee = $_POST['assigned_to'];
            if ($formName === '') {
                $detailsError = 'Enter a task name.';
            } elseif (strlen($formName) > 200) {
                $detailsError = 'Task names can be up to 200 characters.';
            }
        }

        if ($detailsError === null) {
            try {
                $connection->beginTransaction();
                // Recheck inside the transaction so repeated saves do not duplicate notifications.
                $currentTask = task_for_member($workspaceId, $userId, $taskId);
                if ($currentTask === null || !task_can_edit($currentTask, $userId)) {
                    $connection->rollBack();
                    http_response_code(403);
                    exit('You no longer have permission to edit this task.');
                }
                $currentChoices = task_assignee_choices($workspaceId, $listId);
                $assignedTo = null;
                if ($formAssignee === 'keep'
                    && $currentTask['assigned_to'] !== null
                    && !array_key_exists((int) $currentTask['assigned_to'], $currentChoices)) {
                    // Preserve a historical assignment without making it a selectable new assignee.
                    $assignedTo = (int) $currentTask['assigned_to'];
                } elseif ($formAssignee !== 'all') {
                    $candidate = filter_var($formAssignee, FILTER_VALIDATE_INT);
                    if ($candidate === false || !array_key_exists($candidate, $currentChoices)) {
                        $detailsError = 'Choose an active member of this task list or Everyone.';
                    } else {
                        $assignedTo = (int) $candidate;
                    }
                }

                if ($detailsError !== null) {
                    $connection->rollBack();
                } else {
                    $statement = $connection->prepare(
                        'UPDATE tasks SET name = ?, description = ?, assigned_to = ?
                         WHERE id = ? AND task_list_id = ?'
                    );
                    $statement->execute([
                        $formName, $formDescription !== '' ? $formDescription : null,
                        $assignedTo, $taskId, $listId,
                    ]);
                    $previousAssignee = $currentTask['assigned_to'] !== null
                        ? (int) $currentTask['assigned_to'] : null;
                    if ($assignedTo !== null && $assignedTo !== $previousAssignee && $assignedTo !== $userId) {
                        create_notification([
                            'workspace_id' => $workspaceId,
                            'user_id' => $assignedTo,
                            'actor_user_id' => $userId,
                            'type' => 'task_assigned',
                            'category' => 'tasks',
                            'title' => (string) $user['display_name'] . ' assigned you a task',
                            'body' => $formName,
                            'target_type' => 'task',
                            'target_id' => $taskId,
                            'target_url' => '/tasks/task.php?id=' . $taskId,
                        ]);
                    }
                    $connection->commit();
                    header('Location: /tasks/task.php?id=' . $taskId . '&saved=details', true, 303);
                    exit;
                }
            } catch (Throwable $exception) {
                if ($connection->inTransaction()) {
                    $connection->rollBack();
                }
                $detailsError = 'Could not save task details. Please try again.';
            }
        }
    } elseif ($action === 'save_values') {
        if ($definition === null) {
            http_response_code(400);
            exit('The Work Template definition is unavailable for this task.');
        }
        if (!is_array($_POST['values'] ?? [])) {
            $workError = 'Invalid work values. Nothing was saved; please try again.';
        } else {
            $valuesSubmitted = true;
            $submittedTemplateValues = $_POST['values'] ?? [];
            try {
                $templateValueErrors = work_template_save_task_values(
                    $taskId, $definition['sections'], $submittedTemplateValues,
                    $personChoices, $teamChoices
                );
                if ($templateValueErrors === []) {
                    header('Location: /tasks/task.php?id=' . $taskId . '&saved=work', true, 303);
                    exit;
                }
                $workError = 'Work was not saved. Please fix the highlighted fields.';
            } catch (Throwable $exception) {
                $workError = 'Could not save work. Your entries are shown below; please try again.';
            }
        }
    } else {
        http_response_code(400);
        exit('Unknown task action.');
    }
}

$escape = static fn (string $text): string => htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
$formatDate = static function (?string $value): string {
    if ($value === null || $value === '') {
        return '';
    }
    $timestamp = strtotime($value);
    return $timestamp === false ? $value : date('M j, Y · H:i', $timestamp);
};
$savedMessage = match ($_GET['saved'] ?? '') {
    'details' => 'Task details saved.',
    'work' => 'Work saved.',
    default => null,
};
if (($_GET['state'] ?? '') === $task['status']) {
    $savedMessage = $task['status'] === 'completed' ? 'Task completed.' : 'Task reopened.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="/assets/css/task-advanced.css">
    <title><?= $escape((string) $task['name']) ?> | Alliances</title>
</head>
<body>
<?php render_navigation($user); ?>
<main class="app-main">
    <div class="page-container">
        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title"><?= $escape((string) $task['name']) ?></h1>
                <div class="record-meta">
                    <span class="record-meta-item">Task List: <a href="/tasks/task-list.php?id=<?= $listId ?>"><?= $escape((string) $task['list_name']) ?></a></span>
                    <span class="record-meta-item">Assignee: <?= $escape($assignedLabel) ?></span>
                    <span class="badge <?= $task['status'] === 'completed' ? 'badge--success' : 'badge--warning' ?>"><?= $task['status'] === 'completed' ? 'Completed' : 'Pending' ?></span>
                    <?php if (($list['project_id'] ?? null) !== null): ?>
                        <span class="record-meta-item">Project: <?= $canViewProject ? $escape((string) $project['name']) : 'Linked project (unavailable to you)' ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="page-header-actions">
                <a class="secondary-action" href="/tasks/task-list.php?id=<?= $listId ?>">Back to Task List</a>
                <?php if ($canViewProject): ?>
                    <a class="secondary-action" href="/projects/project.php?id=<?= (int) $project['id'] ?>">Project</a>
                <?php endif; ?>
            </div>
        </header>

        <?php if ($savedMessage !== null): ?>
            <p class="form-success" role="status"><?= $escape($savedMessage) ?></p>
        <?php endif; ?>
        <?php if (isset($_GET['state_error'])): ?>
            <p class="form-error" role="alert">Could not change the task status. Please try again.</p>
        <?php endif; ?>

        <section class="section" aria-labelledby="task-details-title">
            <header class="section-header">
                <h2 class="section-title" id="task-details-title">Task details</h2>
            </header>
            <div class="stack">
                <div class="record-description"><?= $task['description'] !== null && $task['description'] !== '' ? nl2br($escape((string) $task['description'])) : 'No description.' ?></div>
                <div class="record-meta">
                    <span class="record-meta-item">Created <?= $escape($formatDate($task['created_at'])) ?></span>
                    <?php if ($task['status'] === 'completed' && $task['completed_at'] !== null): ?>
                        <span class="record-meta-item">Completed <?= $escape($formatDate($task['completed_at'])) ?></span>
                    <?php endif; ?>
                </div>
                <?php if ($canEdit): ?>
                    <details <?= $detailsError !== null ? 'open' : '' ?>>
                        <summary>Edit task details</summary>
                        <?php if ($detailsError !== null): ?>
                            <p class="form-error" role="alert"><?= $escape($detailsError) ?></p>
                        <?php endif; ?>
                        <form method="post" class="form" data-task-edit <?= $detailsError !== null ? 'data-unsaved' : '' ?>>
                            <?= csrf_input() ?>
                            <input type="hidden" name="action" value="save_details">
                            <div class="form-group">
                                <label class="form-label" for="task-name">Name</label>
                                <input id="task-name" name="name" value="<?= $escape($formName) ?>" maxlength="200" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="task-description">Description</label>
                                <textarea id="task-description" name="description" rows="4"><?= $escape($formDescription) ?></textarea>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="task-assignee">Assignee</label>
                                <select id="task-assignee" name="assigned_to">
                                    <?php if ($unavailableAssignee): ?>
                                        <option value="keep" <?= $formAssignee === 'keep' ? 'selected' : '' ?>>Keep: <?= $escape($assignedLabel) ?></option>
                                    <?php endif; ?>
                                    <option value="all" <?= $formAssignee === 'all' ? 'selected' : '' ?>>Everyone</option>
                                    <?php foreach ($assigneeChoices as $id => $label): ?>
                                        <option value="<?= (int) $id ?>" <?= $formAssignee === (string) $id ? 'selected' : '' ?>><?= $escape((string) $label) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="form-hint">Everyone means any member of this Task List.</p>
                            </div>
                            <div class="form-actions"><button class="primary-action" type="submit">Save task details</button></div>
                        </form>
                    </details>
                <?php else: ?>
                    <p class="muted">Task details and work values are read-only for you.</p>
                <?php endif; ?>
            </div>
        </section>

        <?php if ($task['template_version_id'] !== null): ?>
            <section class="section" aria-labelledby="work-title">
                <header class="section-header">
                    <h2 class="section-title" id="work-title">Work Template</h2>
                    <?php if ($definition !== null): ?>
                        <div class="record-meta">
                            <span><?= $escape($definition['template_name']) ?> · Version <?= (int) $definition['version_number'] ?></span>
                            <?php if ($definition['template_status'] === 'archived'): ?><span class="badge">Archived template</span><?php endif; ?>
                        </div>
                    <?php endif; ?>
                </header>
                <?php if ($definition === null): ?>
                    <p class="form-error" role="alert">This task's saved Work Template version is unavailable. Its work values have not been changed.</p>
                <?php else: ?>
                    <?php if ($workError !== null): ?><p class="form-error" role="alert"><?= $escape($workError) ?></p><?php endif; ?>
                    <?php if ($canEdit): ?>
                        <form method="post" class="form" data-task-edit <?= $valuesSubmitted ? 'data-unsaved' : '' ?>>
                            <?= csrf_input() ?>
                            <input type="hidden" name="action" value="save_values">
                            <p class="form-hint">Save work updates the fields below. Task details and completion are saved separately.</p>
                    <?php else: ?>
                        <div class="stack">
                    <?php endif; ?>
                    <?php foreach ($definition['sections'] as $section): ?>
                        <div class="stack">
                            <?php if ((string) $section['name'] !== ''): ?><h3><?= $escape((string) $section['name']) ?></h3><?php endif; ?>
                            <?php if (!empty($section['description'])): ?><p class="muted"><?= nl2br($escape((string) $section['description'])) ?></p><?php endif; ?>
                            <?php foreach ($section['fields'] as $field): ?>
                                <?php
                                $fieldId = (int) $field['id'];
                                $fieldType = (string) $field['field_type'];
                                if (!work_template_field_uses_task_values($fieldType)) { continue; }
                                $storedValue = work_template_field_current_value($field, $values[$fieldId] ?? null);
                                $storedError = work_template_validate_value($field, $storedValue, $personChoices, $teamChoices, $projectChoices);
                                $hasHistoricalError = isset($values[$fieldId]) && $storedValue !== null && $storedError !== null;
                                $inputValue = $valuesSubmitted ? ($submittedTemplateValues[$fieldId] ?? null) : $storedValue;
                                ?>
                                <div class="form-group" role="group" aria-labelledby="field-label-<?= $fieldId ?>">
                                    <div class="form-label" id="field-label-<?= $fieldId ?>"><?= $escape((string) $field['name']) ?><?= !empty($field['is_required']) ? ' (required)' : '' ?></div>
                                    <?php if (!empty($field['description'])): ?><p class="form-hint"><?= nl2br($escape((string) $field['description'])) ?></p><?php endif; ?>
                                    <?php if ($hasHistoricalError): ?>
                                        <p class="task-template-field-error">Saved value needs attention: <?= $escape($storedError) ?> Saved: <?= $escape(is_scalar($storedValue) ? (string) $storedValue : work_template_encode_json($storedValue)) ?></p>
                                    <?php endif; ?>
                                    <?php if ($canEdit): ?>
                                        <?= work_template_render_field_input($field, $inputValue, $personChoices, $teamChoices, $templateValueErrors[$fieldId] ?? null, $projectChoices) ?>
                                    <?php elseif (!$hasHistoricalError): ?>
                                        <div class="record-description"><?= work_template_render_field_value($field, $storedValue, $personChoices, $teamChoices, $projectChoices) ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                    <?php if ($canEdit): ?>
                            <div class="form-actions"><button class="primary-action" type="submit">Save work</button></div>
                        </form>
                    <?php else: ?>
                        </div>
                    <?php endif; ?>
                    <?php foreach ($definition['sections'] as $section): ?>
                        <?php foreach ($section['fields'] as $field): ?>
                            <?php if (work_template_field_uses_task_values((string) $field['field_type'])) { continue; } ?>
                            <div class="form-group" role="group" aria-labelledby="advanced-label-<?= (int) $field['id'] ?>">
                                <div class="form-label" id="advanced-label-<?= (int) $field['id'] ?>"><?= $escape((string) $field['name']) ?></div>
                                <?php if (!empty($field['description'])): ?><p class="form-hint"><?= nl2br($escape((string) $field['description'])) ?></p><?php endif; ?>
                                <?= work_template_advanced_render_field($field, $taskId, $advanced, $workspaceId, $userId, $access, $canEdit, $computed) ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </section>
        <?php endif; ?>

        <?php if ($canComplete || $canDelete): ?>
            <section class="section" aria-labelledby="task-actions-title">
                <header class="section-header"><h2 class="section-title" id="task-actions-title">Task actions</h2></header>
                <div class="section-actions">
                    <?php if ($canComplete): ?>
                        <form method="post" action="/actions/tasks/complete-task.php">
                            <?= csrf_input() ?>
                            <input type="hidden" name="task_id" value="<?= $taskId ?>">
                            <input type="hidden" name="action" value="<?= $task['status'] === 'completed' ? 'reopen' : 'complete' ?>">
                            <button class="primary-action" type="submit"><?= $task['status'] === 'completed' ? 'Reopen task' : 'Complete task' ?></button>
                        </form>
                    <?php endif; ?>
                    <?php if ($canDelete): ?>
                        <form method="post" action="/actions/tasks/delete-task.php" onsubmit="return confirm('Delete this task?');">
                            <?= csrf_input() ?>
                            <input type="hidden" name="task_id" value="<?= $taskId ?>">
                            <button class="secondary-action" type="submit">Delete task</button>
                        </form>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>
    </div>
</main>
<script>
// Warn before a separate save, status action, or navigation discards unsaved work.
const dirtyForms = new Set(document.querySelectorAll('[data-unsaved]'));
document.querySelectorAll('[data-task-edit]').forEach(form => {
    form.addEventListener('input', () => dirtyForms.add(form));
    form.addEventListener('change', () => dirtyForms.add(form));
});
document.addEventListener('submit', event => {
    if (event.defaultPrevented) return;
    const otherChanges = [...dirtyForms].some(form => form !== event.target);
    if (otherChanges && !confirm('There are unsaved changes in another section. Continue without saving them?')) {
        event.preventDefault();
        return;
    }
    dirtyForms.clear();
});
window.addEventListener('beforeunload', event => {
    if (dirtyForms.size) {
        event.preventDefault();
        event.returnValue = '';
    }
});
</script>
<script>
(function () {
    document.querySelectorAll('form[data-artifact]').forEach(function (form) {
        var canvas = form.querySelector('[data-canvas]');
        var payload = form.querySelector('input[name="payload"]');
        if (!canvas || !payload) return;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.strokeStyle = '#111827';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        var drawing = false;
        var point = function (e) {
            var rect = canvas.getBoundingClientRect();
            var touch = e.touches && e.touches[0];
            var clientX = touch ? touch.clientX : e.clientX;
            var clientY = touch ? touch.clientY : e.clientY;
            return {
                x: (clientX - rect.left) * (canvas.width / rect.width),
                y: (clientY - rect.top) * (canvas.height / rect.height)
            };
        };
        var begin = function (e) { drawing = true; var p = point(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); e.preventDefault(); };
        var move = function (e) { if (!drawing) return; var p = point(e); ctx.lineTo(p.x, p.y); ctx.stroke(); e.preventDefault(); };
        var end = function () { drawing = false; };
        canvas.addEventListener('mousedown', begin);
        canvas.addEventListener('mousemove', move);
        canvas.addEventListener('mouseup', end);
        canvas.addEventListener('mouseleave', end);
        canvas.addEventListener('touchstart', begin, { passive: false });
        canvas.addEventListener('touchmove', move, { passive: false });
        canvas.addEventListener('touchend', end);
        form.addEventListener('submit', function () {
            payload.value = canvas.toDataURL('image/png').split(',')[1] || '';
        });
    });
})();
</script>
</body>
</html>
