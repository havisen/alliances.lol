<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/notifications.php';

$user = require_login();
$connection = db();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    exit('No workspace is assigned to this user.');
}

$workspaceId = (int) $access['workspace_id'];

$showCompleted =
    isset($_GET['show_completed'])
    && $_GET['show_completed'] === '1';

/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$teamsStatement = $connection->prepare(
    'SELECT
        t.id,
        t.name,
        t.team_lead_id,
        u.display_name AS team_lead_name
     FROM teams t
     LEFT JOIN users u
         ON u.id = t.team_lead_id
     WHERE t.workspace_id = ?
       AND t.status = "active"
     ORDER BY t.name ASC'
);

$teamsStatement->execute([$workspaceId]);

$teams = $teamsStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Workspace users
|--------------------------------------------------------------------------
*/

$workspaceUsersStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.email,
        u.job_title,
        u.avatar_path
     FROM users u
     INNER JOIN workspace_members wm
         ON wm.user_id = u.id
     WHERE wm.workspace_id = ?
       AND u.account_status = "active"
     ORDER BY u.display_name ASC'
);

$workspaceUsersStatement->execute([$workspaceId]);

$workspaceUsers = $workspaceUsersStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Team membership map
|--------------------------------------------------------------------------
|
| Used by JavaScript so selecting a team automatically checks the people
| who currently belong to that team.
|
| This is only a convenience in the form.
|
| The server separately copies the current team members when the task list
| is actually created.
|
*/

$teamMembersStatement = $connection->prepare(
    'SELECT
        tm.team_id,
        tm.user_id
     FROM team_members tm
     INNER JOIN teams t
         ON t.id = tm.team_id
     INNER JOIN users u
         ON u.id = tm.user_id
     WHERE t.workspace_id = ?
       AND t.status = "active"
       AND u.account_status = "active"'
);

$teamMembersStatement->execute([$workspaceId]);

$teamMembersByTeam = [];

foreach ($teamMembersStatement->fetchAll() as $teamMember) {
    $teamId = (int) $teamMember['team_id'];
    $memberId = (int) $teamMember['user_id'];

    if (!isset($teamMembersByTeam[$teamId])) {
        $teamMembersByTeam[$teamId] = [];
    }

    $teamMembersByTeam[$teamId][] = $memberId;
}

/*
|--------------------------------------------------------------------------
| Form state
|--------------------------------------------------------------------------
*/

$error = null;

$formName = '';
$formStartDate = '';
$formDeadline = '';
$formTeamId = null;
$formMembersCanEdit = true;
$formMemberIds = [(int) $user['id']];

/*
|--------------------------------------------------------------------------
| Create task list
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $formName = trim($_POST['name'] ?? '');
    $formStartDate = trim($_POST['start_date'] ?? '');
    $formDeadline = trim($_POST['deadline'] ?? '');

    $submittedTeamId = filter_input(
        INPUT_POST,
        'team_id',
        FILTER_VALIDATE_INT
    );

    $formTeamId = $submittedTeamId ?: null;

    $submittedMemberIds = $_POST['member_ids'] ?? [];

    if (!is_array($submittedMemberIds)) {
        $submittedMemberIds = [];
    }

    $formMemberIds = [];

    foreach ($submittedMemberIds as $memberId) {
        $memberId = filter_var(
            $memberId,
            FILTER_VALIDATE_INT
        );

        if ($memberId) {
            $formMemberIds[] = (int) $memberId;
        }
    }

    /*
     * The creator must always belong to their own task list.
     */
    $formMemberIds[] = (int) $user['id'];

    $formMemberIds = array_values(
        array_unique($formMemberIds)
    );

    $formMembersCanEdit =
        isset($_POST['members_can_edit']);

    /*
    |--------------------------------------------------------------------------
    | Validate name
    |--------------------------------------------------------------------------
    */

    if ($formName === '') {
        $error = 'Enter a name for the task list.';
    } elseif (strlen($formName) > 150) {
        $error = 'Task list names can be up to 150 characters.';
    }

    /*
    |--------------------------------------------------------------------------
    | Validate dates
    |--------------------------------------------------------------------------
    */

    if (
        $error === null
        && $formStartDate !== ''
        && $formDeadline !== ''
        && $formDeadline < $formStartDate
    ) {
        $error = 'The deadline cannot be before the start date.';
    }

    /*
    |--------------------------------------------------------------------------
    | Validate team
    |--------------------------------------------------------------------------
    */

    if (
        $error === null
        && $formTeamId !== null
    ) {
        $validTeam = false;

        foreach ($teams as $team) {
            if ((int) $team['id'] === $formTeamId) {
                $validTeam = true;
                break;
            }
        }

        if (!$validTeam) {
            $error = 'Choose a valid team.';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Create list
    |--------------------------------------------------------------------------
    */

    if ($error === null) {
        try {
            $connection->beginTransaction();

            $listStatement = $connection->prepare(
                'INSERT INTO task_lists
                    (
                        workspace_id,
                        created_by,
                        team_id,
                        name,
                        start_date,
                        deadline,
                        members_can_edit
                    )
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );

            $listStatement->execute([
                $workspaceId,
                $user['id'],
                $formTeamId,
                $formName,
                $formStartDate !== ''
                    ? $formStartDate
                    : null,
                $formDeadline !== ''
                    ? $formDeadline
                    : null,
                $formMembersCanEdit ? 1 : 0,
            ]);

            $listId = (int) $connection->lastInsertId();

            /*
            |--------------------------------------------------------------------------
            | Add individually selected members
            |--------------------------------------------------------------------------
            |
            | The SELECT ensures that submitted IDs actually belong to the
            | current workspace.
            |
            */

            $memberStatement = $connection->prepare(
                'INSERT OR IGNORE INTO task_list_members
                    (
                        task_list_id,
                        user_id
                    )
                 SELECT ?, wm.user_id
                 FROM workspace_members wm
                 INNER JOIN users u
                     ON u.id = wm.user_id
                 WHERE wm.workspace_id = ?
                   AND wm.user_id = ?
                   AND u.account_status = "active"'
            );

            foreach ($formMemberIds as $memberId) {
                $memberStatement->execute([
                    $listId,
                    $workspaceId,
                    $memberId,
                ]);
            }

            /*
            |--------------------------------------------------------------------------
            | Snapshot team membership
            |--------------------------------------------------------------------------
            |
            | Team members are copied into the task list now.
            |
            | Later changes to the team DO NOT alter this task list.
            |
            */

            if ($formTeamId !== null) {
                $teamMembersInsert = $connection->prepare(
                    'INSERT OR IGNORE INTO task_list_members
                        (
                            task_list_id,
                            user_id
                        )
                     SELECT ?, tm.user_id
                     FROM team_members tm
                     INNER JOIN teams t
                         ON t.id = tm.team_id
                     INNER JOIN users u
                         ON u.id = tm.user_id
                     WHERE tm.team_id = ?
                       AND t.workspace_id = ?
                       AND t.status = "active"
                       AND u.account_status = "active"'
                );

                $teamMembersInsert->execute([
                    $listId,
                    $formTeamId,
                    $workspaceId,
                ]);
            }

            $recipientStatement = $connection->prepare(
                'SELECT DISTINCT tlm.user_id
                 FROM task_list_members tlm
                 INNER JOIN users u
                     ON u.id = tlm.user_id
                 WHERE tlm.task_list_id = ?
                   AND u.account_status = "active"'
            );

            $recipientStatement->execute([$listId]);

            $recipientIds = array_map(
                static fn (array $row): int => (int) $row['user_id'],
                $recipientStatement->fetchAll()
            );

            create_notifications_for_users($recipientIds, [
                'workspace_id' => $workspaceId,
                'actor_user_id' => (int) $user['id'],
                'type' => $formTeamId !== null
                    ? 'task_team_list_created'
                    : 'task_list_created',
                'category' => 'tasks',
                'title' => $formTeamId !== null
                    ? 'A task list was assigned to your team'
                    : 'You were added to a task list',
                'body' => $formName,
                'target_type' => 'task_list',
                'target_id' => $listId,
                'target_url' => '/tasks/task-list.php?id=' . $listId,
            ]);

            $connection->commit();

            /*
             * Go directly into the new list instead of returning to Tasks.
             * This makes creating a list feel like one continuous workflow.
             */
            header(
                'Location: /tasks/task-list.php?id=' . $listId
            );

            exit;
        } catch (Throwable $exception) {
            if ($connection->inTransaction()) {
                $connection->rollBack();
            }

            $error = 'Could not create the task list. Please try again.';
        }
    }
}

/*
|--------------------------------------------------------------------------
| Task lists visible to current user
|--------------------------------------------------------------------------
*/

$listSql = '
    SELECT DISTINCT
        tl.id,
        tl.name,
        tl.status,
        tl.start_date,
        tl.deadline,
        tl.created_at,
        tl.team_id,
        tl.members_can_edit,

        t.name AS team_name,

        creator.id AS creator_id,
        creator.display_name AS creator_name,
        creator.avatar_path AS creator_avatar,

        (
            SELECT COUNT(*)
            FROM task_list_members member_count
            WHERE member_count.task_list_id = tl.id
        ) AS member_count

    FROM task_lists tl

    INNER JOIN task_list_members tlm
        ON tlm.task_list_id = tl.id
       AND tlm.user_id = ?

    LEFT JOIN teams t
        ON t.id = tl.team_id
       AND t.workspace_id = tl.workspace_id

    LEFT JOIN users creator
        ON creator.id = tl.created_by

    WHERE tl.workspace_id = ?
';

$listParameters = [
    $user['id'],
    $workspaceId,
];

if (!$showCompleted) {
    $listSql .= ' AND tl.status = ?';
    $listParameters[] = 'active';
}

$listSql .= '
    ORDER BY
        CASE
            WHEN tl.deadline IS NULL THEN 1
            ELSE 0
        END,
        tl.deadline ASC,
        tl.created_at DESC
';

$listsStatement = $connection->prepare($listSql);

$listsStatement->execute($listParameters);

$taskLists = $listsStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Page statistics
|--------------------------------------------------------------------------
*/

$activeListCount = 0;
$completedListCount = 0;

$countStatement = $connection->prepare(
    'SELECT
        tl.status,
        COUNT(DISTINCT tl.id) AS list_count
     FROM task_lists tl
     INNER JOIN task_list_members tlm
         ON tlm.task_list_id = tl.id
        AND tlm.user_id = ?
     WHERE tl.workspace_id = ?
     GROUP BY tl.status'
);

$countStatement->execute([
    $user['id'],
    $workspaceId,
]);

foreach ($countStatement->fetchAll() as $countRow) {
    if ($countRow['status'] === 'active') {
        $activeListCount = (int) $countRow['list_count'];
    }

    if ($countRow['status'] === 'completed') {
        $completedListCount = (int) $countRow['list_count'];
    }
}

/*
|--------------------------------------------------------------------------
| Date helper
|--------------------------------------------------------------------------
*/

function task_list_date(?string $value): string
{
    if ($value === null || $value === '') {
        return '';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return $value;
    }

    return date('M j, Y · H:i', $timestamp);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>Tasks | Alliances</title>
</head>

<body>

<?php render_navigation($user); ?>

<main class="app-main tasks-page">

    <!-- ================================================================
         PAGE HEADER
         ================================================================ -->

    <header class="page-header tasks-page-header">

        <div class="page-header-content">
            <p class="page-eyebrow">
                Work
            </p>

            <h1>Tasks</h1>

            <p class="page-description">
                Organize work into task lists, assign people,
                and keep deadlines visible.
            </p>
        </div>

        <div class="page-header-actions">
            <button
                type="button"
                class="primary-action"
                id="open-create-list"
                aria-expanded="<?= $error !== null ? 'true' : 'false' ?>"
                aria-controls="create-task-list-panel"
            >
                <span aria-hidden="true">+</span>
                New task list
            </button>
        </div>

    </header>

    <!-- ================================================================
         CREATE TASK LIST
         ================================================================ -->

    <section
        class="task-create-panel <?= $error !== null ? 'is-open' : '' ?>"
        id="create-task-list-panel"
        <?= $error === null ? 'hidden' : '' ?>
    >

        <div class="task-create-header">

            <div>
                <h2>Create a task list</h2>

                <p>
                    Set up the list, choose who should have access,
                    and optionally connect it to a team.
                </p>
            </div>

            <button
                type="button"
                class="icon-button task-create-close"
                id="close-create-list"
                aria-label="Close"
            >
                ×
            </button>

        </div>

        <?php if ($error !== null): ?>
            <div
                class="form-message form-message-error"
                role="alert"
            >
                <?= htmlspecialchars(
                    $error,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </div>
        <?php endif; ?>

        <form
            method="post"
            class="task-create-form"
        >

            <?= csrf_input() ?>

            <!-- BASIC INFORMATION -->

            <div class="task-form-section">

                <div class="task-form-section-heading">
                    <span class="task-form-step">
                        1
                    </span>

                    <div>
                        <h3>List details</h3>

                        <p>
                            Give the work a clear name and,
                            if needed, a timeframe.
                        </p>
                    </div>
                </div>

                <div class="task-form-fields">

                    <label class="form-field task-list-name-field">

                        <span class="form-label">
                            List name
                        </span>

                        <input
                            type="text"
                            name="name"
                            maxlength="150"
                            required
                            autofocus
                            placeholder="e.g. Website launch"
                            value="<?= htmlspecialchars(
                                $formName,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        >

                    </label>

                    <div class="form-field-row">

                        <label class="form-field">

                            <span class="form-label">
                                Start date
                            </span>

                            <span class="form-hint">
                                Optional
                            </span>

                            <input
                                type="datetime-local"
                                name="start_date"
                                value="<?= htmlspecialchars(
                                    $formStartDate,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </label>

                        <label class="form-field">

                            <span class="form-label">
                                Deadline
                            </span>

                            <span class="form-hint">
                                Optional
                            </span>

                            <input
                                type="datetime-local"
                                name="deadline"
                                value="<?= htmlspecialchars(
                                    $formDeadline,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                        </label>

                    </div>

                </div>

            </div>

            <!-- TEAM -->

            <div class="task-form-section">

                <div class="task-form-section-heading">

                    <span class="task-form-step">
                        2
                    </span>

                    <div>
                        <h3>Team</h3>

                        <p>
                            Assigning a team automatically adds its
                            current members to this list.
                        </p>
                    </div>

                </div>

                <div class="task-form-fields">

                    <label class="form-field">

                        <span class="form-label">
                            Assign to team
                        </span>

                        <select
                            name="team_id"
                            id="team_id"
                        >
                            <option value="">
                                No team — choose members manually
                            </option>

                            <?php foreach ($teams as $team): ?>

                                <option
                                    value="<?= (int) $team['id'] ?>"
                                    <?= $formTeamId === (int) $team['id']
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= htmlspecialchars(
                                        $team['name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </label>

                    <div
                        class="task-team-notice"
                        id="team-selection-notice"
                        hidden
                    >
                        <strong id="selected-team-name"></strong>

                        <span>
                            Team members have been selected below.
                            This membership is copied when the list
                            is created.
                        </span>
                    </div>

                </div>

            </div>

            <!-- MEMBERS -->

            <div class="task-form-section">

                <div class="task-form-section-heading">

                    <span class="task-form-step">
                        3
                    </span>

                    <div>
                        <h3>People</h3>

                        <p>
                            Choose everyone who should be able to
                            access this task list.
                        </p>
                    </div>

                </div>

                <div class="task-form-fields">

                    <div class="task-member-toolbar">

                        <span>
                            List members
                        </span>

                        <span
                            class="task-member-count"
                            id="selected-member-count"
                        >
                            0 selected
                        </span>

                    </div>

                    <div
                        class="task-member-selector"
                        id="list-members"
                    >

                        <?php foreach ($workspaceUsers as $workspaceUser): ?>

                            <?php
                            $workspaceUserId =
                                (int) $workspaceUser['id'];

                            $isCurrentUser =
                                $workspaceUserId
                                === (int) $user['id'];

                            $isSelected = in_array(
                                $workspaceUserId,
                                $formMemberIds,
                                true
                            );

                            $memberInitial = strtoupper(
                                substr(
                                    $workspaceUser['display_name'],
                                    0,
                                    1
                                )
                            );
                            ?>

                            <label class="task-member-option">

                                <input
                                    type="checkbox"
                                    name="member_ids[]"
                                    value="<?= $workspaceUserId ?>"
                                    <?= $isSelected ? 'checked' : '' ?>
                                    <?= $isCurrentUser ? 'disabled' : '' ?>
                                >

                                <?php if ($isCurrentUser): ?>
                                    <input
                                        type="hidden"
                                        name="member_ids[]"
                                        value="<?= $workspaceUserId ?>"
                                    >
                                <?php endif; ?>

                                <?php if (!empty($workspaceUser['avatar_path'])): ?>

                                    <img
                                        class="task-member-avatar"
                                        src="<?= htmlspecialchars(
                                            $workspaceUser['avatar_path'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>"
                                        alt=""
                                    >

                                <?php else: ?>

                                    <span
                                        class="task-member-avatar task-member-avatar-placeholder"
                                    >
                                        <?= htmlspecialchars(
                                            $memberInitial,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                <?php endif; ?>

                                <span class="task-member-info">

                                    <strong>
                                        <?= htmlspecialchars(
                                            $workspaceUser['display_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                        <?php if ($isCurrentUser): ?>
                                            <span class="task-you-label">
                                                You
                                            </span>
                                        <?php endif; ?>
                                    </strong>

                                    <small>
                                        <?= htmlspecialchars(
                                            $workspaceUser['job_title']
                                                ?: $workspaceUser['email'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </small>

                                </span>

                                <span
                                    class="task-member-check"
                                    aria-hidden="true"
                                >
                                    ✓
                                </span>

                            </label>

                        <?php endforeach; ?>

                    </div>

                </div>

            </div>

            <!-- PERMISSIONS -->

            <div class="task-form-section">

                <div class="task-form-section-heading">

                    <span class="task-form-step">
                        4
                    </span>

                    <div>
                        <h3>Permissions</h3>

                        <p>
                            Decide whether members can help manage
                            the work in this list.
                        </p>
                    </div>

                </div>

                <div class="task-form-fields">

                    <label class="task-permission-option">

                        <input
                            type="checkbox"
                            name="members_can_edit"
                            value="1"
                            <?= $formMembersCanEdit
                                ? 'checked'
                                : '' ?>
                        >

                        <span class="task-permission-copy">

                            <strong>
                                Members can add and edit tasks
                            </strong>

                            <small>
                                Turn this off if only the list creator
                                should manage tasks.
                            </small>

                        </span>

                    </label>

                </div>

            </div>

            <div class="task-create-actions">

                <button
                    type="button"
                    class="secondary-action"
                    id="cancel-create-list"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="primary-action"
                >
                    Create task list
                </button>

            </div>

        </form>

    </section>

    <!-- ================================================================
         TASK LIST OVERVIEW
         ================================================================ -->

    <section class="task-lists-section">

        <div class="task-lists-toolbar">

            <div class="task-view-tabs">

                <a
                    href="/tasks/tasks.php"
                    class="task-view-tab <?= !$showCompleted
                        ? 'is-active'
                        : '' ?>"
                >
                    Active

                    <span>
                        <?= $activeListCount ?>
                    </span>
                </a>

                <a
                    href="/tasks/tasks.php?show_completed=1"
                    class="task-view-tab <?= $showCompleted
                        ? 'is-active'
                        : '' ?>"
                >
                    All

                    <span>
                        <?= $activeListCount + $completedListCount ?>
                    </span>
                </a>

            </div>

            <?php if ($completedListCount > 0): ?>

                <div class="task-completed-summary">
                    <?= $completedListCount ?>
                    completed
                </div>

            <?php endif; ?>

        </div>

        <?php if ($taskLists === []): ?>

            <div class="tasks-empty-state">

                <div
                    class="tasks-empty-icon"
                    aria-hidden="true"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="m9 11 2 2 4-4"></path>
                        <path
                            d="M5 4h14a2 2 0 0 1 2 2v12a2
                            2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2
                            2 0 0 1 2-2Z"
                        ></path>
                    </svg>
                </div>

                <?php if ($showCompleted): ?>

                    <h2>No task lists yet</h2>

                    <p>
                        Create your first task list to start
                        organizing work.
                    </p>

                <?php else: ?>

                    <h2>No active task lists</h2>

                    <?php if ($completedListCount > 0): ?>

                        <p>
                            You're caught up. Your completed lists
                            are still available in All.
                        </p>

                        <a
                            href="/tasks/tasks.php?show_completed=1"
                            class="secondary-action"
                        >
                            View completed lists
                        </a>

                    <?php else: ?>

                        <p>
                            Create a task list to start organizing
                            work with your team.
                        </p>

                    <?php endif; ?>

                <?php endif; ?>

            </div>

<?php else: ?>

    <div class="task-list-table">

        <?php foreach ($taskLists as $list): ?>

            <?php

            $isCompleted =
                $list['status'] === 'completed';

            $hasDeadline =
                !empty($list['deadline']);

            $deadlineTimestamp =
                $hasDeadline
                    ? strtotime($list['deadline'])
                    : false;

            $isOverdue =
                !$isCompleted
                && $deadlineTimestamp !== false
                && $deadlineTimestamp < time();

                $canDeleteList =
                !empty($access['is_admin'])
                || (int) $list['creator_id'] === (int) $user['id'];
            ?>

            <div class="task-list-row">

                <div class="task-list-row-main">

                    <div class="task-list-row-title">

<h2>
    <a
        href="/tasks/task-list.php?id=<?= (int) $list['id'] ?>"
        class="task-list-row-link"
    >
        <?= htmlspecialchars(
            $list['name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?>
    </a>
</h2>

                        <?php if ($isCompleted): ?>

                            <span class="task-list-row-status">
                                Completed
                            </span>

                        <?php elseif ($isOverdue): ?>

                            <span class="task-list-row-status is-overdue">
                                Overdue
                            </span>

                        <?php else: ?>

                            <span class="task-list-row-status">
                                Active
                            </span>

                        <?php endif; ?>

                    </div>


                    <div class="task-list-row-subtitle">

                        <?php if (!empty($list['team_name'])): ?>

                            <span>
                                <?= htmlspecialchars(
                                    $list['team_name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </span>

                        <?php else: ?>

                            <span>
                                No team
                            </span>

                        <?php endif; ?>

                    </div>

                </div>


                <div class="task-list-row-details">

                    <div class="task-list-row-detail">

                        <span>
                            Members
                        </span>

                        <strong>
                            <?= (int) $list['member_count'] ?>
                        </strong>

                    </div>


                    <div class="task-list-row-detail">

                        <span>
                            Starts
                        </span>

                        <strong>
                            <?php if (!empty($list['start_date'])): ?>

                                <?= htmlspecialchars(
                                    task_list_date(
                                        $list['start_date']
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            <?php else: ?>

                                Not set

                            <?php endif; ?>
                        </strong>

                    </div>


                    <div class="task-list-row-detail">

                        <span>
                            Deadline
                        </span>

                        <strong
                            class="<?= $isOverdue
                                ? 'is-overdue'
                                : '' ?>"
                        >
                            <?php if ($hasDeadline): ?>

                                <?= htmlspecialchars(
                                    task_list_date(
                                        $list['deadline']
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            <?php else: ?>

                                Not set

                            <?php endif; ?>
                        </strong>

                    </div>

                </div>


<div class="task-list-row-actions">

    <?php if ($canDeleteList): ?>

        <details class="task-list-menu">

            <summary
                class="task-list-menu-button"
                aria-label="Task list actions"
                title="Task list actions"
            >
                ⋯
            </summary>

            <div class="task-list-menu-dropdown">

                <a
                    href="/tasks/task-list.php?id=<?= (int) $list['id'] ?>"
                    class="task-list-menu-item"
                >
                    Open
                </a>

                <form
                    method="post"
                    action="/actions/tasks/delete-task-list.php"
                    onsubmit="return confirm('Delete this task list and all tasks inside it? This cannot be undone.');"
                >
                    <?= csrf_input() ?>

                    <input
                        type="hidden"
                        name="list_id"
                        value="<?= (int) $list['id'] ?>"
                    >

                    <button
                        type="submit"
                        class="task-list-menu-item task-list-menu-delete"
                    >
                        Delete task list
                    </button>

                </form>

            </div>

        </details>

    <?php else: ?>

        <a
            href="/tasks/task-list.php?id=<?= (int) $list['id'] ?>"
            class="task-list-row-arrow"
            aria-label="Open task list"
        >
            →
        </a>

    <?php endif; ?>

</div>

                            </div>

        <?php endforeach; ?>

    </div>

<?php endif; ?>

    </section>

</main>

<script>
    const createPanel =
        document.getElementById('create-task-list-panel');

    const openCreateButton =
        document.getElementById('open-create-list');

    const closeCreateButton =
        document.getElementById('close-create-list');

    const cancelCreateButton =
        document.getElementById('cancel-create-list');

    function openCreatePanel() {
        createPanel.hidden = false;
        createPanel.classList.add('is-open');

        openCreateButton.setAttribute(
            'aria-expanded',
            'true'
        );

        const nameInput =
            createPanel.querySelector('input[name="name"]');

        if (nameInput) {
            window.setTimeout(() => {
                nameInput.focus();
            }, 50);
        }
    }

    function closeCreatePanel() {
        createPanel.classList.remove('is-open');
        createPanel.hidden = true;

        openCreateButton.setAttribute(
            'aria-expanded',
            'false'
        );
    }

    openCreateButton.addEventListener(
        'click',
        openCreatePanel
    );

    closeCreateButton.addEventListener(
        'click',
        closeCreatePanel
    );

    cancelCreateButton.addEventListener(
        'click',
        closeCreatePanel
    );

    /*
    |--------------------------------------------------------------------------
    | Team → member selection
    |--------------------------------------------------------------------------
    */

    const teamMembersByTeam = <?= json_encode(
        $teamMembersByTeam,
        JSON_HEX_TAG
        | JSON_HEX_APOS
        | JSON_HEX_AMP
        | JSON_HEX_QUOT
    ) ?>;

    const teamSelect =
        document.getElementById('team_id');

    const memberCheckboxes =
        document.querySelectorAll(
            '#list-members input[type="checkbox"][name="member_ids[]"]'
        );

    const memberCount =
        document.getElementById('selected-member-count');

    const teamNotice =
        document.getElementById('team-selection-notice');

    const selectedTeamName =
        document.getElementById('selected-team-name');

    function updateMemberCount() {
        let selected = 0;

        memberCheckboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                selected++;
            }
        });

        memberCount.textContent =
            selected
            + (selected === 1
                ? ' selected'
                : ' selected');
    }

    function updateTeamNotice() {
        const selectedOption =
            teamSelect.options[teamSelect.selectedIndex];

        if (!teamSelect.value) {
            teamNotice.hidden = true;
            selectedTeamName.textContent = '';
            return;
        }

        selectedTeamName.textContent =
            selectedOption.textContent.trim();

        teamNotice.hidden = false;
    }

    teamSelect.addEventListener('change', () => {
        const selectedIds = new Set(
            (teamMembersByTeam[teamSelect.value] || [])
                .map(Number)
        );

        memberCheckboxes.forEach((checkbox) => {
            if (selectedIds.has(Number(checkbox.value))) {
                checkbox.checked = true;
            }
        });

        updateMemberCount();
        updateTeamNotice();
    });

    memberCheckboxes.forEach((checkbox) => {
        checkbox.addEventListener(
            'change',
            updateMemberCount
        );
    });

    updateMemberCount();
    updateTeamNotice();
</script>

</body>
</html>
