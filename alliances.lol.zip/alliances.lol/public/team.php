<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/auth.php';

$currentUser = require_login();
$connection = db();

$access = workspace_access((int) $currentUser['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

$teamId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$teamId) {
    http_response_code(400);
    exit('Invalid team.');
}

$teamStatement = $connection->prepare(
    'SELECT
        t.id,
        t.name,
        t.description,
        t.team_lead_id,
        lead.display_name AS team_lead_name,
        lead.email AS team_lead_email,
        lead.job_title AS team_lead_job_title,
        lead.avatar_path AS team_lead_avatar,
        lead.current_status AS team_lead_status,
        lead.out_of_office AS team_lead_out_of_office
     FROM teams t
     LEFT JOIN users lead
        ON lead.id = t.team_lead_id
     WHERE t.id = ?
       AND t.workspace_id = ?
     LIMIT 1'
);

$teamStatement->execute([
    $teamId,
    $workspaceId,
]);

$team = $teamStatement->fetch();

if (!$team) {
    http_response_code(404);
    exit('Team not found.');
}

$membersStatement = $connection->prepare(
    'SELECT
        u.id,
        u.display_name,
        u.email,
        u.job_title,
        u.avatar_path,
        u.current_status,
        u.out_of_office,
        wm.role
     FROM team_members tm
     INNER JOIN users u
        ON u.id = tm.user_id
     INNER JOIN workspace_members wm
        ON wm.user_id = u.id
       AND wm.workspace_id = ?
     WHERE tm.team_id = ?
     ORDER BY
        CASE
            WHEN u.id = ? THEN 0
            ELSE 1
        END,
        u.display_name ASC'
);

$membersStatement->execute([
    $workspaceId,
    $teamId,
    $team['team_lead_id'] ?? 0,
]);

$teamMembers = $membersStatement->fetchAll();

$memberIds = array_map(
    static fn (array $member): int => (int) $member['id'],
    $teamMembers
);

if (
    $team['team_lead_id']
    && !in_array((int) $team['team_lead_id'], $memberIds, true)
) {
    $memberIds[] = (int) $team['team_lead_id'];
}

$memberCount = count($teamMembers);

function team_status_label(?string $status): string
{
    if ($status === 'busy') {
        return 'Busy';
    }

    if ($status === 'dnd') {
        return 'Do Not Disturb';
    }

    return 'Available';
}

$messageQuery = http_build_query([
    'start_team' => (int) $team['id'],
]);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= htmlspecialchars(
        $team['name'],
        ENT_QUOTES,
        'UTF-8'
    ) ?> | Alliances</title>
</head>
<body>
<?php render_navigation($currentUser); ?>

    <main class="profile-page team-page">
        <header class="profile-page-heading">
            <div>
                <p class="profile-eyebrow">Team</p>

                <h1><?= htmlspecialchars(
                    $team['name'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></h1>

                <p class="profile-page-description">
                    <?= htmlspecialchars(
                        $team['description']
                            ?: 'Workspace team page.',
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </p>
            </div>

            <div class="page-header-actions">
                <a
                    class="primary-action"
                    href="/tasks/tasks.php?team=<?= (int) $team['id'] ?>"
                >
                    View tasks
                </a>

                <?php if ($memberIds !== []): ?>
                    <a
                        class="secondary-action"
                        href="/messaging/?<?= htmlspecialchars(
                            $messageQuery,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                    >
                        Message team
                    </a>
                <?php endif; ?>
            </div>
        </header>

        <section class="admin-summary-card">
            <div class="admin-workspace-info">
                <span class="admin-summary-label">Team</span>
                <h2><?= htmlspecialchars(
                    $team['name'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></h2>
                <p><?= htmlspecialchars(
                    $team['description'] ?: 'No description yet.',
                    ENT_QUOTES,
                    'UTF-8'
                ) ?></p>
            </div>

            <div class="admin-summary-stats">
                <div class="admin-stat">
                    <strong><?= $memberCount ?></strong>
                    <span><?= $memberCount === 1 ? 'Member' : 'Members' ?></span>
                </div>
            </div>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Team Lead</h2>
                    <p>The person responsible for this team.</p>
                </div>
            </div>

            <?php if ($team['team_lead_id']): ?>
                <a
                    class="profile-person admin-team-lead-profile"
                    href="/profile/?id=<?= (int) $team['team_lead_id'] ?>"
                >
                    <?php if (!empty($team['team_lead_avatar'])): ?>
                        <img
                            class="org-avatar"
                            src="<?= htmlspecialchars(
                                $team['team_lead_avatar'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt=""
                        >
                    <?php else: ?>
                        <span class="org-avatar org-avatar-placeholder">
                            <?= htmlspecialchars(
                                strtoupper(substr($team['team_lead_name'] ?? '?', 0, 1)),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>
                    <?php endif; ?>

                    <span class="profile-person-details">
                        <strong><?= htmlspecialchars(
                            $team['team_lead_name'] ?? 'Unknown user',
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?></strong>

                        <small><?= htmlspecialchars(
                            $team['team_lead_job_title']
                                ?: ($team['team_lead_email'] ?? ''),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?></small>
                    </span>
                </a>
            <?php else: ?>
                <div class="profile-empty-state">
                    This team does not currently have a Team Lead.
                </div>
            <?php endif; ?>
        </section>

        <section class="profile-section">
            <div class="profile-section-heading">
                <div>
                    <h2>Members</h2>
                    <p>People currently assigned to this team.</p>
                </div>
            </div>

            <?php if ($teamMembers === []): ?>
                <div class="profile-empty-state">
                    This team does not have any members yet.
                </div>
            <?php else: ?>
                <div class="profile-member-grid">
                    <?php foreach ($teamMembers as $member): ?>
                        <a
                            class="profile-person profile-member"
                            href="/profile/?id=<?= (int) $member['id'] ?>"
                        >
                            <?php if (!empty($member['avatar_path'])): ?>
                                <img
                                    class="org-avatar"
                                    src="<?= htmlspecialchars(
                                        $member['avatar_path'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                    alt=""
                                >
                            <?php else: ?>
                                <span class="org-avatar org-avatar-placeholder">
                                    <?= htmlspecialchars(
                                        strtoupper(substr($member['display_name'], 0, 1)),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </span>
                            <?php endif; ?>

                            <span class="profile-person-details">
                                <strong><?= htmlspecialchars(
                                    $member['display_name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?></strong>

                                <small><?= htmlspecialchars(
                                    $member['job_title']
                                        ?: team_status_label($member['current_status'] ?? null),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?></small>

                                <small>
                                    <?= htmlspecialchars(
                                        team_status_label($member['current_status'] ?? null),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                    <?= (int) ($member['out_of_office'] ?? 0) === 1
                                        ? ' · Out of Office'
                                        : ''
                                    ?>
                                </small>
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>
