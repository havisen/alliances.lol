<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/tasks/templates.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';
require_once dirname(__DIR__, 2) . '/src/tasks/values.php';

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    exit('No workspace is assigned to this user.');
}

$workspaceId = (int) $access['workspace_id'];

if (!work_template_can_manage($access)) {
    http_response_code(403);
    exit('Workspace administrator access required.');
}

$templateId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$templateId) {
    http_response_code(404);
    exit('Template not found.');
}

$template = work_template_by_id($workspaceId, (int) $templateId);

if ($template === null) {
    http_response_code(404);
    exit('Template not found.');
}

$templateId = (int) $template['id'];
$draftVersion = work_template_latest_draft($workspaceId, $templateId);
$publishedVersion = work_template_published_version($workspaceId, $templateId);
$draftVersionId = $draftVersion !== null ? (int) $draftVersion['id'] : 0;

$error = null;
$notice = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $action = (string) ($_POST['action'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '') ?: null;
    $sectionId = (int) ($_POST['section_id'] ?? 0);
    $fieldId = (int) ($_POST['field_id'] ?? 0);
    $sectionName = trim($_POST['section_name'] ?? '');
    $sectionDescription = trim($_POST['section_description'] ?? '') ?: null;
    $fieldName = trim($_POST['field_name'] ?? '');
    $fieldType = (string) ($_POST['field_type'] ?? '');
    $optionsRaw = trim($_POST['options'] ?? '') ?: null;
    $numberUnit = trim($_POST['number_unit'] ?? '') ?: null;
    $minMax = [
        'min' => $_POST['min'] ?? null,
        'max' => $_POST['max'] ?? null,
        'step' => trim($_POST['step'] ?? '') ?: null,
        'labels' => trim($_POST['labels'] ?? '') ?: null,
        'approver_ids' => $_POST['approver_ids'] ?? [],
        'relation_field_key' => $_POST['relation_field_key'] ?? '',
        'target_type' => $_POST['lookup_target'] ?? '',
        'descriptor' => 'name',
        'operation' => 'count',
    ];

    try {
        switch ($action) {
            case 'update_identity':
                if ($name === '') {
                    $error = 'Enter a template name.';
                } elseif (strlen($name) > 150) {
                    $error = 'Template names can be up to 150 characters.';
                } else {
                    work_template_update_identity($workspaceId, $templateId, $name, $description);
                    $notice = 'Template details updated.';
                }
                break;

            case 'new_version':
                work_template_create_draft_version($workspaceId, (int) $user['id'], $templateId);
                $notice = 'New draft version created.';
                break;

            case 'publish':
                $publishError = work_template_publish_version($workspaceId, (int) ($_POST['version_id'] ?? 0));

                if ($publishError !== null) {
                    $error = $publishError;
                } else {
                    $notice = 'Version published.';
                }
                break;

            case 'archive':
                work_template_archive($workspaceId, $templateId);
                $notice = 'Template archived.';
                break;

            case 'unarchive':
                work_template_unarchive($workspaceId, $templateId);
                $notice = 'Template restored.';
                break;

            case 'delete':
                $deleteError = work_template_delete_safe($workspaceId, $templateId);

                if ($deleteError !== null) {
                    $error = $deleteError;
                } else {
                    header('Location: /templates/index.php');
                    exit;
                }
                break;
case 'add_section':
                if ($sectionName === '') {
                    $error = 'Enter a section name.';
                } else {
                    work_template_add_section($workspaceId, $draftVersionId, $sectionName, $sectionDescription);
                    $notice = 'Section added.';
                }
                break;

            case 'update_section':
                if ($sectionName === '') {
                    $error = 'Enter a section name.';
                } else {
                    work_template_update_section($workspaceId, $sectionId, $sectionName, $sectionDescription);
                    $notice = 'Section updated.';
                }
                break;

            case 'delete_section':
                work_template_delete_section($workspaceId, $sectionId);
                $notice = 'Section deleted.';
                break;

            case 'move_section':
                work_template_move_section($workspaceId, $sectionId, (string) ($_POST['direction'] ?? ''));
                break;

            case 'add_field':
                if ($fieldName === '') {
                    $error = 'Enter a field name.';
                } else {
                    work_template_add_field($workspaceId, $sectionId, $fieldName, $fieldType, $optionsRaw, $numberUnit, $minMax);
                    $notice = 'Field added.';
                }
                break;

            case 'update_field':
                if ($fieldName === '') {
                    $error = 'Enter a field name.';
                } else {
                    work_template_update_field($workspaceId, $fieldId, $fieldName, $fieldType, isset($_POST['is_required']), $optionsRaw, $numberUnit, $minMax);
                    $notice = 'Field updated.';
                }
                break;

            case 'delete_field':
                work_template_delete_field($workspaceId, $fieldId);
                $notice = 'Field deleted.';
                break;

            case 'move_field':
                work_template_move_field($workspaceId, $fieldId, (string) ($_POST['direction'] ?? ''));
                break;

            default:
                $error = 'Unknown action.';
        }
    } catch (RuntimeException $exception) {
        $error = $exception->getMessage();
    } catch (Throwable $exception) {
        $error = 'Could not save changes. Please try again.';
    }

    if ($error === null) {
        header('Location: /templates/builder.php?id=' . $templateId . '&saved=1');
        exit;
    }
}

$displayVersion = $draftVersion ?? $publishedVersion;

$definition = $displayVersion !== null
    ? work_template_definition((int) $displayVersion['id'])
    : [];

$canEditDraft = $template['status'] === 'active' && $draftVersion !== null;
$fieldTypeGroups = work_template_field_type_groups();
$approvalChoices = work_template_person_choices($workspaceId);
$fieldTypeMeta = [];

foreach (work_template_field_types() as $type => $typeDefinition) {
    $fieldTypeMeta[$type] = [
        'custom_options' => (bool) ($typeDefinition['custom_options'] ?? false),
        'config' => $typeDefinition['config'] ?? [],
        'needs_unit' => ($typeDefinition['control'] ?? '') === 'number_unit',
    ];
}
function render_work_template_field_form(?array $field, int $sectionId, array $fieldTypeGroups): void
{
    global $approvalChoices;
    $isEdit = $field !== null;
    $name = $isEdit ? (string) $field['name'] : '';
    $type = $isEdit ? (string) $field['field_type'] : 'short_text';
    $isRequired = $isEdit && (bool) $field['is_required'];
    $options = $isEdit ? implode("\n", $field['options'] ?? []) : '';
    $numberUnit = $isEdit ? (string) ($field['number_unit'] ?? '') : '';
    $config = $isEdit ? ($field['config'] ?? []) : [];
    $min = (string) ($config['min'] ?? '');
    $max = (string) ($config['max'] ?? '');
    $step = (string) ($config['step'] ?? '');

    $labels = '';

    if (is_array($config['labels'] ?? null)) {
        $lines = [];

        foreach ($config['labels'] as $label) {
            $lines[] = (string) ($label['value'] ?? '')
                . ' = '
                . (string) ($label['label'] ?? '');
        }

        $labels = implode("\n", $lines);
    }

    $escape = static fn (string $text): string => htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    ?>
    <form method="post" class="form">
        <?= csrf_input() ?>
        <input type="hidden" name="action" value="<?= $isEdit ? 'update_field' : 'add_field' ?>">
        <input type="hidden" name="section_id" value="<?= (int) $sectionId ?>">
        <?php if ($isEdit): ?>
            <input type="hidden" name="field_id" value="<?= (int) $field['id'] ?>">
        <?php endif; ?>

        <div class="form-row">
            <label class="form-group">
                Field name
                <input type="text" name="field_name" maxlength="200" value="<?= $escape($name) ?>" required>
            </label>

            <label class="form-group">
                Field type
                <select name="field_type">
                    <?php foreach ($fieldTypeGroups as $groupLabel => $types): ?>
                        <optgroup label="<?= $escape((string) $groupLabel) ?>">
                            <?php foreach ($types as $typeValue): ?>
                                <option value="<?= $escape($typeValue) ?>" <?= $typeValue === $type ? 'selected' : '' ?>>
                                    <?= $escape(work_template_field_type_label($typeValue)) ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>

        <label class="task-template-checkbox">
            <input type="checkbox" name="is_required" <?= $isRequired ? 'checked' : '' ?>>
            Required
        </label>

        <div class="form-field-config" data-field-config="approval">
            <label>Designated approvers
                <select name="approver_ids[]" multiple>
                    <?php foreach ($approvalChoices as $id => $label): ?>
                        <option value="<?= (int) $id ?>" <?= in_array((int) $id, $config['approver_ids'] ?? [], true) ? 'selected' : '' ?>><?= $escape($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <p>Approvers must also belong to the Task List. One eligible decision closes a requested cycle.</p>
        </div>
        <div class="form-field-config" data-field-config="relation_source">
            <label>Source relation field key <input name="relation_field_key" value="<?= $escape((string) ($config['relation_field_key'] ?? '')) ?>"></label>
            <p>Lookup displays the first accessible target name. Rollup counts accessible targets only.</p>
        </div>
        <div class="form-field-config" data-field-config="lookup_target">
            <label>Lookup target <select name="lookup_target">
                <?php foreach (['task', 'project', 'file', 'record'] as $target): ?>
                    <option value="<?= $target ?>" <?= ($config['target_type'] ?? '') === $target ? 'selected' : '' ?>><?= ucfirst($target) ?></option>
                <?php endforeach; ?>
            </select></label>
        </div>
        <div class="form-field-config" data-field-config="options">
            <label class="form-group">
                Options (one per line)
                <textarea name="options" rows="3"><?= $escape($options) ?></textarea>
            </label>
        </div>

        <div class="form-field-config" data-field-config="number_unit">
            <label class="form-group">
                Unit (number with unit only)
                <input type="text" name="number_unit" maxlength="40" value="<?= $escape($numberUnit) ?>">
            </label>
        </div>

        <div class="form-field-config" data-field-config="minmax">
            <div class="form-row">
                <label class="form-group">
                    Minimum
                    <input type="text" name="min" value="<?= $escape($min) ?>">
                </label>

                <label class="form-group">
                    Maximum
                    <input type="text" name="max" value="<?= $escape($max) ?>">
                </label>
            </div>
        </div>

        <div class="form-field-config" data-field-config="step">
            <label class="form-group">
                Step (range and scale only)
                <input type="text" name="step" value="<?= $escape($step) ?>">
            </label>
        </div>

        <div class="form-field-config" data-field-config="labels">
            <label class="form-group">
                Scale labels (optional; one per line: value = label)
                <textarea name="labels" rows="3"><?= $escape($labels) ?></textarea>
            </label>
        </div>

        <div class="form-actions">
            <button type="submit" class="primary-action">
                <?= $isEdit ? 'Save field' : 'Add field' ?>
            </button>
        </div>
    </form>
    <?php
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($template['name'], ENT_QUOTES, 'UTF-8') ?> | Alliances</title>
</head>
<body>

<?php render_navigation($user); ?>

<main class="app-main">
    <div class="page-container">
    <a href="/templates/index.php" class="task-workspace-breadcrumb">
        ← Work templates
    </a>

    <header class="page-header">
        <div class="page-header-content">
            <div class="task-workspace-badges">
                <span class="badge <?= $template['status'] === 'active' ? 'badge--warning' : 'badge--danger' ?>">
                    <?= htmlspecialchars($template['status'], ENT_QUOTES, 'UTF-8') ?>
                </span>

                <?php if ($publishedVersion !== null): ?>
                    <span class="badge badge--success">
                        Published v<?= (int) $publishedVersion['version_number'] ?>
                    </span>
                <?php endif; ?>

                <?php if ($draftVersion !== null): ?>
                    <span class="badge badge--warning">
                        Draft v<?= (int) $draftVersion['version_number'] ?>
                    </span>
                <?php endif; ?>
            </div>

            <h1 class="page-title"><?= htmlspecialchars($template['name'], ENT_QUOTES, 'UTF-8') ?></h1>

            <?php if (!empty($template['description'])): ?>
                <p class="page-description"><?= nl2br(htmlspecialchars($template['description'], ENT_QUOTES, 'UTF-8')) ?></p>
            <?php endif; ?>
        </div>
    </header><?php if (isset($_GET['saved'])): ?>
        <p class="form-success">Saved.</p>
    <?php endif; ?>

    <?php if ($error !== null): ?>
        <p class="form-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <section class="section">
        <div class="section-header">
            <h2 class="section-title">Template details</h2>
        </div>

        <form method="post" class="form">
            <?= csrf_input() ?>
            <input type="hidden" name="action" value="update_identity">

            <label class="form-group">
                Template name
                <input type="text" name="name" maxlength="150"
                    value="<?= htmlspecialchars($template['name'], ENT_QUOTES, 'UTF-8') ?>" required>
            </label>

            <label class="form-group">
                Description (optional)
                <textarea name="description" rows="3"><?= htmlspecialchars((string) $template['description'], ENT_QUOTES, 'UTF-8') ?></textarea>
            </label>

            <div class="form-actions">
                <button type="submit" class="primary-action">Save details</button>
            </div>
        </form>

        <div class="form-actions">
            <?php if ($canEditDraft): ?>
                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="publish">
                    <input type="hidden" name="version_id" value="<?= (int) $draftVersionId ?>">
                    <button type="submit" class="primary-action">Publish draft</button>
                </form>

                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="new_version">
                    <button type="submit" class="secondary-action">New version</button>
                </form>
            <?php elseif ($template['status'] === 'active'): ?>
                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="new_version">
                    <button type="submit" class="primary-action">Start new draft version</button>
                </form>
            <?php endif; ?>

            <?php if ($template['status'] === 'active'): ?>
                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="archive">
                    <button type="submit" class="secondary-action">Archive</button>
                </form>
            <?php else: ?>
                <form method="post">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="unarchive">
                    <button type="submit" class="secondary-action">Restore</button>
                </form>

                <form method="post" onsubmit="return confirm('Delete this template permanently?');">
                    <?= csrf_input() ?>
                    <input type="hidden" name="action" value="delete">
                    <button type="submit" class="secondary-action">Delete</button>
                </form>
            <?php endif; ?>
        </div>
    </section>

    <header class="section-header">
        <h2 class="section-title">Sections</h2>
        <p class="record-description">
            <?= $canEditDraft
                ? count($definition) . ' section(s)'
                : 'Read only - start a draft version to edit.' ?>
        </p>
    </header>

    <?php if ($canEditDraft): ?>
        <details class="section">
            <summary>Add a section</summary>
            <form method="post" class="form">
                <?= csrf_input() ?>
                <input type="hidden" name="action" value="add_section">

                <label class="form-group">
                    Section name
                    <input type="text" name="section_name" maxlength="150" required>
                </label>

                <label class="form-group">
                    Description (optional)
                    <textarea name="section_description" rows="2"></textarea>
                </label>

                <div class="form-actions">
                    <button type="submit" class="primary-action">Add section</button>
                </div>
            </form>
        </details>
    <?php endif; ?>

    <?php if ($definition === []): ?>
        <p class="empty-state">
            <?= $canEditDraft
                ? 'Add a section to start building this template.'
                : 'This template has no sections yet.' ?>
        </p>
    <?php endif; ?>
<?php foreach ($definition as $sectionIndex => $section): ?>
        <article class="section">
            <div class="section-header">
                <div>
                    <h3 class="section-title"><?= (int) $sectionIndex + 1 ?>. <?= htmlspecialchars($section['name'], ENT_QUOTES, 'UTF-8') ?></h3>
                    <?php if (!empty($section['description'])): ?>
                        <p><?= nl2br(htmlspecialchars($section['description'], ENT_QUOTES, 'UTF-8')) ?></p>
                    <?php endif; ?>
                </div>

                <?php if ($canEditDraft): ?>
                    <div class="section-actions">
                        <form method="post">
                            <?= csrf_input() ?>
                            <input type="hidden" name="action" value="move_section">
                            <input type="hidden" name="section_id" value="<?= (int) $section['id'] ?>">
                            <input type="hidden" name="direction" value="up">
                            <button type="submit" class="secondary-action">↑</button>
                        </form>

                        <form method="post">
                            <?= csrf_input() ?>
                            <input type="hidden" name="action" value="move_section">
                            <input type="hidden" name="section_id" value="<?= (int) $section['id'] ?>">
                            <input type="hidden" name="direction" value="down">
                            <button type="submit" class="secondary-action">↓</button>
                        </form>

                        <form method="post" onsubmit="return confirm('Delete this section and all its fields?');">
                            <?= csrf_input() ?>
                            <input type="hidden" name="action" value="delete_section">
                            <input type="hidden" name="section_id" value="<?= (int) $section['id'] ?>">
                            <button type="submit" class="secondary-action">Delete</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
<?php foreach ($section['fields'] as $field): ?>
                <article class="list-item">
                    <div class="task-item-heading">
                        <h4><?= htmlspecialchars($field['name'], ENT_QUOTES, 'UTF-8') ?></h4>
                        <span class="badge badge--warning">
                            <?= htmlspecialchars(
                                work_template_field_type_label($field['field_type']),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </span>
                        <?php if ($field['is_required']): ?>
                            <span class="badge badge--danger">Required</span>
                        <?php endif; ?>
                    </div>

                    <?php if ($canEditDraft): ?>
                        <div class="section-actions">
                            <form method="post">
                                <?= csrf_input() ?>
                                <input type="hidden" name="action" value="move_field">
                                <input type="hidden" name="field_id" value="<?= (int) $field['id'] ?>">
                                <input type="hidden" name="direction" value="up">
                                <button type="submit" class="secondary-action">↑</button>
                            </form>

                            <form method="post">
                                <?= csrf_input() ?>
                                <input type="hidden" name="action" value="move_field">
                                <input type="hidden" name="field_id" value="<?= (int) $field['id'] ?>">
                                <input type="hidden" name="direction" value="down">
                                <button type="submit" class="secondary-action">↓</button>
                            </form>

                            <form method="post" onsubmit="return confirm('Delete this field?');">
                                <?= csrf_input() ?>
                                <input type="hidden" name="action" value="delete_field">
                                <input type="hidden" name="field_id" value="<?= (int) $field['id'] ?>">
                                <button type="submit" class="secondary-action">Delete</button>
                            </form>

                            <details>
                                <summary>Edit</summary>
                                <?php render_work_template_field_form($field, (int) $section['id'], $fieldTypeGroups); ?>
                            </details>
                        </div>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>

            <?php if ($canEditDraft): ?>
                <details class="section">
                    <summary>Add a field</summary>
                    <?php render_work_template_field_form(null, (int) $section['id'], $fieldTypeGroups); ?>
                </details>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>
    </div>
</main>

<script>
(function () {
    var fieldTypeMeta = <?= work_template_encode_json($fieldTypeMeta) ?>;

    function applyVisibility(form) {
        var select = form.querySelector('select[name="field_type"]');
        if (!select) {
            return;
        }

        var meta = fieldTypeMeta[select.value] || {};
        var configKeys = meta.config || [];

        form.querySelectorAll('[data-field-config]').forEach(function (row) {
            var key = row.getAttribute('data-field-config');

            if (key === 'options') {
                row.hidden = !meta.custom_options;
            } else if (key === 'number_unit') {
                row.hidden = !meta.needs_unit;
            } else if (key === 'minmax') {
                row.hidden = configKeys.indexOf('min') === -1;
            } else if (key === 'step') {
                row.hidden = configKeys.indexOf('step') === -1;
            } else if (key === 'labels') {
                row.hidden = configKeys.indexOf('labels') === -1;
            } else if (key === 'approval') {
                row.hidden = select.value !== 'approval';
            } else if (key === 'relation_source') {
                row.hidden = ['lookup', 'rollup'].indexOf(select.value) === -1;
            } else if (key === 'lookup_target') {
                row.hidden = select.value !== 'lookup';
            }
        });
    }

    document.addEventListener('change', function (event) {
        var select = event.target.closest('select[name="field_type"]');
        if (select && select.form) {
            applyVisibility(select.form);
        }
    });

    document.querySelectorAll('form').forEach(applyVisibility);
})();
</script>
</body>
</html>
