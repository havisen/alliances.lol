<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/tasks/templates.php';
require_once dirname(__DIR__, 2) . '/src/tasks/access.php';

$user = require_login();
$access = workspace_access((int) $user['id']);

if ($access === null) {
    exit('No workspace is assigned to this user.');
}

$workspaceId = (int) $access['workspace_id'];

if (!work_template_can_manage($access)) {
    http_response_code(403);
    exit('Workspace administrator access required.');
}

$error = null;
$formName = '';
$formDescription = '';
$showArchived = isset($_GET['archived']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    $formName = trim($_POST['name'] ?? '');
    $formDescription = trim($_POST['description'] ?? '');

    if ($formName === '') {
        $error = 'Enter a template name.';
    } elseif (strlen($formName) > 150) {
        $error = 'Template names can be up to 150 characters.';
    }

    if ($error === null) {
        try {
            $templateId = work_template_create(
                $workspaceId,
                (int) $user['id'],
                $formName,
                $formDescription
            );

            header('Location: /templates/builder.php?id=' . $templateId);
            exit;
        } catch (Throwable $exception) {
            $error = 'Could not create the template. Please try again.';
        }
    }
}

$templates = work_templates_for_workspace($workspaceId, $showArchived);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="/assets/css/app.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Work templates | Alliances</title>
</head>
<body>

<?php render_navigation($user); ?>

<main class="app-main">
    <div class="page-container">

        <header class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">Work templates</h1>
                <p class="page-description">Build the fields that template-backed tasks are filled in from.</p>
            </div>
        </header>

    <?php if ($error !== null): ?>
        <p class="form-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <section class="section">
        <div class="section-header">
            <h2 class="section-title">Create template</h2>
        </div>

        <form method="post" class="form">
            <?= csrf_input() ?>

            <div class="form-group">
                <label class="form-label" for="template-name">Template name</label>
                <input type="text" id="template-name" name="name" maxlength="150"
                    value="<?= htmlspecialchars($formName, ENT_QUOTES, 'UTF-8') ?>" required>
            </div>

            <div class="form-group">
                <label class="form-label" for="template-description">Description (optional)</label>
                <textarea id="template-description" name="description" rows="3"><?= htmlspecialchars($formDescription, ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="primary-action">Create template</button>
            </div>
        </form>
    </section>

    <section class="section">
        <div class="section-header">
            <h2 class="section-title"><?= $showArchived ? 'All templates' : 'Active templates' ?></h2>
            <div class="section-actions">
                <a href="/templates/index.php<?= $showArchived ? '' : '?archived=1' ?>" class="secondary-action">
                    <?= $showArchived ? 'Hide archived' : 'Show archived' ?>
                </a>
            </div>
        </div>

        <?php if ($templates === []): ?>
            <p class="empty-state">No templates yet.</p>
        <?php else: ?>
            <div class="record-list">
                <?php foreach ($templates as $template): ?>
                    <article class="record">
                        <h3 class="record-title">
                            <a href="/templates/builder.php?id=<?= (int) $template['id'] ?>">
                                <?= htmlspecialchars($template['name'], ENT_QUOTES, 'UTF-8') ?>
                            </a>
                        </h3>

                        <?php if (!empty($template['description'])): ?>
                            <p class="record-description">
                                <?= nl2br(htmlspecialchars($template['description'], ENT_QUOTES, 'UTF-8')) ?>
                            </p>
                        <?php endif; ?>

                        <div class="record-meta">
                            <div class="record-meta-item">
                                <span>Status</span>
                                <strong><?= htmlspecialchars($template['status'], ENT_QUOTES, 'UTF-8') ?></strong>
                            </div>
                            <div class="record-meta-item">
                                <span>Versions</span>
                                <strong><?= (int) $template['version_count'] ?></strong>
                            </div>
                            <div class="record-meta-item">
                                <span>Published</span>
                                <strong>
                                    <?= $template['published_number'] !== null
                                        ? 'v' . (int) $template['published_number']
                                        : '—' ?>
                                </strong>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    </div>
</main>

</body>
</html>