<?php

declare(strict_types=1);

require_once dirname(__DIR__, 2) . '/src/auth.php';
require_once dirname(__DIR__, 2) . '/src/navigation.php';

$user = require_login();

$access = workspace_access((int) $user['id']);

if ($access === null) {
    http_response_code(403);
    exit('Workspace access required.');
}

$workspaceId = (int) $access['workspace_id'];

/*
|--------------------------------------------------------------------------
| Workspace
|--------------------------------------------------------------------------
*/

$workspaceStatement = db()->prepare(
    '
    SELECT
        id,
        name
    FROM workspaces
    WHERE id = ?
    LIMIT 1
    '
);

$workspaceStatement->execute([
    $workspaceId,
]);

$workspace = $workspaceStatement->fetch();

if (!$workspace) {
    http_response_code(404);
    exit('Workspace not found.');
}

/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$teamsStatement = db()->prepare(
    '
    SELECT
        t.id,
        t.name,
        t.team_lead_id,
        u.display_name AS team_lead_name,
        u.job_title AS team_lead_job_title,
        u.avatar_path AS team_lead_avatar
    FROM teams t
    LEFT JOIN users u
        ON u.id = t.team_lead_id
    WHERE t.workspace_id = ?
    ORDER BY t.name ASC
    '
);

$teamsStatement->execute([
    $workspaceId,
]);

$teams = $teamsStatement->fetchAll();

/*
|--------------------------------------------------------------------------
| Team members
|--------------------------------------------------------------------------
*/

$membersStatement = db()->prepare(
    '
    SELECT
        tm.team_id,
        u.id,
        u.display_name,
        u.job_title,
        u.avatar_path
    FROM team_members tm
    INNER JOIN teams t
        ON t.id = tm.team_id
    INNER JOIN users u
        ON u.id = tm.user_id
    WHERE t.workspace_id = ?
    ORDER BY
        u.display_name ASC
    '
);

$membersStatement->execute([
    $workspaceId,
]);

$memberRows = $membersStatement->fetchAll();

$membersByTeam = [];

foreach ($memberRows as $member) {
    $teamId = (int) $member['team_id'];

    if (!isset($membersByTeam[$teamId])) {
        $membersByTeam[$teamId] = [];
    }

    $membersByTeam[$teamId][] = $member;
}

/*
|--------------------------------------------------------------------------
| Workspace members
|--------------------------------------------------------------------------
|
| Used for the total member count and for finding people who currently
| aren't assigned to a team.
|
*/

$workspaceMembersStatement = db()->prepare(
    '
    SELECT
        u.id,
        u.display_name,
        u.job_title,
        u.avatar_path
    FROM workspace_members wm
    INNER JOIN users u
        ON u.id = wm.user_id
    WHERE wm.workspace_id = ?
    ORDER BY
        u.display_name ASC
    '
);

$workspaceMembersStatement->execute([
    $workspaceId,
]);

$workspaceMembers = $workspaceMembersStatement->fetchAll();

$assignedUserIds = [];

foreach ($teams as $team) {
    if (!empty($team['team_lead_id'])) {
        $assignedUserIds[(int) $team['team_lead_id']] = true;
    }
}

foreach ($memberRows as $member) {
    $assignedUserIds[(int) $member['id']] = true;
}

$unassignedMembers = [];

foreach ($workspaceMembers as $workspaceMember) {
    $memberId = (int) $workspaceMember['id'];

    if (!isset($assignedUserIds[$memberId])) {
        $unassignedMembers[] = $workspaceMember;
    }
}

/*
|--------------------------------------------------------------------------
| Counts
|--------------------------------------------------------------------------
*/

$totalMembers = count($workspaceMembers);
$totalTeams = count($teams);

/*
|--------------------------------------------------------------------------
| Current user's team
|--------------------------------------------------------------------------
*/

$myTeamStatement = db()->prepare(
    '
    SELECT
        t.id,
        t.name,
        t.team_lead_id,
        u.display_name AS team_lead_name
    FROM team_members tm
    INNER JOIN teams t
        ON t.id = tm.team_id
    LEFT JOIN users u
        ON u.id = t.team_lead_id
    WHERE
        tm.user_id = ?
        AND t.workspace_id = ?
    ORDER BY t.name ASC
    LIMIT 1
    '
);

$myTeamStatement->execute([
    (int) $user['id'],
    $workspaceId,
]);

$myTeam = $myTeamStatement->fetch();

/*
 * A Team Lead may not necessarily also have an entry
 * in team_members, so check teams directly as well.
 */
if (!$myTeam) {
    $myLeadTeamStatement = db()->prepare(
        '
        SELECT
            t.id,
            t.name,
            t.team_lead_id,
            u.display_name AS team_lead_name
        FROM teams t
        LEFT JOIN users u
            ON u.id = t.team_lead_id
        WHERE
            t.workspace_id = ?
            AND t.team_lead_id = ?
        ORDER BY t.name ASC
        LIMIT 1
        '
    );

    $myLeadTeamStatement->execute([
        $workspaceId,
        (int) $user['id'],
    ]);

    $myTeam = $myLeadTeamStatement->fetch();
}

/*
|--------------------------------------------------------------------------
| Team lead count
|--------------------------------------------------------------------------
*/

$teamLeadCount = 0;

foreach ($teams as $team) {
    if (!empty($team['team_lead_id'])) {
        $teamLeadCount++;
    }
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function workspace_person_initial(string $name): string
{
    $name = trim($name);

    if ($name === '') {
        return '?';
    }

    return strtoupper(substr($name, 0, 1));
}

function workspace_person_avatar(
    ?string $avatarPath,
    string $displayName,
    string $className = ''
): string {
    $avatarPath = trim((string) $avatarPath);

    if ($avatarPath !== '') {
        return sprintf(
            '<img class="workspace-person-avatar %s" src="%s" alt="">',
            htmlspecialchars($className, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($avatarPath, ENT_QUOTES, 'UTF-8')
        );
    }

    return sprintf(
        '<span class="workspace-person-avatar workspace-person-placeholder %s">%s</span>',
        htmlspecialchars($className, ENT_QUOTES, 'UTF-8'),
        htmlspecialchars(
            workspace_person_initial($displayName),
            ENT_QUOTES,
            'UTF-8'
        )
    );
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1"
    >

    <title>
        <?= htmlspecialchars(
            (string) $workspace['name'],
            ENT_QUOTES,
            'UTF-8'
        ) ?>
        · Teams
    </title>

    <link
        rel="stylesheet"
        href="/assets/css/app.css"
    >
</head>

<body>

<div class="app-shell">

    <?php render_navigation($user); ?>

    <main class="app-main">

        <div class="workspace-overview">

            <header class="workspace-overview-header">

                <div>
                    <span class="workspace-overview-eyebrow">
                        Workspace
                    </span>

                    <h1>
                        <?= htmlspecialchars(
                            (string) $workspace['name'],
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </h1>

                    <p>
                        Teams and people in this workspace.
                    </p>
                </div>

                <div class="workspace-overview-stats">

                    <div class="workspace-overview-stat">
                        <strong>
                            <?= $totalTeams ?>
                        </strong>

                        <span>
                            <?= $totalTeams === 1
                                ? 'Team'
                                : 'Teams' ?>
                        </span>
                    </div>

                    <div class="workspace-overview-stat">
                        <strong>
                            <?= $totalMembers ?>
                        </strong>

                        <span>
                            <?= $totalMembers === 1
                                ? 'Member'
                                : 'Members' ?>
                        </span>
                    </div>

                </div>

            </header>

            <section class="workspace-dashboard">

    <div class="workspace-dashboard-card workspace-dashboard-welcome">

        <div class="workspace-dashboard-icon">
            <svg
                viewBox="0 0 24 24"
                aria-hidden="true"
            >
                <circle cx="9" cy="8" r="3"></circle>
                <circle cx="17" cy="9" r="2"></circle>

                <path d="M3 20v-2a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v2"></path>
                <path d="M15 14h1a4 4 0 0 1 4 4v2"></path>
            </svg>
        </div>

        <div>
            <span class="workspace-dashboard-label">
                Your workspace
            </span>

            <h2>
                <?= htmlspecialchars(
                    (string) $workspace['name'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h2>

            <p>
                <?= $totalMembers ?>
                <?= $totalMembers === 1
                    ? 'person works'
                    : 'people work' ?>
                across
                <?= $totalTeams ?>
                <?= $totalTeams === 1
                    ? 'team'
                    : 'teams' ?>.
            </p>
        </div>

    </div>


    <div class="workspace-dashboard-card">

        <span class="workspace-dashboard-label">
            Your team
        </span>

        <?php if ($myTeam): ?>

            <strong class="workspace-dashboard-value">
                <?= alliances_team_link(
                    (int) $myTeam['id'],
                    (string) $myTeam['name'],
                    'team-link workspace-team-link'
                ) ?>
            </strong>

            <p class="workspace-dashboard-description">
                <?php if (
                    (int) $myTeam['team_lead_id']
                    === (int) $user['id']
                ): ?>

                    You are the Team Lead.

                <?php elseif (
                    !empty($myTeam['team_lead_name'])
                ): ?>

                    Led by
                    <?= alliances_profile_link(
                        (int) $myTeam['team_lead_id'],
                        (string) $myTeam['team_lead_name'],
                        'profile-link workspace-profile-link'
                    ) ?>.

                <?php else: ?>

                    No Team Lead assigned.

                <?php endif; ?>
            </p>

        <?php else: ?>

            <strong class="workspace-dashboard-value">
                Unassigned
            </strong>

            <p class="workspace-dashboard-description">
                You aren't currently assigned to a team.
            </p>

        <?php endif; ?>

    </div>


    <div class="workspace-dashboard-card">

        <span class="workspace-dashboard-label">
            Team Leads
        </span>

        <strong class="workspace-dashboard-value">
            <?= $teamLeadCount ?>
        </strong>

        <p class="workspace-dashboard-description">
            <?= $teamLeadCount === 1
                ? 'Team currently has a lead.'
                : 'Teams currently have leads.' ?>
        </p>

    </div>


    <div class="workspace-dashboard-card">

        <span class="workspace-dashboard-label">
            Directory
        </span>

        <strong class="workspace-dashboard-value">
            <?= $totalMembers ?>
        </strong>

        <p class="workspace-dashboard-description">
            Workspace profiles available.
        </p>

    </div>

</section>

            <section class="workspace-teams-section">

                <div class="workspace-section-heading">

                    <div>
                        <h2>Teams</h2>

                        <p>
                            Everyone in the workspace grouped by team.
                        </p>
                    </div>

                </div>


                <?php if (!$teams): ?>

                    <div class="workspace-empty-state">
                        <h3>No teams yet</h3>

                        <p>
                            Teams created in Administration will appear here.
                        </p>
                    </div>

                <?php else: ?>

                    <div class="workspace-team-grid">

                        <?php foreach ($teams as $team): ?>

                            <?php
                            $teamId = (int) $team['id'];

                            $teamMembers =
                                $membersByTeam[$teamId] ?? [];

                            /*
                             * Do not display the Team Lead twice if they
                             * also exist in team_members.
                             */
                            if (!empty($team['team_lead_id'])) {
                                $teamLeadId =
                                    (int) $team['team_lead_id'];

                                $teamMembers = array_values(
                                    array_filter(
                                        $teamMembers,
                                        static function (
                                            array $member
                                        ) use ($teamLeadId): bool {
                                            return
                                                (int) $member['id']
                                                !== $teamLeadId;
                                        }
                                    )
                                );
                            }
                            ?>

                            <article class="workspace-team-card">

                                <header class="workspace-team-header">

                                    <div>
                                        <span class="workspace-team-label">
                                            Team
                                        </span>

                                        <h3>
                                            <?= alliances_team_link(
                                                (int) $team['id'],
                                                (string) $team['name'],
                                                'team-link workspace-team-link'
                                            ) ?>
                                        </h3>
                                    </div>

                                    <div class="workspace-team-header-actions">
                                        <span class="workspace-team-count">
                                            <?= count($teamMembers)
                                                + (
                                                    !empty(
                                                        $team['team_lead_id']
                                                    )
                                                        ? 1
                                                        : 0
                                                ) ?>
                                            people
                                        </span>

                                        <a
                                            class="workspace-open-team-link"
                                            href="/team.php?id=<?= (int) $team['id'] ?>"
                                        >
                                            Open team page
                                        </a>
                                    </div>

                                </header>


                                <div class="workspace-team-chart">

                                    <?php if (
                                        !empty(
                                            $team['team_lead_id']
                                        )
                                    ): ?>

                                        <div class="workspace-team-lead">

                                            <a
                                                class="workspace-person-card workspace-lead-card"
                                                href="/profile/?id=<?= (int) $team['team_lead_id'] ?>"
                                            >

                                                <?= workspace_person_avatar(
                                                    $team['team_lead_avatar']
                                                        ?? null,
                                                    (string) (
                                                        $team['team_lead_name']
                                                        ?? ''
                                                    ),
                                                    'workspace-lead-avatar'
                                                ) ?>

                                                <span class="workspace-person-info">

                                                    <strong>
                                                        <?= htmlspecialchars(
                                                            (string) (
                                                                $team['team_lead_name']
                                                                ?? 'Unknown user'
                                                            ),
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>
                                                    </strong>

                                                    <span>
                                                        <?= htmlspecialchars(
                                                            trim(
                                                                (string) (
                                                                    $team['team_lead_job_title']
                                                                    ?? ''
                                                                )
                                                            ) !== ''
                                                                ? (string) $team['team_lead_job_title']
                                                                : 'Team Lead',
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>
                                                    </span>

                                                    <small>
                                                        Team Lead
                                                    </small>

                                                </span>

                                            </a>

                                        </div>


                                        <?php if ($teamMembers): ?>

                                            <div
                                                class="workspace-chart-connector"
                                                aria-hidden="true"
                                            ></div>

                                        <?php endif; ?>

                                    <?php else: ?>

                                        <div class="workspace-no-team-lead">
                                            No Team Lead assigned
                                        </div>

                                    <?php endif; ?>


                                    <?php if ($teamMembers): ?>

                                        <div class="workspace-member-grid">

                                            <?php foreach (
                                                $teamMembers as $member
                                            ): ?>

                                                <a
                                                    class="workspace-person-card workspace-member-card"
                                                    href="/profile/?id=<?= (int) $member['id'] ?>"
                                                >

                                                    <?= workspace_person_avatar(
                                                        $member['avatar_path']
                                                            ?? null,
                                                        (string) (
                                                            $member['display_name']
                                                            ?? ''
                                                        )
                                                    ) ?>

                                                    <span class="workspace-person-info">

                                                        <strong>
                                                            <?= htmlspecialchars(
                                                                (string) (
                                                                    $member['display_name']
                                                                    ?? 'Unknown user'
                                                                ),
                                                                ENT_QUOTES,
                                                                'UTF-8'
                                                            ) ?>
                                                        </strong>

                                                        <span>
                                                            <?= htmlspecialchars(
                                                                trim(
                                                                    (string) (
                                                                        $member['job_title']
                                                                        ?? ''
                                                                    )
                                                                ) !== ''
                                                                    ? (string) $member['job_title']
                                                                    : 'Member',
                                                                ENT_QUOTES,
                                                                'UTF-8'
                                                            ) ?>
                                                        </span>

                                                    </span>

                                                </a>

                                            <?php endforeach; ?>

                                        </div>

                                    <?php elseif (
                                        empty($team['team_lead_id'])
                                    ): ?>

                                        <div class="workspace-team-empty">
                                            This team has no members yet.
                                        </div>

                                    <?php endif; ?>

                                </div>

                            </article>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </section>


            <?php if ($unassignedMembers): ?>

                <section class="workspace-unassigned-section">

                    <div class="workspace-section-heading">
                        <div>
                            <h2>Unassigned members</h2>

                            <p>
                                Workspace members who aren't currently
                                assigned to a team.
                            </p>
                        </div>
                    </div>

                    <div class="workspace-unassigned-grid">

                        <?php foreach (
                            $unassignedMembers as $member
                        ): ?>

                            <a
                                class="workspace-person-card workspace-member-card"
                                href="/profile/?id=<?= (int) $member['id'] ?>"
                            >

                                <?= workspace_person_avatar(
                                    $member['avatar_path'] ?? null,
                                    (string) (
                                        $member['display_name'] ?? ''
                                    )
                                ) ?>

                                <span class="workspace-person-info">

                                    <strong>
                                        <?= htmlspecialchars(
                                            (string) (
                                                $member['display_name']
                                                ?? 'Unknown user'
                                            ),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </strong>

                                    <span>
                                        <?= htmlspecialchars(
                                            trim(
                                                (string) (
                                                    $member['job_title']
                                                    ?? ''
                                                )
                                            ) !== ''
                                                ? (string) $member['job_title']
                                                : 'Member',
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>
                                    </span>

                                </span>

                            </a>

                        <?php endforeach; ?>

                    </div>

                </section>

            <?php endif; ?>

        </div>

    </main>

</div>

</body>
</html>
