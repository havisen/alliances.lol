<?php

declare(strict_types=1);

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/entity-links.php';
require_once __DIR__ . '/preferences.php';

function start_session(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function session_fingerprint(): ?string
{
    start_session();

    $sessionId = session_id();

    if ($sessionId === '') {
        return null;
    }

    return hash('sha256', $sessionId);
}

function request_user_agent(): ?string
{
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

    if (!is_string($userAgent) || trim($userAgent) === '') {
        return null;
    }

    return substr($userAgent, 0, 500);
}

function request_ip_address(): ?string
{
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? null;

    if (!is_string($ipAddress) || trim($ipAddress) === '') {
        return null;
    }

    return substr($ipAddress, 0, 64);
}

function register_current_session(int $userId): void
{
    $sessionHash = session_fingerprint();

    if ($sessionHash === null) {
        return;
    }

    try {
        $statement = db()->prepare(
            'INSERT INTO user_sessions
                (user_id, session_hash, user_agent, ip_address, created_at, last_seen_at)
             VALUES
                (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
             ON CONFLICT(session_hash)
             DO UPDATE SET
                user_id = excluded.user_id,
                user_agent = excluded.user_agent,
                ip_address = excluded.ip_address,
                last_seen_at = CURRENT_TIMESTAMP,
                revoked_at = NULL'
        );

        $statement->execute([
            $userId,
            $sessionHash,
            request_user_agent(),
            request_ip_address(),
        ]);
    } catch (Throwable $error) {
        return;
    }
}

function current_session_is_valid(int $userId): bool
{
    $sessionHash = session_fingerprint();

    if ($sessionHash === null) {
        return true;
    }

    try {
        $statement = db()->prepare(
            'SELECT revoked_at
             FROM user_sessions
             WHERE user_id = ?
               AND session_hash = ?
             LIMIT 1'
        );

        $statement->execute([
            $userId,
            $sessionHash,
        ]);

        $session = $statement->fetch();

        if (!$session) {
            register_current_session($userId);
            return true;
        }

        if ($session['revoked_at'] !== null) {
            return false;
        }

        $update = db()->prepare(
            'UPDATE user_sessions
             SET last_seen_at = CURRENT_TIMESTAMP
             WHERE user_id = ?
               AND session_hash = ?'
        );

        $update->execute([
            $userId,
            $sessionHash,
        ]);
    } catch (Throwable $error) {
        return true;
    }

    return true;
}

function active_user_sessions(int $userId): array
{
    try {
        $statement = db()->prepare(
            'SELECT
                id,
                session_hash,
                user_agent,
                ip_address,
                created_at,
                last_seen_at
             FROM user_sessions
             WHERE user_id = ?
               AND revoked_at IS NULL
             ORDER BY last_seen_at DESC, created_at DESC'
        );

        $statement->execute([$userId]);

        return $statement->fetchAll();
    } catch (Throwable $error) {
        return [];
    }
}

function revoke_user_session(int $userId, int $sessionRecordId): void
{
    $currentHash = session_fingerprint();

    $statement = db()->prepare(
        'UPDATE user_sessions
         SET revoked_at = CURRENT_TIMESTAMP
         WHERE user_id = ?
           AND id = ?
           AND session_hash != ?'
    );

    $statement->execute([
        $userId,
        $sessionRecordId,
        $currentHash ?? '',
    ]);
}

function revoke_other_user_sessions(int $userId): void
{
    $currentHash = session_fingerprint();

    if ($currentHash === null) {
        return;
    }

    $statement = db()->prepare(
        'UPDATE user_sessions
         SET revoked_at = CURRENT_TIMESTAMP
         WHERE user_id = ?
           AND session_hash != ?
           AND revoked_at IS NULL'
    );

    $statement->execute([
        $userId,
        $currentHash,
    ]);
}

function revoke_all_user_sessions(int $userId, bool $keepCurrentSession = false): void
{
    $currentHash = $keepCurrentSession
        ? session_fingerprint()
        : null;

    if ($keepCurrentSession && $currentHash !== null) {
        $statement = db()->prepare(
            'UPDATE user_sessions
             SET revoked_at = CURRENT_TIMESTAMP
             WHERE user_id = ?
               AND session_hash != ?
               AND revoked_at IS NULL'
        );

        $statement->execute([
            $userId,
            $currentHash,
        ]);

        return;
    }

    $statement = db()->prepare(
        'UPDATE user_sessions
         SET revoked_at = CURRENT_TIMESTAMP
         WHERE user_id = ?
           AND revoked_at IS NULL'
    );

    $statement->execute([$userId]);
}

function current_session_record_hash(): ?string
{
    return session_fingerprint();
}

function admin_audit_log(
    int $workspaceId,
    ?int $actorUserId,
    string $action,
    string $targetType,
    ?int $targetId = null,
    ?string $details = null
): void {
    try {
        $statement = db()->prepare(
            'INSERT INTO admin_audit_events
                (workspace_id, actor_user_id, action, target_type, target_id, details)
             VALUES
                (?, ?, ?, ?, ?, ?)'
        );

        $statement->execute([
            $workspaceId,
            $actorUserId,
            $action,
            $targetType,
            $targetId,
            $details,
        ]);
    } catch (Throwable $error) {
    }
}

function current_user(): ?array
{
    start_session();

    if (!isset($_SESSION['user_id'])) {
        return null;
    }

    $userId = (int) $_SESSION['user_id'];

    if (!current_session_is_valid($userId)) {
        $_SESSION = [];
        session_destroy();
        return null;
    }

    $statement = db()->prepare(
        'SELECT
            id,
            display_name,
            email,
            job_title,
            avatar_path,
            account_status
        FROM users
        WHERE id = ?'
            );

    $statement->execute([$userId]);

    $currentUser = $statement->fetch();

    if (!$currentUser || $currentUser['account_status'] !== 'active') {
        $_SESSION = [];
        session_destroy();
        return null;
    }

    return $currentUser;
}

function require_login(): array
{
    $user = current_user();

    if ($user === null) {
        header('Location: /login.php');
        exit;
    }

    return $user;
}

function csrf_token(): string
{
    start_session();

    if (
        !isset($_SESSION['csrf_token'])
        || !is_string($_SESSION['csrf_token'])
        || strlen($_SESSION['csrf_token']) !== 64
    ) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_input(): string
{
    return '<input type="hidden" name="csrf_token" value="'
        . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8')
        . '">';
}

function require_valid_csrf(): void
{
    start_session();

    $submittedToken = $_POST['csrf_token'] ?? '';
    $sessionToken = $_SESSION['csrf_token'] ?? '';

    if (
        !is_string($submittedToken)
        || !is_string($sessionToken)
        || $sessionToken === ''
        || !hash_equals($sessionToken, $submittedToken)
    ) {
        http_response_code(403);
        exit(
            'Invalid or expired request. Please go back and try again.'
        );
    }
}

function user_workspaces(int $userId): array
{
    try {
        $statement = db()->prepare(
            'SELECT w.id, w.name, wm.role
             FROM workspace_members AS wm
             INNER JOIN workspaces AS w ON w.id = wm.workspace_id
             WHERE wm.user_id = ?
             ORDER BY w.name COLLATE NOCASE ASC, w.id ASC'
        );

        $statement->execute([$userId]);

        $workspaces = [];

        foreach ($statement->fetchAll() as $row) {
            $workspaces[] = [
                'id' => (int) $row['id'],
                'name' => (string) $row['name'],
                'role' => (string) $row['role'],
            ];
        }

        return $workspaces;
    } catch (Throwable $error) {
        return [];
    }
}

function workspace_is_member(int $workspaceId, int $userId): bool
{
    $statement = db()->prepare(
        'SELECT 1
         FROM workspace_members
         WHERE workspace_id = ?
           AND user_id = ?
         LIMIT 1'
    );

    $statement->execute([$workspaceId, $userId]);

    return $statement->fetchColumn() !== false;
}

function resolve_active_workspace_id(int $userId): ?int
{
    $workspaces = user_workspaces($userId);

    if ($workspaces === []) {
        return null;
    }

    $memberIds = array_map(
        static fn(array $workspace): int => (int) $workspace['id'],
        $workspaces
    );

    $sessionActive = session_status() === PHP_SESSION_ACTIVE;

    if ($sessionActive && isset($_SESSION['active_workspace_id'])) {
        $candidate = filter_var(
            $_SESSION['active_workspace_id'],
            FILTER_VALIDATE_INT
        );

        if (
            $candidate !== false
            && in_array((int) $candidate, $memberIds, true)
        ) {
            return (int) $candidate;
        }
    }

    $fallback = $memberIds[0];

    if ($sessionActive) {
        $_SESSION['active_workspace_id'] = $fallback;
    }

    return $fallback;
}

function switch_workspace(int $userId, int $workspaceId): bool
{
    if ($workspaceId <= 0 || !workspace_is_member($workspaceId, $userId)) {
        return false;
    }

    start_session();
    $_SESSION['active_workspace_id'] = $workspaceId;

    return true;
}

function workspace_access(int $userId): ?array
{
    $connection = db();

    /*
     * Resolve the trusted, session-selected active Workspace. The Workspace
     * is always re-verified against workspace_members on every request, so a
     * stale or forged active_workspace_id is ignored.
     */
    $workspaceId = resolve_active_workspace_id($userId);

    if ($workspaceId === null) {
        return null;
    }

    $statement = $connection->prepare(
        'SELECT role
         FROM workspace_members
         WHERE workspace_id = ?
           AND user_id = ?
         LIMIT 1'
    );

    $statement->execute([$workspaceId, $userId]);
    $membership = $statement->fetch();

    if (!$membership) {
        return null;
    }

    $isAdmin = $membership['role'] === 'admin';

    $teamStatement = $connection->prepare(
        'SELECT id
         FROM teams
         WHERE workspace_id = ?
           AND team_lead_id = ?
           AND status = ?
         ORDER BY id ASC'
    );

    $teamStatement->execute([
        $workspaceId,
        $userId,
        'active',
    ]);

    $teamIds = array_map(
        'intval',
        $teamStatement->fetchAll(PDO::FETCH_COLUMN)
    );

    return [
        'workspace_id' => $workspaceId,
        'role' => $membership['role'],
        'is_admin' => $isAdmin,
        'is_team_lead' => $teamIds !== [],
        'team_ids' => $teamIds,
    ];
}

function require_administration_access(array $user): array
{
    $access = workspace_access((int) $user['id']);

    if (
        $access === null
        || (!$access['is_admin'] && !$access['is_team_lead'])
    ) {
        http_response_code(403);
        exit('Administration access required.');
    }

    return $access;
}

function can_manage_team(array $access, int $teamId): bool
{
    if ($access['is_admin']) {
        return true;
    }

    return in_array(
        $teamId,
        $access['team_ids'],
        true
    );
}

function can_manage_user(array $access, int $userId): bool
{
    if ($access['is_admin']) {
        return true;
    }

    if (!$access['is_team_lead']) {
        return false;
    }

    if ((int) $userId === 0) {
        return false;
    }

    $teamIds = $access['team_ids'];

    if ($teamIds === []) {
        return false;
    }

    $placeholders = implode(
        ',',
        array_fill(0, count($teamIds), '?')
    );

    $parameters = $teamIds;
    $parameters[] = $userId;

    $statement = db()->prepare(
        'SELECT 1
         FROM team_members
         WHERE team_id IN (' . $placeholders . ')
           AND user_id = ?
         LIMIT 1'
    );

    $statement->execute($parameters);

    return $statement->fetchColumn() !== false;
}

function login_user(string $email, string $password): bool
{
    $statement = db()->prepare(
        'SELECT id, password_hash, account_status
         FROM users
         WHERE email = ?'
    );

    $statement->execute([strtolower(trim($email))]);
    $user = $statement->fetch();

    if (
        !$user
        || $user['account_status'] !== 'active'
        || !password_verify($password, $user['password_hash'])
    ) {
        return false;
    }

    start_session();
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    register_current_session((int) $user['id']);

    return true;
}

function logout_user(): void
{
    start_session();

    $sessionHash = session_fingerprint();
    $userId = isset($_SESSION['user_id'])
        ? (int) $_SESSION['user_id']
        : null;

    if ($sessionHash !== null && $userId !== null) {
        try {
            $statement = db()->prepare(
                'UPDATE user_sessions
                 SET revoked_at = CURRENT_TIMESTAMP
                 WHERE user_id = ?
                   AND session_hash = ?'
            );

            $statement->execute([
                $userId,
                $sessionHash,
            ]);
        } catch (Throwable $error) {
        }
    }

    $_SESSION = [];
    session_destroy();
}

require_once __DIR__ . '/navigation.php';
