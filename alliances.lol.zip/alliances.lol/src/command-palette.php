<?php

declare(strict_types=1);

function render_command_palette(
    array $user,
    ?array $access,
    bool $showAdministration
): void {
    $commands = [
        ['label' => 'Home', 'url' => '/index.php'],
    ];

    if ($access !== null) {
        $commands[] = [
            'label' => 'Workspace Overview',
            'url' => '/workspace/',
        ];

        $commands[] = [
            'label' => 'Projects',
            'url' => '/projects/',
        ];

        $commands[] = [
            'label' => 'Tasks',
            'url' => '/tasks/',
        ];

        $commands[] = [
            'label' => 'Calendar',
            'url' => '/calendar.php',
        ];

        $commands[] = [
            'label' => 'Drive',
            'url' => '/drive/',
        ];

        $commands[] = [
            'label' => 'Messaging',
            'url' => '/messaging/',
        ];

        $commands[] = [
            'label' => 'Key Vault',
            'url' => '/key-vault/',
        ];
    }

    $commands[] = [
        'label' => 'Notifications',
        'url' => '/notifications/',
    ];

    $commands[] = [
        'label' => 'Settings',
        'url' => '/settings/',
    ];

    $commands[] = [
        'label' => 'My Profile',
        'url' => '/profile/?id=' . (int) $user['id'],
    ];

    if ($showAdministration) {
        $commands[] = [
            'label' => 'Administration',
            'url' => '/admin/admin.php',
        ];
    }

    $commandsJson = json_encode(
        $commands,
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
    );

    $scriptSrc = '/assets/js/command-palette.js';
    $scriptPath = dirname(__DIR__) . '/public/assets/js/command-palette.js';

    if (is_file($scriptPath)) {
        $scriptSrc .= '?v=' . urlencode((string) filemtime($scriptPath));
    }

    ?>
    <link rel="stylesheet" href="/assets/css/command-palette.css">

    <script type="module" src="<?= htmlspecialchars($scriptSrc, ENT_QUOTES, 'UTF-8') ?>"></script>

    <script type="application/json" id="command-palette-nav"><?= $commandsJson ?></script>

    <div
        class="command-palette"
        id="command-palette"
        role="dialog"
        aria-modal="true"
        aria-label="Command palette"
        hidden
    >
        <div class="command-palette-backdrop" data-command-palette-close></div>

        <div class="command-palette-dialog">
            <div class="command-palette-input-row">
                <span class="command-palette-search-icon" aria-hidden="true">⌕</span>

                <input
                    type="text"
                    class="command-palette-input"
                    id="command-palette-input"
                    placeholder="Search people, teams, projects, tasks, calendar, Drive…"
                    autocomplete="off"
                    spellcheck="false"
                    aria-label="Search"
                >

                <kbd class="command-palette-kbd" aria-hidden="true">ESC</kbd>
            </div>

            <div
                class="command-palette-results"
                id="command-palette-results"
                role="listbox"
            ></div>

            <div class="command-palette-footer">
                <span><kbd>↑</kbd> <kbd>↓</kbd> Navigate</span>
                <span><kbd>Enter</kbd> Open</span>
                <span><kbd>Esc</kbd> Close</span>
            </div>
        </div>
    </div>
    <?php
}
