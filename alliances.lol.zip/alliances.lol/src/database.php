<?php

declare(strict_types=1);

function db(): PDO
{
    static $connection = null;

    if ($connection === null) {
        $config = require dirname(__DIR__) . '/database/config/database.php';

        $connection = new PDO(
            'sqlite:' . $config['path'],
            null,
            null,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );

        $connection->exec('PRAGMA foreign_keys = ON');
    }

    return $connection;
}