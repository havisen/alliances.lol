<?php

declare(strict_types=1);

/**
 * Alliances Encrypted Drive
 *
 * Server-side storage helpers.
 *
 * IMPORTANT:
 * - Files stored here are already encrypted by the browser.
 * - Plaintext file contents must never be written here.
 * - Raw file encryption keys must never be written here.
 */


/**
 * Absolute directory containing encrypted Drive files.
 *
 * The directory is outside /public so encrypted files cannot
 * be requested directly through the web server.
 */
function drive_storage_path(): string
{
    return dirname(__DIR__, 2) . DIRECTORY_SEPARATOR
        . 'storage' . DIRECTORY_SEPARATOR
        . 'drive';
}


/**
 * Ensure the Drive storage directory exists.
 */
function drive_ensure_storage_directory(): void
{
    $path = drive_storage_path();

    if (is_dir($path)) {
        return;
    }

    if (!mkdir($path, 0750, true) && !is_dir($path)) {
        throw new RuntimeException(
            'Unable to create Drive storage directory.'
        );
    }
}


/**
 * Generate a random storage identifier.
 *
 * This identifier intentionally has no relationship to the
 * original filename.
 */
function drive_generate_storage_id(): string
{
    return bin2hex(random_bytes(32));
}


/**
 * Convert a storage ID into its physical encrypted-file path.
 *
 * Files are split into subdirectories using the first two
 * characters of the storage ID. This prevents one directory
 * from eventually containing thousands of files.
 *
 * Example:
 *
 * storage ID:
 * a84b12...
 *
 * becomes:
 *
 * storage/drive/a8/a84b12....encrypted
 */
function drive_file_path(string $storageId): string
{
    if (!preg_match('/^[a-f0-9]{64}$/', $storageId)) {
        throw new InvalidArgumentException(
            'Invalid Drive storage identifier.'
        );
    }

    $prefix = substr($storageId, 0, 2);

    return drive_storage_path()
        . DIRECTORY_SEPARATOR
        . $prefix
        . DIRECTORY_SEPARATOR
        . $storageId
        . '.encrypted';
}


/**
 * Ensure the subdirectory required for a storage ID exists.
 */
function drive_ensure_file_directory(string $storageId): void
{
    $filePath = drive_file_path($storageId);
    $directory = dirname($filePath);

    if (is_dir($directory)) {
        return;
    }

    if (!mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException(
            'Unable to create Drive file directory.'
        );
    }
}


/**
 * Delete an encrypted file from server storage.
 */
function drive_delete_stored_file(string $storageId): void
{
    $path = drive_file_path($storageId);

    if (!is_file($path)) {
        return;
    }

    if (!unlink($path)) {
        throw new RuntimeException(
            'Unable to delete encrypted Drive file.'
        );
    }
}
/** Return the user's current effective permission from active individual/team grants. */
function drive_effective_access(PDO $pdo, int $workspaceId, int $fileId, int $userId): ?array
{
    $statement = $pdo->prepare(
        'SELECT f.uploaded_by, ea.can_edit
         FROM drive_files f
         INNER JOIN drive_effective_access ea ON ea.file_id = f.id AND ea.user_id = :user_id
         WHERE f.id = :file_id AND f.workspace_id = :workspace_id
         LIMIT 1'
    );
    $statement->execute([':user_id'=>$userId, ':file_id'=>$fileId, ':workspace_id'=>$workspaceId]);
    $row = $statement->fetch(PDO::FETCH_ASSOC);
    if (!$row) return null;
    return ['can_view'=>true, 'can_edit'=>(int)$row['can_edit']===1, 'is_uploader'=>(int)$row['uploaded_by']===$userId];
}



/**
 * Determine whether a Drive file can be opened in the built-in encrypted
 * editor, mirroring the client-side logic in drive.js.
 *
 * Only text, DOCX, XLSX and PDF documents open in the editor. Images open
 * in the Drive image preview and every other MIME type is downloaded;
 * neither of those has a deep-linkable URL.
 */
function drive_file_editor_supported(string $name, ?string $mimeType): bool
{
    $fileName = strtolower(trim($name));
    $mime = strtolower(trim(explode(';', (string) $mimeType)[0]));

    return str_ends_with($fileName, '.txt')
        || $mime === 'text/plain'
        || str_ends_with($fileName, '.docx')
        || str_ends_with($fileName, '.xlsx')
        || str_ends_with($fileName, '.pdf')
        || $mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        || $mime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        || $mime === 'application/pdf';
}

/**
 * Search Drive for the folders and files the current user may access.
 *
 * This reuses the exact authorization joins proven in
 * public/actions/drive/search.php so universal search can never expose
 * Drive metadata the dedicated Drive search would not also expose:
 *
 * - non-trashed folders with a non-trashed ancestor chain;
 * - non-trashed files in a visible (or root) folder;
 * - an active individual/team grant via drive_effective_access;
 * - the current user's wrapped key via drive_file_keys.
 *
 * Only metadata is returned. No wrapped keys, storage IDs, or file
 * contents are exposed.
 *
 * @return array{folders: array<int, array<string, mixed>>, files: array<int, array<string, mixed>>}
 */
function drive_search_metadata(int $workspaceId, int $userId, string $likeQuery): array
{
    $pdo = db();

    /*
     * Search visible folders. visible_folders begins only at non-trashed
     * root folders and recursively follows non-trashed children, so a
     * folder underneath a trashed ancestor cannot appear.
     */
    $folderStatement = $pdo->prepare('
        WITH RECURSIVE visible_folders (id, parent_id, created_by, name, path) AS (
            SELECT id, parent_id, created_by, name, \'/\' || id || \'/\'
            FROM drive_folders
            WHERE workspace_id = :root_workspace_id
              AND parent_id IS NULL
              AND trashed_at IS NULL
            UNION ALL
            SELECT child.id, child.parent_id, child.created_by, child.name,
                   visible_folders.path || child.id || \'/\'
            FROM drive_folders child
            INNER JOIN visible_folders ON child.parent_id = visible_folders.id
            WHERE child.workspace_id = :child_workspace_id
              AND child.trashed_at IS NULL
              AND instr(visible_folders.path, \'/\' || child.id || \'/\') = 0
        )
        SELECT vf.id, vf.name, creator.display_name AS owner_name
        FROM visible_folders vf
        INNER JOIN users creator ON creator.id = vf.created_by
        WHERE vf.created_by = :folder_user_id AND vf.name LIKE :folder_query COLLATE NOCASE
        ORDER BY vf.name COLLATE NOCASE ASC, vf.id ASC
        LIMIT 100
    ');

    $folderStatement->execute([
        ':root_workspace_id' => $workspaceId,
        ':child_workspace_id' => $workspaceId,
        ':folder_query' => $likeQuery,
        ':folder_user_id' => $userId,
    ]);

    $folders = $folderStatement->fetchAll(PDO::FETCH_ASSOC);

    foreach ($folders as &$folder) {
        $folder['id'] = (int) $folder['id'];
        $folder['owner_name'] = (string) ($folder['owner_name'] ?? '');
    }

    unset($folder);

    /*
     * Search accessible files. The user must hold an effective, non-expired
     * permission and the current wrapped key for every returned file.
     */
    $fileStatement = $pdo->prepare('
        WITH RECURSIVE visible_folders (id, parent_id, path) AS (
            SELECT id, parent_id, \'/\' || id || \'/\'
            FROM drive_folders
            WHERE workspace_id = :root_workspace_id
              AND parent_id IS NULL
              AND trashed_at IS NULL
            UNION ALL
            SELECT child.id, child.parent_id, visible_folders.path || child.id || \'/\'
            FROM drive_folders child
            INNER JOIN visible_folders ON child.parent_id = visible_folders.id
            WHERE child.workspace_id = :child_workspace_id
              AND child.trashed_at IS NULL
              AND instr(visible_folders.path, \'/\' || child.id || \'/\') = 0
        )
        SELECT df.id, df.folder_id, df.original_name AS name, df.mime_type,
               owner.display_name AS owner_name
        FROM drive_files df
        INNER JOIN drive_effective_access dfa
            ON dfa.file_id = df.id AND dfa.user_id = :access_user_id
        INNER JOIN drive_file_keys dfk
            ON dfk.file_id = df.id
           AND dfk.user_id = :key_user_id
           AND dfk.key_version = df.key_version
        INNER JOIN users owner ON owner.id = df.uploaded_by
        LEFT JOIN visible_folders vf ON vf.id = df.folder_id
        WHERE df.workspace_id = :file_workspace_id
          AND df.trashed_at IS NULL
          AND (df.folder_id IS NULL OR vf.id IS NOT NULL)
           AND df.original_name LIKE :file_query COLLATE NOCASE
        ORDER BY df.original_name COLLATE NOCASE ASC, df.id ASC
        LIMIT 100
    ');

    $fileStatement->execute([
        ':root_workspace_id' => $workspaceId,
        ':child_workspace_id' => $workspaceId,
        ':access_user_id' => $userId,
        ':key_user_id' => $userId,
        ':file_workspace_id' => $workspaceId,
        ':file_query' => $likeQuery,
    ]);

    $files = $fileStatement->fetchAll(PDO::FETCH_ASSOC);

    foreach ($files as &$file) {
        $file['id'] = (int) $file['id'];
        $file['folder_id'] = $file['folder_id'] !== null
            ? (int) $file['folder_id']
            : null;
        $file['mime_type'] = $file['mime_type'] !== null
            ? (string) $file['mime_type']
            : null;
        $file['owner_name'] = (string) ($file['owner_name'] ?? '');
    }

    unset($file);

    return [
        'folders' => $folders,
        'files' => $files,
    ];
}

/** Folder access is owner-only: Drive has no folder grants. File shares grant no folder metadata. */
function drive_accessible_folder(
    int $workspaceId,
    int $userId,
    int $folderId
): ?array {
    $pdo = db();

    $statement = $pdo->prepare('
        WITH RECURSIVE visible_folders (id, parent_id, created_by, name, path) AS (
            SELECT id, parent_id, created_by, name, \'/\' || id || \'/\'
            FROM drive_folders
            WHERE workspace_id = :root_workspace_id
              AND parent_id IS NULL
              AND trashed_at IS NULL
            UNION ALL
            SELECT child.id, child.parent_id, child.created_by, child.name, visible_folders.path || child.id || \'/\'
            FROM drive_folders child
            INNER JOIN visible_folders ON child.parent_id = visible_folders.id
            WHERE child.workspace_id = :child_workspace_id
              AND child.trashed_at IS NULL
              AND instr(visible_folders.path, \'/\' || child.id || \'/\') = 0
        )
        SELECT vf.id, vf.name, creator.display_name AS owner_name
        FROM visible_folders vf
        INNER JOIN users creator ON creator.id = vf.created_by
        WHERE vf.id = :folder_id AND vf.created_by = :user_id
        LIMIT 1
    ');

    $statement->execute([
        ':root_workspace_id' => $workspaceId,
        ':child_workspace_id' => $workspaceId,
        ':folder_id' => $folderId,
        ':user_id' => $userId,
    ]);

    $folder = $statement->fetch(PDO::FETCH_ASSOC);

    if ($folder === false) {
        return null;
    }

    return [
        'type' => 'drive_folder',
        'id' => (int) $folder['id'],
        'title' => (string) $folder['name'],
        'subtitle' => (string) ($folder['owner_name'] ?? ''),
        'url' => '/drive/',
    ];
}

