<?php

declare(strict_types=1);

require_once __DIR__ . '/../database.php';

/*
 * Per-Workspace Drive storage ceiling.
 *
 * 1 GiB = 1073741824 bytes. This number is used everywhere so the accounting
 * and the migration never drift apart.
 */
const ALLIANCES_WORKSPACE_STORAGE_LIMIT_BYTES = 1073741824;

class DriveQuotaExceededException extends RuntimeException
{
    public function __construct(int $usedBytes, int $incomingBytes, int $limitBytes)
    {
        parent::__construct(
            sprintf(
                'Workspace Drive quota exceeded: %d bytes already used, '
                . '%d additional requested, %d byte limit.',
                $usedBytes,
                $incomingBytes,
                $limitBytes
            )
        );
    }
}

/*
 * Bytes of encrypted storage physically retained for a Workspace.
 *
 * This mirrors public/actions/drive/storage-usage.php byte-for-byte: version 1
 * can share its storage_id with drive_files, so storage is grouped by
 * storage_id before summing to avoid double-counting. Trashed blobs are still
 * counted while their bytes remain on disk.
 */
function workspace_storage_used(PDO $pdo, int $workspaceId): int
{
    $statement = $pdo->prepare(
        '
        SELECT
            COALESCE(SUM(size), 0) AS used_bytes
        FROM (
            SELECT
                storage_id,
                MAX(encrypted_size) AS size
            FROM (
                SELECT
                    storage_id,
                    encrypted_size
                FROM drive_files
                WHERE workspace_id = :workspace_id

                UNION ALL

                SELECT
                    v.storage_id,
                    v.encrypted_size
                FROM drive_file_versions AS v
                INNER JOIN drive_files AS f
                    ON f.id = v.file_id
                WHERE f.workspace_id = :workspace_id
            ) AS retained_storage
            GROUP BY storage_id
        ) AS distinct_storage
        '
    );

    $statement->execute([
        ':workspace_id' => $workspaceId,
    ]);

    return (int) ($statement->fetchColumn() ?: 0);
}

function workspace_storage_limit(PDO $pdo, int $workspaceId): int
{
    try {
        $statement = $pdo->prepare(
            'SELECT storage_limit_bytes
             FROM workspace_quotas
             WHERE workspace_id = ?
             LIMIT 1'
        );

        $statement->execute([$workspaceId]);
        $limit = $statement->fetchColumn();

        if ($limit !== false && $limit !== null) {
            return (int) $limit;
        }
    } catch (Throwable $error) {
        /*
         * workspace_quotas is added by an additive migration that may not have
         * been applied yet. Fall back to the standard 1 GiB default ceiling.
         */
    }

    return ALLIANCES_WORKSPACE_STORAGE_LIMIT_BYTES;
}

function workspace_quota_assert_capacity(
    PDO $pdo,
    int $workspaceId,
    int $incomingBytes
): void {
    if ($incomingBytes <= 0) {
        return;
    }

    $limit = workspace_storage_limit($pdo, $workspaceId);

    if ($incomingBytes > $limit) {
        throw new DriveQuotaExceededException(0, $incomingBytes, $limit);
    }

    $used = workspace_storage_used($pdo, $workspaceId);

    if ($used > $limit - $incomingBytes) {
        throw new DriveQuotaExceededException($used, $incomingBytes, $limit);
    }
}

/*
 * Authoritative quota gate to be called immediately after beginTransaction().
 *
 * SQLite is a single-writer database and a deferred transaction does not take
 * the write lock until its first write statement. Performing a no-op UPDATE
 * against the Workspace's quota row forces the RESERVED lock to be acquired
 * now, so two concurrent uploads/saves cannot both observe "usage is fine"
 * and then both commit past the ceiling.
 */
function workspace_quota_lock_and_assert(
    PDO $pdo,
    int $workspaceId,
    int $incomingBytes
): void {
    try {
        $lock = $pdo->prepare(
            'UPDATE workspace_quotas
             SET storage_limit_bytes = storage_limit_bytes
             WHERE workspace_id = ?'
        );

        $lock->execute([$workspaceId]);
    } catch (Throwable $error) {
        /*
         * The quota table may not exist before the migration runs. Enforcement
         * continues below using the default ceiling.
         */
    }

    workspace_quota_assert_capacity($pdo, $workspaceId, $incomingBytes);
}