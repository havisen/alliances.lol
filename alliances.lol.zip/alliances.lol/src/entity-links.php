<?php

declare(strict_types=1);

function alliances_team_url(int $teamId): string
{
    return '/team.php?id=' . max(0, $teamId);
}

function alliances_profile_url(int $userId): string
{
    return '/profile/?id=' . max(0, $userId);
}

function alliances_team_link(
    int $teamId,
    string $teamName,
    string $className = 'team-link'
): string {
    $teamName = trim($teamName);

    if ($teamId <= 0 || $teamName === '') {
        return htmlspecialchars(
            $teamName !== '' ? $teamName : 'Unknown team',
            ENT_QUOTES,
            'UTF-8'
        );
    }

    return '<a href="'
        . htmlspecialchars(alliances_team_url($teamId), ENT_QUOTES, 'UTF-8')
        . '" class="'
        . htmlspecialchars($className, ENT_QUOTES, 'UTF-8')
        . '">'
        . htmlspecialchars($teamName, ENT_QUOTES, 'UTF-8')
        . '</a>';
}

function alliances_profile_link(
    int $userId,
    string $displayName,
    string $className = 'profile-link'
): string {
    $displayName = trim($displayName);

    if ($userId <= 0 || $displayName === '') {
        return htmlspecialchars(
            $displayName !== '' ? $displayName : 'Unknown user',
            ENT_QUOTES,
            'UTF-8'
        );
    }

    return '<a href="'
        . htmlspecialchars(alliances_profile_url($userId), ENT_QUOTES, 'UTF-8')
        . '" class="'
        . htmlspecialchars($className, ENT_QUOTES, 'UTF-8')
        . '">'
        . htmlspecialchars($displayName, ENT_QUOTES, 'UTF-8')
        . '</a>';
}
