<?php

declare(strict_types=1);

/**
 * Load the encrypted Key Vault belonging to a user.
 *
 * The server never decrypts the Key Vault.
 * encrypted_vault contains the complete portable
 * Alliances Key Vault envelope.
 */
function load_key_vault(int $userId): ?array
{
    $connection = db();

    $statement = $connection->prepare(
        'SELECT
            id,
            user_id,
            format_version,
            encrypted_vault,
            created_at,
            updated_at
         FROM key_vaults
         WHERE user_id = ?
         LIMIT 1'
    );

    $statement->execute([$userId]);

    $vault = $statement->fetch();

    return $vault ?: null;
}


/**
 * Check whether a user already has a Key Vault.
 */
function key_vault_exists(int $userId): bool
{
    $connection = db();

    $statement = $connection->prepare(
        'SELECT 1
         FROM key_vaults
         WHERE user_id = ?
         LIMIT 1'
    );

    $statement->execute([$userId]);

    return $statement->fetchColumn() !== false;
}


/**
 * Create a new encrypted Key Vault.
 *
 * $encryptedVault must already be encrypted by
 * the user's browser before it reaches PHP.
 */
function create_key_vault(
    int $userId,
    string $encryptedVault,
    int $formatVersion = 1
): bool {
    $connection = db();

    $statement = $connection->prepare(
        'INSERT INTO key_vaults (
            user_id,
            format_version,
            encrypted_vault,
            created_at,
            updated_at
         )
         VALUES (
            ?,
            ?,
            ?,
            CURRENT_TIMESTAMP,
            CURRENT_TIMESTAMP
         )'
    );

    return $statement->execute([
        $userId,
        $formatVersion,
        $encryptedVault,
    ]);
}


/**
 * Replace an existing encrypted Key Vault.
 *
 * PHP does not inspect or decrypt the vault contents.
 */
function update_key_vault(
    int $userId,
    string $encryptedVault,
    int $formatVersion = 1
): bool {
    $connection = db();

    $statement = $connection->prepare(
        'UPDATE key_vaults
         SET
            format_version = ?,
            encrypted_vault = ?,
            updated_at = CURRENT_TIMESTAMP
         WHERE user_id = ?'
    );

    return $statement->execute([
        $formatVersion,
        $encryptedVault,
        $userId,
    ]);
}