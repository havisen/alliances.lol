<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Messaging
|--------------------------------------------------------------------------
|
| Shared database helpers for Alliances Messaging.
|
| These functions deal only with conversation metadata, membership and
| encrypted data. Plaintext messages and raw conversation keys must never
| be passed to this file.
|
*/

/*
|--------------------------------------------------------------------------
| User conversations
|--------------------------------------------------------------------------
*/

function messaging_conversations_for_user(
    int $workspaceId,
    int $userId
): array {
    $connection = db();

    $statement = $connection->prepare(
        'SELECT
            c.id,
            c.workspace_id,
            c.created_by,
            c.type,

            CASE
                WHEN c.type = \'direct\' THEN (
                    SELECT other_user.display_name
                    FROM conversation_members other_cm
                    INNER JOIN users other_user
                        ON other_user.id = other_cm.user_id
                    WHERE
                        other_cm.conversation_id = c.id
                        AND other_cm.user_id <> ?
                    LIMIT 1
                )
                ELSE c.name
            END AS name,

            CASE
                WHEN c.type = \'direct\' THEN (
                    SELECT other_user.avatar_path
                    FROM conversation_members avatar_cm
                    INNER JOIN users other_user
                        ON other_user.id = avatar_cm.user_id
                    WHERE
                        avatar_cm.conversation_id = c.id
                        AND avatar_cm.user_id <> ?
                    LIMIT 1
                )
                ELSE NULL
            END AS other_avatar_path,

            c.description,
            c.key_version,
            c.created_at,
            c.updated_at,
            cm.role
         FROM conversations c
         INNER JOIN conversation_members cm
            ON cm.conversation_id = c.id
         WHERE
            c.workspace_id = ?
            AND cm.user_id = ?
         ORDER BY
            c.updated_at DESC,
            c.id DESC'
    );

    $statement->execute([
        $userId,
        $userId,
        $workspaceId,
        $userId,
    ]);

    return $statement->fetchAll();
}

/*
|--------------------------------------------------------------------------
| Single conversation
|--------------------------------------------------------------------------
*/

function messaging_conversation(
    int $conversationId,
    int $userId
): ?array {
    $connection = db();

    $statement = $connection->prepare(
        'SELECT
            c.id,
            c.workspace_id,
            c.created_by,
            c.type,

            CASE
                WHEN c.type = \'direct\' THEN (
                    SELECT other_user.display_name
                    FROM conversation_members other_cm
                    INNER JOIN users other_user
                        ON other_user.id = other_cm.user_id
                    WHERE
                        other_cm.conversation_id = c.id
                        AND other_cm.user_id <> ?
                    LIMIT 1
                )
                ELSE c.name
            END AS name,

            c.description,
            c.key_version,
            c.created_at,
            c.updated_at,
            cm.role
         FROM conversations c
         INNER JOIN conversation_members cm
            ON cm.conversation_id = c.id
         WHERE
            c.id = ?
            AND cm.user_id = ?
         LIMIT 1'
    );

    $statement->execute([
        $userId,
        $conversationId,
        $userId,
    ]);

    $conversation =
        $statement->fetch();

    return $conversation ?: null;
}

/*
|--------------------------------------------------------------------------
| Membership check
|--------------------------------------------------------------------------
*/

function messaging_user_is_member(
    int $conversationId,
    int $userId
): bool {
    $connection = db();

    $statement = $connection->prepare(
        'SELECT 1
         FROM conversation_members
         WHERE
            conversation_id = ?
            AND user_id = ?
         LIMIT 1'
    );

    $statement->execute([
        $conversationId,
        $userId,
    ]);

    return $statement->fetchColumn() !== false;
}

/*
|--------------------------------------------------------------------------
| Conversation members
|--------------------------------------------------------------------------
*/

function messaging_conversation_members(
    int $conversationId
): array {
    $connection = db();

    $statement = $connection->prepare(
        'SELECT
            cm.user_id,
            cm.role,
            cm.joined_at,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path
         FROM conversation_members cm
         INNER JOIN users u
            ON u.id = cm.user_id
         WHERE cm.conversation_id = ?
         ORDER BY
            CASE cm.role
                WHEN \'owner\' THEN 1
                WHEN \'admin\' THEN 2
                ELSE 3
            END,
            u.display_name ASC'
    );

    $statement->execute([
        $conversationId,
    ]);

    return $statement->fetchAll();
}

/*
|--------------------------------------------------------------------------
| Encrypted messages
|--------------------------------------------------------------------------
*/

function messaging_messages(
    int $conversationId,
    int $limit = 100
): array {
    $connection = db();

    $limit = max(
        1,
        min($limit, 200)
    );

    $statement = $connection->prepare(
        'SELECT
            m.id,
            m.conversation_id,
            m.sender_id,
            m.key_version,
            m.ciphertext,
            m.iv,
            m.created_at,
            m.edited_at,
            u.display_name AS sender_name,
            u.avatar_path AS sender_avatar
         FROM messages m
         INNER JOIN users u
            ON u.id = m.sender_id
         WHERE m.conversation_id = ?
         ORDER BY m.id DESC
         LIMIT ' . $limit
    );

    $statement->execute([
        $conversationId,
    ]);

    $messages =
        $statement->fetchAll();

    /*
     * Query newest-first for efficiency, then return
     * chronological order to the browser.
     */

    return array_reverse(
        $messages
    );
}
/*
|--------------------------------------------------------------------------
| Create conversation
|--------------------------------------------------------------------------
|
| Creates the conversation metadata and membership records.
|
| Conversation encryption keys are NOT generated here. They are generated
| in the browser and stored separately as encrypted key envelopes.
|
*/

function messaging_create_conversation(
    int $workspaceId,
    int $createdBy,
    string $type,
    string $name,
    ?string $description,
    array $memberIds
): int {
    $connection = db();

    $name = trim($name);

    $description =
        $description !== null
            ? trim($description)
            : null;

    if ($name === '') {
        throw new InvalidArgumentException(
            'Conversation name is required.'
        );
    }

    if (
        $type !== 'group'
        && $type !== 'channel'
    ) {
        throw new InvalidArgumentException(
            'Invalid conversation type.'
        );
    }

/*
|--------------------------------------------------------------------------
| Available workspace members
|--------------------------------------------------------------------------
|
| Returns users who belong to the current workspace so they can be
| selected when creating a group chat or channel.
|
*/

function messaging_workspace_members(
    int $workspaceId
): array {
    $connection = db();

    $statement =
        $connection->prepare(
            'SELECT
                u.id,
                u.display_name,
                u.email,
                u.job_title,
                u.avatar_path,
                wm.role AS workspace_role
             FROM workspace_members wm
             INNER JOIN users u
                ON u.id = wm.user_id
             WHERE wm.workspace_id = ?
             ORDER BY
                u.display_name ASC,
                u.email ASC'
        );

    $statement->execute([
        $workspaceId,
    ]);

    return $statement->fetchAll();
}

    /*
     * The creator must always be a member.
     */

    $memberIds[] = $createdBy;

    $memberIds = array_values(
        array_unique(
            array_map(
                'intval',
                $memberIds
            )
        )
    );

    /*
     * Verify that every requested member belongs
     * to this workspace.
     */

    $memberStatement =
        $connection->prepare(
            'SELECT 1
             FROM workspace_members
             WHERE
                workspace_id = ?
                AND user_id = ?
             LIMIT 1'
        );

    foreach ($memberIds as $memberId) {
        if ($memberId <= 0) {
            throw new InvalidArgumentException(
                'Invalid conversation member.'
            );
        }

        $memberStatement->execute([
            $workspaceId,
            $memberId,
        ]);

        if (
            $memberStatement->fetchColumn()
            === false
        ) {
            throw new InvalidArgumentException(
                'A selected user does not belong to this workspace.'
            );
        }
    }

    /*
     * Create the conversation and all memberships
     * atomically.
     */

    $connection->beginTransaction();

    try {
        $statement =
            $connection->prepare(
                'INSERT INTO conversations (
                    workspace_id,
                    created_by,
                    type,
                    name,
                    description,
                    key_version,
                    created_at,
                    updated_at
                 )
                 VALUES (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    1,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                 )'
            );

        $statement->execute([
            $workspaceId,
            $createdBy,
            $type,
            $name,
            $description !== ''
                ? $description
                : null,
        ]);

        $conversationId =
            (int) $connection->lastInsertId();

        $membershipStatement =
            $connection->prepare(
                'INSERT INTO conversation_members (
                    conversation_id,
                    user_id,
                    role,
                    joined_at
                 )
                 VALUES (
                    ?,
                    ?,
                    ?,
                    CURRENT_TIMESTAMP
                 )'
            );

        foreach ($memberIds as $memberId) {
            $role =
                $memberId === $createdBy
                    ? 'owner'
                    : 'member';

            $membershipStatement->execute([
                $conversationId,
                $memberId,
                $role,
            ]);
        }

        $connection->commit();

        return $conversationId;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}