<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Messaging public keys
|--------------------------------------------------------------------------
|
| Public OpenPGP identities used for Messaging key distribution.
|
| This file must never receive, store or return a user's private key.
|
*/

/*
|--------------------------------------------------------------------------
| Public key for one user
|--------------------------------------------------------------------------
*/

function messaging_public_key_for_user(
    int $userId
): ?array {
    $connection = db();

    $statement =
        $connection->prepare(
            'SELECT
                user_id,
                key_type,
                format_version,
                public_key,
                fingerprint,
                created_at,
                updated_at
             FROM user_public_keys
             WHERE user_id = ?
             LIMIT 1'
        );

    $statement->execute([
        $userId,
    ]);

    $key = $statement->fetch();

    return $key ?: null;
}

/*
|--------------------------------------------------------------------------
| Public keys for multiple users
|--------------------------------------------------------------------------
*/

function messaging_public_keys_for_users(
    array $userIds
): array {
    $userIds = array_values(
        array_unique(
            array_filter(
                array_map(
                    'intval',
                    $userIds
                ),
                static fn (int $userId): bool =>
                    $userId > 0
            )
        )
    );

    if ($userIds === []) {
        return [];
    }

    $connection = db();

    $placeholders =
        implode(
            ',',
            array_fill(
                0,
                count($userIds),
                '?'
            )
        );

    $statement =
        $connection->prepare(
            'SELECT
                user_id,
                key_type,
                format_version,
                public_key,
                fingerprint,
                created_at,
                updated_at
             FROM user_public_keys
             WHERE user_id IN ('
                . $placeholders
                . ')'
        );

    $statement->execute(
        $userIds
    );

    $keys = [];

    foreach ($statement->fetchAll() as $key) {
        $keys[(int) $key['user_id']] =
            $key;
    }

    return $keys;
}

/*
|--------------------------------------------------------------------------
| Publish first public key
|--------------------------------------------------------------------------
|
| This deliberately uses INSERT rather than UPSERT.
|
| Once a user has published an identity, replacing that identity must go
| through a separate explicit key-change flow.
|
*/

function messaging_publish_public_key(
    int $userId,
    string $publicKey,
    string $fingerprint
): bool {
    $publicKey = trim(
        $publicKey
    );

    $fingerprint = strtolower(
        trim($fingerprint)
    );

    if (
        $userId <= 0
        || $publicKey === ''
        || $fingerprint === ''
    ) {
        throw new InvalidArgumentException(
            'Invalid public key.'
        );
    }

    $connection = db();

    $statement =
        $connection->prepare(
            'INSERT INTO user_public_keys (
                user_id,
                key_type,
                format_version,
                public_key,
                fingerprint,
                created_at,
                updated_at
             )
             VALUES (
                ?,
                \'openpgp\',
                1,
                ?,
                ?,
                CURRENT_TIMESTAMP,
                CURRENT_TIMESTAMP
             )'
        );

    return $statement->execute([
        $userId,
        $publicKey,
        $fingerprint,
    ]);
}