<?php

declare(strict_types=1);

require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/command-palette.php';

function render_navigation(array $user): void
{
    render_theme_bootstrap($user);

    $access = workspace_access((int) $user['id']);
    $notificationUnreadCount = $access !== null
        ? unread_notification_count((int) $access['workspace_id'], (int) $user['id'])
        : 0;

    /*
    |--------------------------------------------------------------------------
    | Administration access
    |--------------------------------------------------------------------------
    */

    $showAdministration =
        $access !== null
        && (
            !empty($access['is_admin'])
            || !empty($access['is_team_lead'])
        );

    $showTemplates =
        $access !== null
        && !empty($access['is_admin']);

    /*
    |--------------------------------------------------------------------------
    | Current location
    |--------------------------------------------------------------------------
    |
    | We use the full URL path instead of only basename(PHP_SELF).
    |
    | This is important because both:
    |
    |   /index.php
    |   /tasks/index.php
    |
    | are named index.php.
    |
    */

    $currentPath = parse_url(
        $_SERVER['REQUEST_URI'] ?? '/',
        PHP_URL_PATH
    );

    $currentPath = $currentPath ?: '/';

    /*
     * Normalize trailing slashes so:
     *
     * /tasks
     * /tasks/
     *
     * are treated as the same location.
     */
    if ($currentPath !== '/') {
        $currentPath = rtrim($currentPath, '/');
    }

    /*
    |--------------------------------------------------------------------------
    | Active navigation states
    |--------------------------------------------------------------------------
    */

    $isHomeActive =
        $currentPath === '/'
        || $currentPath === '/index.php';

    $isProjectsActive =
        $currentPath === '/projects'
        || $currentPath === '/projects/index.php'
        || str_starts_with(
            $currentPath,
            '/projects/'
        );

    $isTasksActive =
        $currentPath === '/tasks'
        || $currentPath === '/tasks/index.php'
        || str_starts_with(
            $currentPath,
            '/tasks/'
        );

    $isCalendarActive =
        $currentPath === '/calendar.php';

    $isDriveActive =
        $currentPath === '/drive'
        || $currentPath === '/drive/index.php'
        || str_starts_with(
            $currentPath,
            '/drive/'
        );

    $isWorkspaceOverviewActive =
        $currentPath === '/workspace'
        || $currentPath === '/workspace/index.php';

    $isKeyVaultActive =
    $currentPath === '/key-vault'
    || $currentPath === '/key-vault/index.php'
    || str_starts_with(
        $currentPath,
        '/key-vault/'
    );

    $isSettingsActive =
        $currentPath === '/settings'
        || $currentPath === '/settings/index.php'
        || str_starts_with(
            $currentPath,
            '/settings/'
        );

    $isNotificationsActive =
        $currentPath === '/notifications'
        || $currentPath === '/notifications/index.php'
        || str_starts_with(
            $currentPath,
            '/notifications/'
        );

    $isMessagingActive =
        $currentPath === '/messaging'
        || $currentPath === '/messaging/index.php'
        || str_starts_with(
            $currentPath,
            '/messaging/'
        );

    $isAdminActive =
        $currentPath === '/admin'
        || $currentPath === '/admin/admin.php'
        || str_starts_with(
            $currentPath,
            '/admin/'
        );

    $isTemplatesActive =
        $currentPath === '/templates'
        || $currentPath === '/templates/index.php'
        || str_starts_with(
            $currentPath,
            '/templates/'
        );

    /*
    |--------------------------------------------------------------------------
    | User display information
    |--------------------------------------------------------------------------
    */

    $displayName = trim(
        (string) ($user['display_name'] ?? '')
    );

    $avatarPath = $user['avatar_path'] ?? null;

    $initial = '?';

    if ($displayName !== '') {
        $initial = strtoupper(
            substr($displayName, 0, 1)
        );
    }

    ?>

    <aside class="app-sidebar">

        <!-- =========================================================
             BRAND
             ========================================================= -->

        <div class="sidebar-header">

            <a
                href="/index.php"
                class="sidebar-brand"
            >
                <span class="sidebar-brand-mark">
                    A
                </span>

                <span class="sidebar-brand-name">
                    Alliances
                </span>
            </a>

        </div>


        <!-- =========================================================
             NAVIGATION
             ========================================================= -->

        <nav class="sidebar-navigation">


            <!-- =====================================================
                 WORKSPACE
                 ===================================================== -->

            <div class="sidebar-section">

                <span class="sidebar-section-title">
                    Workspace
                </span>


                <!-- Home -->

                <a
                    href="/index.php"
                    class="sidebar-link <?= $isHomeActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <path d="M3 10.5 12 3l9 7.5"></path>
                            <path d="M5 9.5V21h14V9.5"></path>
                            <path d="M9 21v-7h6v7"></path>
                        </svg>
                    </span>

                    <span>
                        Home
                    </span>
                </a>

                <a
                    href="/workspace/"
                    class="sidebar-link <?= $isWorkspaceOverviewActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <rect x="3" y="4" width="18" height="16" rx="2"></rect>
                            <path d="M8 9h8"></path>
                            <path d="M8 13h5"></path>
                        </svg>
                    </span>

                    <span>
                        Workspace Overview
                    </span>
                </a>

                <!-- Messaging -->

                <a
                    href="/messaging/"
                    class="sidebar-link <?= $isMessagingActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"></path>
                            <path d="M8 9h8"></path>
                            <path d="M8 13h5"></path>
                        </svg>
                    </span>

                    <span>
                        Messaging
                    </span>
                </a>

                <a
                    href="/notifications/"
                    class="sidebar-link <?= $isNotificationsActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"></path>
                            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                        </svg>
                    </span>

                    <span>
                        Notifications
                        <?php if ($notificationUnreadCount > 0): ?>
                            <strong class="sidebar-count">
                                <?= $notificationUnreadCount > 99
                                    ? '99+'
                                    : (int) $notificationUnreadCount
                                ?>
                            </strong>
                        <?php endif; ?>
                    </span>
                </a>

            </div>


            <!-- =====================================================
                 WORK
                 ===================================================== -->

            <div class="sidebar-section">

                <span class="sidebar-section-title">
                    Work
                </span>


                <!-- Projects -->

                <a
                    href="/projects/"
                    class="sidebar-link <?= $isProjectsActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <rect x="2" y="7" width="20" height="14" rx="2"></rect>
                            <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                        </svg>
                    </span>

                    <span>
                        Projects
                    </span>
                </a>

                <?php if ($showTemplates): ?>

                    <!-- Templates -->

                    <a
                        href="/templates/index.php"
                        class="sidebar-link <?= $isTemplatesActive
                            ? 'is-active'
                            : '' ?>"
                    >
                        <span
                            class="sidebar-icon"
                            aria-hidden="true"
                        >
                            <svg viewBox="0 0 24 24">
                                <path d="M9 3H5a2 2 0 0 0-2 2v4h6V3Z"></path>
                                <path d="M15 3h4a2 2 0 0 1 2 2v4h-6V3Z"></path>
                                <path d="M9 15H3v4a2 2 0 0 0 2 2h4v-6Z"></path>
                                <path d="M15 15h6v4a2 2 0 0 1-2 2h-4v-6Z"></path>
                            </svg>
                        </span>

                        <span>
                            Templates
                        </span>
                    </a>

                <?php endif; ?>

                <!-- Tasks -->

                <a
                    href="/tasks/"
                    class="sidebar-link <?= $isTasksActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <path d="m9 11 2 2 4-4"></path>
                            <path d="M5 4h14a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z"></path>
                        </svg>
                    </span>

                    <span>
                        Tasks
                    </span>
                </a>

                <!-- Calendar -->

                <a
                    href="/calendar.php"
                    class="sidebar-link <?= $isCalendarActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <path d="M8 2v4"></path>
                            <path d="M16 2v4"></path>

                            <rect
                                x="3"
                                y="5"
                                width="18"
                                height="16"
                                rx="2"
                            ></rect>

                            <path d="M3 10h18"></path>
                        </svg>
                    </span>

                    <span>
                        Calendar
                    </span>
                </a>

            </div>


            <!-- =====================================================
                 VAULT
                 ===================================================== -->

            <div class="sidebar-section">

                <span class="sidebar-section-title">
                    Vault
                </span>


                <!-- Key Vault -->

                <a
                    href="/key-vault/"
                    class="sidebar-link <?= $isKeyVaultActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <rect
                                x="3"
                                y="3"
                                width="18"
                                height="18"
                                rx="3"
                            ></rect>

                            <circle
                                cx="12"
                                cy="12"
                                r="4"
                            ></circle>

                            <path d="M12 8v2"></path>
                            <path d="M12 14v2"></path>
                            <path d="M8 12h2"></path>
                            <path d="M14 12h2"></path>
                        </svg>
                    </span>

                    <span>
                        Key Vault
                    </span>
                </a>

                <!-- Drive -->

                <a
                    href="/drive/"
                    class="sidebar-link <?= $isDriveActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"></path>
                            <path d="M3 11h18"></path>
                        </svg>
                    </span>

                    <span>
                        Drive
                    </span>
                </a>

                <!-- Settings -->

                <a
                    href="/settings/"
                    class="sidebar-link <?= $isSettingsActive
                        ? 'is-active'
                        : '' ?>"
                >
                    <span
                        class="sidebar-icon"
                        aria-hidden="true"
                    >
                        <svg viewBox="0 0 24 24">
                            <circle cx="12" cy="12" r="3"></circle>
                            <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.04.04a2 2 0 0 1-2.83 2.83l-.04-.04A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6l-.03.04a2 2 0 0 1-3.94 0L10 20a1.7 1.7 0 0 0-1-.6 1.7 1.7 0 0 0-1.88.34l-.04.04a2 2 0 0 1-2.83-2.83l.04-.04A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1l-.04-.03a2 2 0 0 1 0-3.94L4 10a1.7 1.7 0 0 0 .6-1 1.7 1.7 0 0 0-.34-1.88l-.04-.04a2 2 0 0 1 2.83-2.83l.04.04A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6l.03-.04a2 2 0 0 1 3.94 0L14 4a1.7 1.7 0 0 0 1 .6 1.7 1.7 0 0 0 1.88-.34l.04-.04a2 2 0 0 1 2.83 2.83l-.04.04A1.7 1.7 0 0 0 19.4 9c.24.37.43.71.6 1l.04.03a2 2 0 0 1 0 3.94L20 14a1.7 1.7 0 0 0-.6 1Z"></path>
                        </svg>
                    </span>

                    <span>
                        Settings
                    </span>
                </a>

            </div>


            <!-- =====================================================
                 MANAGEMENT
                 ===================================================== -->

            <?php if ($showAdministration): ?>

                <div class="sidebar-section">

                    <span class="sidebar-section-title">
                        Management
                    </span>


                    <!-- Administration -->

                    <a
                        href="/admin/admin.php"
                        class="sidebar-link <?= $isAdminActive
                            ? 'is-active'
                            : '' ?>"
                    >
                        <span
                            class="sidebar-icon"
                            aria-hidden="true"
                        >
                            <svg viewBox="0 0 24 24">
                                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                        </span>

                        <span>
                            Administration
                        </span>
                    </a>

                </div>

            <?php endif; ?>

        </nav>


        <!-- =========================================================
             USER
             ========================================================= -->

        <div class="sidebar-footer">


            <!-- Profile -->

            <a
                class="sidebar-profile"
                href="/profile/?id=<?= (int) $user['id'] ?>"
            >

<span
    class="sidebar-vault-status"
    id="sidebar-vault-status"
    title="Key Vault unlocked"
    aria-label="Key Vault unlocked"
    hidden
></span>

                <?php if (!empty($avatarPath)): ?>

                    <img
                        class="sidebar-profile-avatar"
                        src="<?= htmlspecialchars(
                            (string) $avatarPath,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        alt=""
                    >

                <?php else: ?>

                    <span
                        class="sidebar-profile-avatar sidebar-profile-placeholder"
                    >
                        <?= htmlspecialchars(
                            $initial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </span>

                <?php endif; ?>


                <span class="sidebar-profile-info">

                    <strong>
                        <?= htmlspecialchars(
                            $displayName !== ''
                                ? $displayName
                                : 'My profile',
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    </strong>

                    <small>
                        View profile
                    </small>

                </span>

            </a>


            <!-- Logout -->

            <a
                href="/logout.php"
                class="sidebar-logout"
                title="Log out"
            >
                <span
                    class="sidebar-icon"
                    aria-hidden="true"
                >
                    <svg viewBox="0 0 24 24">
                        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                        <path d="m16 17 5-5-5-5"></path>
                        <path d="M21 12H9"></path>
                    </svg>
                </span>

                <span>
                    Log out
                </span>
            </a>

        </div>

    </aside>

<script>
(function () {
    'use strict';

    const statusElement =
        document.getElementById(
            'sidebar-vault-status'
        );

    if (!statusElement) {
        return;
    }

    const VAULT_SESSION_DATA_KEY =
        'alliances.key-vault.session-data';

    const VAULT_SESSION_KEY_KEY =
        'alliances.key-vault.session-key';

    const VAULT_SESSION_EXPIRES_KEY =
        'alliances.key-vault.expires-at';

        const VAULT_SESSION_USER_KEY =
    'alliances.key-vault.user-id';

const currentUserId =
    <?= json_encode(
        (string) $user['id'],
        JSON_HEX_TAG
        | JSON_HEX_AMP
        | JSON_HEX_APOS
        | JSON_HEX_QUOT
    ) ?>;

    function updateVaultStatus() {
        const sessionData =
            localStorage.getItem(
                VAULT_SESSION_DATA_KEY
            );

        const sessionKey =
            localStorage.getItem(
                VAULT_SESSION_KEY_KEY
            );

        const expiresAt =
            Number(
                localStorage.getItem(
                    VAULT_SESSION_EXPIRES_KEY
                )
            );

                    const sessionUserId =
    localStorage.getItem(
        VAULT_SESSION_USER_KEY
    );

const sessionIsActive =
    Boolean(sessionData)
    && Boolean(sessionKey)
    && Number.isFinite(expiresAt)
    && expiresAt > Date.now()
    && sessionUserId === currentUserId;

        if (sessionIsActive) {
            statusElement.hidden = false;

            statusElement.title =
                'Key Vault unlocked';

            statusElement.setAttribute(
                'aria-label',
                'Key Vault unlocked'
            );

            return;
        }

        statusElement.hidden = true;

        /*
         * Clean up an expired or incomplete session.
         */
if (
    sessionData
    || sessionKey
    || Number.isFinite(expiresAt)
    || sessionUserId
) {
            localStorage.removeItem(
                VAULT_SESSION_DATA_KEY
            );

            localStorage.removeItem(
                VAULT_SESSION_KEY_KEY
            );

            localStorage.removeItem(
                VAULT_SESSION_EXPIRES_KEY
            );
            localStorage.removeItem(
    VAULT_SESSION_USER_KEY
);
        }
    }

    updateVaultStatus();

    /*
     * Update when another tab changes the session.
     */
    window.addEventListener(
        'storage',
        updateVaultStatus
    );

    /*
     * Update after navigating back to this tab/window.
     */
    window.addEventListener(
        'focus',
        updateVaultStatus
    );

    document.addEventListener(
        'visibilitychange',
        function () {
            if (!document.hidden) {
                updateVaultStatus();
            }
        }
    );
})();
</script>

<?php render_command_palette($user, $access, $showAdministration); ?>
                
    <?php
}
