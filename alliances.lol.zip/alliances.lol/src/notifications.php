<?php

declare(strict_types=1);

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/preferences.php';

function notification_category_for_type(string $type): string
{
    if (str_starts_with($type, 'message_')) {
        return 'messaging';
    }

    if (str_starts_with($type, 'task_')) {
        return 'tasks';
    }

    if (str_starts_with($type, 'calendar_')) {
        return 'calendar';
    }

    if (str_starts_with($type, 'team_')) {
        return 'teams';
    }

    if (str_starts_with($type, 'drive_')) {
        return 'drive';
    }

    if (str_starts_with($type, 'project_')) {
        return 'projects';
    }

    if (str_starts_with($type, 'account_') || str_starts_with($type, 'security_')) {
        return 'security';
    }

    return 'general';
}

function notification_category_is_preference_controlled(string $category): bool
{
    return in_array(
        $category,
        ['messaging', 'tasks', 'calendar', 'teams', 'drive', 'projects'],
        true
    );
}

function notification_safe_target_url(?string $targetUrl): ?string
{
    if ($targetUrl === null) {
        return null;
    }

    $targetUrl = trim($targetUrl);

    if ($targetUrl === '' || $targetUrl[0] !== '/') {
        return null;
    }

    if (str_starts_with($targetUrl, '//')) {
        return null;
    }

    return substr($targetUrl, 0, 500);
}

function create_notification(array $data): ?int
{
    $workspaceId = (int) ($data['workspace_id'] ?? 0);
    $recipientId = (int) ($data['user_id'] ?? 0);
    $type = trim((string) ($data['type'] ?? ''));
    $title = trim((string) ($data['title'] ?? ''));

    if ($workspaceId <= 0 || $recipientId <= 0 || $type === '' || $title === '') {
        return null;
    }

    $category = (string) ($data['category'] ?? notification_category_for_type($type));
    $category = $category !== '' ? $category : 'general';

    $connection = db();

    $memberStatement = $connection->prepare(
        'SELECT 1
         FROM users u
         INNER JOIN workspace_members wm
            ON wm.user_id = u.id
         WHERE u.id = ?
           AND u.account_status = ?
           AND wm.workspace_id = ?
         LIMIT 1'
    );

    $memberStatement->execute([
        $recipientId,
        'active',
        $workspaceId,
    ]);

    if ($memberStatement->fetchColumn() === false) {
        return null;
    }

    if (
        notification_category_is_preference_controlled($category)
        && !notification_enabled($recipientId, $category)
    ) {
        return null;
    }

    $actorUserId = isset($data['actor_user_id'])
        ? (int) $data['actor_user_id']
        : null;

    if ($actorUserId !== null && $actorUserId <= 0) {
        $actorUserId = null;
    }

    $body = isset($data['body'])
        ? trim((string) $data['body'])
        : null;

    if ($body === '') {
        $body = null;
    }

    $statement = $connection->prepare(
        'INSERT INTO notifications
            (
                workspace_id,
                user_id,
                actor_user_id,
                type,
                category,
                title,
                body,
                target_type,
                target_id,
                target_url
            )
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );

    $statement->execute([
        $workspaceId,
        $recipientId,
        $actorUserId,
        substr($type, 0, 80),
        substr($category, 0, 40),
        substr($title, 0, 200),
        $body !== null ? substr($body, 0, 500) : null,
        isset($data['target_type'])
            ? substr(trim((string) $data['target_type']), 0, 80)
            : null,
        isset($data['target_id']) ? (int) $data['target_id'] : null,
        notification_safe_target_url($data['target_url'] ?? null),
    ]);

    return (int) $connection->lastInsertId();
}

function create_notifications_for_users(array $recipientIds, array $data): void
{
    $recipientIds = array_values(array_unique(array_map('intval', $recipientIds)));
    $actorUserId = isset($data['actor_user_id']) ? (int) $data['actor_user_id'] : null;

    foreach ($recipientIds as $recipientId) {
        if ($recipientId <= 0 || ($actorUserId !== null && $recipientId === $actorUserId)) {
            continue;
        }

        $data['user_id'] = $recipientId;
        create_notification($data);
    }
}

/**
 * Create a bounded batch of Project notifications.
 *
 * Recipient discovery and Project authorization intentionally remain in the
 * Project domain layer. This helper only normalizes/deduplicates the supplied
 * IDs and caps fan-out so a single Project action cannot create an unbounded
 * notification batch. create_notification() still revalidates active workspace
 * membership and the recipient's Projects notification preference.
 */
function create_project_notifications_for_users(
    array $recipientIds,
    array $data,
    int $maxRecipients = 250
): void {
    $maxRecipients = max(1, min($maxRecipients, 500));

    $recipientIds = array_values(array_unique(array_filter(
        array_map('intval', $recipientIds),
        static fn (int $recipientId): bool => $recipientId > 0
    )));

    if (count($recipientIds) > $maxRecipients) {
        $recipientIds = array_slice($recipientIds, 0, $maxRecipients);
    }

    $data['category'] = 'projects';
    create_notifications_for_users($recipientIds, $data);
}

function notifications_for_user(
    int $workspaceId,
    int $userId,
    ?string $category = null,
    bool $unreadOnly = false,
    int $limit = 50,
    int $offset = 0
): array {
    $limit = max(1, min($limit, 50));
    $offset = max(0, $offset);

    $sql = 'SELECT
                n.*,
                actor.display_name AS actor_name
            FROM notifications n
            LEFT JOIN users actor
                ON actor.id = n.actor_user_id
            WHERE n.workspace_id = ?
              AND n.user_id = ?';

    $parameters = [$workspaceId, $userId];

    if ($category !== null && $category !== '') {
        $sql .= ' AND n.category = ?';
        $parameters[] = $category;
    }

    if ($unreadOnly) {
        $sql .= ' AND n.is_read = 0';
    }

    $sql .= ' ORDER BY n.created_at DESC, n.id DESC LIMIT ? OFFSET ?';
    $parameters[] = $limit;
    $parameters[] = $offset;

    $statement = db()->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}

function unread_notification_count(int $workspaceId, int $userId): int
{
    try {
        $statement = db()->prepare(
            'SELECT COUNT(*)
             FROM notifications
             WHERE workspace_id = ?
               AND user_id = ?
               AND is_read = 0'
        );

        $statement->execute([$workspaceId, $userId]);

        return (int) $statement->fetchColumn();
    } catch (Throwable $error) {
        return 0;
    }
}

function mark_notification_read(int $workspaceId, int $userId, int $notificationId): ?string
{
    $statement = db()->prepare(
        'SELECT target_url
         FROM notifications
         WHERE id = ?
           AND workspace_id = ?
           AND user_id = ?
         LIMIT 1'
    );

    $statement->execute([$notificationId, $workspaceId, $userId]);
    $notification = $statement->fetch();

    if (!$notification) {
        return null;
    }

    $update = db()->prepare(
        'UPDATE notifications
         SET is_read = 1,
             read_at = COALESCE(read_at, CURRENT_TIMESTAMP)
         WHERE id = ?
           AND workspace_id = ?
           AND user_id = ?'
    );

    $update->execute([$notificationId, $workspaceId, $userId]);

    return notification_safe_target_url($notification['target_url'] ?? null);
}

function mark_all_notifications_read(int $workspaceId, int $userId): void
{
    $statement = db()->prepare(
        'UPDATE notifications
         SET is_read = 1,
             read_at = COALESCE(read_at, CURRENT_TIMESTAMP)
         WHERE workspace_id = ?
           AND user_id = ?
           AND is_read = 0'
    );

    $statement->execute([$workspaceId, $userId]);
}
