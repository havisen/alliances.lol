<?php

declare(strict_types=1);

function preference_allowed_keys(): array
{
    return [
        'theme',
        'date_format',
        'time_format',
        'reduced_motion',
        'high_contrast',
        'interface_density',
        'notify_messaging',
        'notify_tasks',
        'notify_calendar',
        'notify_mentions',
        'notify_teams',
        'notify_drive',
        'notify_projects',
    ];
}

function preference_defaults(): array
{
    return [
        'theme' => 'system',
        'date_format' => 'dd_mm_yyyy',
        'time_format' => '24',
        'reduced_motion' => 'system',
        'high_contrast' => 'system',
        'interface_density' => 'comfortable',
        'notify_messaging' => '1',
        'notify_tasks' => '1',
        'notify_calendar' => '1',
        'notify_mentions' => '1',
        'notify_teams' => '1',
        'notify_drive' => '1',
        'notify_projects' => '1',
    ];
}

function get_user_preference(
    int $userId,
    string $key,
    ?string $default = null
): ?string {
    if (!in_array($key, preference_allowed_keys(), true)) {
        return $default;
    }

    $defaults = preference_defaults();
    $fallback = $default ?? ($defaults[$key] ?? null);

    try {
        $statement = db()->prepare(
            'SELECT preference_value
             FROM user_preferences
             WHERE user_id = ?
               AND preference_key = ?
             LIMIT 1'
        );

        $statement->execute([
            $userId,
            $key,
        ]);

        $value = $statement->fetchColumn();

        return $value !== false
            ? (string) $value
            : $fallback;
    } catch (Throwable $error) {
        return $fallback;
    }
}

function set_user_preference(
    int $userId,
    string $key,
    string $value
): void {
    if (!in_array($key, preference_allowed_keys(), true)) {
        throw new InvalidArgumentException('Unsupported preference.');
    }

    $statement = db()->prepare(
        'INSERT INTO user_preferences
            (user_id, preference_key, preference_value, updated_at)
         VALUES
            (?, ?, ?, CURRENT_TIMESTAMP)
         ON CONFLICT(user_id, preference_key)
         DO UPDATE SET
            preference_value = excluded.preference_value,
            updated_at = CURRENT_TIMESTAMP'
    );

    $statement->execute([
        $userId,
        $key,
        $value,
    ]);
}

function set_user_preferences(int $userId, array $values): void
{
    foreach ($values as $key => $value) {
        set_user_preference($userId, (string) $key, (string) $value);
    }
}

function user_preferences(int $userId): array
{
    $preferences = preference_defaults();

    foreach (array_keys($preferences) as $key) {
        $preferences[$key] =
            get_user_preference(
                $userId,
                $key,
                $preferences[$key]
            ) ?? $preferences[$key];
    }

    return $preferences;
}

function valid_theme_preference(string $value): bool
{
    return in_array($value, ['light', 'dark', 'system'], true);
}

function valid_date_format_preference(string $value): bool
{
    return in_array($value, ['dd_mm_yyyy', 'mm_dd_yyyy', 'yyyy_mm_dd'], true);
}

function valid_time_format_preference(string $value): bool
{
    return in_array($value, ['12', '24'], true);
}

function valid_reduced_motion_preference(string $value): bool
{
    return in_array($value, ['system', 'reduce'], true);
}

function valid_high_contrast_preference(string $value): bool
{
    return in_array($value, ['system', 'more'], true);
}

function valid_interface_density_preference(string $value): bool
{
    return in_array($value, ['comfortable', 'compact'], true);
}

function valid_notification_preference(string $value): bool
{
    return in_array($value, ['0', '1'], true);
}

function notification_preference_keys(): array
{
    return [
        'notify_messaging',
        'notify_tasks',
        'notify_calendar',
        'notify_mentions',
        'notify_teams',
        'notify_drive',
        'notify_projects',
    ];
}

function notification_enabled(int $userId, string $category): bool
{
    $key = str_starts_with($category, 'notify_')
        ? $category
        : 'notify_' . $category;

    if (!in_array($key, notification_preference_keys(), true)) {
        return true;
    }

    return get_user_preference($userId, $key, '1') === '1';
}

function format_user_date(
    DateTimeInterface $date,
    string $dateFormat
): string {
    return match ($dateFormat) {
        'mm_dd_yyyy' => $date->format('m/d/Y'),
        'yyyy_mm_dd' => $date->format('Y-m-d'),
        default => $date->format('d/m/Y'),
    };
}

function format_user_time(
    DateTimeInterface $date,
    string $timeFormat
): string {
    return $timeFormat === '12'
        ? $date->format('g:i A')
        : $date->format('H:i');
}

function render_theme_bootstrap(array $user): void
{
    $preferences =
        user_preferences((int) $user['id']);

    ?>
    <script>
    (function () {
        var preference = <?= json_encode($preferences['theme']) ?>;
        var reducedMotion = <?= json_encode($preferences['reduced_motion']) ?>;
        var highContrast = <?= json_encode($preferences['high_contrast']) ?>;
        var density = <?= json_encode($preferences['interface_density']) ?>;
        var root = document.documentElement;

        function resolveTheme() {
            if (preference === 'light' || preference === 'dark') {
                return preference;
            }

            return window.matchMedia
                && window.matchMedia('(prefers-color-scheme: light)').matches
                    ? 'light'
                    : 'dark';
        }

        function applyTheme() {
            root.dataset.themePreference = preference;
            root.dataset.theme = resolveTheme();
            root.dataset.reducedMotion = reducedMotion;
            root.dataset.highContrast = highContrast;
            root.dataset.interfaceDensity = density;
        }

        applyTheme();

        if (
            preference === 'system'
            && window.matchMedia
        ) {
            var media = window.matchMedia('(prefers-color-scheme: light)');

            if (media.addEventListener) {
                media.addEventListener('change', applyTheme);
            } else if (media.addListener) {
                media.addListener(applyTheme);
            }
        }
    })();
    </script>
    <?php
}
