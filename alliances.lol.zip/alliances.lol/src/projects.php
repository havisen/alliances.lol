<?php

declare(strict_types=1);

require_once __DIR__ . '/database.php';

/*
|--------------------------------------------------------------------------
| Projects domain / access layer
|--------------------------------------------------------------------------
|
| Central authorization and persistence layer for Projects.
|
| The authority model is deliberately simple:
|
|   - Workspace Admin: can view and manage every Project in the workspace.
|   - Project Lead:    has an explicit project_members row with role='lead';
|                      can manage that Project only.
|   - Project Member:  has an explicit project_members row; can view only.
|   - Team Member:     becomes an effective Project member through an
|                      attached synchronized team; can view only.
|
| Team Leads receive no automatic Project authority of any kind.
|
| Every read and every mutation is workspace-scoped. A Project id alone can
| never cross a workspace boundary.
|
*/

/*
|--------------------------------------------------------------------------
| Value registries + validation
|--------------------------------------------------------------------------
*/

function project_status_list(): array
{
    return ['planning', 'active', 'on_hold', 'completed', 'archived'];
}

/** Archived Projects have no mutation exception, including status changes. */
function project_is_writable(array $project): bool
{
    return ($project['status'] ?? '') !== 'archived';
}

function project_require_writable_request(array $project): void
{
    if (!project_is_writable($project)) {
        http_response_code(409);
        exit('Archived projects are read-only.');
    }
}

function project_assert_writable(int $projectId, ?PDO $connection = null): void
{
    $statement = ($connection ?? db())->prepare('SELECT status FROM projects WHERE id = ?');
    $statement->execute([$projectId]);
    $project = $statement->fetch();
    if (!$project || !project_is_writable($project)) {
        throw new InvalidArgumentException('Project is unavailable or archived.');
    }
}

function project_status_exists(string $status): bool
{
    return in_array($status, project_status_list(), true);
}

/**
 * Curated Project icon identifiers. Keep this deliberately small and stable:
 * callers store the identifier, while the UI owns how it is rendered.
 */
function project_icon_list(): array
{
    return [
        'briefcase',
        'calendar',
        'check-circle',
        'flag',
        'folder',
        'lightbulb',
        'rocket',
        'star',
        'target',
        'users',
    ];
}

function project_health_list(): array
{
    return ['unknown', 'on_track', 'at_risk', 'off_track'];
}

function project_validate_icon(?string $icon): ?string
{
    $icon = project_normalize_optional($icon);

    if ($icon === null) {
        return null;
    }

    if (!in_array($icon, project_icon_list(), true)) {
        throw new InvalidArgumentException('Invalid project icon.');
    }

    return $icon;
}

function project_validate_color(?string $color): ?string
{
    $color = project_normalize_optional($color);

    if ($color === null) {
        return null;
    }

    if (preg_match('/^#[0-9A-Fa-f]{6}$/D', $color) !== 1) {
        throw new InvalidArgumentException(
            'Project colors must use the #RRGGBB format.'
        );
    }

    return strtoupper($color);
}

function project_validate_health(string $health): string
{
    $health = trim($health);

    if (!in_array($health, project_health_list(), true)) {
        throw new InvalidArgumentException('Invalid project health.');
    }

    return $health;
}

function project_member_role_list(): array
{
    return ['member', 'lead'];
}

function project_member_role_valid(string $role): bool
{
    return in_array($role, project_member_role_list(), true);
}

/**
 * Projects in these states must keep at least one explicit Project Lead.
 * Completed and archived projects are exempt so they can be closed out and
 * so a Workspace Admin can always recover a Project.
 */
function project_status_requires_lead(string $status): bool
{
    return in_array($status, ['planning', 'active', 'on_hold'], true);
}

function project_normalize_optional(?string $value): ?string
{
    if ($value === null) {
        return null;
    }

    $value = trim($value);

    return $value === '' ? null : $value;
}

function project_validate_name(string $name): string
{
    $name = trim($name);

    if ($name === '') {
        throw new InvalidArgumentException('Enter a name for the project.');
    }

    if (strlen($name) > 150) {
        throw new InvalidArgumentException(
            'Project names can be up to 150 characters.'
        );
    }

    return $name;
}

function project_normalize_user_ids(array $ids): array
{
    $normalized = [];

    foreach ($ids as $id) {
        $id = filter_var($id, FILTER_VALIDATE_INT);

        if ($id !== false && $id > 0) {
            $normalized[] = $id;
        }
    }

    return array_values(array_unique($normalized));
}

/*
|--------------------------------------------------------------------------
| Read helpers
|--------------------------------------------------------------------------
*/

/**
 * Return a Project only when it belongs to the specified workspace.
 */
function project_by_id(int $projectId, int $workspaceId): ?array
{
    if ($projectId <= 0 || $workspaceId <= 0) {
        return null;
    }

    $statement = db()->prepare(
        'SELECT *
         FROM projects
         WHERE id = ?
           AND workspace_id = ?
         LIMIT 1'
    );

    $statement->execute([$projectId, $workspaceId]);

    $project = $statement->fetch();

    return $project ?: null;
}

function projects_for_workspace(
    int $workspaceId,
    bool $includeArchived = false,
    ?string $likeQuery = null,
    ?int $limit = null
): array {
    $sql = 'SELECT *
            FROM projects
            WHERE workspace_id = ?';

    $parameters = [$workspaceId];

    if (!$includeArchived) {
        $sql .= ' AND status != "archived"';
    }

    if ($likeQuery !== null) {
        $sql .= ' AND (name LIKE ? COLLATE NOCASE OR description LIKE ? COLLATE NOCASE)';
        $parameters[] = $likeQuery;
        $parameters[] = $likeQuery;
    }

    $sql .= ' ORDER BY name COLLATE NOCASE ASC, id ASC';

    if ($limit !== null) {
        $sql .= ' LIMIT ' . max(1, $limit);
    }

    $statement = db()->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}

/**
 * Return Projects where the user has effective membership through either an
 * explicit project_members row or a synchronized attached team.
 * Optional search/limit arguments keep filtering in SQL without changing the
 * existing list defaults or performing per-result authorization queries.
 */
function projects_for_user(
    int $workspaceId,
    int $userId,
    bool $includeArchived = false,
    ?string $likeQuery = null,
    ?int $limit = null
): array {
    $sql = 'SELECT DISTINCT p.*
            FROM projects p
            WHERE p.workspace_id = ?
              AND (
                  EXISTS (
                      SELECT 1
                      FROM project_members pm
                      WHERE pm.project_id = p.id
                        AND pm.user_id = ?
                  )
                  OR EXISTS (
                      SELECT 1
                      FROM project_teams pt
                      INNER JOIN teams t
                          ON t.id = pt.team_id
                         AND t.workspace_id = p.workspace_id
                      INNER JOIN team_members tm
                          ON tm.team_id = t.id
                      WHERE pt.project_id = p.id
                        AND pt.membership_mode = "synchronized"
                        AND tm.user_id = ?
                  )
              )';

    $parameters = [$workspaceId, $userId, $userId];

    if (!$includeArchived) {
        $sql .= ' AND p.status != "archived"';
    }

    if ($likeQuery !== null) {
        $sql .= ' AND (p.name LIKE ? COLLATE NOCASE OR p.description LIKE ? COLLATE NOCASE)';
        $parameters[] = $likeQuery;
        $parameters[] = $likeQuery;
    }

    $sql .= ' ORDER BY p.name COLLATE NOCASE ASC, p.id ASC';

    if ($limit !== null) {
        $sql .= ' LIMIT ' . max(1, $limit);
    }

    $statement = db()->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}

/**
 * Direct Project members with useful user information for the UI.
 */
function project_direct_members(int $projectId, int $workspaceId): array
{
    $statement = db()->prepare(
        'SELECT
            u.id AS user_id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path,
            u.account_status,
            pm.role,
            pm.added_by,
            pm.created_at
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         INNER JOIN users u
             ON u.id = pm.user_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?
         ORDER BY
             CASE WHEN pm.role = "lead" THEN 0 ELSE 1 END,
             u.display_name COLLATE NOCASE ASC,
             u.id ASC'
    );

    $statement->execute([$projectId, $workspaceId]);

    return $statement->fetchAll();
}

/**
 * Explicit Project Leads only. Team Leads are NOT included automatically.
 */
function project_leads(int $projectId, int $workspaceId): array
{
    $statement = db()->prepare(
        'SELECT
            u.id AS user_id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path,
            u.account_status,
            pm.added_by,
            pm.created_at
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         INNER JOIN users u
             ON u.id = pm.user_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?
           AND pm.role = "lead"
         ORDER BY
             u.display_name COLLATE NOCASE ASC,
             u.id ASC'
    );

    $statement->execute([$projectId, $workspaceId]);

    return $statement->fetchAll();
}

/**
 * Teams attached through project_teams, including membership_mode.
 */
function project_attached_teams(int $projectId, int $workspaceId): array
{
    $statement = db()->prepare(
        'SELECT
            t.id AS team_id,
            t.name AS team_name,
            t.description AS team_description,
            t.team_lead_id,
            t.status AS team_status,
            pt.membership_mode,
            pt.added_by,
            pt.created_at
         FROM project_teams pt
         INNER JOIN projects p
             ON p.id = pt.project_id
         INNER JOIN teams t
             ON t.id = pt.team_id
            AND t.workspace_id = p.workspace_id
         WHERE pt.project_id = ?
           AND p.workspace_id = ?
         ORDER BY
             t.name COLLATE NOCASE ASC,
             t.id ASC'
    );

    $statement->execute([$projectId, $workspaceId]);

    return $statement->fetchAll();
}

/**
 * Deduplicated set of people who currently have Project membership.
 *
 * Membership sources are:
 *   A. explicit project_members rows
 *   B. synchronized project_teams -> team_members (current membership only)
 *
 * Snapshot project_teams rows are intentionally ignored: snapshot behavior
 * has not been implemented yet, so snapshot rows cannot contribute current
 * team members.
 *
 * Each result row exposes enough to distinguish an explicit Project Lead,
 * a direct member, a team-derived member, and multiple team sources.
 * No project_members rows are created or modified here.
 */
function project_effective_members(int $projectId, int $workspaceId): array
{
    $connection = db();

    $directStatement = $connection->prepare(
        'SELECT
            u.id AS user_id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path,
            pm.role AS direct_role
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         INNER JOIN users u
             ON u.id = pm.user_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?'
    );

    $directStatement->execute([$projectId, $workspaceId]);

    $teamStatement = $connection->prepare(
        'SELECT
            u.id AS user_id,
            u.display_name,
            u.email,
            u.job_title,
            u.avatar_path,
            t.id AS team_id,
            t.name AS team_name,
            pt.membership_mode
         FROM project_teams pt
         INNER JOIN projects p
             ON p.id = pt.project_id
         INNER JOIN teams t
             ON t.id = pt.team_id
            AND t.workspace_id = p.workspace_id
         INNER JOIN team_members tm
             ON tm.team_id = t.id
         INNER JOIN users u
             ON u.id = tm.user_id
         WHERE pt.project_id = ?
           AND p.workspace_id = ?
           AND pt.membership_mode = "synchronized"
         ORDER BY
             t.name COLLATE NOCASE ASC,
             t.id ASC,
             u.display_name COLLATE NOCASE ASC,
             u.id ASC'
    );

    $teamStatement->execute([$projectId, $workspaceId]);

    $members = [];

    foreach ($directStatement->fetchAll() as $row) {
        $userId = (int) $row['user_id'];

        $members[$userId] = [
            'user_id' => $userId,
            'display_name' => (string) $row['display_name'],
            'email' => (string) $row['email'],
            'job_title' => $row['job_title'] !== null
                ? (string) $row['job_title']
                : null,
            'avatar_path' => $row['avatar_path'] !== null
                ? (string) $row['avatar_path']
                : null,
            'is_direct_member' => true,
            'direct_role' => (string) $row['direct_role'],
            'is_lead' => $row['direct_role'] === 'lead',
            'team_memberships' => [],
        ];
    }

    foreach ($teamStatement->fetchAll() as $row) {
        $userId = (int) $row['user_id'];

        if (!isset($members[$userId])) {
            $members[$userId] = [
                'user_id' => $userId,
                'display_name' => (string) $row['display_name'],
                'email' => (string) $row['email'],
                'job_title' => $row['job_title'] !== null
                    ? (string) $row['job_title']
                    : null,
                'avatar_path' => $row['avatar_path'] !== null
                    ? (string) $row['avatar_path']
                    : null,
                'is_direct_member' => false,
                'direct_role' => null,
                'is_lead' => false,
                'team_memberships' => [],
            ];
        }

        $members[$userId]['team_memberships'][] = [
            'team_id' => (int) $row['team_id'],
            'team_name' => (string) $row['team_name'],
            'membership_mode' => (string) $row['membership_mode'],
        ];
    }

    uasort(
        $members,
        static function (array $a, array $b): int {
            return strcasecmp(
                (string) $a['display_name'],
                (string) $b['display_name']
            );
        }
    );

    return array_values($members);
}

/*
|--------------------------------------------------------------------------
| Access helpers
|--------------------------------------------------------------------------
*/

function project_user_is_direct_member(
    int $projectId,
    int $workspaceId,
    int $userId
): bool {
    $statement = db()->prepare(
        'SELECT 1
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?
           AND pm.user_id = ?
         LIMIT 1'
    );

    $statement->execute([$projectId, $workspaceId, $userId]);

    return $statement->fetchColumn() !== false;
}

/**
 * TRUE only for an explicit project_members.role = 'lead'.
 * A Workspace Admin is deliberately NOT an explicit Project Lead.
 */
function project_user_is_lead(
    int $projectId,
    int $workspaceId,
    int $userId
): bool {
    $statement = db()->prepare(
        'SELECT 1
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?
           AND pm.user_id = ?
           AND pm.role = "lead"
         LIMIT 1'
    );

    $statement->execute([$projectId, $workspaceId, $userId]);

    return $statement->fetchColumn() !== false;
}

/**
 * TRUE for a direct Project member OR a member of an attached synchronized
 * team. Team Lead status by itself grants nothing here.
 */
function project_user_is_effective_member(
    int $projectId,
    int $workspaceId,
    int $userId
): bool {
    $statement = db()->prepare(
        'SELECT 1
         FROM projects p
         WHERE p.id = ?
           AND p.workspace_id = ?
           AND (
               EXISTS (
                   SELECT 1
                   FROM project_members pm
                   WHERE pm.project_id = p.id
                     AND pm.user_id = ?
               )
               OR EXISTS (
                   SELECT 1
                   FROM project_teams pt
                   INNER JOIN teams t
                       ON t.id = pt.team_id
                      AND t.workspace_id = p.workspace_id
                   INNER JOIN team_members tm
                       ON tm.team_id = t.id
                   WHERE pt.project_id = p.id
                     AND pt.membership_mode = "synchronized"
                     AND tm.user_id = ?
               )
           )
         LIMIT 1'
    );

    $statement->execute([
        $projectId,
        $workspaceId,
        $userId,
        $userId,
    ]);

    return $statement->fetchColumn() !== false;
}

/**
 * Workspace Admin or effective Project member can view.
 */
function project_user_can_view(
    array $access,
    int $userId,
    int $projectId
): bool {
    if (!empty($access['is_admin'])) {
        return true;
    }

    $workspaceId = (int) ($access['workspace_id'] ?? 0);

    if ($workspaceId <= 0 || $userId <= 0 || $projectId <= 0) {
        return false;
    }

    return project_user_is_effective_member(
        $projectId,
        $workspaceId,
        $userId
    );
}

/**
 * Workspace Admin or explicit Project Lead can manage.
 * Team Lead status never grants Project management here.
 */
function project_user_can_manage(
    array $access,
    int $userId,
    int $projectId
): bool {
    if (!empty($access['is_admin'])) {
        return true;
    }

    $workspaceId = (int) ($access['workspace_id'] ?? 0);

    if ($workspaceId <= 0 || $userId <= 0 || $projectId <= 0) {
        return false;
    }

    return project_user_is_lead($projectId, $workspaceId, $userId);
}

function project_lead_count(int $projectId, int $workspaceId): int
{
    $statement = db()->prepare(
        'SELECT COUNT(*)
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?
           AND pm.role = "lead"'
    );

    $statement->execute([$projectId, $workspaceId]);

    return (int) $statement->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| Internal mutation support
|--------------------------------------------------------------------------
*/

function project_fetch_or_fail(int $projectId, int $workspaceId): array
{
    $project = project_by_id($projectId, $workspaceId);

    if ($project === null) {
        throw new RuntimeException('Project not found in this workspace.');
    }

    return $project;
}

function project_direct_role(
    int $projectId,
    int $workspaceId,
    int $userId
): ?string {
    $statement = db()->prepare(
        'SELECT pm.role
         FROM project_members pm
         INNER JOIN projects p
             ON p.id = pm.project_id
         WHERE pm.project_id = ?
           AND p.workspace_id = ?
           AND pm.user_id = ?
         LIMIT 1'
    );

    $statement->execute([$projectId, $workspaceId, $userId]);

    $role = $statement->fetchColumn();

    return $role !== false ? (string) $role : null;
}

function project_user_in_workspace(int $workspaceId, int $userId): bool
{
    $statement = db()->prepare(
        'SELECT 1
         FROM workspace_members wm
         INNER JOIN users u
             ON u.id = wm.user_id
         WHERE wm.workspace_id = ?
           AND wm.user_id = ?
           AND u.account_status = "active"
         LIMIT 1'
    );

    $statement->execute([$workspaceId, $userId]);

    return $statement->fetchColumn() !== false;
}

function project_team_available(int $workspaceId, int $teamId): bool
{
    $statement = db()->prepare(
        'SELECT 1
         FROM teams
         WHERE id = ?
           AND workspace_id = ?
           AND status = "active"
         LIMIT 1'
    );

    $statement->execute([$teamId, $workspaceId]);

    return $statement->fetchColumn() !== false;
}

/**
 * Block removal/demotion of the last explicit Lead for a planning, active,
 * or on_hold Project. The $force flag lets a Workspace Admin recover a
 * Project without introducing an impossible database state.
 */
function project_guard_lead_removal(
    int $projectId,
    int $workspaceId,
    array $project,
    bool $force
): void {
    if ($force) {
        return;
    }

    if (!project_status_requires_lead((string) $project['status'])) {
        return;
    }

    if (project_lead_count($projectId, $workspaceId) > 1) {
        return;
    }

    throw new RuntimeException(
        'A project that is planning, active, or on hold must retain at least one lead.'
    );
}

/*
|--------------------------------------------------------------------------
| Project creation / update / lifecycle
|--------------------------------------------------------------------------
*/

/**
 * Create a Project. The initial status is always 'planning'. Optional lead
 * ids are written as authoritative project_members rows inside the same
 * transaction so partial creation can never be observed.
 */
function project_create(
    int $workspaceId,
    int $createdBy,
    string $name,
    ?string $description = null,
    ?string $startDate = null,
    ?string $targetDate = null,
    array $leadUserIds = [],
    ?string $icon = null,
    ?string $color = null,
    string $health = 'unknown'
): int {
    $name = project_validate_name($name);
    $description = project_normalize_optional($description);
    $startDate = project_normalize_optional($startDate);
    $targetDate = project_normalize_optional($targetDate);
    $leadUserIds = project_normalize_user_ids($leadUserIds);
    $icon = project_validate_icon($icon);
    $color = project_validate_color($color);
    $health = project_validate_health($health);

    $connection = db();
    $connection->beginTransaction();

    try {
        $statement = $connection->prepare(
            'INSERT INTO projects
                (workspace_id, created_by, name, description, start_date, target_date, status, icon, color, health)
             VALUES (?, ?, ?, ?, ?, ?, "planning", ?, ?, ?)'
        );

        $statement->execute([
            $workspaceId,
            $createdBy,
            $name,
            $description,
            $startDate,
            $targetDate,
            $icon,
            $color,
            $health,
        ]);

        $projectId = (int) $connection->lastInsertId();

        foreach ($leadUserIds as $leadUserId) {
            project_add_direct_member(
                $projectId,
                $workspaceId,
                $leadUserId,
                'lead',
                $createdBy
            );
        }

        require_once __DIR__ . '/projects/overview.php';
        project_overview_bootstrap($projectId);
        $connection->commit();

        return $projectId;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}

function project_update(
    int $projectId,
    int $workspaceId,
    string $name,
    ?string $description = null,
    ?string $startDate = null,
    ?string $targetDate = null,
    ?string $icon = null,
    ?string $color = null,
    string $health = 'unknown'
): void {
    $name = project_validate_name($name);
    $description = project_normalize_optional($description);
    $startDate = project_normalize_optional($startDate);
    $targetDate = project_normalize_optional($targetDate);
    $icon = project_validate_icon($icon);
    $color = project_validate_color($color);
    $health = project_validate_health($health);

    project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    $statement = db()->prepare(
        'UPDATE projects
         SET name = ?,
             description = ?,
             start_date = ?,
             target_date = ?,
             icon = ?,
             color = ?,
             health = ?,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?
           AND workspace_id = ?'
    );

    $statement->execute([
        $name,
        $description,
        $startDate,
        $targetDate,
        $icon,
        $color,
        $health,
        $projectId,
        $workspaceId,
    ]);
}

/**
 * Dedicated lifecycle mutation. Only known statuses are accepted, and the
 * completed_at / archived_at markers are maintained according to the
 * transition:
 *
 *   -> completed  : set completed_at, preserve archived_at
 *   -> archived   : set archived_at, preserve completed_at
 *   -> otherwise  : clear completed_at (when leaving completed) and
 *                   clear archived_at (when leaving archived)
 */
function project_set_status(
    int $projectId,
    int $workspaceId,
    string $status
): void {
    if (!project_status_exists($status)) {
        throw new InvalidArgumentException('Invalid project status.');
    }

    project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    if ($status === 'completed') {
        $completedAssignment = 'completed_at = CURRENT_TIMESTAMP';
    } elseif ($status === 'archived') {
        $completedAssignment = 'completed_at = completed_at';
    } else {
        $completedAssignment = 'completed_at = NULL';
    }

    $archivedAssignment = $status === 'archived'
        ? 'archived_at = CURRENT_TIMESTAMP'
        : 'archived_at = NULL';

    $statement = db()->prepare(
        'UPDATE projects
         SET status = ?,
             ' . $completedAssignment . ',
             ' . $archivedAssignment . ',
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?
           AND workspace_id = ?'
    );

    $statement->execute([$status, $projectId, $workspaceId]);
}

/*
|--------------------------------------------------------------------------
| Direct membership mutations
|--------------------------------------------------------------------------
*/

/**
 * Add a direct Project member (role 'member' or 'lead'). Uses an upsert so
 * an existing direct membership is deliberately updated rather than
 * duplicated.
 */
function project_add_direct_member(
    int $projectId,
    int $workspaceId,
    int $userId,
    string $role,
    int $addedBy
): void {
    if (!project_member_role_valid($role)) {
        throw new InvalidArgumentException('Invalid project member role.');
    }

    if ($userId <= 0 || $addedBy <= 0) {
        throw new InvalidArgumentException('A valid user is required.');
    }

    $project = project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    if (!project_user_in_workspace($workspaceId, $userId)) {
        throw new RuntimeException(
            'The user is not an active member of this workspace.'
        );
    }

    $currentRole = project_direct_role($projectId, $workspaceId, $userId);

    if ($currentRole === 'lead' && $role !== 'lead') {
        project_guard_lead_removal(
            $projectId,
            $workspaceId,
            $project,
            false
        );
    }

    $statement = db()->prepare(
        'INSERT INTO project_members (project_id, user_id, role, added_by)
         VALUES (?, ?, ?, ?)
         ON CONFLICT(project_id, user_id)
         DO UPDATE SET role = excluded.role'
    );

    $statement->execute([$projectId, $userId, $role, $addedBy]);
}

function project_update_direct_member_role(
    int $projectId,
    int $workspaceId,
    int $userId,
    string $role,
    bool $force = false
): void {
    if (!project_member_role_valid($role)) {
        throw new InvalidArgumentException('Invalid project member role.');
    }

    $project = project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    $currentRole = project_direct_role($projectId, $workspaceId, $userId);

    if ($currentRole === null) {
        throw new RuntimeException(
            'The user is not a direct member of this project.'
        );
    }

    if ($currentRole === 'lead' && $role !== 'lead') {
        project_guard_lead_removal(
            $projectId,
            $workspaceId,
            $project,
            $force
        );
    }

    $statement = db()->prepare(
        'UPDATE project_members
         SET role = ?
         WHERE project_id = ?
           AND user_id = ?'
    );

    $statement->execute([$role, $projectId, $userId]);
}

function project_remove_direct_member(
    int $projectId,
    int $workspaceId,
    int $userId,
    bool $force = false
): void {
    $project = project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    $currentRole = project_direct_role($projectId, $workspaceId, $userId);

    if ($currentRole === null) {
        return;
    }

    if ($currentRole === 'lead') {
        project_guard_lead_removal(
            $projectId,
            $workspaceId,
            $project,
            $force
        );
    }

    $statement = db()->prepare(
        'DELETE FROM project_members
         WHERE project_id = ?
           AND user_id = ?'
    );

    $statement->execute([$projectId, $userId]);
}

/*
|--------------------------------------------------------------------------
| Team attachment mutations
|--------------------------------------------------------------------------
*/

/**
 * Attach a Team using synchronized membership. Snapshot behavior is not
 * implemented yet. Attaching copies nothing into project_members and never
 * promotes a team_lead_id into a Project Lead.
 */
function project_attach_team(
    int $projectId,
    int $workspaceId,
    int $teamId,
    int $addedBy
): void {
    if ($teamId <= 0 || $addedBy <= 0) {
        throw new InvalidArgumentException('A valid team is required.');
    }

    project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    if (!project_team_available($workspaceId, $teamId)) {
        throw new RuntimeException(
            'The team is not an active team in this workspace.'
        );
    }

    $statement = db()->prepare(
        'INSERT INTO project_teams (project_id, team_id, membership_mode, added_by)
         VALUES (?, ?, "synchronized", ?)
         ON CONFLICT(project_id, team_id) DO NOTHING'
    );

    $statement->execute([$projectId, $teamId, $addedBy]);
}

/**
 * Detach a Team without touching direct project_members rows.
 */
function project_detach_team(
    int $projectId,
    int $workspaceId,
    int $teamId
): void {
    project_fetch_or_fail($projectId, $workspaceId);
    project_assert_writable($projectId);

    $statement = db()->prepare(
        'DELETE FROM project_teams
         WHERE project_id = ?
           AND team_id = ?'
    );

    $statement->execute([$projectId, $teamId]);
}
