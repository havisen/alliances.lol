<?php

declare(strict_types=1);

function project_overview_validate_resource_config(int $projectId, int $workspaceId, int $userId, string $key, array $config): void
{
    $id = (int) ($config['resource_id'] ?? 0);
    if ($id === 0) {
        return;
    }
    $kind = in_array($key, ['channel', 'group_chat'], true) ? 'conversation' : 'drive_file';
    $table = project_resource_tables()[$kind];
    $statement = db()->prepare('SELECT 1 FROM ' . $table . ' WHERE project_id = ? AND resource_id = ?');
    $statement->execute([$projectId, $id]);
    $resource = project_resource_revalidate($workspaceId, $userId, $kind, $id);
    if (!$statement->fetchColumn() || $resource === null || !project_overview_resource_matches($key, $resource)) {
        throw new InvalidArgumentException('Choose an attached resource you can access.');
    }
}

function project_overview_manager(int $projectId, int $workspaceId, int $userId, array $page): void
{
    if (!(int) $page['id']) {
        return;
    }
    $e = 'project_overview_e';
    $resources = project_resources_for_project($projectId, $workspaceId, $userId);
    $base = csrf_input() . '<input type="hidden" name="project_id" value="' . $projectId . '">'
        . '<input type="hidden" name="page_id" value="' . (int) $page['id'] . '">';
    $pages = project_overview_all_pages($projectId);
    $activePages = array_values(array_filter($pages, static fn(array $candidate): bool => ($candidate['archived_at'] ?? null) === null));

    echo '<section class="section"><h2>Overview pages</h2>';
    echo '<p>Create and organize up to 8 active Overview pages. A Project always keeps at least one active page.</p>';
    if (count($activePages) < 8) {
        echo '<form method="post" action="/actions/projects/overview-page-save.php" class="form">'
            . csrf_input()
            . '<input type="hidden" name="project_id" value="' . $projectId . '">'
            . '<label>Page title <input name="title" maxlength="120" required></label>'
            . '<button name="action" value="create">Create page</button></form>';
    } else {
        echo '<p>The 8-page active limit has been reached. Archive a page before creating another.</p>';
    }

    foreach ($activePages as $managedPage) {
        $managedPageId = (int) $managedPage['id'];
        $isCurrent = $managedPageId === (int) $page['id'];
        $isDefault = (int) ($managedPage['is_default'] ?? 0) === 1;
        echo '<form method="post" action="/actions/projects/overview-page-save.php" class="form">'
            . csrf_input()
            . '<input type="hidden" name="project_id" value="' . $projectId . '">'
            . '<input type="hidden" name="page_id" value="' . $managedPageId . '">'
            . '<label>Title <input name="title" maxlength="120" required value="' . $e((string) $managedPage['title']) . '"></label>';
        if ($isCurrent) { echo ' <strong>Current</strong>'; }
        if ($isDefault) { echo ' <strong>Default</strong>'; }
        echo ' <button name="action" value="rename">Rename</button>';
        echo ' <button name="action" value="move_up">Move up</button>';
        echo ' <button name="action" value="move_down">Move down</button>';
        if (!$isDefault) {
            echo ' <button name="action" value="set_default">Set default</button>';
        }
        if (count($activePages) > 1) {
            echo ' <button name="action" value="archive">Archive</button>';
        }
        echo '</form>';
    }

    $archivedPages = array_values(array_filter($pages, static fn(array $candidate): bool => ($candidate['archived_at'] ?? null) !== null));
    if ($archivedPages !== []) {
        echo '<details><summary>Archived Overview pages (' . count($archivedPages) . ')</summary><ul>';
        foreach ($archivedPages as $archivedPage) {
            echo '<li>' . $e((string) $archivedPage['title']) . '</li>';
        }
        echo '</ul></details>';
    }
    echo '</section>';

    echo '<section class="section"><h2>Configure this Overview page</h2>';
    echo '<form method="post" action="/actions/projects/overview-module-save.php" class="form">' . $base;
    echo '<label>Module <select name="module_key">';
    foreach (project_overview_module_registry() as $key => $meta) {
        echo '<option value="' . $e($key) . '">' . $e($meta['label']) . '</option>';
    }
    echo '</select></label><button name="action" value="add">Add module</button></form>';
    foreach (project_overview_modules_all($projectId, (int) $page['id']) as $module) {
        $meta = project_overview_module_meta($module['module_key']);
        if ($meta === null) { continue; }
        try { $config = project_overview_decode_config($module['module_key'], $module['config']); }
        catch (Throwable $error) { $config = project_overview_normalize_config($module['module_key'], []); }
        echo '<details><summary>' . $e($module['title'] ?: $meta['label']) . '</summary>';
        echo '<form method="post" action="/actions/projects/overview-module-save.php" class="form">' . $base;
        echo '<input type="hidden" name="module_id" value="' . (int) $module['id'] . '">';
        echo '<label>Title <input name="title" maxlength="120" value="' . $e($module['title'] ?? '') . '"></label>';
        echo '<label>Column span <select name="col_span">';
        foreach ([1, 2, 3] as $span) {
            echo '<option' . ((int) $module['col_span'] === $span ? ' selected' : '') . '>' . $span . '</option>';
        }
        echo '</select></label><label>Visibility <select name="visibility">';
        foreach (['all' => 'All Project viewers', 'leads' => 'Project leads and administrators'] as $value => $label) {
            echo '<option value="' . $value . '"' . ($module['visibility'] === $value ? ' selected' : '') . '>' . $label . '</option>';
        }
        echo '</select></label>';
        foreach ($meta['config_schema'] as $name => $spec) {
            echo '<label>' . $e(ucwords(str_replace('_', ' ', $name))) . ' ';
            if ($name === 'resource_id') {
                echo '<select name="config[resource_id]"><option value="0">First accessible attached resource</option>';
                foreach ($resources as $resource) {
                    if (project_overview_resource_matches($module['module_key'], $resource)) {
                        echo '<option value="' . (int) $resource['id'] . '"' . ((int) $resource['id'] === $config[$name] ? ' selected' : '') . '>' . $e($resource['title']) . '</option>';
                    }
                }
                if ($config[$name] !== 0 && !array_filter($resources, static fn(array $r): bool => (int) $r['id'] === $config[$name] && project_overview_resource_matches($module['module_key'], $r))) {
                    echo '<option value="' . $config[$name] . '" selected>Resource unavailable; choose a replacement</option>';
                }
                echo '</select>';
            } elseif ($spec['type'] === 'enum') {
                echo '<select name="config[' . $name . ']">';
                foreach ($spec['values'] as $value) {
                    echo '<option value="' . $e($value) . '"' . ($config[$name] === $value ? ' selected' : '') . '>' . $e(ucwords(str_replace('_', ' ', $value))) . '</option>';
                }
                echo '</select>';
            } elseif ($spec['type'] === 'text') {
                echo '<textarea name="config[' . $name . ']" maxlength="' . $spec['max'] . '">' . $e($config[$name]) . '</textarea>';
            } else {
                echo '<input type="number" name="config[' . $name . ']" min="' . $spec['min'] . '" max="' . $spec['max'] . '" value="' . $config[$name] . '">';
            }
            echo '</label>';
        }
        foreach (['save' => 'Save', 'up' => 'Move up', 'down' => 'Move down', 'duplicate' => 'Duplicate', 'remove' => 'Remove'] as $operation => $label) {
            echo '<button name="action" value="' . $operation . '">' . $label . '</button> ';
        }
        echo '</form></details>';
    }
    echo '</section><section class="section"><h2>Attach resources</h2>';
    $query = is_string($_GET['resource_query'] ?? null) ? mb_substr(trim($_GET['resource_query']), 0, 100) : '';
    echo '<form method="get" class="form"><input type="hidden" name="id" value="' . $projectId . '">'
        . '<label>Search your Drive files, folders, channels and groups <input name="resource_query" maxlength="100" value="' . $e($query) . '"></label><button>Search</button></form>';
    if ($query !== '') {
        $results = array_merge(project_resource_picker_drive($workspaceId, $userId, $query), project_resource_picker_conversations($workspaceId, $userId, $query));
        foreach ($results as $resource) {
            echo '<form method="post" action="/actions/projects/resource-attach.php">' . $base
                . '<input type="hidden" name="kind" value="' . $e($resource['type']) . '">'
                . '<input type="hidden" name="resource_id" value="' . (int) $resource['id'] . '">'
                . $e($resource['title']) . ' <button>Attach</button></form>';
        }
        if ($results === []) { echo '<p>No accessible resources found.</p>'; }
    }
    foreach ($resources as $resource) {
        echo '<form method="post" action="/actions/projects/resource-remove.php">' . $base
            . '<input type="hidden" name="kind" value="' . $e($resource['type']) . '">'
            . '<input type="hidden" name="resource_id" value="' . (int) $resource['id'] . '">'
            . $e($resource['title']) . ' <button>Detach</button></form>';
    }
    echo '</section>';

    echo '<section class="section"><h2>Milestones</h2>';
    echo '<form method="post" action="/actions/projects/milestone-save.php" class="form">' . $base
        . '<label>Title <input name="title" maxlength="160" required></label>'
        . '<label>Description <textarea name="description" maxlength="4000"></textarea></label>'
        . '<label>Due date <input type="date" name="due_date"></label>'
        . '<button>Add milestone</button></form>';
    foreach (project_overview_milestones($projectId, 100) as $milestone) {
        echo '<details><summary>' . $e((string) $milestone['title'])
            . (((string) $milestone['status']) === 'completed' ? ' — Completed' : '') . '</summary>';
        echo '<form method="post" action="/actions/projects/milestone-save.php" class="form">' . $base
            . '<input type="hidden" name="milestone_id" value="' . (int) $milestone['id'] . '">'
            . '<label>Title <input name="title" maxlength="160" required value="' . $e((string) $milestone['title']) . '"></label>'
            . '<label>Description <textarea name="description" maxlength="4000">' . $e((string) ($milestone['description'] ?? '')) . '</textarea></label>'
            . '<label>Due date <input type="date" name="due_date" value="' . $e((string) ($milestone['due_date'] ?? '')) . '"></label>'
            . '<button>Save</button></form>';
        echo '<form method="post" action="/actions/projects/milestone-toggle.php">' . $base
            . '<input type="hidden" name="milestone_id" value="' . (int) $milestone['id'] . '">'
            . '<button>' . (((string) $milestone['status']) === 'completed' ? 'Reopen' : 'Complete') . '</button></form>';
        echo '<form method="post" action="/actions/projects/milestone-delete.php">' . $base
            . '<input type="hidden" name="milestone_id" value="' . (int) $milestone['id'] . '">'
            . '<button>Delete</button></form>';
        echo '</details>';
    }
    echo '</section>';

    echo '<section class="section"><h2>Announcements</h2>';
    echo '<form method="post" action="/actions/projects/announcement-save.php" class="form">' . $base
        . '<label>Title <input name="title" maxlength="160" required></label>'
        . '<label>Body <textarea name="body" maxlength="10000"></textarea></label>'
        . '<button>Post announcement</button></form>';
    foreach (project_overview_announcements($projectId, 100) as $announcement) {
        echo '<details><summary>' . ($announcement['is_pinned'] ? 'Pinned — ' : '') . $e((string) $announcement['title']) . '</summary>';
        echo '<form method="post" action="/actions/projects/announcement-save.php" class="form">' . $base
            . '<input type="hidden" name="announcement_id" value="' . (int) $announcement['id'] . '">'
            . '<label>Title <input name="title" maxlength="160" required value="' . $e((string) $announcement['title']) . '"></label>'
            . '<label>Body <textarea name="body" maxlength="10000">' . $e((string) ($announcement['body'] ?? '')) . '</textarea></label>'
            . '<button>Save</button></form>';
        echo '<form method="post" action="/actions/projects/announcement-toggle-pin.php">' . $base
            . '<input type="hidden" name="announcement_id" value="' . (int) $announcement['id'] . '">'
            . '<button>' . ($announcement['is_pinned'] ? 'Unpin' : 'Pin') . '</button></form>';
        echo '<form method="post" action="/actions/projects/announcement-archive.php">' . $base
            . '<input type="hidden" name="announcement_id" value="' . (int) $announcement['id'] . '">'
            . '<button>Archive</button></form>';
        echo '</details>';
    }
    echo '</section>';

    echo '<section class="section"><h2>Links</h2>';
    echo '<form method="post" action="/actions/projects/link-save.php" class="form">' . $base
        . '<label>Title <input name="title" maxlength="160" required></label>'
        . '<label>URL <input type="url" name="url" maxlength="2048" required></label>'
        . '<label>Kind <input name="kind" maxlength="40" value="link"></label>'
        . '<button>Add link</button></form>';
    foreach (project_overview_links($projectId, 100) as $link) {
        echo '<details><summary>' . $e((string) $link['title']) . '</summary>';
        echo '<form method="post" action="/actions/projects/link-save.php" class="form">' . $base
            . '<input type="hidden" name="link_id" value="' . (int) $link['id'] . '">'
            . '<label>Title <input name="title" maxlength="160" required value="' . $e((string) $link['title']) . '"></label>'
            . '<label>URL <input type="url" name="url" maxlength="2048" required value="' . $e((string) $link['url']) . '"></label>'
            . '<label>Kind <input name="kind" maxlength="40" value="' . $e((string) $link['kind']) . '"></label>'
            . '<button>Save</button></form>';
        echo '<form method="post" action="/actions/projects/link-remove.php">' . $base
            . '<input type="hidden" name="link_id" value="' . (int) $link['id'] . '">'
            . '<button>Remove</button></form>';
        echo '</details>';
    }
    echo '</section>';
}
