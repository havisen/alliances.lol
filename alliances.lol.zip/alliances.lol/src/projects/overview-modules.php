<?php

declare(strict_types=1);

/** The persisted V1 contract. Each entry is an independent, repeatable module. */
function project_overview_v1_registry(): array
{
    $limit = ['type' => 'integer', 'min' => 1, 'max' => 20, 'default' => 10];
    $resource = ['type' => 'integer', 'min' => 0, 'max' => PHP_INT_MAX, 'default' => 0];
    $definitions = [
        'status' => ['Status', [], []],
        'progress' => ['Progress', [], ['tasks']],
        'tasks' => ['Tasks', ['filter' => ['type' => 'enum', 'values' => ['open', 'overdue', 'mine', 'all'], 'default' => 'open'], 'limit' => $limit], ['tasks']],
        'members' => ['Members', ['filter' => ['type' => 'enum', 'values' => ['all', 'leads'], 'default' => 'all']], ['members']],
        'milestones' => ['Milestones', ['limit' => $limit], ['milestones']],
        'calendar' => ['Calendar', ['limit' => $limit], ['calendar']],
        'channel' => ['Channel', ['resource_id' => $resource], ['resources']],
        'group_chat' => ['Group Chat', ['resource_id' => $resource], ['resources']],
        'files' => ['Files', ['limit' => $limit], ['resources']],
        'document' => ['Document', ['resource_id' => $resource], ['resources']],
        'spreadsheet' => ['Spreadsheet', ['resource_id' => $resource], ['resources']],
        'activity' => ['Activity', ['limit' => ['type' => 'integer', 'min' => 1, 'max' => 50, 'default' => 20]], ['activity']],
        'announcements' => ['Announcements', ['limit' => ['type' => 'integer', 'min' => 1, 'max' => 10, 'default' => 5]], ['announcements']],
        'metrics' => ['Metrics', ['metric' => ['type' => 'enum', 'values' => ['open_tasks', 'completed_tasks', 'overdue_tasks', 'completion_percent', 'members', 'milestones_completed'], 'default' => 'open_tasks']], ['tasks', 'members', 'milestones']],
        'links' => ['Links', ['limit' => $limit], ['links']],
        'notes' => ['Notes', ['content' => ['type' => 'text', 'max' => 2000, 'default' => '']], []],
        'custom_content' => ['Custom Content', ['title' => ['type' => 'text', 'max' => 120, 'default' => ''], 'content' => ['type' => 'text', 'max' => 2000, 'default' => '']], []],
    ];
    $registry = [];
    foreach ($definitions as $key => [$label, $schema, $needs]) {
        $registry[$key] = ['key' => $key, 'label' => $label, 'description' => $label,
            'page' => 'overview', 'available' => true, 'default_span' => 1,
            'config_schema' => $schema, 'needs' => $needs];
    }
    return $registry;
}

function project_overview_normalize_config(string $key, array $input): array
{
    $meta = project_overview_module_meta($key);
    if ($meta === null || (isset($input['v']) && $input['v'] !== 1)) {
        throw new InvalidArgumentException('Unsupported module or configuration version.');
    }
    $out = ['v' => 1];
    foreach ($meta['config_schema'] as $name => $spec) {
        $value = $input[$name] ?? $spec['default'];
        if ($spec['type'] === 'integer') {
            $value = filter_var($value, FILTER_VALIDATE_INT);
            if ($value === false || $value < $spec['min'] || $value > $spec['max']) {
                throw new InvalidArgumentException('Invalid ' . str_replace('_', ' ', $name) . '.');
            }
        } elseif ($spec['type'] === 'enum') {
            if (!is_string($value) || !in_array($value, $spec['values'], true)) {
                throw new InvalidArgumentException('Invalid ' . $name . '.');
            }
        } elseif (!is_string($value) || mb_strlen($value) > $spec['max']) {
            throw new InvalidArgumentException('Content exceeds the module limit.');
        }
        $out[$name] = $value;
    }
    if (strlen(json_encode($out, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE)) > 4096) {
        throw new InvalidArgumentException('Module configuration exceeds 4096 bytes.');
    }
    return $out;
}

function project_overview_decode_config(string $key, ?string $json): array
{
    $input = $json === null || $json === '' ? [] : json_decode($json, true, 16, JSON_THROW_ON_ERROR);
    if (!is_array($input)) {
        throw new InvalidArgumentException('Invalid module configuration.');
    }
    return project_overview_normalize_config($key, $input);
}

function project_overview_module_visible(array $module, bool $isLeadOrAdmin): bool
{
    return (int) ($module['is_enabled'] ?? 1) === 1
        && (($module['visibility'] ?? 'all') === 'all'
            || (($module['visibility'] ?? '') === 'leads' && $isLeadOrAdmin));
}

function project_overview_valid_url(string $url): bool
{
    return filter_var($url, FILTER_VALIDATE_URL) !== false
        && in_array(strtolower((string) parse_url($url, PHP_URL_SCHEME)), ['http', 'https'], true);
}

/** All metrics and rows derive from exactly the same Task-list membership predicate. */
function project_overview_tasks_sql(string $select): string
{
    return 'SELECT ' . $select . ' FROM tasks t
        INNER JOIN task_lists tl ON tl.id = t.task_list_id
        INNER JOIN task_list_members member ON member.task_list_id = tl.id AND member.user_id = ?
        WHERE tl.workspace_id = ? AND tl.project_id = ?';
}

function project_overview_context(array $modules, int $workspaceId, int $projectId, int $userId): array
{
    $needs = [];
    foreach ($modules as $module) {
        $meta = project_overview_module_meta($module['module_key']);
        foreach ($meta['needs'] ?? [] as $family) {
            $needs[$family] = true;
        }
    }
    $context = [];
    if (isset($needs['tasks']) || isset($needs['calendar'])) {
        $statement = db()->prepare(project_overview_tasks_sql(
            'COUNT(t.id) AS total, COALESCE(SUM(t.status = \'completed\'), 0) AS completed,
             COALESCE(SUM(t.status != \'completed\' AND date(t.deadline) < date(\'now\')), 0) AS overdue'
        ));
        $statement->execute([$userId, $workspaceId, $projectId]);
        $context['task_counts'] = $statement->fetch();
        $statement = db()->prepare('SELECT COUNT(*) FROM task_lists tl
            INNER JOIN task_list_members member ON member.task_list_id = tl.id AND member.user_id = ?
            WHERE tl.workspace_id = ? AND tl.project_id = ?');
        $statement->execute([$userId, $workspaceId, $projectId]);
        $context['list_count'] = (int) $statement->fetchColumn();
        // Four fixed queries, regardless of module count; each filter has its own bounded result set.
        foreach (['all', 'open', 'overdue', 'mine'] as $filter) {
            $where = match ($filter) {
                'open' => " AND t.status != 'completed'",
                'overdue' => " AND t.status != 'completed' AND date(t.deadline) < date('now')",
                'mine' => ' AND t.assigned_to = ?',
                default => '',
            };
            $statement = db()->prepare(project_overview_tasks_sql('t.id, t.name, t.status, t.deadline')
                . $where . ' ORDER BY t.id DESC LIMIT 20');
            $statement->execute($filter === 'mine' ? [$userId, $workspaceId, $projectId, $userId] : [$userId, $workspaceId, $projectId]);
            $context['tasks'][$filter] = $statement->fetchAll();
        }
    }
    if (isset($needs['members'])) {
        $context['members'] = project_effective_members($projectId, $workspaceId);
        $context['leads'] = project_leads($projectId, $workspaceId);
    }
    if (isset($needs['resources'])) {
        $context['resources'] = project_resources_for_project($projectId, $workspaceId, $userId);
    }
    if (isset($needs['milestones']) || isset($needs['calendar'])) {
        $context['milestones'] = project_overview_milestones($projectId, 100);
        $statement = db()->prepare("SELECT COUNT(*) FROM project_milestones WHERE project_id = ? AND status = 'completed'");
        $statement->execute([$projectId]);
        $context['milestones_completed'] = (int) $statement->fetchColumn();
    }
    if (isset($needs['calendar'])) {
        $statement = db()->prepare('SELECT id, title, starts_at AS date FROM calendar_events
            WHERE workspace_id = ? AND project_id = ? ORDER BY starts_at LIMIT 20');
        $statement->execute([$workspaceId, $projectId]);
        $events = $statement->fetchAll();
        foreach ($context['milestones'] as $milestone) {
            if ($milestone['due_date'] !== null) {
                $events[] = ['title' => $milestone['title'], 'date' => $milestone['due_date']];
            }
        }
        $statement = db()->prepare(project_overview_tasks_sql('t.name AS title, t.deadline AS date')
            . ' AND t.deadline IS NOT NULL ORDER BY t.deadline LIMIT 20');
        $statement->execute([$userId, $workspaceId, $projectId]);
        $events = array_merge($events, $statement->fetchAll());
        usort($events, static fn(array $a, array $b): int => strcmp($a['date'], $b['date']));
        $context['calendar'] = $events;
    }
    if (isset($needs['activity'])) {
        $context['activity'] = project_overview_activity($projectId, 50);
    }
    if (isset($needs['announcements'])) {
        $context['announcements'] = project_overview_announcements($projectId, 10);
    }
    if (isset($needs['links'])) {
        $context['links'] = project_overview_links($projectId, 20);
    }
    return $context;
}

function project_overview_resource_matches(string $moduleKey, array $resource): bool
{
    if (!empty($resource['unavailable'])) {
        return false;
    }
    if ($moduleKey === 'files') {
        return in_array($resource['type'], ['drive_file', 'drive_folder'], true);
    }
    if (in_array($moduleKey, ['channel', 'group_chat'], true)) {
        return $resource['type'] === 'conversation'
            && ($resource['conversation_type'] ?? '') === ($moduleKey === 'channel' ? 'channel' : 'group');
    }
    if ($resource['type'] !== 'drive_file' || !drive_file_editor_supported($resource['title'], $resource['mime_type'] ?? null)) {
        return false;
    }
    $sheet = str_ends_with(strtolower($resource['title']), '.xlsx')
        || ($resource['mime_type'] ?? '') === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    return $moduleKey === 'spreadsheet' ? $sheet : ($moduleKey === 'document' && !$sheet);
}

/** Pure renderer: data is already authorized for this viewer by the page context. */
function project_overview_render_v1(array $module, array $project, array $context): string
{
    $key = $module['module_key'];
    try {
        $config = project_overview_decode_config($key, $module['config'] ?? null);
    } catch (Throwable $error) {
        return '<p class="empty-state">Module configuration unavailable.</p>';
    }
    $e = 'project_overview_e';
    $empty = '<p class="empty-state">No items available.</p>';
    if ($key === 'status') {
        return project_overview_module_status($project);
    }
    if ($key === 'notes' || $key === 'custom_content') {
        return ($key === 'custom_content' && $config['title'] !== '' ? '<h3>' . $e($config['title']) . '</h3>' : '')
            . '<p class="overview-text">' . nl2br($e($config['content'])) . '</p>';
    }
    if ($key === 'progress' || $key === 'metrics') {
        $counts = $context['task_counts'];
        $total = (int) $counts['total'];
        $completed = (int) $counts['completed'];
        $percent = $total ? (int) round(100 * $completed / $total) : 0;
        if ($key === 'progress') {
            return ($total ? '<p>' . $completed . ' / ' . $total . ' completed</p>' . project_overview_progress_bar($percent)
                : '<p>No tasks yet.</p>') . '<p>Based on ' . (int) $context['list_count'] . ' lists you can see.</p>';
        }
        $value = match ($config['metric']) {
            'open_tasks' => $total - $completed, 'completed_tasks' => $completed,
            'overdue_tasks' => (int) $counts['overdue'], 'completion_percent' => $percent . '%',
            'members' => count($context['members']), 'milestones_completed' => $context['milestones_completed'],
        };
        return '<p>' . $e(ucwords(str_replace('_', ' ', $config['metric']))) . ': <strong>' . $e((string) $value) . '</strong></p>';
    }
    if (in_array($key, ['channel', 'group_chat', 'files', 'document', 'spreadsheet'], true)) {
        $rows = array_filter($context['resources'] ?? [], static fn(array $r): bool =>
            project_overview_resource_matches($key, $r) && (empty($config['resource_id']) || (int) $r['id'] === $config['resource_id']));
        if ($rows === []) {
            return '<p class="empty-state">Resource unavailable or not configured.</p>';
        }
        $html = '<ul class="stack">';
        foreach (array_slice(array_values($rows), 0, $config['limit'] ?? 1) as $row) {
            $html .= '<li><a href="' . $e($row['url']) . '">' . $e($row['title']) . '</a></li>';
        }
        return $html . '</ul>';
    }
    $rows = match ($key) {
        'tasks' => $context['tasks'][$config['filter']] ?? [],
        'members' => $context[$config['filter'] === 'leads' ? 'leads' : 'members'] ?? [],
        default => $context[$key] ?? [],
    };
    if ($rows === []) {
        return $empty;
    }
    $html = '<ul class="stack">';
    foreach (array_slice($rows, 0, $config['limit'] ?? 100) as $row) {
        $body = match ($key) {
            'tasks' => '<a href="/tasks/task.php?id=' . (int) $row['id'] . '">' . $e($row['name']) . '</a> — ' . $e($row['status']),
            'members' => $e($row['display_name']),
            'milestones' => $e($row['title']) . ' — ' . $e($row['status']) . ' ' . $e($row['due_date'] ?? ''),
            'calendar' => $e($row['date']) . ' — ' . $e($row['title']),
            // Ignore any historical free-text summary. Only allowlisted neutral event copy is rendered.
            'activity' => $e(project_overview_activity_summary($row['activity_type'])) . ' — ' . $e($row['actor_name']),
            'announcements' => '<strong>' . $e($row['title']) . '</strong><p>' . nl2br($e($row['body'] ?? '')) . '</p>',
            'links' => project_overview_valid_url($row['url'])
                ? '<a href="' . $e($row['url']) . '" target="_blank" rel="noopener noreferrer">' . $e($row['title']) . '</a>' : 'Link unavailable',
            default => '',
        };
        $html .= '<li>' . $body . '</li>';
    }
    return $html . '</ul>';
}

function project_overview_activity_types(): array
{
    return ['project_updated' => 'Project updated', 'status_changed' => 'Project status changed',
        'member_added' => 'Project member added', 'member_removed' => 'Project member removed',
        'member_role_changed' => 'Project member role changed', 'team_attached' => 'Team attached',
        'team_detached' => 'Team detached', 'task_list_attached' => 'Task list attached',
        'task_list_detached' => 'Task list detached', 'resource_attached' => 'Resource attached',
        'resource_removed' => 'Resource removed', 'link_changed' => 'Project link changed',
        'milestone_changed' => 'Project milestone changed', 'announcement_posted' => 'Announcement posted'];
}

function project_overview_activity_summary(string $type): string
{
    return project_overview_activity_types()[$type] ?? 'Project updated';
}
