<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Project Overview
|--------------------------------------------------------------------------
|
| Registry, bootstrap, read, and render helpers for the Project Overview
| surface (public/projects/project.php). Pages and module instances live in
| project_overview_pages / project_overview_modules and are keyed against the
| registry below rather than hard-coded in markup.
*/

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../projects.php';
require_once __DIR__ . '/../notifications.php';
require_once __DIR__ . '/../tasks/lists.php';
require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../entity-links.php';
require_once __DIR__ . '/resources.php';
require_once __DIR__ . '/overview-modules.php';
require_once __DIR__ . '/overview-management.php';

/**
 * Registry of every module the Overview surface can render. The key is stored
 * in project_overview_modules.module_key; "page" is the default page a module
 * is seeded onto during bootstrap.
 *
 * @return array<string, array{key: string, label: string, description: string, page: string}>
 */
function project_overview_module_registry(): array
{
    return project_overview_v1_registry();
}

/**
 * Default Overview pages, seeded at creation or by migration.
 *
 * @return list<array{key: string, title: string}>
 */
function project_overview_default_pages(): array
{
    return [['key' => 'overview', 'title' => 'Overview']];
}

/**
 * Metadata for a single module key, or null when unknown.
 *
 * @return array{key: string, label: string, description: string, page: string}|null
 */
function project_overview_module_meta(string $moduleKey): ?array
{
    $registry = project_overview_module_registry();

    return $registry[$moduleKey] ?? null;
}

/**
 * Idempotently seed the default pages and modules for a project.
 */
function project_overview_bootstrap(int $projectId): void
{
    project_assert_writable($projectId);
    $connection = db();

    $pageStatement = $connection->prepare(
        'INSERT OR IGNORE INTO project_overview_pages
            (project_id, page_key, title, position, is_default)
         VALUES (?, ?, ?, ?, ?)'
    );

    foreach (project_overview_default_pages() as $position => $page) {
        $pageStatement->execute([
            $projectId,
            $page['key'],
            $page['title'],
            $position,
            $position === 0 ? 1 : 0,
        ]);
    }

    $registry = project_overview_module_registry();

    $pageIds = [];
    $idStatement = $connection->prepare(
        'SELECT id, page_key
         FROM project_overview_pages
         WHERE project_id = ? AND archived_at IS NULL'
    );
    $idStatement->execute([$projectId]);

    foreach ($idStatement->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $pageIds[(string) $row['page_key']] = (int) $row['id'];
    }

    $moduleStatement = $connection->prepare(
        'INSERT OR IGNORE INTO project_overview_modules
            (project_id, page_id, module_key, title, position, seed_key)
         VALUES (?, ?, ?, ?, ?, ?)'
    );

    $positionByPage = [];

    foreach ($registry as $module) {
        if (!in_array($module['key'], ['status', 'progress', 'tasks', 'members', 'activity'], true)) { continue; }
        $pageKey = (string) $module['page'];
        $pageId = $pageIds[$pageKey] ?? null;

        if ($pageId === null) {
            continue;
        }

        $positionByPage[$pageKey] = ($positionByPage[$pageKey] ?? 0);
        $position = $positionByPage[$pageKey];

        $moduleStatement->execute([
            $projectId,
            $pageId,
            $module['key'],
            $module['label'],
            $position,
            'starter_' . $module['key'],
        ]);

        $positionByPage[$pageKey] = $position + 1;
    }
}

/**
 * @return list<array{id: int, project_id: int, page_key: string, title: string, position: int, is_visible: int, is_default: int, archived_at: ?string, config_json: ?string}>
 */
function project_overview_all_pages(int $projectId): array
{
    $statement = db()->prepare(
        'SELECT id, project_id, page_key, title, position, is_visible, is_default, archived_at, config_json
         FROM project_overview_pages
         WHERE project_id = ?
         ORDER BY
             CASE WHEN archived_at IS NULL THEN 0 ELSE 1 END,
             position ASC,
             id ASC'
    );
    $statement->execute([$projectId]);

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Visible pages only, ordered by position.
 *
 * @return list<array{id: int, project_id: int, page_key: string, title: string, position: int, is_visible: int, is_default: int, archived_at: ?string, config_json: ?string}>
 */
function project_overview_pages(int $projectId): array
{
    $statement = db()->prepare(
        'SELECT id, project_id, page_key, title, position, is_visible, is_default, archived_at, config_json
         FROM project_overview_pages
         WHERE project_id = ? AND archived_at IS NULL AND is_visible = 1
         ORDER BY is_default DESC, position ASC, id ASC'
    );
    $statement->execute([$projectId]);

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Resolve the active default page. If legacy/incomplete data has no explicit
 * default, fall back deterministically to the first active visible page.
 *
 * @return array{id: int, project_id: int, page_key: string, title: string, position: int, is_visible: int, is_default: int, archived_at: ?string, config_json: ?string}|null
 */
function project_overview_default_page(int $projectId): ?array
{
    $statement = db()->prepare(
        'SELECT id, project_id, page_key, title, position, is_visible, is_default, archived_at, config_json
         FROM project_overview_pages
         WHERE project_id = ? AND archived_at IS NULL AND is_visible = 1
         ORDER BY is_default DESC, position ASC, id ASC
         LIMIT 1'
    );
    $statement->execute([$projectId]);
    $page = $statement->fetch(PDO::FETCH_ASSOC);

    return $page !== false ? $page : null;
}

/**
 * Fetch one active Overview page scoped to its Project.
 *
 * @return array{id: int, project_id: int, page_key: string, title: string, position: int, is_visible: int, is_default: int, archived_at: ?string, config_json: ?string}|null
 */
function project_overview_page(int $projectId, int $pageId): ?array
{
    $statement = db()->prepare(
        'SELECT id, project_id, page_key, title, position, is_visible, is_default, archived_at, config_json
         FROM project_overview_pages
         WHERE id = ? AND project_id = ? AND archived_at IS NULL
         LIMIT 1'
    );
    $statement->execute([$pageId, $projectId]);
    $page = $statement->fetch(PDO::FETCH_ASSOC);

    return $page !== false ? $page : null;
}

/**
 * Enabled module instances for a page, ordered by position, with the registry
 * label attached as a fallback title.
 *
 * @return list<array{id: int, page_id: int, module_key: string, title: string, position: int, config: ?string, label: string}>
 */
function project_overview_modules(int $projectId, int $pageId): array
{
    $statement = db()->prepare(
        'SELECT id, page_id, module_key, title, position, col_span, visibility, config
         FROM project_overview_modules
         WHERE project_id = ? AND page_id = ? AND is_enabled = 1
         ORDER BY position ASC, id ASC'
    );
    $statement->execute([$projectId, $pageId]);

    $modules = $statement->fetchAll(PDO::FETCH_ASSOC);

    foreach ($modules as &$module) {
        $meta = project_overview_module_meta((string) $module['module_key']);
        $module['label'] = $meta['label'] ?? (string) $module['module_key'];
    }
    unset($module);

    return $modules;
}

/**
 * All module instances (enabled and disabled) for a page, for the
 * manager-only configuration panel.
 *
 * @return list<array{id: int, page_id: int, module_key: string, title: string, position: int, is_enabled: int, config: ?string, label: string}>
 */
function project_overview_modules_all(int $projectId, int $pageId): array
{
    $statement = db()->prepare(
        'SELECT id, page_id, module_key, title, position, col_span, visibility, is_enabled, config
         FROM project_overview_modules
         WHERE project_id = ? AND page_id = ?
         ORDER BY position ASC, id ASC'
    );
    $statement->execute([$projectId, $pageId]);

    $modules = $statement->fetchAll(PDO::FETCH_ASSOC);

    foreach ($modules as &$module) {
        $meta = project_overview_module_meta((string) $module['module_key']);
        $module['label'] = $meta['label'] ?? (string) $module['module_key'];
    }
    unset($module);

    return $modules;
}

/**
 * Append an activity entry. Safe to call from any Project-scoped action.
 */
function project_overview_record_activity(
    int $projectId,
    int $actorUserId,
    string $type,
    string $summary,
    ?string $targetType = null,
    ?int $targetId = null
): void {
    if ($projectId <= 0 || $actorUserId <= 0 || !isset(project_overview_activity_types()[$type])) {
        throw new InvalidArgumentException('Invalid Project activity.');
    }
    project_assert_writable($projectId);
    // Caller text is deliberately discarded; external names never enter durable activity.
    $summary = project_overview_activity_summary($type);
    if (!in_array($targetType, ['drive_file', 'drive_folder', 'conversation', 'task_list', 'team', 'user', 'project'], true)) {
        $targetType = null;
        $targetId = null;
    }

    $statement = db()->prepare(
        'INSERT INTO project_activity
            (project_id, actor_user_id, activity_type, summary, target_type, target_id)
         VALUES (?, ?, ?, ?, ?, ?)'
    );

    $statement->execute([
        $projectId,
        $actorUserId,
        substr($type, 0, 80),
        substr($summary, 0, 500),
        $targetType !== null ? substr($targetType, 0, 80) : null,
        $targetId !== null && $targetId > 0 ? $targetId : null,
    ]);
}

/**
 * @return list<array{id: int, title: string, description: ?string, due_date: ?string, status: string, position: int, created_by: int, author_name: string, completed_by: ?int, completed_by_name: ?string, completed_at: ?string, created_at: string}>
 */
function project_overview_milestones(int $projectId, int $limit = 20): array
{
    $limit = max(1, min($limit, 100));

    $statement = db()->prepare(
        'SELECT
             m.id,
             m.title,
             m.description,
             m.due_date,
             m.status,
             m.position,
             m.created_by,
             author.display_name AS author_name,
             m.completed_by,
             completer.display_name AS completed_by_name,
             m.completed_at,
             m.created_at
         FROM project_milestones m
         INNER JOIN users author ON author.id = m.created_by
         LEFT JOIN users completer ON completer.id = m.completed_by
         WHERE m.project_id = ?
         ORDER BY
             CASE WHEN m.status = \'open\' THEN 0 ELSE 1 END,
             m.position ASC,
             CASE WHEN m.due_date IS NULL THEN 1 ELSE 0 END,
             m.due_date ASC,
             m.id ASC
         LIMIT ?'
    );
    $statement->execute([$projectId, $limit]);

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * @return list<array{id: int, title: string, body: ?string, is_pinned: int, author_id: int, author_name: string, archived_at: ?string, created_at: string}>
 */
function project_overview_activity(int $projectId, int $limit = 50): array
{
    $limit = max(1, min($limit, 100));

    $statement = db()->prepare(
        'SELECT
             a.id,
             a.activity_type,
             a.summary,
             actor.display_name AS actor_name,
             a.created_at
         FROM project_activity a
         INNER JOIN users actor ON actor.id = a.actor_user_id
         WHERE a.project_id = ?
         ORDER BY a.created_at DESC, a.id DESC
         LIMIT ?'
    );
    $statement->execute([$projectId, $limit]);

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * @return list<array{id: int, title: string, body: ?string, is_pinned: int, author_id: int, author_name: string, archived_at: ?string, created_at: string}>
 */
function project_overview_announcements(int $projectId, int $limit = 10): array
{
    $limit = max(1, min($limit, 100));

    $statement = db()->prepare(
        'SELECT
             a.id,
             a.title,
             a.body,
             a.is_pinned,
             a.author_id,
             author.display_name AS author_name,
             a.archived_at,
             a.created_at
         FROM project_announcements a
         INNER JOIN users author ON author.id = a.author_id
         WHERE a.project_id = ? AND a.archived_at IS NULL
         ORDER BY
             a.is_pinned DESC,
             a.created_at DESC,
             a.id DESC
         LIMIT ?'
    );
    $statement->execute([$projectId, $limit]);

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * @return list<array{id: int, title: string, url: string, kind: string, added_by: int, added_name: string, created_at: string}>
 */
function project_overview_links(int $projectId, int $limit = 20): array
{
    $limit = max(1, min($limit, 100));

    $statement = db()->prepare(
        'SELECT
             l.id,
             l.title,
             l.url,
             l.kind,
             l.added_by,
             adder.display_name AS added_name,
             l.created_at
         FROM project_links l
         INNER JOIN users adder ON adder.id = l.added_by
         WHERE l.project_id = ?
         ORDER BY l.created_at DESC, l.id DESC
         LIMIT ?'
    );
    $statement->execute([$projectId, $limit]);

    return $statement->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Escape a value for safe HTML output.
 */
function project_overview_e(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/**
 * Human-friendly date, or an em dash for null/empty.
 */
function project_overview_date(?string $value): string
{
    if ($value === null || $value === '') {
        return '&mdash;';
    }

    $timestamp = strtotime($value);

    if ($timestamp === false) {
        return project_overview_e($value);
    }

    return project_overview_e(date('M j, Y', $timestamp));
}

/**
 * Friendly label for a project status code.
 */
function project_overview_status_label(?string $status): string
{
    $status = (string) $status;

    $labels = [
        'planning' => 'Planning',
        'active' => 'Active',
        'on_hold' => 'On hold',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled',
        'archived' => 'Archived',
    ];

    return $labels[$status] ?? (string) $status;
}

/**
 * CSS class for a status badge.
 */
function project_overview_status_class(?string $status): string
{
    $status = (string) $status;

    $modifiers = [
        'planning' => '',
        'active' => 'badge--success',
        'on_hold' => 'badge--warning',
        'completed' => 'badge--success',
        'cancelled' => 'badge--danger',
        'archived' => '',
    ];

    return $modifiers[$status] ?? '';
}

/**
 * Render a full badge for a project status using the shared badge classes.
 */
function project_overview_status_badge(?string $status): string
{
    return '<span class="badge ' . project_overview_status_class($status) . '">'
        . project_overview_e(project_overview_status_label($status))
        . '</span>';
}

/**
 * Render an accessible progress bar (0-100).
 */
function project_overview_progress_bar(int $percent): string
{
    $percent = max(0, min(100, $percent));

    return '<div'
        . ' class="task-progress-track"'
        . ' role="progressbar"'
        . ' aria-valuemin="0"'
        . ' aria-valuemax="100"'
        . ' aria-valuenow="' . $percent . '"'
        . '>'
        . '<span class="task-progress-value" style="width: ' . $percent . '%"></span>'
        . '</div>';
}

/**
 * Render every enabled module for a page, each as its own section.
 */
function project_overview_render_page(int $workspaceId, int $projectId, int $userId, array $project, array $page, bool $canManage): void
{
    $access = workspace_access($userId);
    $isLeadOrAdmin = $access !== null && project_user_can_manage($access, $userId, $projectId);
    $modules = array_values(array_filter($page['modules'], static fn(array $module): bool => project_overview_module_visible($module, $isLeadOrAdmin)));
    $context = project_overview_context($modules, $workspaceId, $projectId, $userId);
    echo '<div class="project-overview-grid">';
    foreach ($modules as $module) {
        $title = trim((string) ($module['title'] ?? $module['label'] ?? ''));
        $span = max(1, min(3, (int) ($module['col_span'] ?? 1)));
        echo '<section class="section overview-span-' . $span . '"><h2>' . project_overview_e($title) . '</h2>';
        echo project_overview_render_v1($module, $project, $context);
        echo '</section>';
    }
    echo '</div>';
}
/**
 * Status, dates, and completion.
 */
function project_overview_module_status(array $project): string
{
    $html = '<div class="cluster">'
        . project_overview_status_badge($project['status'] ?? null)
        . '</div>';

    $items = [
        ['Start date', project_overview_date($project['start_date'] ?? null)],
        ['Target date', project_overview_date($project['target_date'] ?? null)],
    ];

    if (!empty($project['completed_at'])) {
        $items[] = ['Completed', project_overview_date((string) $project['completed_at'])];
    }

    if (!empty($project['archived_at'])) {
        $items[] = ['Archived', project_overview_date((string) $project['archived_at'])];
    }

    $html .= '<div class="record-meta">';

    foreach ($items as [$label, $value]) {
        $html .= '<div class="record-meta-item"><span>'
            . project_overview_e($label)
            . '</span><strong>' . $value . '</strong></div>';
    }

    $html .= '</div>';

    return $html;
}
