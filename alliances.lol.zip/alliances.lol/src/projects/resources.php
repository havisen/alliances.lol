<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Project resource attachments
|--------------------------------------------------------------------------
|
| Resource rows in project_resources persist only the reference
| (project_id, kind, resource_id). Metadata and links are re-fetched from
| the source subsystem (Drive or Messaging) at read time so that the source
| subsystem's authorization remains authoritative: a viewer only ever sees
| a resource they can still actually open in Drive or Messaging.
|
| No wrapped file keys, storage IDs, or conversation keys are stored or
| revealed here.
*/

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../projects.php';
require_once __DIR__ . '/../drive/drive.php';
require_once __DIR__ . '/../messaging/messaging.php';

/**
 * The resource kinds the overview surface supports.
 *
 * @return list<string>
 */
function project_resource_kinds(): array
{
    return ['drive_file', 'drive_folder', 'conversation'];
}

function project_resource_tables(): array
{
    return ['drive_file' => 'project_drive_files', 'drive_folder' => 'project_drive_folders',
        'conversation' => 'project_conversations'];
}

/**
 * Human readable label for a resource kind.
 */
function project_resource_kind_label(?string $kind): string
{
    return match ($kind) {
        'drive_file' => 'Drive file',
        'drive_folder' => 'Drive folder',
        'conversation' => 'Channel',
        default => 'Resource',
    };
}

/**
 * Revalidate a single Drive file against the exact authorization joins used by
 * the dedicated Drive search: an active effective grant, the current wrapped
 * key, a non-trashed file, and a visible (or root) folder chain.
 *
 * Returns the resolved row (id/name/mime/owner) or null when the file is no
 * longer accessible to this user.
 *
 * @return array{type: string, id: int, title: string, subtitle: string, url: string}|null
 */
function project_resource_revalidate_drive_file(
    int $workspaceId,
    int $userId,
    int $fileId
): ?array {
    $pdo = db();

    $statement = $pdo->prepare('
        WITH RECURSIVE visible_folders (id, parent_id, created_by, name, path) AS (
            SELECT id, parent_id, created_by, name, \'/\' || id || \'/\'
            FROM drive_folders
            WHERE workspace_id = :root_workspace_id
              AND parent_id IS NULL
              AND trashed_at IS NULL
            UNION ALL
            SELECT child.id, child.parent_id, child.created_by, child.name, visible_folders.path || child.id || \'/\'
            FROM drive_folders child
            INNER JOIN visible_folders ON child.parent_id = visible_folders.id
            WHERE child.workspace_id = :child_workspace_id
              AND child.trashed_at IS NULL
              AND instr(visible_folders.path, \'/\' || child.id || \'/\') = 0
        )
        SELECT df.id, df.original_name AS name, df.mime_type,
               owner.display_name AS owner_name
        FROM drive_files df
        INNER JOIN drive_effective_access dfa
            ON dfa.file_id = df.id AND dfa.user_id = :access_user_id
        INNER JOIN drive_file_keys dfk
            ON dfk.file_id = df.id
           AND dfk.user_id = :key_user_id
           AND dfk.key_version = df.key_version
        INNER JOIN users owner ON owner.id = df.uploaded_by
        LEFT JOIN visible_folders vf ON vf.id = df.folder_id
        WHERE df.id = :file_id
          AND df.workspace_id = :file_workspace_id
          AND df.trashed_at IS NULL
           AND (df.folder_id IS NULL OR vf.id IS NOT NULL)
         LIMIT 1
    ');

    $statement->execute([
        ':root_workspace_id' => $workspaceId,
        ':child_workspace_id' => $workspaceId,
        ':access_user_id' => $userId,
        ':key_user_id' => $userId,
        ':file_id' => $fileId,
        ':file_workspace_id' => $workspaceId,
    ]);

    $file = $statement->fetch(PDO::FETCH_ASSOC);

    if ($file === false) {
        return null;
    }

    return [
        'type' => 'drive_file',
        'id' => (int) $file['id'],
        'title' => (string) $file['name'],
        'mime_type' => $file['mime_type'],
        'subtitle' => (string) ($file['owner_name'] ?? ''),
        'url' => '/drive/editor.php?file_id=' . (int) $file['id'],
    ];
}

/**
 * Revalidate a single Drive folder (non-trashed and outside any trashed
 * ancestor chain).
 *
 * @return array{type: string, id: int, title: string, subtitle: string, url: string}|null
 */
function project_resource_revalidate_drive_folder(int $workspaceId, int $userId, int $folderId): ?array
{
    return drive_accessible_folder($workspaceId, $userId, $folderId);
}

/**
 * Revalidate a Messaging conversation. Direct messages are intentionally
 * excluded: only channels/groups can be shared onto a Project surface.
 *
 * @return array{type: string, id: int, title: string, subtitle: string, url: string}|null
 */
function project_resource_revalidate_conversation(
    int $workspaceId,
    int $userId,
    int $conversationId
): ?array {
    $conversation = messaging_conversation($conversationId, $userId);

    if ($conversation === null) {
        return null;
    }

    if ((int) $conversation['workspace_id'] !== $workspaceId
        || !in_array($conversation['type'], ['channel', 'group'], true)) {
        return null;
    }

    return [
        'type' => 'conversation',
        'conversation_type' => $conversation['type'],
        'id' => (int) $conversation['id'],
        'title' => (string) $conversation['name'],
        'subtitle' => trim((string) ($conversation['description'] ?? '')) !== ''
            ? (string) $conversation['description']
            : 'Channel',
        'url' => '/messaging/?conversation_id=' . (int) $conversation['id'],
    ];
}

/**
 * Revalidate a resource reference against the source subsystem.
 *
 * @return array{type: string, id: int, title: string, subtitle: string, url: string}|null
 */
function project_resource_revalidate(
    int $workspaceId,
    int $userId,
    string $kind,
    int $resourceId
): ?array {
    return match ($kind) {
        'drive_file' => project_resource_revalidate_drive_file(
            $workspaceId,
            $userId,
            $resourceId
        ),
        'drive_folder' => project_resource_revalidate_drive_folder(
            $workspaceId,
            $userId,
            $resourceId
        ),
        'conversation' => project_resource_revalidate_conversation(
            $workspaceId,
            $userId,
            $resourceId
        ),
        default => null,
    };
}

/**
 * Attach a resource to a project after revalidating that the caller can
 * actually access it in the source subsystem. Idempotent: re-attaching an
 * already attached resource is a success.
 */
function project_resource_attach(
    int $projectId,
    string $kind,
    int $resourceId,
    int $addedBy,
    int $workspaceId
): void {
    project_assert_writable($projectId);
    if ($projectId <= 0 || $addedBy <= 0 || $resourceId <= 0) {
        throw new InvalidArgumentException('Invalid resource reference.');
    }

    if (!in_array($kind, project_resource_kinds(), true)) {
        throw new InvalidArgumentException('Unsupported resource kind.');
    }

    $resolved = project_resource_revalidate(
        $workspaceId,
        $addedBy,
        $kind,
        $resourceId
    );

    if ($resolved === null) {
        throw new InvalidArgumentException(
            'That resource is not accessible to you anymore.'
        );
    }

    $table = project_resource_tables()[$kind];
    $statement = db()->prepare('INSERT OR IGNORE INTO ' . $table
        . ' (project_id, resource_id, added_by) SELECT ?, ?, ? FROM projects
            WHERE id = ? AND workspace_id = ? AND status != \'archived\'');

    $statement->execute([
        $projectId,
        $resourceId,
        $addedBy,
        $projectId,
        $workspaceId,
    ]);
}

/**
 * Remove a resource attachment from a project.
 */
function project_resource_remove(
    int $projectId,
    string $kind,
    int $resourceId
): void {
    project_assert_writable($projectId);
    if ($projectId <= 0 || $resourceId <= 0) {
        throw new InvalidArgumentException('Invalid resource reference.');
    }

    if (!in_array($kind, project_resource_kinds(), true)) {
        throw new InvalidArgumentException('Unsupported resource kind.');
    }

    $table = project_resource_tables()[$kind];
    $statement = db()->prepare('DELETE FROM ' . $table . ' WHERE project_id = ? AND resource_id = ?
        AND EXISTS (SELECT 1 FROM projects WHERE projects.id = ' . $table . '.project_id AND status != \'archived\')');
    $statement->execute([$projectId, $resourceId]);
}

/**
 * Read all resource attachments for a project, revalidating each one against
 * the source subsystem and dropping references that are no longer accessible.
 *
 * @return list<array{type: string, id: int, title: string, subtitle: string, url: string, added_by: int, created_at: string}>
 */
function project_resources_for_project(
    int $projectId,
    int $workspaceId,
    int $userId
): array {
    $statement = db()->prepare(project_resource_union_sql());
    $statement->execute([$projectId, $projectId, $projectId]);

    $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

    $resources = [];

    foreach ($rows as $row) {
        $kind = (string) $row['kind'];
        $resourceId = (int) $row['resource_id'];

        $resolved = project_resource_revalidate(
            $workspaceId,
            $userId,
            $kind,
            $resourceId
        );

        if ($resolved === null) {
            $resolved = ['type' => $kind, 'id' => $resourceId, 'title' => 'Resource unavailable',
                'subtitle' => '', 'url' => '', 'unavailable' => true];
        }

        $resolved['added_by'] = (int) $row['added_by'];
        $resolved['created_at'] = (string) $row['created_at'];

        $resources[] = $resolved;
    }

    return $resources;
}

function project_resource_union_sql(): string
{
    $parts = [];
    foreach (project_resource_tables() as $kind => $table) {
        $parts[] = "SELECT '$kind' AS kind, resource_id, added_by, created_at FROM $table WHERE project_id = ?";
    }
    return implode(' UNION ALL ', $parts) . ' ORDER BY created_at DESC, resource_id DESC LIMIT 200';
}

/**
 * Searchable Drive picker. Reuses the proven authorization joins from the
 * dedicated Drive search so the picker can never expose metadata that Drive
 * search would not also expose.
 *
 * @return list<array{type: string, id: int, title: string, subtitle: string}>
 */
function project_resource_picker_drive(
    int $workspaceId,
    int $userId,
    string $query
): array {
    $query = trim($query);

    if ($query === '') {
        return [];
    }

    $results = drive_search_metadata(
        $workspaceId,
        $userId,
        '%' . $query . '%'
    );

    $items = [];

    foreach (array_slice($results['folders'], 0, 20) as $folder) {
        $items[] = [
            'type' => 'drive_folder',
            'id' => (int) $folder['id'],
            'title' => (string) $folder['name'],
            'subtitle' => (string) ($folder['owner_name'] ?? 'Folder'),
        ];
    }

    foreach (array_slice($results['files'], 0, 20) as $file) {
        $items[] = [
            'type' => 'drive_file',
            'id' => (int) $file['id'],
            'title' => (string) $file['name'],
            'subtitle' => (string) ($file['owner_name'] ?? 'File'),
        ];
    }

    return $items;
}

/**
 * Searchable Messaging picker for accessible channels/groups that the user is
 * already a member of. Direct messages are excluded.
 *
 * @return list<array{type: string, id: int, title: string, subtitle: string}>
 */
function project_resource_picker_conversations(
    int $workspaceId,
    int $userId,
    string $query
): array {
    $query = trim($query);

    if ($query === '') {
        return [];
    }

    $statement = db()->prepare(
        'SELECT c.id, c.name, c.description
         FROM conversations c
         INNER JOIN conversation_members cm
             ON cm.conversation_id = c.id AND cm.user_id = :user_id
         WHERE c.workspace_id = :workspace_id
           AND c.type IN (\'channel\', \'group\')
           AND c.name LIKE :query COLLATE NOCASE
         ORDER BY c.name COLLATE NOCASE ASC, c.id ASC
         LIMIT 20'
    );

    $statement->execute([
        ':user_id' => $userId,
        ':workspace_id' => $workspaceId,
        ':query' => '%' . $query . '%',
    ]);

    $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

    $items = [];

    foreach ($rows as $row) {
        $items[] = [
            'type' => 'conversation',
            'id' => (int) $row['id'],
            'title' => (string) $row['name'],
            'subtitle' => trim((string) ($row['description'] ?? '')) !== ''
                ? (string) $row['description']
                : 'Channel',
        ];
    }

    return $items;
}
