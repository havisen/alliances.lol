<?php

declare(strict_types=1);

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/entity-links.php';
require_once __DIR__ . '/projects.php';
require_once __DIR__ . '/drive/drive.php';

/**
 * Universal search across the workspace the current user belongs to.
 *
 * Every category enforces its own authorization:
 *
 * - People:      active workspace members only.
 * - Teams:       active teams in the workspace.
 * - Projects:    workspace admin or effective Project member; excludes archived.
 * - Tasks/lists: strictly membership-based via task_list_members.
 * - Calendar:    workspace-wide events.
 * - Drive:       metadata only, requiring an effective grant and the
 *                current user's wrapped key (see drive_search_metadata).
 *
 * @return array{results: array<int, array<string, mixed>>, count: int}
 */
function alliances_search(
    array $user,
    array $access,
    string $query
): array {
    $workspaceId = (int) $access['workspace_id'];
    $userId = (int) $user['id'];

    $query = trim($query);

    if ($query === '') {
        return ['results' => [], 'count' => 0];
    }

    if (mb_strlen($query) > 200) {
        $query = mb_substr($query, 0, 200);
    }

    $likeQuery = '%' . $query . '%';

    $results = [];

    $results = array_merge(
        $results,
        alliances_search_people($workspaceId, $likeQuery)
    );

    $results = array_merge(
        $results,
        alliances_search_teams($workspaceId, $likeQuery)
    );

    $results = array_merge(
        $results,
        alliances_search_projects($access, $userId, $likeQuery)
    );

    $results = array_merge(
        $results,
        alliances_search_task_lists($workspaceId, $userId, $likeQuery)
    );

    $results = array_merge(
        $results,
        alliances_search_tasks($workspaceId, $userId, $likeQuery)
    );

    $results = array_merge(
        $results,
        alliances_search_calendar_events($workspaceId, $likeQuery)
    );

    $drive = drive_search_metadata($workspaceId, $userId, $likeQuery);

    foreach ($drive['folders'] as $folder) {
        $results[] = [
            'type' => 'drive_folder',
            'id' => (int) $folder['id'],
            'title' => (string) $folder['name'],
            'subtitle' => 'Folder',
            'url' => '/drive/',
        ];
    }

    foreach ($drive['files'] as $file) {
        $editorable = drive_file_editor_supported(
            (string) $file['name'],
            $file['mime_type']
        );

        $results[] = [
            'type' => 'drive_file',
            'id' => (int) $file['id'],
            'title' => (string) $file['name'],
            'subtitle' => $editorable
                ? 'Open in encrypted editor'
                : 'Download file',
            'url' => $editorable
                ? '/drive/editor.php?file_id=' . (int) $file['id']
                : '/drive/',
        ];
    }

    return [
        'results' => $results,
        'count' => count($results),
    ];
}

function alliances_search_people(
    int $workspaceId,
    string $likeQuery
): array {
    $statement = db()->prepare(
        'SELECT u.id, u.display_name, u.email, u.job_title
         FROM users u
         INNER JOIN workspace_members wm ON wm.user_id = u.id
         WHERE wm.workspace_id = ?
           AND u.account_status = \'active\'
           AND (
               u.display_name LIKE ? COLLATE NOCASE
               OR u.email LIKE ? COLLATE NOCASE
           )
         ORDER BY u.display_name COLLATE NOCASE ASC, u.id ASC
         LIMIT 20'
    );

    $statement->execute([$workspaceId, $likeQuery, $likeQuery]);

    $results = [];

    foreach ($statement->fetchAll() as $row) {
        $subtitle = trim((string) ($row['job_title'] ?? ''));

        if ($subtitle === '') {
            $subtitle = (string) $row['email'];
        }

        $results[] = [
            'type' => 'people',
            'id' => (int) $row['id'],
            'title' => (string) $row['display_name'],
            'subtitle' => $subtitle,
            'url' => alliances_profile_url((int) $row['id']),
        ];
    }

    return $results;
}


function alliances_search_teams(
    int $workspaceId,
    string $likeQuery
): array {
    $statement = db()->prepare(
        'SELECT t.id, t.name
         FROM teams t
         WHERE t.workspace_id = ?
           AND t.status = \'active\'
           AND t.name LIKE ? COLLATE NOCASE
         ORDER BY t.name COLLATE NOCASE ASC, t.id ASC
         LIMIT 20'
    );

    $statement->execute([$workspaceId, $likeQuery]);

    $results = [];

    foreach ($statement->fetchAll() as $row) {
        $results[] = [
            'type' => 'team',
            'id' => (int) $row['id'],
            'title' => (string) $row['name'],
            'subtitle' => 'Team',
            'url' => alliances_team_url((int) $row['id']),
        ];
    }

    return $results;
}


/** Reuse the Project list's authorization helpers; search is not an access grant. */
function alliances_search_projects(array $access, int $userId, string $likeQuery): array
{
    $workspaceId = (int) ($access['workspace_id'] ?? 0);
    if ($workspaceId <= 0 || $userId <= 0) {
        return [];
    }

    // Match the ordinary Projects list: archived Projects remain available via
    // its Show archived control, but are excluded from Universal Search.
    $projects = !empty($access['is_admin'])
        ? projects_for_workspace($workspaceId, false, $likeQuery, 20)
        : projects_for_user($workspaceId, $userId, false, $likeQuery, 20);

    $results = [];
    foreach ($projects as $project) {
        $status = ucfirst(str_replace('_', ' ', (string) $project['status']));
        $description = trim(preg_replace('/\s+/u', ' ', (string) ($project['description'] ?? '')) ?? '');
        if (mb_strlen($description) > 140) {
            $description = mb_substr($description, 0, 139) . '…';
        }

        $results[] = [
            'type' => 'project',
            'id' => (int) $project['id'],
            'title' => (string) $project['name'],
            'subtitle' => 'Project · ' . $status . ($description !== '' ? ' · ' . $description : ''),
            'url' => '/projects/project.php?id=' . (int) $project['id'],
        ];
    }

    return $results;
}


function alliances_search_task_lists(
    int $workspaceId,
    int $userId,
    string $likeQuery
): array {
    $statement = db()->prepare(
        'SELECT tl.id, tl.name, tl.status
         FROM task_lists tl
         INNER JOIN task_list_members tlm ON tlm.task_list_id = tl.id
         WHERE tl.workspace_id = ?
           AND tlm.user_id = ?
           AND tl.name LIKE ? COLLATE NOCASE
         ORDER BY tl.name COLLATE NOCASE ASC, tl.id ASC
         LIMIT 20'
    );

    $statement->execute([$workspaceId, $userId, $likeQuery]);

    $results = [];

    foreach ($statement->fetchAll() as $row) {
        $results[] = [
            'type' => 'task_list',
            'id' => (int) $row['id'],
            'title' => (string) $row['name'],
            'subtitle' => $row['status'] === 'completed'
                ? 'Task list · Completed'
                : 'Task list',
            'url' => '/tasks/task-list.php?id=' . (int) $row['id'],
        ];
    }

    return $results;
}


function alliances_search_tasks(
    int $workspaceId,
    int $userId,
    string $likeQuery
): array {
    $statement = db()->prepare(
        'SELECT tk.id, tk.name, tk.status, tk.task_list_id
         FROM tasks tk
         INNER JOIN task_list_members tlm ON tlm.task_list_id = tk.task_list_id
         INNER JOIN task_lists tl ON tl.id = tk.task_list_id
         WHERE tl.workspace_id = ?
           AND tlm.user_id = ?
           AND tk.name LIKE ? COLLATE NOCASE
         ORDER BY tk.name COLLATE NOCASE ASC, tk.id ASC
         LIMIT 20'
    );

    $statement->execute([$workspaceId, $userId, $likeQuery]);

    $results = [];

    foreach ($statement->fetchAll() as $row) {
        $results[] = [
            'type' => 'task',
            'id' => (int) $row['id'],
            'title' => (string) $row['name'],
            'subtitle' => $row['status'] === 'completed'
                ? 'Task · Completed'
                : 'Task',
            'url' => '/tasks/task-list.php?id=' . (int) $row['task_list_id'],
        ];
    }

    return $results;
}


function alliances_search_calendar_events(
    int $workspaceId,
    string $likeQuery
): array {
    $statement = db()->prepare(
        'SELECT ce.id, ce.title, ce.starts_at
         FROM calendar_events ce
         WHERE ce.workspace_id = ?
           AND ce.title LIKE ? COLLATE NOCASE
         ORDER BY ce.starts_at DESC, ce.id DESC
         LIMIT 20'
    );

    $statement->execute([$workspaceId, $likeQuery]);

    $results = [];

    foreach ($statement->fetchAll() as $row) {
        $startsAt = trim((string) ($row['starts_at'] ?? ''));

        if ($startsAt !== '') {
            $startsAt = str_replace(
                'T',
                ' ',
                substr($startsAt, 0, 16)
            );
        }

        $results[] = [
            'type' => 'calendar_event',
            'id' => (int) $row['id'],
            'title' => (string) $row['title'],
            'subtitle' => $startsAt !== ''
                ? 'Calendar event · ' . $startsAt
                : 'Calendar event',
            'url' => '/calendar.php',
        ];
    }

    return $results;
}

