<?php

declare(strict_types=1);

require_once __DIR__ . '/../database.php';

/*
|--------------------------------------------------------------------------
| Work Template authorization
|--------------------------------------------------------------------------
|
| Reuses the existing Alliances workspace authorization model. There is no
| generic RBAC for templates.
|
| Templates are workspace-scoped and shared across all team task lists, so
| only a Workspace Administrator may manage them. Team leads are deliberately
| NOT treated as administrators here.
|
*/

function work_template_can_manage(array $access): bool
{
    return (bool) ($access['is_admin'] ?? false);
}

/**
 * Existing Task List management permission.
 *
 * A Task List can be managed by its creator or a Workspace Administrator.
 * Project authority never factors into this check; Task List management is an
 * independent boundary from Project management.
 */
function task_list_can_manage(array $access, array $list, int $userId): bool
{
    if (!empty($access['is_admin'])) {
        return true;
    }

    if ($userId <= 0) {
        return false;
    }

    return (int) ($list['created_by'] ?? 0) === $userId;
}

/** Task access always requires both workspace scope and explicit list membership. */
function task_for_member(int $workspaceId, int $userId, int $taskId): ?array
{
    $statement = db()->prepare(
        'SELECT t.*, tl.workspace_id, tl.name AS list_name,
                tl.created_by AS list_created_by, tl.members_can_edit,
                assigned.display_name AS assigned_to_name,
                assigned.account_status AS assigned_to_status
         FROM tasks t
         INNER JOIN task_lists tl ON tl.id = t.task_list_id
         INNER JOIN task_list_members viewer
             ON viewer.task_list_id = tl.id AND viewer.user_id = ?
         LEFT JOIN users assigned ON assigned.id = t.assigned_to
             AND EXISTS (
                 SELECT 1 FROM workspace_members wm
                 WHERE wm.user_id = assigned.id AND wm.workspace_id = tl.workspace_id
             )
         WHERE t.id = ? AND tl.workspace_id = ?
         LIMIT 1'
    );
    $statement->execute([$userId, $taskId, $workspaceId]);

    return $statement->fetch() ?: null;
}

/** Call only after task_for_member has established access. */
function task_can_edit(array $task, int $userId): bool
{
    return $userId > 0 && (
        (int) $task['list_created_by'] === $userId
        || (int) $task['members_can_edit'] === 1
    );
}

/** The existing completion rule also governs reopening. */
function task_can_complete(array $task, int $userId): bool
{
    return $userId > 0 && (
        (int) $task['list_created_by'] === $userId
        || $task['assigned_to'] === null
        || (int) $task['assigned_to'] === $userId
    );
}

/** Only active workspace users who already belong to this list can be assigned. */
function task_assignee_choices(int $workspaceId, int $listId): array
{
    $statement = db()->prepare(
        'SELECT u.id, u.display_name
         FROM task_list_members member
         INNER JOIN task_lists tl ON tl.id = member.task_list_id
         INNER JOIN users u ON u.id = member.user_id
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id AND wm.workspace_id = tl.workspace_id
         WHERE tl.id = ? AND tl.workspace_id = ? AND u.account_status = "active"
         ORDER BY u.display_name COLLATE NOCASE ASC, u.id ASC'
    );
    $statement->execute([$listId, $workspaceId]);

    return $statement->fetchAll(PDO::FETCH_KEY_PAIR);
}
