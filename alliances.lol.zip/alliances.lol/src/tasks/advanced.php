<?php

declare(strict_types=1);

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/fields.php';
require_once __DIR__ . '/templates.php';
require_once __DIR__ . '/values.php';
require_once __DIR__ . '/access.php';
require_once __DIR__ . '/lists.php';
require_once __DIR__ . '/formula.php';
require_once __DIR__ . '/../projects.php';
require_once __DIR__ . '/../drive/drive.php';
require_once __DIR__ . '/../projects/resources.php';

/*
|--------------------------------------------------------------------------
| Advanced field value pipeline
|--------------------------------------------------------------------------
|
| Relations, evidence, artifacts, structured state, and approvals live in
| normalized Task-owned tables. Calculated fields (formula/lookup/rollup) are
| computed on read. Nothing in this file grants authorization: every target id
| is re-resolved against the current viewer's access, and a Task evidence/
| reference row NEVER grants Drive access.
|
*/

/**
 * Find a field definition inside the task's immutable sections.
 *
 * @param array<int, array<string, mixed>> $sections
 * @return array<string, mixed>|null
 */
function work_template_advanced_field_by_key(array $sections, string $fieldKey): ?array
{
    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            if (work_template_field_key($field['field_key'] ?? null, (int) $field['id']) === $fieldKey) {
                return $field;
            }
        }
    }

    return null;
}

/** Field keys are unique within one version. */
function work_template_advanced_fields_by_key(array $sections): array
{
    $map = [];
    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            $map[(string) $field['field_key']] = $field;
        }
    }

    return $map;
}

/** @return list<string> */
function work_template_advanced_target_types(array $field): array
{
    $type = (string) $field['field_type'];

    return match ($type) {
        'task_relation' => ['task'],
        'project_relation' => ['project'],
        'file_relation' => ['file'],
        'record_relation' => ['record'],
        'relation' => array_values(array_unique(array_map(
            'strval',
            (array) ($field['config']['target_types'] ?? [])
        ))),
        default => [],
    };
}

/**
 * Resolve a Drive file for the current viewer with full re-checks: same
 * workspace, exists, not trashed, and current effective access. Returns only
 * safe metadata; never exposes path, storage id, or wrapped key information.
 *
 * @return array{id: int, name: string, mime_type: ?string}|null
 */
function work_template_drive_visible_file(int $workspaceId, int $userId, int $fileId): ?array
{
    $file = project_resource_revalidate_drive_file($workspaceId, $userId, $fileId);
    return $file === null ? null : ['id' => $file['id'], 'name' => $file['title'], 'mime_type' => $file['mime_type']];
}
function work_template_drive_file_is_image(?string $mimeType): bool
{
    return $mimeType !== null && str_starts_with(strtolower($mimeType), 'image/');
}

/**
 * Re-resolve a relation target fully against the current viewer.
 *
 * @return array{label: string, url: ?string, target_type: string, target_id: int}|null
 */
function work_template_advanced_resolve_target(
    int $workspaceId,
    int $userId,
    array $access,
    string $targetType,
    int $targetId
): ?array {
    if ($targetId <= 0) {
        return null;
    }

    if ($targetType === 'task' || $targetType === 'record') {
        $task = task_for_member($workspaceId, $userId, $targetId);
        if ($task === null) {
            return null;
        }
        if ($targetType === 'record' && $task['template_version_id'] === null) {
            return null;
        }

        return [
            'label' => (string) $task['name'],
            'url' => '/tasks/task.php?id=' . $targetId,
            'target_type' => $targetType,
            'target_id' => $targetId,
        ];
    }

    if ($targetType === 'project') {
        $project = project_by_id($targetId, $workspaceId);
        if ($project === null || !project_user_can_view($access, $userId, $targetId)) {
            return null;
        }

        return [
            'label' => (string) $project['name'],
            'url' => '/projects/project.php?id=' . $targetId,
            'target_type' => $targetType,
            'target_id' => $targetId,
        ];
    }

    if ($targetType === 'file') {
        $file = work_template_drive_visible_file($workspaceId, $userId, $targetId);
        if ($file === null) {
            return null;
        }

        return [
            'label' => $file['name'],
            'url' => null,
            'target_type' => $targetType,
            'target_id' => $targetId,
        ];
    }

    return null;
}

/*
|--------------------------------------------------------------------------
| Batch state loaders (avoid N+1)
|--------------------------------------------------------------------------
*/

/** @return array<int, list<array<string, mixed>>> */
function work_template_advanced_load_relations(int $taskId): array
{
    $statement = db()->prepare(
        'SELECT field_key, target_type, target_id, sort_order
         FROM task_value_relations
         WHERE task_id = ?
         ORDER BY sort_order ASC, id ASC'
    );
    $statement->execute([$taskId]);

    $result = [];
    foreach ($statement->fetchAll() as $row) {
        $result[(string) $row['field_key']][] = [
            'target_type' => (string) $row['target_type'],
            'target_id' => (int) $row['target_id'],
            'sort_order' => (int) $row['sort_order'],
        ];
    }

    return $result;
}

/** @return array<int, list<array<string, mixed>>> */
function work_template_advanced_load_evidence(int $taskId): array
{
    $statement = db()->prepare(
        'SELECT field_key, drive_file_id, mime_type, sort_order
         FROM task_value_evidence
         WHERE task_id = ?
         ORDER BY sort_order ASC, id ASC'
    );
    $statement->execute([$taskId]);

    $result = [];
    foreach ($statement->fetchAll() as $row) {
        $result[(string) $row['field_key']][] = [
            'drive_file_id' => (int) $row['drive_file_id'],
            'mime_type' => $row['mime_type'] !== null ? (string) $row['mime_type'] : null,
            'sort_order' => (int) $row['sort_order'],
        ];
    }

    return $result;
}

/** @return array<int, array<string, array<string, mixed>>> field_key => row_key => column_key => value */
function work_template_advanced_load_table(int $taskId): array
{
    $rows = db()->prepare(
        'SELECT field_key, row_key, sort_order
         FROM task_value_table_rows
         WHERE task_id = ?
         ORDER BY sort_order ASC, id ASC'
    );
    $rows->execute([$taskId]);

    $cells = db()->prepare(
        'SELECT field_key, row_key, column_key, value_text, value_integer, value_real, value_json
         FROM task_value_table_cells
         WHERE task_id = ?
         ORDER BY id ASC'
    );
    $cells->execute([$taskId]);

    $result = [];
    foreach ($rows->fetchAll() as $row) {
        $result[(string) $row['field_key']][(string) $row['row_key']] = [];
    }
    foreach ($cells->fetchAll() as $cell) {
        $value = $cell['value_json'] !== null
            ? json_decode((string) $cell['value_json'], true)
            : ($cell['value_integer'] !== null
                ? (int) $cell['value_integer']
                : ($cell['value_real'] !== null
                    ? (float) $cell['value_real']
                    : $cell['value_text']));
        $result[(string) $cell['field_key']][(string) $cell['row_key']][(string) $cell['column_key']]
            = is_array($value) ? $value : (string) $value;
    }

    return $result;
}

/** @return array<int, array<string, array<string, mixed>>> field_key => instance_key => child_key => value */
function work_template_advanced_load_repeater(int $taskId): array
{
    $instances = db()->prepare(
        'SELECT field_key, instance_key, sort_order
         FROM task_value_repeater_instances
         WHERE task_id = ?
         ORDER BY sort_order ASC, id ASC'
    );
    $instances->execute([$taskId]);

    $values = db()->prepare(
        'SELECT field_key, instance_key, child_key, value_text, value_integer, value_real, value_json
         FROM task_value_repeater_values
         WHERE task_id = ?
         ORDER BY id ASC'
    );
    $values->execute([$taskId]);

    $result = [];
    foreach ($instances->fetchAll() as $row) {
        $result[(string) $row['field_key']][(string) $row['instance_key']] = [];
    }
    foreach ($values->fetchAll() as $row) {
        $value = $row['value_json'] !== null
            ? json_decode((string) $row['value_json'], true)
            : ($row['value_integer'] !== null
                ? (int) $row['value_integer']
                : ($row['value_real'] !== null
                    ? (float) $row['value_real']
                    : $row['value_text']));
        $result[(string) $row['field_key']][(string) $row['instance_key']][(string) $row['child_key']]
            = is_array($value) ? $value : (string) $value;
    }

    return $result;
}

/** @return array<int, list<array<string, mixed>>> field_key => decision history (oldest first) */
function work_template_advanced_load_approvals(int $taskId): array
{
    $statement = db()->prepare(
        'SELECT a.id, a.field_key, a.cycle, a.event_type, a.decision, a.comment, a.decided_by, a.decided_by_name,
                a.decided_at, a.created_at, u.display_name AS actor_name
         FROM task_value_approvals a
         LEFT JOIN users u ON u.id = a.decided_by
         WHERE a.task_id = ?
         ORDER BY a.id ASC'
    );
    $statement->execute([$taskId]);

    $result = [];
    foreach ($statement->fetchAll() as $row) {
        $result[(string) $row['field_key']][] = [
            'id' => (int) $row['id'],
            'cycle' => (int) $row['cycle'],
            'event_type' => (string) $row['event_type'],
            'decision' => (string) $row['decision'],
            'comment' => $row['comment'] !== null ? (string) $row['comment'] : '',
            'decided_by' => $row['decided_by'] !== null ? (int) $row['decided_by'] : null,
            'decided_by_name' => (string) ($row['decided_by_name'] !== ''
                ? $row['decided_by_name']
                : ($row['actor_name'] ?? '')),
            'decided_at' => $row['decided_at'] !== null ? (string) $row['decided_at'] : (string) $row['created_at'],
        ];
    }

    return $result;
}

/**
 * @return array<string, mixed>
 */
function work_template_advanced_load(int $taskId): array
{
    return [
        'relations' => work_template_advanced_load_relations($taskId),
        'evidence' => work_template_advanced_load_evidence($taskId),
        'artifacts' => work_template_advanced_load_artifacts($taskId),
        'checklists' => work_template_advanced_load_checklists($taskId),
        'table' => work_template_advanced_load_table($taskId),
        'repeater' => work_template_advanced_load_repeater($taskId),
        'approvals' => work_template_advanced_load_approvals($taskId),
    ];
}

/*
|--------------------------------------------------------------------------
| Calculated fields (formula/lookup/rollup)
|--------------------------------------------------------------------------
*/

/** @return array<string, string> field_key => formula source */
function work_template_advanced_formula_sources(array $sections): array
{
    $formulas = [];
    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            if ($field['field_type'] === 'formula') {
                $formulas[(string) $field['field_key']]
                    = (string) ($field['config']['formula'] ?? '');
            }
        }
    }

    return $formulas;
}

/**
 * Map the task's stored numeric leaves (real/integer storage, not computed) to
 * field keys so formulas can reference them.
 *
 * @param array<int, mixed> $currentValues field_key => current value
 * @return array<string, float|null>
 */
function work_template_advanced_numeric_leaves(array $sections, array $currentValues): array
{
    $leaves = [];
    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            $type = (string) $field['field_type'];
            $storage = work_template_field_storage($type);
            if (!in_array($storage, ['real', 'integer'], true)
                || work_template_field_is_computed($type)) {
                continue;
            }
            $value = $currentValues[(int) $field['id']] ?? null;
            $leaves[(string) $field['field_key']] = is_numeric($value)
                ? (float) $value
                : null;
        }
    }

    return $leaves;
}

/*
|--------------------------------------------------------------------------
| Mutations (called by the save endpoint after full validation)
|--------------------------------------------------------------------------
*/

/**
 * @param list<array{target_type: string, target_id: int}> $rows
 */
function work_template_advanced_replace_relations(int $taskId, string $fieldKey, array $rows): void
{
    $connection = db();
    $connection->beginTransaction();

    try {
        $delete = $connection->prepare(
            'DELETE FROM task_value_relations WHERE task_id = ? AND field_key = ?'
        );
        $delete->execute([$taskId, $fieldKey]);

        $insert = $connection->prepare(
            'INSERT INTO task_value_relations (task_id, field_key, target_type, target_id, sort_order)
             VALUES (?, ?, ?, ?, ?)'
        );
        $order = 0;
        foreach ($rows as $row) {
            $insert->execute([
                $taskId,
                $fieldKey,
                $row['target_type'],
                (int) $row['target_id'],
                $order++,
            ]);
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

/**
 * @param list<array{drive_file_id: int, mime_type: ?string}> $rows
 */
function work_template_advanced_replace_evidence(int $taskId, string $fieldKey, array $rows): void
{
    $connection = db();
    $connection->beginTransaction();

    try {
        $delete = $connection->prepare(
            'DELETE FROM task_value_evidence WHERE task_id = ? AND field_key = ?'
        );
        $delete->execute([$taskId, $fieldKey]);

        $insert = $connection->prepare(
            'INSERT INTO task_value_evidence (task_id, field_key, drive_file_id, mime_type, sort_order)
             VALUES (?, ?, ?, ?, ?)'
        );
        $order = 0;
        foreach ($rows as $row) {
            $insert->execute([
                $taskId,
                $fieldKey,
                (int) $row['drive_file_id'],
                $row['mime_type'] ?? null,
                $order++,
            ]);
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

/**
 * @param array<string, mixed> $artifact
 */
function work_template_advanced_upsert_artifact(int $taskId, string $fieldKey, array $artifact): void
{
    $connection = db();
    $connection->beginTransaction();

    try {
        $delete = $connection->prepare(
            'DELETE FROM task_value_artifacts WHERE task_id = ? AND field_key = ?'
        );
        $delete->execute([$taskId, $fieldKey]);

        $insert = $connection->prepare(
            'INSERT INTO task_value_artifacts
                (task_id, field_key, kind, signer_id, signer_name, signed_at, typed_name,
                 mime_type, width, height, payload)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $insert->execute([
            $taskId,
            $fieldKey,
            (string) $artifact['kind'],
            $artifact['signer_id'] ?? null,
            $artifact['signer_name'] ?? null,
            $artifact['signed_at'] ?? null,
            $artifact['typed_name'] ?? null,
            (string) ($artifact['mime_type'] ?? 'image/png'),
            $artifact['width'] ?? null,
            $artifact['height'] ?? null,
            (string) $artifact['payload'],
        ]);

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

/**
 * @param list<array{key: string, label: string}> $steps
 * @param array<string, array{checked: bool, result: string, notes: string}> $submitted
 */
function work_template_advanced_save_checklist(
    int $taskId,
    string $fieldKey,
    array $steps,
    array $submitted,
    bool $structured
): void {
    $connection = db();
    $connection->beginTransaction();

    try {
        $delete = $connection->prepare(
            'DELETE FROM task_value_checklist_items WHERE task_id = ? AND field_key = ?'
        );
        $delete->execute([$taskId, $fieldKey]);

        $upsert = $connection->prepare(
            'INSERT INTO task_value_checklist_items
                (task_id, field_key, step_key, checked, result, notes, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );

        $order = 0;
        foreach ($steps as $step) {
            $key = (string) $step['key'];
            $state = $submitted[$key] ?? null;
            $checked = $state !== null && !empty($state['checked']) ? 1 : 0;
            $result = $structured && $state !== null ? trim((string) ($state['result'] ?? '')) : null;
            $notes = $structured && $state !== null ? trim((string) ($state['notes'] ?? '')) : null;

            $upsert->execute([
                $taskId,
                $fieldKey,
                $key,
                $checked,
                $result !== null && $result !== '' ? $result : null,
                $notes !== null && $notes !== '' ? $notes : null,
                $order++,
            ]);
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

/**
 * @param list<array{key: string, label: string, type: string}> $columns
 * @param array<string, array<string, string>> $submittedRows row_key => column_key => value
 */
function work_template_advanced_save_table(
    int $taskId,
    string $fieldKey,
    array $columns,
    array $submittedRows
): void {
    $connection = db();
    $connection->beginTransaction();

    try {
        $connection->prepare('DELETE FROM task_value_table_cells WHERE task_id = ? AND field_key = ?')
            ->execute([$taskId, $fieldKey]);
        $connection->prepare('DELETE FROM task_value_table_rows WHERE task_id = ? AND field_key = ?')
            ->execute([$taskId, $fieldKey]);

        $insertRow = $connection->prepare(
            'INSERT INTO task_value_table_rows (task_id, field_key, row_key, sort_order)
             VALUES (?, ?, ?, ?)'
        );
        $insertCell = $connection->prepare(
            'INSERT INTO task_value_table_cells
                (task_id, field_key, row_key, column_key, value_text, value_integer, value_real, value_json)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );

        $order = 0;
        foreach ($submittedRows as $rowKey => $cells) {
            $insertRow->execute([$taskId, $fieldKey, (string) $rowKey, $order++]);

            foreach ($columns as $column) {
                $columnKey = (string) $column['key'];
                $raw = (string) ($cells[$columnKey] ?? '');
                $typed = work_template_advanced_typed_value((string) $column['type'], $raw);

                $insertCell->execute([
                    $taskId,
                    $fieldKey,
                    (string) $rowKey,
                    $columnKey,
                    $typed['value_text'],
                    $typed['value_integer'],
                    $typed['value_real'],
                    $typed['value_json'],
                ]);
            }
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

/**
 * Map a raw table/repeater cell value onto typed columns.
 *
 * @return array{value_text: ?string, value_integer: ?int, value_real: ?float, value_json: ?string}
 */
function work_template_advanced_typed_value(string $childType, string $raw): array
{
    $value = [
        'value_text' => null,
        'value_integer' => null,
        'value_real' => null,
        'value_json' => null,
    ];

    if ($raw === '') {
        return $value;
    }

    if ($childType === 'number') {
        $value['value_real'] = is_numeric($raw) ? (float) $raw : null;
    } elseif ($childType === 'integer') {
        $value['value_integer'] = is_numeric($raw) ? (int) $raw : null;
    } else {
        $value['value_text'] = $raw;
    }

    return $value;
}

/**
 * Compute formula/lookup/rollup values for every calculated field of a task.
 *
 * @param array<int, mixed>           $currentValues field_key => current value
 * @param array<string, mixed>        $advanced      loaded advanced state
 * @return array<string, mixed> field_key => ?float|string
 */
function work_template_advanced_compute_fields(
    array $sections,
    array $currentValues,
    array $advanced,
    int $workspaceId,
    int $userId,
    array $access
): array {
    $fieldsByKey = work_template_advanced_fields_by_key($sections);
    $formulas = work_template_advanced_formula_sources($sections);
    $leaves = work_template_advanced_numeric_leaves($sections, $currentValues);
    $formulaResults = work_template_formula_evaluate_all($formulas, $leaves);

    $computed = $formulaResults;

    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            $type = (string) $field['field_type'];
            $key = (string) $field['field_key'];
            if ($type !== 'lookup' && $type !== 'rollup') {
                continue;
            }

            $config = (array) ($field['config'] ?? []);
            $relationKey = (string) ($config['relation_field_key'] ?? '');
            $relationField = $fieldsByKey[$relationKey] ?? null;
            if ($relationField === null || work_template_advanced_target_types($relationField) === []) {
                $computed[$key] = null;
                continue;
            }

            $relations = (array) ($advanced['relations'][(string) $relationField['field_key']] ?? []);

            $visible = [];
            foreach ($relations as $relation) {
                if ($type === 'lookup' && ($config['target_type'] ?? '') !== $relation['target_type']) {
                    continue;
                }
                $resolved = work_template_advanced_resolve_target(
                    $workspaceId,
                    $userId,
                    $access,
                    (string) $relation['target_type'],
                    (int) $relation['target_id']
                );
                if ($resolved !== null) {
                    $visible[] = $resolved;
                }
            }
            $computed[$key] = $type === 'rollup'
                ? (($config['operation'] ?? '') === 'count' && empty($config['value_field_key']) ? count($visible) : null)
                : (($config['descriptor'] ?? '') === 'name' ? ($visible[0]['label'] ?? null) : null);
        }
    }

    return $computed;
}

/**
 * Render an advanced field's value (and, when editable, a form to change it)
 * for the Task doing-surface.
 *
 * @param array<string, mixed>      $advanced   loaded advanced state
 * @param array<string, mixed>      $computed   field_key => computed value
 */
function work_template_advanced_render_field(
    array $field,
    int $taskId,
    array $advanced,
    int $workspaceId,
    int $userId,
    array $access,
    bool $canEdit,
    array $computed
): string {
    $escape = static fn (string $text): string =>
        htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    $type = (string) $field['field_type'];
    $fieldKey = work_template_field_key($field['field_key'] ?? null, (int) $field['id']);
    $key = (string) $field['field_key'];

    if (work_template_field_is_computed($type)) {
        $value = $computed[$key] ?? null;
        if ($value === null || $value === '') {
            return '<span class="muted">—</span>';
        }
        if (is_float($value) || is_int($value)) {
            return '<span>' . $escape(work_template_format_bound((float) $value)) . '</span>';
        }

        return '<span>' . $escape((string) $value) . '</span>';
    }

    $relationTypes = ['relation', 'task_relation', 'project_relation', 'file_relation', 'record_relation'];
    $evidenceTypes = ['file', 'files', 'photo', 'photos'];

    if (in_array($type, $relationTypes, true)) {
        $rows = (array) ($advanced['relations'][$fieldKey] ?? []);
        $allowed = work_template_advanced_target_types($field);
        $resolved = [];
        foreach ($rows as $row) {
            $entry = work_template_advanced_resolve_target(
                $workspaceId,
                $userId,
                $access,
                (string) $row['target_type'],
                (int) $row['target_id']
            );
            if ($entry === null) {
                $resolved[] = '<span class="muted">Unavailable</span>';
                continue;
            }
            $resolved[] = $entry['url'] !== null
                ? '<a href="' . $escape($entry['url']) . '">' . $escape($entry['label']) . '</a>'
                : $escape($entry['label']);
        }

        $out = $resolved === []
            ? '<span class="muted">No relations.</span>'
            : implode('<br>', $resolved);

        if ($canEdit) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form">'
                . csrf_input()
                . '<input type="hidden" name="action" value="save_relations">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">';
            foreach ($rows as $index => $row) {
                $out .= '<div class="form-row">'
                    . '<select name="target_type[]">';
                foreach ($allowed as $targetType) {
                    $selected = (string) ($row['target_type'] ?? '') === $targetType ? 'selected' : '';
                    $out .= '<option value="' . $escape($targetType) . '" ' . $selected . '>'
                        . $escape($targetType) . '</option>';
                }
                $out .= '</select>'
                    . '<input type="number" name="target_id[]" value="'
                    . (int) ($row['target_id'] ?? 0) . '">'
                    . '</div>';
            }
            $out .= '<div class="form-row">'
                . '<select name="target_type[]">';
            foreach ($allowed as $targetType) {
                $out .= '<option value="' . $escape($targetType) . '">' . $escape($targetType) . '</option>';
            }
            $out .= '</select><input type="number" name="target_id[]" value="">'
                . '</div>'
                . '<div class="form-actions"><button class="primary-action">Save relations</button></div>'
                . '</form>';
        }

        return $out;
    }

    if (in_array($type, $evidenceTypes, true)) {
        $rows = (array) ($advanced['evidence'][$fieldKey] ?? []);
        $resolved = [];
        foreach ($rows as $row) {
            $file = work_template_drive_visible_file(
                $workspaceId,
                $userId,
                (int) $row['drive_file_id']
            );
            $resolved[] = $file !== null
                ? $escape($file['name'])
                : '<span class="muted">Unavailable</span>';
        }
        $out = $resolved === []
            ? '<span class="muted">Nothing attached.</span>'
            : implode('<br>', $resolved);

        if ($canEdit) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form">'
                . csrf_input()
                . '<input type="hidden" name="action" value="save_evidence">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">'
                . '<div class="form-row">'
                . '<input type="number" name="drive_file_id[]" placeholder="Drive file id">'
                . '</div>'
                . '<p class="form-hint">Attach an existing Drive file you can access. A Task reference never grants Drive access.</p>'
                . '<div class="form-actions"><button class="primary-action">Attach</button></div>'
                . '</form>';
        }

        return $out;
    }

    // signature / drawing
    if ($type === 'signature' || $type === 'drawing') {
        $artifacts = (array) ($advanced['artifacts'][$fieldKey] ?? []);
        $latest = end($artifacts) ?: null;
        $out = '';
        if ($latest !== null && trim((string) ($latest['payload'] ?? '')) !== '') {
            $out .= '<img class="task-advanced-artifact" src="data:image/png;base64,'
                . $escape((string) $latest['payload']) . '" alt="">';
        } else {
            $out .= '<span class="muted">Nothing recorded.</span>';
        }
        if ($type === 'signature' && $latest !== null) {
            $name = (string) ($latest['signer_name'] ?? '');
            $out .= '<p class="form-hint">Signed by '
                . $escape($name !== '' ? $name : 'a removed user') . '</p>';
        }
        if ($canEdit) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form" data-artifact>'
                . csrf_input()
                . '<input type="hidden" name="action" value="save_artifact">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">'
                . ($type === 'signature'
                    ? '<div class="form-group"><label class="form-label">Typed name</label>'
                        . '<input type="text" name="typed_name" maxlength="200"></div>'
                    : '')
                . '<div class="form-group"><canvas class="task-advanced-canvas" data-canvas width="400" height="160"></canvas></div>'
                . '<input type="hidden" name="payload" value="">'
                . '<div class="form-actions"><button class="primary-action">Save</button></div>'
                . '</form>';
        }

        return $out;
    }

    // checklist / structured checklist
    if ($type === 'checklist' || $type === 'structured_checklist') {
        $steps = (array) ($field['config']['steps'] ?? []);
        $state = (array) ($advanced['checklists'][$fieldKey] ?? []);
        $structured = $type === 'structured_checklist';
        $out = '';
        if ($steps === []) {
            $out = '<span class="muted">No steps defined.</span>';
        } else {
            $out .= '<ul class="task-advanced-list">';
            foreach ($steps as $step) {
                $itemState = $state[(string) $step['key']] ?? null;
                $checked = $itemState !== null && !empty($itemState['checked']);
                $out .= '<li>' . ($checked ? 'Y ' : '- ') . $escape((string) $step['label']);
                if ($structured && $itemState !== null) {
                    if (trim((string) ($itemState['result'] ?? '')) !== '') {
                        $out .= ' : ' . $escape((string) $itemState['result']);
                    }
                    if (trim((string) ($itemState['notes'] ?? '')) !== '') {
                        $out .= ' (' . $escape((string) $itemState['notes']) . ')';
                    }
                }
                $out .= '</li>';
            }
            $out .= '</ul>';
        }
        if ($canEdit) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form">'
                . csrf_input()
                . '<input type="hidden" name="action" value="save_checklist">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">';
            foreach ($steps as $step) {
                $stepKey = (string) $step['key'];
                $itemState = $state[$stepKey] ?? null;
                $checked = $itemState !== null && !empty($itemState['checked']);
                $out .= '<label class="task-template-checkbox"><input type="checkbox" name="steps['
                    . $escape($stepKey) . '][checked]" value="1" '
                    . ($checked ? 'checked' : '') . '> ' . $escape((string) $step['label']) . '</label>';
                if ($structured) {
                    $out .= '<div class="form-row">'
                        . '<input type="text" name="steps[' . $escape($stepKey) . '][result]" placeholder="Result" value="'
                        . $escape((string) ($itemState['result'] ?? '')) . '">'
                        . '<input type="text" name="steps[' . $escape($stepKey) . '][notes]" placeholder="Notes" value="'
                        . $escape((string) ($itemState['notes'] ?? '')) . '">'
                        . '</div>';
                }
            }
            $out .= '<div class="form-actions"><button class="primary-action">Save checklist</button></div></form>';
        }

        return $out;
    }

    // table
    if ($type === 'table') {
        $columns = (array) ($field['config']['columns'] ?? []);
        $rows = (array) ($advanced['table'][$fieldKey] ?? []);
        $out = '<div class="table-wrapper"><table class="task-advanced-table"><thead><tr>';
        foreach ($columns as $column) {
            $out .= '<th>' . $escape((string) $column['label']) . '</th>';
        }
        $out .= '</tr></thead><tbody>';
        foreach ($rows as $rowCells) {
            $out .= '<tr>';
            foreach ($columns as $column) {
                $out .= '<td>' . $escape((string) ($rowCells[(string) $column['key']] ?? '')) . '</td>';
            }
            $out .= '</tr>';
        }
        $out .= '</tbody></table></div>';
        if ($canEdit) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form" data-table>'
                . csrf_input()
                . '<input type="hidden" name="action" value="save_table">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">';
            foreach ($rows as $rowCells) {
                $out .= '<div class="form-row">';
                foreach ($columns as $column) {
                    $out .= '<input type="text" name="rows[][' . $escape((string) $column['key']) . ']" value="'
                        . $escape((string) ($rowCells[(string) $column['key']] ?? '')) . '">';
                }
                $out .= '</div>';
            }
            $out .= '<div class="form-row">';
            foreach ($columns as $column) {
                $out .= '<input type="text" name="rows[][' . $escape((string) $column['key']) . ']" value="">';
            }
            $out .= '</div><div class="form-actions"><button class="primary-action">Save table</button></div></form>';
        }

        return $out;
    }

    // repeater
    if ($type === 'repeater') {
        $children = (array) ($field['config']['children'] ?? []);
        $instances = (array) ($advanced['repeater'][$fieldKey] ?? []);
        $out = '<ul class="task-advanced-list">';
        if ($instances === []) {
            $out .= '<li><span class="muted">No entries.</span></li>';
        }
        foreach ($instances as $values) {
            $parts = [];
            foreach ($children as $child) {
                $parts[] = $escape((string) $child['label']) . ': '
                    . $escape((string) ($values[(string) $child['key']] ?? ''));
            }
            $out .= '<li>' . implode(', ', $parts) . '</li>';
        }
        $out .= '</ul>';
        if ($canEdit) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form" data-repeater>'
                . csrf_input()
                . '<input type="hidden" name="action" value="save_repeater">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">';
            foreach ($instances as $values) {
                $out .= '<div class="form-row">';
                foreach ($children as $child) {
                    $out .= '<input type="text" name="instances[][' . $escape((string) $child['key']) . ']" placeholder="'
                        . $escape((string) $child['label']) . '" value="'
                        . $escape((string) ($values[(string) $child['key']] ?? '')) . '">';
                }
                $out .= '</div>';
            }
            $out .= '<div class="form-actions"><button class="primary-action">Save</button></div></form>';
        }

        return $out;
    }

    // approval
    if ($type === 'approval') {
        $history = (array) ($advanced['approvals'][$fieldKey] ?? []);
        $out = '<ul class="task-advanced-list">';
        if ($history === []) {
            $out .= '<li><span class="muted">No decisions yet.</span></li>';
        }
        foreach ($history as $entry) {
            $out .= '<li>Cycle ' . (int) $entry['cycle'] . ': <span class="badge">' . $escape(ucfirst(str_replace('_', ' ', (string) $entry['decision'])))
                . '</span> ' . $escape((string) $entry['decided_by_name']) . '</li>';
            if (trim((string) $entry['comment']) !== '') {
                $out .= '<li class="muted">' . $escape((string) $entry['comment']) . '</li>';
            }
        }
        $out .= '</ul>';
        $latest = $history === [] ? null : $history[array_key_last($history)];
        $pending = ($latest['decision'] ?? '') === 'pending';
        $canRequest = $canEdit && !empty($field['config']['approver_ids']);
        if (($pending && work_template_approval_can_decide($field, $userId)) || (!$pending && $canRequest)) {
            $out .= '<form method="post" action="/actions/tasks/save-advanced.php" class="form">'
                . csrf_input()
                . '<input type="hidden" name="action" value="' . ($pending ? 'save_approval' : 'request_approval') . '">'
                . '<input type="hidden" name="task_id" value="' . $taskId . '">'
                . '<input type="hidden" name="field_key" value="' . $escape($fieldKey) . '">'
                . '<input type="hidden" name="expected_decision_id" value="' . (int) ($latest['id'] ?? 0) . '">'
                . '<div class="form-row"><select name="decision">'
                . ($pending
                    ? '<option value="approved">Approve</option><option value="rejected">Reject</option><option value="changes_requested">Request changes</option>'
                    : '<option value="pending">Request approval in a new cycle</option>')
                . '</select>'
                . '<input type="text" name="comment" maxlength="500" placeholder="Comment">'
                . '</div>'
                . '<div class="form-actions"><button class="primary-action">Record decision</button></div></form>';
        }

        return $out;
    }

    return '<span class="muted">-</span>';
}

/**
 * @param list<array{key: string, label: string, type: string}> $children
 * @param array<string, array<string, string>> $submittedInstances instance_key => child_key => value
 */
function work_template_advanced_save_repeater(
    int $taskId,
    string $fieldKey,
    array $children,
    array $submittedInstances
): void {
    $connection = db();
    $connection->beginTransaction();

    try {
        $connection->prepare('DELETE FROM task_value_repeater_values WHERE task_id = ? AND field_key = ?')
            ->execute([$taskId, $fieldKey]);
        $connection->prepare('DELETE FROM task_value_repeater_instances WHERE task_id = ? AND field_key = ?')
            ->execute([$taskId, $fieldKey]);

        $insertInstance = $connection->prepare(
            'INSERT INTO task_value_repeater_instances (task_id, field_key, instance_key, sort_order)
             VALUES (?, ?, ?, ?)'
        );
        $insertValue = $connection->prepare(
            'INSERT INTO task_value_repeater_values
                (task_id, field_key, instance_key, child_key, value_text, value_integer, value_real, value_json)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );

        $order = 0;
        foreach ($submittedInstances as $instanceKey => $values) {
            $insertInstance->execute([$taskId, $fieldKey, (string) $instanceKey, $order++]);

            foreach ($children as $child) {
                $childKey = (string) $child['key'];
                $raw = (string) ($values[$childKey] ?? '');
                $typed = work_template_advanced_typed_value((string) $child['type'], $raw);

                $insertValue->execute([
                    $taskId,
                    $fieldKey,
                    (string) $instanceKey,
                    $childKey,
                    $typed['value_text'],
                    $typed['value_integer'],
                    $typed['value_real'],
                    $typed['value_json'],
                ]);
            }
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }
        throw $error;
    }
}

/**
 * @param array{decision: string, comment: string, decided_by: ?int, decided_by_name: string} $decision
 */
function work_template_approval_can_decide(array $field, int $userId): bool
{
    return $userId > 0 && ($field['field_type'] ?? '') === 'approval'
        && in_array($userId, (array) ($field['config']['approver_ids'] ?? []), true);
}

function work_template_approval_transition_allowed(string $current, string $next): bool
{
    return $current === 'pending'
        ? in_array($next, ['approved', 'rejected', 'changes_requested'], true)
        : in_array($current, ['not_requested', 'approved', 'rejected', 'changes_requested'], true) && $next === 'pending';
}

function work_template_advanced_append_approval(int $workspaceId, int $taskId, string $fieldKey, array $decision): void
{
    $actor = (int) ($decision['decided_by'] ?? 0);
    $task = task_for_member($workspaceId, $actor, $taskId);
    $definition = work_template_task_definition($workspaceId, $taskId);
    $field = work_template_advanced_field_by_key($definition['sections'] ?? [], $fieldKey);
    $request = ($decision['event_type'] ?? '') === 'requested';
    if ($task === null || $field === null || $field['field_type'] !== 'approval'
        || ($request ? (!task_can_edit($task, $actor) || empty($field['config']['approver_ids']))
            : !work_template_approval_can_decide($field, $actor))
        || ($request !== ($decision['decision'] === 'pending'))) {
        throw new InvalidArgumentException('Approval permission required.');
    }
    $history = work_template_advanced_load_approvals($taskId)[$fieldKey] ?? [];
    $latest = $history === [] ? null : $history[array_key_last($history)];
    $expected = (int) ($decision['expected_decision_id'] ?? -1);
    if ($expected !== (int) ($latest['id'] ?? 0)
        || !work_template_approval_transition_allowed($latest['decision'] ?? 'not_requested', $decision['decision'])) {
        throw new InvalidArgumentException('Approval changed. Refresh before recording another decision.');
    }
    $comment = trim((string) ($decision['comment'] ?? ''));
    if (mb_strlen($comment) > 500 || (($request && $latest !== null || $decision['decision'] === 'changes_requested') && $comment === '')) {
        throw new InvalidArgumentException('Comments are limited to 500 characters; changes and new cycles require a reason.');
    }
    $statement = db()->prepare(
        'INSERT INTO task_value_approvals
            (task_id, field_key, decided_by, decided_by_name, decision, comment, cycle, event_type, decided_at)
         SELECT ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
         WHERE COALESCE((SELECT MAX(id) FROM task_value_approvals WHERE task_id = ? AND field_key = ?), 0) = ?'
    );
    $statement->execute([
        $taskId,
        $fieldKey,
        $decision['decided_by'] ?? null,
        $decision['decided_by_name'] ?? '',
        $decision['decision'],
        $comment !== '' ? $comment : null,
        (int) ($latest['cycle'] ?? 0) + ($request ? 1 : 0),
        $request ? 'requested' : 'decision',
        $taskId, $fieldKey, $expected,
    ]);
    if ($statement->rowCount() !== 1) {
        throw new InvalidArgumentException('Approval changed. Refresh before recording another decision.');
    }
}

/** @return array<int, list<array<string, mixed>>> */
function work_template_advanced_load_artifacts(int $taskId): array
{
    $statement = db()->prepare(
        'SELECT id, field_key, kind, signer_id, signer_name, signed_at, typed_name,
                mime_type, width, height, payload, created_at
         FROM task_value_artifacts
         WHERE task_id = ?
         ORDER BY id ASC'
    );
    $statement->execute([$taskId]);

    $result = [];
    foreach ($statement->fetchAll() as $row) {
        $result[(string) $row['field_key']][] = $row;
    }

    return $result;
}

/** @return array<int, array<string, array<string, mixed>>> field_key => step_key => state */
function work_template_advanced_load_checklists(int $taskId): array
{
    $statement = db()->prepare(
        'SELECT field_key, step_key, checked, result, notes, sort_order
         FROM task_value_checklist_items
         WHERE task_id = ?
         ORDER BY sort_order ASC, id ASC'
    );
    $statement->execute([$taskId]);

    $result = [];
    foreach ($statement->fetchAll() as $row) {
        $result[(string) $row['field_key']][(string) $row['step_key']] = [
            'checked' => (int) $row['checked'] === 1,
            'result' => $row['result'] !== null ? (string) $row['result'] : '',
            'notes' => $row['notes'] !== null ? (string) $row['notes'] : '',
        ];
    }

    return $result;
}
