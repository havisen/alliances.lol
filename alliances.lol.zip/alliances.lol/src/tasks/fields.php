<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/database.php';

/*
|--------------------------------------------------------------------------
| Work Template field registry
|--------------------------------------------------------------------------
|
| This registry is the authoritative map from a field_type string to its
| storage column and validation behaviour.
|
| The submitted field_type is NEVER trusted. The definition loaded from the
| task's immutable template version is looked up here to decide which typed
| column receives the value.
|
*/

function work_template_field_types(): array
{
    return [
        // Text
        'short_text' => [
            'label' => 'Short text',
            'storage' => 'text',
            'control' => 'text',
            'category' => 'Text',
        ],
        'long_text' => [
            'label' => 'Long text',
            'storage' => 'text',
            'control' => 'textarea',
            'category' => 'Text',
        ],
        'rich_text' => [
            'label' => 'Rich text',
            'storage' => 'text',
            'control' => 'richtext',
            'category' => 'Text',
        ],
        'code' => [
            'label' => 'Code',
            'storage' => 'text',
            'control' => 'code',
            'category' => 'Text',
        ],

        // Numbers
        'number' => [
            'label' => 'Number',
            'storage' => 'real',
            'control' => 'number',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        'integer' => [
            'label' => 'Whole number',
            'storage' => 'integer',
            'control' => 'integer',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        'decimal' => [
            'label' => 'Decimal',
            'storage' => 'real',
            'control' => 'decimal',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        'number_unit' => [
            'label' => 'Number with unit',
            'storage' => 'real',
            'control' => 'number_unit',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        'currency' => [
            'label' => 'Currency',
            'storage' => 'real',
            'control' => 'currency',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        'percentage' => [
            'label' => 'Percentage',
            'storage' => 'real',
            'control' => 'percentage',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        'range' => [
            'label' => 'Range',
            'storage' => 'real',
            'control' => 'range',
            'category' => 'Numbers',
            'config' => ['min', 'max', 'step'],
        ],
        'rating' => [
            'label' => 'Rating',
            'storage' => 'real',
            'control' => 'rating',
            'category' => 'Numbers',
            'config' => ['min', 'max'],
        ],
        // Boolean / State
        'yes_no' => [
            'label' => 'Yes / No',
            'storage' => 'text',
            'control' => 'yes_no',
            'category' => 'Boolean / State',
        ],
        'checkbox' => [
            'label' => 'Checkbox',
            'storage' => 'integer',
            'control' => 'checkbox',
            'category' => 'Boolean / State',
        ],
        'pass_fail' => [
            'label' => 'Pass / Fail',
            'storage' => 'text',
            'control' => 'pass_fail',
            'category' => 'Boolean / State',
        ],
        'tri_state' => [
            'label' => 'Tri-state',
            'storage' => 'text',
            'control' => 'tri_state',
            'category' => 'Boolean / State',
        ],
        'status' => [
            'label' => 'Status',
            'storage' => 'text',
            'control' => 'status',
            'category' => 'Boolean / State',
            'custom_options' => true,
        ],
        // Choice
        'dropdown' => [
            'label' => 'Dropdown',
            'storage' => 'text',
            'control' => 'dropdown',
            'category' => 'Choice',
            'custom_options' => true,
        ],
        'multi_select' => [
            'label' => 'Multi-select',
            'storage' => 'json',
            'control' => 'multi_select',
            'category' => 'Choice',
            'custom_options' => true,
        ],
        'radio' => [
            'label' => 'Radio buttons',
            'storage' => 'text',
            'control' => 'radio',
            'category' => 'Choice',
            'custom_options' => true,
        ],
        'checkbox_group' => [
            'label' => 'Checkbox group',
            'storage' => 'json',
            'control' => 'checkbox_group',
            'category' => 'Choice',
            'custom_options' => true,
        ],
        'scale' => [
            'label' => 'Scale',
            'storage' => 'real',
            'control' => 'scale',
            'category' => 'Choice',
            'config' => ['min', 'max', 'step', 'labels'],
        ],
        // Date / Time
        'date' => [
            'label' => 'Date',
            'storage' => 'text',
            'control' => 'date',
            'category' => 'Date / Time',
        ],
        'datetime' => [
            'label' => 'Date & time',
            'storage' => 'text',
            'control' => 'datetime',
            'category' => 'Date / Time',
        ],
        'time' => [
            'label' => 'Time',
            'storage' => 'text',
            'control' => 'time',
            'category' => 'Date / Time',
        ],
        'date_range' => [
            'label' => 'Date range',
            'storage' => 'json',
            'control' => 'date_range',
            'category' => 'Date / Time',
        ],
        'time_range' => [
            'label' => 'Time range',
            'storage' => 'json',
            'control' => 'time_range',
            'category' => 'Date / Time',
        ],
        'duration' => [
            'label' => 'Duration (seconds)',
            'storage' => 'integer',
            'control' => 'duration',
            'category' => 'Date / Time',
        ],
        // People
        'email' => [
            'label' => 'Email',
            'storage' => 'text',
            'control' => 'email',
            'category' => 'People',
        ],
        'phone' => [
            'label' => 'Phone',
            'storage' => 'text',
            'control' => 'phone',
            'category' => 'People',
        ],
        'url' => [
            'label' => 'URL',
            'storage' => 'text',
            'control' => 'url',
            'category' => 'People',
        ],
        'person' => [
            'label' => 'Person',
            'storage' => 'integer',
            'control' => 'person',
            'category' => 'People',
        ],
        'team' => [
            'label' => 'Team',
            'storage' => 'integer',
            'control' => 'team',
            'category' => 'People',
        ],

        // Location
        'address' => [
            'label' => 'Address',
            'storage' => 'text',
            'control' => 'address',
            'category' => 'Location',
        ],
        'location' => [
            'label' => 'Location',
            'storage' => 'text',
            'control' => 'location',
            'category' => 'Location',
        ],
        'coordinates' => [
            'label' => 'Coordinates',
            'storage' => 'json',
            'control' => 'coordinates',
            'category' => 'Location',
        ],

        // Specialized
        'color' => [
            'label' => 'Color',
            'storage' => 'text',
            'control' => 'color',
            'category' => 'Specialized',
        ],
        'version' => [
            'label' => 'Version',
            'storage' => 'text',
            'control' => 'version',
            'category' => 'Specialized',
        ],
        'ip_address' => [
            'label' => 'IP address',
            'storage' => 'text',
            'control' => 'ip_address',
            'category' => 'Specialized',
        ],
        'barcode' => [
            'label' => 'Barcode',
            'storage' => 'text',
            'control' => 'barcode',
            'category' => 'Specialized',
        ],
        'qr_code' => [
            'label' => 'QR code',
            'storage' => 'text',
            'control' => 'qr_code',
            'category' => 'Specialized',
        ],

        // People (multi-value, creation-time)
        'people' => [
            'label' => 'People',
            'storage' => 'json',
            'control' => 'people',
            'category' => 'People',
            'available' => true,
            'creation' => true,
        ],
        'teams' => [
            'label' => 'Teams',
            'storage' => 'json',
            'control' => 'teams',
            'category' => 'People',
            'available' => true,
            'creation' => true,
        ],
        'project_role' => [
            'label' => 'Project role',
            'storage' => 'json',
            'control' => 'project_role',
            'category' => 'People',
            'available' => true,
            'creation' => true,
        ],

        // Evidence
        'file' => [
            'label' => 'File',
            'storage' => 'json',
            'control' => 'file',
            'category' => 'Evidence',
            'available' => true,
            'normalized' => true,
        ],
        'files' => [
            'label' => 'Files',
            'storage' => 'json',
            'control' => 'files',
            'category' => 'Evidence',
            'available' => true,
            'normalized' => true,
        ],
        'photo' => [
            'label' => 'Photo',
            'storage' => 'json',
            'control' => 'photo',
            'category' => 'Evidence',
            'available' => true,
            'normalized' => true,
        ],
        'photos' => [
            'label' => 'Photos',
            'storage' => 'json',
            'control' => 'photos',
            'category' => 'Evidence',
            'available' => true,
            'normalized' => true,
        ],
        'signature' => [
            'label' => 'Signature',
            'storage' => 'json',
            'control' => 'signature',
            'category' => 'Evidence',
            'available' => true,
            'normalized' => true,
        ],
        'drawing' => [
            'label' => 'Drawing',
            'storage' => 'json',
            'control' => 'drawing',
            'category' => 'Evidence',
            'available' => true,
            'normalized' => true,
        ],

        // Relations
        'relation' => [
            'label' => 'Relation',
            'storage' => 'json',
            'control' => 'relation',
            'category' => 'Relations',
            'available' => true,
            'normalized' => true,
        ],
        'task_relation' => [
            'label' => 'Task relation',
            'storage' => 'json',
            'control' => 'task_relation',
            'category' => 'Relations',
            'available' => true,
            'normalized' => true,
        ],
        'project_relation' => [
            'label' => 'Project relation',
            'storage' => 'json',
            'control' => 'project_relation',
            'category' => 'Relations',
            'available' => true,
            'normalized' => true,
        ],
        'file_relation' => [
            'label' => 'File relation',
            'storage' => 'json',
            'control' => 'file_relation',
            'category' => 'Relations',
            'available' => true,
            'normalized' => true,
        ],
        'record_relation' => [
            'label' => 'Record relation',
            'storage' => 'json',
            'control' => 'record_relation',
            'category' => 'Relations',
            'available' => true,
            'normalized' => true,
        ],
        'asset_relation' => [
            'label' => 'Asset relation',
            'storage' => 'json',
            'control' => 'asset_relation',
            'category' => 'Relations',
            'available' => false,
            'normalized' => true,
        ],

        // Calculated (read-only, no eval)
        'formula' => [
            'label' => 'Formula',
            'storage' => 'json',
            'control' => 'formula',
            'category' => 'Calculated',
            'available' => true,
            'computed' => true,
        ],
        'lookup' => [
            'label' => 'Lookup',
            'storage' => 'json',
            'control' => 'lookup',
            'category' => 'Calculated',
            'available' => true,
            'computed' => true,
        ],
        'rollup' => [
            'label' => 'Rollup',
            'storage' => 'json',
            'control' => 'rollup',
            'category' => 'Calculated',
            'available' => true,
            'computed' => true,
        ],

        // Structured
        'checklist' => [
            'label' => 'Checklist',
            'storage' => 'json',
            'control' => 'checklist',
            'category' => 'Structured',
            'available' => true,
            'normalized' => true,
        ],
        'structured_checklist' => [
            'label' => 'Structured checklist',
            'storage' => 'json',
            'control' => 'structured_checklist',
            'category' => 'Structured',
            'available' => true,
            'normalized' => true,
        ],
        'table' => [
            'label' => 'Table',
            'storage' => 'json',
            'control' => 'table',
            'category' => 'Structured',
            'available' => true,
            'normalized' => true,
        ],
        'repeater' => [
            'label' => 'Repeater',
            'storage' => 'json',
            'control' => 'repeater',
            'category' => 'Structured',
            'available' => true,
            'normalized' => true,
        ],
        'approval' => [
            'label' => 'Approval',
            'storage' => 'json',
            'control' => 'approval',
            'category' => 'Structured',
            'available' => true,
            'normalized' => true,
        ],
    ];
}

function work_template_field_type_exists(string $fieldType): bool
{
    return isset(work_template_field_types()[$fieldType]);
}

function work_template_field_type_label(string $fieldType): string
{
    $types = work_template_field_types();

    return $types[$fieldType]['label'] ?? $fieldType;
}

function work_template_field_storage(string $fieldType): ?string
{
    $types = work_template_field_types();

    return $types[$fieldType]['storage'] ?? null;
}

function work_template_field_type_labels(): array
{
    $labels = [];

    foreach (work_template_field_types() as $type => $definition) {
        $labels[$type] = $definition['label'];
    }

    return $labels;
}
function work_template_field_categories(): array
{
    return [
        'Text',
        'Numbers',
        'Boolean / State',
        'Choice',
        'Date / Time',
        'People',
        'Evidence',
        'Relations',
        'Calculated',
        'Structured',
        'Location',
        'Specialized',
    ];
}

function work_template_field_type_groups(): array
{
    $groups = array_fill_keys(work_template_field_categories(), []);

    foreach (work_template_field_types() as $type => $definition) {
        $category = (string) ($definition['category'] ?? 'Text');

        if (!array_key_exists($category, $groups)) {
            $groups[$category] = [];
        }

        $groups[$category][] = $type;
    }

    return array_filter(
        $groups,
        static fn (array $types): bool => $types !== []
    );
}

function work_template_field_config_keys(string $fieldType): array
{
    $types = work_template_field_types();

    return $types[$fieldType]['config'] ?? [];
}

function work_template_field_config_defaults(string $fieldType): array
{
    return match ($fieldType) {
        'percentage' => ['min' => 0.0, 'max' => 100.0, 'step' => 1.0],
        'range' => ['min' => 0.0, 'max' => 100.0, 'step' => 1.0],
        'scale' => ['min' => 1.0, 'max' => 5.0, 'step' => 1.0, 'labels' => []],
        default => [],
    };
}

/*
|--------------------------------------------------------------------------
| Advanced field type flags
|--------------------------------------------------------------------------
|
| These are the 23 requested advanced types. They are registered through the
| same authoritative registry so the submitted field_type is never trusted;
| the flags below drive availability, creation-time eligibility, and which
| pipeline (task_values vs normalized tables vs computed) owns the value.
|
*/

/**
 * The 23 advanced field types. Used by tests/invariants to assert the catalog.
 */
function work_template_advanced_field_types(): array
{
    return [
        // People
        'people',
        'teams',
        'project_role',
        // Evidence
        'file',
        'files',
        'photo',
        'photos',
        'signature',
        'drawing',
        // Relations
        'relation',
        'task_relation',
        'project_relation',
        'file_relation',
        'record_relation',
        'asset_relation',
        // Calculated
        'formula',
        'lookup',
        'rollup',
        // Structured
        'checklist',
        'structured_checklist',
        'table',
        'repeater',
        'approval',
    ];
}

function work_template_field_available(string $fieldType): bool
{
    $types = work_template_field_types();

    if (!isset($types[$fieldType])) {
        return false;
    }

    return (bool) ($types[$fieldType]['available'] ?? true);
}

/** True when the type's mutable state lives outside task_values. */
function work_template_field_is_normalized(string $fieldType): bool
{
    $types = work_template_field_types();

    return (bool) ($types[$fieldType]['normalized'] ?? false);
}

/** True when the value is computed on read and never stored/submitted. */
function work_template_field_is_computed(string $fieldType): bool
{
    $types = work_template_field_types();

    return (bool) ($types[$fieldType]['computed'] ?? false);
}

/** True when the type participates in the existing task_values persistence. */
function work_template_field_uses_task_values(string $fieldType): bool
{
    return !work_template_field_is_normalized($fieldType)
        && !work_template_field_is_computed($fieldType);
}

/** Creation-time normal fields may be filled on the new-task form. */
function work_template_field_creation_eligible(string $fieldType): bool
{
    $types = work_template_field_types();

    if (!isset($types[$fieldType])) {
        return false;
    }

    return (bool) ($types[$fieldType]['creation'] ?? false);
}
