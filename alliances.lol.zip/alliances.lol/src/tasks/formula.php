<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Safe formula engine (no eval)
|--------------------------------------------------------------------------
|
| Formula fields are computed on read and never store a submitted value. This
| module is pure: it opens no database, reads no files, and never uses eval.
|
| Grammar (whitespace-insensitive):
|   expr        := additive
|   additive    := multiplicative (("+" | "-") multiplicative)*
|   multiplicative := unary (("*" | "/") unary)*
|   unary       := "-" unary | primary
|   primary     := number | field-ref | func-call | "(" expr ")"
|   func-call   := ident "(" args? ")"
|   args        := expr ("," expr)*
|
| Field references use {field_key} and resolve through an injected resolver.
| The evaluator propagates NULL for any missing/unresolved operand and returns
| NULL for division by zero. min/max skip NULL operands (NULL only when every
| operand is NULL). round(x[, digits]) defaults digits to 0.
|
*/

const WORK_TEMPLATE_FORMULA_MAX_TOKENS = 200;
const WORK_TEMPLATE_FORMULA_MAX_NODES = 500;
const WORK_TEMPLATE_FORMULA_MAX_SOURCE = 2000;

/** @return array{ok: bool, tokens: list<array{type: string, value: mixed}>, error: ?string} */
function work_template_formula_tokenize(string $source): array
{
    if (strlen($source) > WORK_TEMPLATE_FORMULA_MAX_SOURCE) {
        return ['ok' => false, 'tokens' => [], 'error' => 'Formula is too long.'];
    }

    $tokens = [];
    $length = strlen($source);
    $index = 0;

    while ($index < $length) {
        $char = $source[$index];

        if (ctype_space($char)) {
            ++$index;
            continue;
        }

        if (str_contains('+-*/(),', $char)) {
            $type = match ($char) {
                '+' => 'plus',
                '-' => 'minus',
                '*' => 'star',
                '/' => 'slash',
                '(' => 'lparen',
                ')' => 'rparen',
                ',' => 'comma',
            };
            $tokens[] = ['type' => $type, 'value' => $char];
            ++$index;
            continue;
        }

        if ($char === '{') {
            $end = strpos($source, '}', $index + 1);
            if ($end === false) {
                return ['ok' => false, 'tokens' => [], 'error' => 'Unclosed field reference.'];
            }
            $key = substr($source, $index + 1, $end - $index - 1);
            if (!preg_match('/^[A-Za-z0-9_-]{1,64}$/', $key)) {
                return ['ok' => false, 'tokens' => [], 'error' => 'Invalid field reference.'];
            }
            $tokens[] = ['type' => 'field', 'value' => $key];
            $index = $end + 1;
            continue;
        }

        if (ctype_digit($char)
            || ($char === '.' && $index + 1 < $length && ctype_digit($source[$index + 1]))) {
            $start = $index;
            $hasDot = false;
            while ($index < $length) {
                $current = $source[$index];
                if (ctype_digit($current)) {
                    ++$index;
                    continue;
                }
                if ($current === '.' && !$hasDot) {
                    $hasDot = true;
                    ++$index;
                    continue;
                }
                break;
            }
            $number = substr($source, $start, $index - $start);
            if (!is_numeric($number)) {
                return ['ok' => false, 'tokens' => [], 'error' => 'Invalid number.'];
            }
            $tokens[] = ['type' => 'number', 'value' => (float) $number];
            continue;
        }

        if (ctype_alpha($char) || $char === '_') {
            $start = $index;
            while ($index < $length && (ctype_alnum($source[$index]) || $source[$index] === '_')) {
                ++$index;
            }
            $tokens[] = ['type' => 'ident', 'value' => substr($source, $start, $index - $start)];
            continue;
        }

        return ['ok' => false, 'tokens' => [], 'error' => 'Unexpected character "' . $char . '".'];
    }

    if (count($tokens) > WORK_TEMPLATE_FORMULA_MAX_TOKENS) {
        return ['ok' => false, 'tokens' => [], 'error' => 'Formula is too complex.'];
    }

    return ['ok' => true, 'tokens' => $tokens, 'error' => null];
}

final class WorkTemplateFormulaParser
{
    /** @var list<array{type: string, value: mixed}> */
    private array $tokens;

    private int $position = 0;

    private int $nodeCount = 0;

    /** @var list<string> */
    private array $refs = [];

    /** @param list<array{type: string, value: mixed}> $tokens */
    public function __construct(array $tokens)
    {
        $this->tokens = $tokens;
    }

    /** @return array{ok: bool, ast: mixed, refs: list<string>, error: ?string} */
    public function parse(): array
    {
        try {
            $ast = $this->parseExpr();

            if ($this->nodeCount > WORK_TEMPLATE_FORMULA_MAX_NODES) {
                return ['ok' => false, 'ast' => null, 'refs' => [], 'error' => 'Formula is too complex.'];
            }

            if ($this->position !== count($this->tokens)) {
                return ['ok' => false, 'ast' => null, 'refs' => [], 'error' => 'Unexpected trailing input.'];
            }

            return [
                'ok' => true,
                'ast' => $ast,
                'refs' => array_values(array_unique($this->refs)),
                'error' => null,
            ];
        } catch (RuntimeException $error) {
            return ['ok' => false, 'ast' => null, 'refs' => [], 'error' => $error->getMessage()];
        }
    }

    /** @return array{type: string, value: mixed}|null */
    private function peek(): ?array
    {
        return $this->tokens[$this->position] ?? null;
    }

    /** @return array{type: string, value: mixed}|null */
    private function advance(): ?array
    {
        return $this->tokens[$this->position++] ?? null;
    }

    private function bump(): void
    {
        ++$this->nodeCount;
    }

    private function parseExpr(): array
    {
        return $this->parseAdditive();
    }

    private function parseAdditive(): array
    {
        $node = $this->parseMultiplicative();

        while (($token = $this->peek()) !== null
            && ($token['type'] === 'plus' || $token['type'] === 'minus')) {
            $op = $token['type'] === 'plus' ? '+' : '-';
            $this->advance();
            $node = [
                'type' => 'binary',
                'op' => $op,
                'left' => $node,
                'right' => $this->parseMultiplicative(),
            ];
        }

        return $node;
    }

    private function parseMultiplicative(): array
    {
        $node = $this->parseUnary();

        while (($token = $this->peek()) !== null
            && ($token['type'] === 'star' || $token['type'] === 'slash')) {
            $op = $token['type'] === 'star' ? '*' : '/';
            $this->advance();
            $node = [
                'type' => 'binary',
                'op' => $op,
                'left' => $node,
                'right' => $this->parseUnary(),
            ];
        }

        return $node;
    }

    private function parseUnary(): array
    {
        $token = $this->peek();
        if ($token !== null && $token['type'] === 'minus') {
            $this->advance();
            $this->bump();

            return ['type' => 'unary', 'op' => '-', 'operand' => $this->parseUnary()];
        }

        return $this->parsePrimary();
    }

    private function parsePrimary(): array
    {
        $token = $this->peek();
        if ($token === null) {
            throw new RuntimeException('Unexpected end of formula.');
        }

        if ($token['type'] === 'number') {
            $this->advance();
            $this->bump();

            return ['type' => 'number', 'value' => $token['value']];
        }

        if ($token['type'] === 'field') {
            $this->advance();
            $this->bump();
            $this->refs[] = (string) $token['value'];

            return ['type' => 'field', 'key' => (string) $token['value']];
        }

        if ($token['type'] === 'lparen') {
            $this->advance();
            $node = $this->parseExpr();
            $closing = $this->advance();

            if ($closing === null || $closing['type'] !== 'rparen') {
                throw new RuntimeException('Missing closing parenthesis.');
            }

            return $node;
        }

        if ($token['type'] === 'ident') {
            $name = strtolower((string) $token['value']);
            $this->advance();
            $lparen = $this->advance();

            if ($lparen === null || $lparen['type'] !== 'lparen') {
                throw new RuntimeException('Expected "(" after function name.');
            }

            $args = [];
            $next = $this->peek();
            if ($next !== null && $next['type'] !== 'rparen') {
                $args[] = $this->parseExpr();
                while (($comma = $this->peek()) !== null && $comma['type'] === 'comma') {
                    $this->advance();
                    $args[] = $this->parseExpr();
                }
            }

            $closing = $this->advance();
            if ($closing === null || $closing['type'] !== 'rparen') {
                throw new RuntimeException('Missing ")" in function call.');
            }

            if (!in_array($name, ['min', 'max', 'round'], true)) {
                throw new RuntimeException('Unknown function "' . $name . '".');
            }

            if ($name === 'round' && (count($args) < 1 || count($args) > 2)) {
                throw new RuntimeException('round() expects one or two arguments.');
            }

            if (($name === 'min' || $name === 'max') && count($args) < 1) {
                throw new RuntimeException($name . '() expects at least one argument.');
            }

            $this->nodeCount += count($args);

            return ['type' => 'call', 'name' => $name, 'args' => $args];
        }

        throw new RuntimeException('Unexpected token.');
    }
}

/** @return array{ok: bool, ast: mixed, refs: list<string>, error: ?string} */
function work_template_formula_parse(string $source): array
{
    $lexed = work_template_formula_tokenize($source);

    if (!$lexed['ok']) {
        return ['ok' => false, 'ast' => null, 'refs' => [], 'error' => $lexed['error']];
    }

    $parser = new WorkTemplateFormulaParser($lexed['tokens']);

    return $parser->parse();
}

/**
 * Evaluate an AST (or source string) against a resolver that maps a field key
 * to a nullable numeric value. Returns a nullable float.
 *
 * @param array|string            $astOrSource
 * @param callable(string): ?float $resolver
 */
function work_template_formula_evaluate(array|string $astOrSource, callable $resolver): ?float
{
    if (is_string($astOrSource)) {
        $parsed = work_template_formula_parse($astOrSource);
        if (!$parsed['ok'] || !is_array($parsed['ast'])) {
            return null;
        }
        $ast = $parsed['ast'];
    } else {
        $ast = $astOrSource;
    }

    $walk = static function (array $node) use (&$walk, $resolver): ?float {
        return match ($node['type']) {
            'number' => $node['value'],
            'field' => $resolver((string) $node['key']),
            'unary' => (static function () use (&$walk, $node): ?float {
                $operand = $walk($node['operand']);

                return $operand === null ? null : -$operand;
            })(),
            'binary' => (static function () use (&$walk, $node): ?float {
                $left = $walk($node['left']);
                $right = $walk($node['right']);

                if ($left === null || $right === null) {
                    return null;
                }

                return match ($node['op']) {
                    '+' => $left + $right,
                    '-' => $left - $right,
                    '*' => $left * $right,
                    '/' => ($right == 0.0) ? null : $left / $right,
                    default => null,
                };
            })(),
            'call' => (static function () use (&$walk, $node): ?float {
                $values = [];
                foreach ($node['args'] as $arg) {
                    $values[] = $walk($arg);
                }

                if ($node['name'] === 'min' || $node['name'] === 'max') {
                    $nonNull = array_values(array_filter(
                        $values,
                        static fn (?float $value): bool => $value !== null
                    ));

                    if ($nonNull === []) {
                        return null;
                    }

                    return $node['name'] === 'min' ? min($nonNull) : max($nonNull);
                }

                // round
                $value = $values[0] ?? null;
                if ($value === null) {
                    return null;
                }

                $digits = (int) ($values[1] ?? 0);
                $factor = 10 ** max(0, min($digits, 12));

                return round($value * $factor) / $factor;
            })(),
            default => null,
        };
    };

    return $walk($ast);
}

/**
 * Build a dependency map from field key to referenced field keys.
 *
 * @param array<string, string> $formulas field_key => formula source
 * @return array<string, array{refs: list<string>, error: ?string}>
 */
function work_template_formula_dependency_graph(array $formulas): array
{
    $graph = [];
    foreach ($formulas as $key => $source) {
        $parsed = work_template_formula_parse((string) $source);
        $graph[$key] = [
            'refs' => $parsed['ok'] ? $parsed['refs'] : [],
            'error' => $parsed['ok'] ? null : $parsed['error'],
        ];
    }

    return $graph;
}

/**
 * Detect every field key involved in a dependency cycle (self, two-node, or
 * transitive). References to field keys outside the graph resolve to NULL and
 * never participate in cycle detection.
 *
 * @param array<string, list<string>> $dependencies field_key => referenced keys
 * @return list<string>
 */
function work_template_formula_find_cycles(array $dependencies): array
{
    $cyclic = [];
    $inStack = [];

    $dfs = function (string $node, array $path) use (&$dfs, $dependencies, &$inStack, &$cyclic): void {
        if (isset($inStack[$node])) {
            $first = array_search($node, $path, true);
            $cycle = $first === false ? [$node] : array_slice($path, $first);
            foreach ($cycle as $key) {
                $cyclic[] = $key;
            }

            return;
        }

        $inStack[$node] = true;
        $path[] = $node;

        foreach ($dependencies[$node] ?? [] as $target) {
            if (isset($dependencies[$target])) {
                $dfs($target, $path);
            }
        }

        unset($inStack[$node]);
    };

    foreach (array_keys($dependencies) as $node) {
        $dfs($node, []);
    }

    return array_values(array_unique($cyclic));
}

/**
 * Evaluate a set of formulas topologically, returning a value per field key or
 * NULL for keys with a syntax error, missing dependency, or a dependency cycle.
 *
 * @param array<string, string>      $formulas field_key => formula source
 * @param array<string, float|null>  $provided known leaf values by field key
 * @return array<string, float|null>
 */
function work_template_formula_evaluate_all(array $formulas, array $provided = []): array
{
    $graph = work_template_formula_dependency_graph($formulas);
    $dependencies = [];
    foreach ($graph as $key => $info) {
        $dependencies[$key] = $info['refs'];
    }

    $cycles = work_template_formula_find_cycles($dependencies);
    $results = [];
    $resolving = [];

    $resolve = function (string $key) use (&$resolve, $formulas, $provided, $graph, $cycles, &$results, &$resolving): ?float {
        if (array_key_exists($key, $results)) {
            return $results[$key];
        }
        if (isset($resolving[$key]) || in_array($key, $cycles, true)) {
            $results[$key] = null;

            return null;
        }
        if (array_key_exists($key, $provided)) {
            $results[$key] = $provided[$key];

            return $provided[$key];
        }
        if (!isset($formulas[$key])) {
            return null;
        }
        if (($graph[$key]['error'] ?? null) !== null) {
            $results[$key] = null;

            return null;
        }

        $resolving[$key] = true;
        $results[$key] = work_template_formula_evaluate(
            $formulas[$key],
            static function (string $dep) use (&$resolve): ?float {
                return $resolve($dep);
            }
        );
        unset($resolving[$key]);

        return $results[$key];
    };

    foreach (array_keys($formulas) as $key) {
        $resolve($key);
    }

    return $results;
}