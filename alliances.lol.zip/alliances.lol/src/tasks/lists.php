<?php

declare(strict_types=1);

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/../projects.php';

/*
|--------------------------------------------------------------------------
| Task List persistence + Project context
|--------------------------------------------------------------------------
|
| Task Lists remain the authoritative security boundary for Tasks. A
| Task List may belong to zero or one Project. Project membership never
| grants Task List access; task_list_members (and the existing workspace-
| scoped rules) remain authoritative.
|
| Project authorization lives in src/projects.php. Nothing in this file
| grants or revokes Task List access based on Project membership.
|
*/

/**
 * Return a workspace-scoped Task List, or null when it does not belong to
 * the given workspace.
 */
function task_list_by_id(int $taskListId, int $workspaceId): ?array
{
    if ($taskListId <= 0 || $workspaceId <= 0) {
        return null;
    }

    $statement = db()->prepare(
        'SELECT
             id,
             workspace_id,
             created_by,
             name,
             status,
             start_date,
             deadline,
             team_id,
             members_can_edit,
             default_template_id,
             project_id
         FROM task_lists
         WHERE id = ?
           AND workspace_id = ?
         LIMIT 1'
    );

    $statement->execute([$taskListId, $workspaceId]);

    $list = $statement->fetch();

    return $list ?: null;
}

/**
 * Attach a detached (project_id IS NULL) Task List to a Project. This only
 * changes context; it never touches tasks, members, teams, or template config.
 *
 * The UPDATE is workspace-scoped and gated on the expected NULL state so a
 * concurrent or out-of-sequence request cannot overwrite an existing link or
 * cross a workspace boundary.
 */
function task_list_attach_project(
    int $workspaceId,
    int $taskListId,
    int $projectId
): void {
    project_assert_writable($projectId);

    if ($workspaceId <= 0 || $taskListId <= 0 || $projectId <= 0) {
        throw new InvalidArgumentException(
            'A valid task list and project are required.'
        );
    }

    $statement = db()->prepare(
        'UPDATE task_lists
         SET project_id = ?
         WHERE id = ?
           AND workspace_id = ?
           AND project_id IS NULL'
    );

    $statement->execute([$projectId, $taskListId, $workspaceId]);

    if ($statement->rowCount() === 0) {
        $list = task_list_by_id($taskListId, $workspaceId);

        if ($list === null) {
            throw new RuntimeException(
                'Task list not found in this workspace.'
            );
        }

        if ($list['project_id'] !== null) {
            throw new RuntimeException(
                'That task list is already attached to a project.'
            );
        }

        throw new RuntimeException('The task list could not be attached.');
    }
}

/**
 * Detach a Task List from its current Project (project_id -> NULL). This only
 * changes context; it never deletes tasks, members, team assignment, or
 * template configuration.
 */
function task_list_detach_project(
    int $workspaceId,
    int $taskListId,
    int $projectId
): void {
    project_assert_writable($projectId);

    if ($workspaceId <= 0 || $taskListId <= 0 || $projectId <= 0) {
        throw new InvalidArgumentException(
            'A valid task list and project are required.'
        );
    }

    $statement = db()->prepare(
        'UPDATE task_lists
         SET project_id = NULL
         WHERE id = ?
           AND workspace_id = ?
           AND project_id = ?'
    );

    $statement->execute([$taskListId, $workspaceId, $projectId]);

    if ($statement->rowCount() === 0) {
        $list = task_list_by_id($taskListId, $workspaceId);

        if ($list === null) {
            throw new RuntimeException(
                'Task list not found in this workspace.'
            );
        }

        if ($list['project_id'] === null) {
            throw new RuntimeException(
                'That task list is not attached to any project.'
            );
        }

        if ((int) $list['project_id'] !== $projectId) {
            throw new RuntimeException(
                'That task list belongs to a different project.'
            );
        }

        throw new RuntimeException('The task list could not be detached.');
    }
}

/**
 * Task Lists belonging to a Project that the current user is already allowed
 * to see under the existing task_list_members rule. Project membership is NOT
 * an access shortcut here.
 */
function project_task_lists_visible(
    int $workspaceId,
    int $projectId,
    int $userId
): array {
    $statement = db()->prepare(
        'SELECT
             tl.id,
             tl.name,
             tl.status,
             tl.start_date,
             tl.deadline,
             tl.created_at,
             tl.team_id,
             tl.created_by,
             tl.project_id,

             team.name AS team_name,

             creator.display_name AS creator_name,

             (
                 SELECT COUNT(*)
                 FROM tasks t
                 WHERE t.task_list_id = tl.id
             ) AS task_count,

             (
                 SELECT COUNT(*)
                 FROM task_list_members tlm
                 WHERE tlm.task_list_id = tl.id
             ) AS member_count

         FROM task_lists tl

         INNER JOIN task_list_members viewer
             ON viewer.task_list_id = tl.id
            AND viewer.user_id = ?

         LEFT JOIN teams team
             ON team.id = tl.team_id
            AND team.workspace_id = tl.workspace_id

         LEFT JOIN users creator
             ON creator.id = tl.created_by

         WHERE tl.workspace_id = ?
           AND tl.project_id = ?

         ORDER BY tl.name COLLATE NOCASE ASC, tl.id ASC'
    );

    $statement->execute([$userId, $workspaceId, $projectId]);

    return $statement->fetchAll();
}

/**
 * Detached (project_id IS NULL) Task Lists in the workspace that the current
 * actor is allowed to manage under the existing Task List rules (creator or
 * workspace admin). Used only to populate the attach selector; it never leaks
 * lists the actor cannot already manage.
 */
function task_lists_attachable(
    int $workspaceId,
    int $userId,
    bool $isAdmin
): array {
    $sql = 'SELECT
                 tl.id,
                 tl.name,
                 tl.status,
                 tl.created_by,
                 tl.team_id
            FROM task_lists tl
            WHERE tl.workspace_id = ?
              AND tl.project_id IS NULL';

    $parameters = [$workspaceId];

    if (!$isAdmin) {
        $sql .= ' AND tl.created_by = ?';
        $parameters[] = $userId;
    }

    $sql .= ' ORDER BY tl.name COLLATE NOCASE ASC, tl.id ASC';

    $statement = db()->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}

/**
 * Create a Task List following the existing Tasks creation model. The only
 * addition is an optional Project context (project_id). Members, the Team
 * snapshot behavior, and the creator-must-belong rule are unchanged.
 *
 * This is a shared implementation so the global Tasks creator (kept intact)
 * and the Project creator use identical task-list semantics. Returns the new
 * Task List id.
 */
function task_list_create(
    int $workspaceId,
    int $createdBy,
    string $name,
    ?string $startDate,
    ?string $deadline,
    ?int $teamId,
    bool $membersCanEdit,
    array $memberIds,
    ?int $projectId
): int {
    if ($workspaceId <= 0 || $createdBy <= 0) {
        throw new InvalidArgumentException(
            'A valid workspace and creator are required.'
        );
    }

    $name = trim($name);

    if ($name === '') {
        throw new InvalidArgumentException(
            'Enter a name for the task list.'
        );
    }

    if (strlen($name) > 150) {
        throw new InvalidArgumentException(
            'Task list names can be up to 150 characters.'
        );
    }

    $startDate = ($startDate !== null && trim($startDate) !== '')
        ? trim($startDate)
        : null;

    $deadline = ($deadline !== null && trim($deadline) !== '')
        ? trim($deadline)
        : null;

    if (
        $startDate !== null
        && $deadline !== null
        && $deadline < $startDate
    ) {
        throw new InvalidArgumentException(
            'The deadline cannot be before the start date.'
        );
    }

    $connection = db();

    if ($teamId !== null && !task_list_team_available($workspaceId, $teamId)) {
        throw new InvalidArgumentException('Choose a valid team.');
    }

    if (
        $projectId !== null
        && !task_list_project_available($workspaceId, $projectId)
    ) {
        throw new InvalidArgumentException('Choose a valid project.');
    }

    $normalizedMembers = [];

    foreach ($memberIds as $memberId) {
        $memberId = filter_var($memberId, FILTER_VALIDATE_INT);

        if ($memberId !== false && $memberId > 0) {
            $normalizedMembers[] = (int) $memberId;
        }
    }

    // The creator must always belong to their own list.
    $normalizedMembers[] = $createdBy;
    $normalizedMembers = array_values(array_unique($normalizedMembers));

    $connection->beginTransaction();

    try {
        $insert = $connection->prepare(
            'INSERT INTO task_lists
                (
                    workspace_id,
                    created_by,
                    team_id,
                    project_id,
                    name,
                    start_date,
                    deadline,
                    members_can_edit
                )
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );

        $insert->execute([
            $workspaceId,
            $createdBy,
            $teamId,
            $projectId,
            $name,
            $startDate,
            $deadline,
            $membersCanEdit ? 1 : 0,
        ]);

        $listId = (int) $connection->lastInsertId();

        $memberInsert = $connection->prepare(
            'INSERT OR IGNORE INTO task_list_members
                (task_list_id, user_id)
             SELECT ?, wm.user_id
             FROM workspace_members wm
             INNER JOIN users u
                 ON u.id = wm.user_id
             WHERE wm.workspace_id = ?
               AND wm.user_id = ?
               AND u.account_status = "active"'
        );

        foreach ($normalizedMembers as $memberId) {
            $memberInsert->execute([
                $listId,
                $workspaceId,
                $memberId,
            ]);
        }

        // Snapshot current team membership exactly like the global creator.
        if ($teamId !== null) {
            $teamInsert = $connection->prepare(
                'INSERT OR IGNORE INTO task_list_members
                    (task_list_id, user_id)
                 SELECT ?, tm.user_id
                 FROM team_members tm
                 INNER JOIN teams t
                     ON t.id = tm.team_id
                 INNER JOIN users u
                     ON u.id = tm.user_id
                 WHERE tm.team_id = ?
                   AND t.workspace_id = ?
                   AND t.status = "active"
                   AND u.account_status = "active"'
            );

            $teamInsert->execute([
                $listId,
                $teamId,
                $workspaceId,
            ]);
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }

    return $listId;
}

function task_list_team_available(int $workspaceId, int $teamId): bool
{
    $statement = db()->prepare(
        'SELECT 1
         FROM teams
         WHERE id = ?
           AND workspace_id = ?
           AND status = "active"
         LIMIT 1'
    );

    $statement->execute([$teamId, $workspaceId]);

    return $statement->fetchColumn() !== false;
}

function task_list_project_available(int $workspaceId, int $projectId): bool
{
    $statement = db()->prepare(
        'SELECT 1
         FROM projects
         WHERE id = ?
           AND workspace_id = ? AND status != "archived"
         LIMIT 1'
    );

    $statement->execute([$projectId, $workspaceId]);

    return $statement->fetchColumn() !== false;
}