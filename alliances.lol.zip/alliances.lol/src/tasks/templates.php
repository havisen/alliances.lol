<?php

declare(strict_types=1);

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/fields.php';
require_once __DIR__ . '/formula.php';

/*
|--------------------------------------------------------------------------
| Work Template persistence + lifecycle
|--------------------------------------------------------------------------
|
| All queries are workspace-scoped. Draft definitions are read and written
| from the relational tables; publishing snapshots a normalized
| definition_json onto the immutable version.
|
*/

function work_template_encode_json(mixed $value): string
{
    return json_encode(
        $value,
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
}

function work_template_decode_options(?string $json): array
{
    if ($json === null || trim($json) === '') {
        return [];
    }

    $decoded = json_decode($json, true);

    return is_array($decoded) ? $decoded : [];
}

function work_template_decode_config(?string $json): array
{
    if ($json === null || trim($json) === '') {
        return [];
    }

    $decoded = json_decode($json, true);

    return is_array($decoded) ? $decoded : [];
}

/*
|--------------------------------------------------------------------------
| Stable field identity
|--------------------------------------------------------------------------
|
| field_key is generated as lower(hex(randomblob(8))) (16 hex chars). It is
| unique within one Template Version and intentionally reusable across draft
| clones of the same logical field, so there is no global unique index. The
| safe fallback for historical definitions without a key is 'f' || id.
|
*/

function work_template_generate_field_key(): string
{
    return strtolower(bin2hex(random_bytes(8)));
}

function work_template_field_key(?string $storedKey, int $fieldId): string
{
    $storedKey = trim((string) ($storedKey ?? ''));

    return $storedKey !== '' ? $storedKey : 'f' . $fieldId;
}

/** @param array<string, mixed> $row */
function work_template_clone_field_key(array $row): string
{
    $stored = trim((string) ($row['field_key'] ?? ''));

    return work_template_field_key($stored, (int) $row['id']);
}

/**
 * Validate + normalize the immutable definition config for the 23 advanced
 * field types. Legacy types are ignored (returned unchanged).
 *
 * @return array{error: ?string, config: array<string, mixed>}
 */
function work_template_normalize_advanced_config(string $fieldType, array $config): array
{
    if (!in_array($fieldType, work_template_advanced_field_types(), true)) {
        return ['error' => null, 'config' => []];
    }

    if (!work_template_field_available($fieldType)) {
        return ['error' => 'That field type is not available yet.', 'config' => []];
    }

    $parseStepList = static function (array $steps, string $word): ?string {
        if ($steps === []) {
            return 'Enter at least one ' . $word . '.';
        }

        $seen = [];
        foreach ($steps as $step) {
            if (!is_array($step)) {
                return 'Each ' . $word . ' must have a key and a label.';
            }

            $key = trim((string) ($step['key'] ?? ''));
            $label = trim((string) ($step['label'] ?? ''));

            if (!preg_match('/^[A-Za-z0-9_-]{1,64}$/', $key)
                || $label === ''
                || strlen($label) > 200) {
                return 'Each ' . $word . ' needs a valid key and label.';
            }

            if (isset($seen[$key])) {
                return 'Each ' . $word . ' key must be unique.';
            }
            $seen[$key] = true;
        }

        return null;
    };

    $parseTypedList = static function (array $items, string $word): ?string {
        if ($items === []) {
            return 'Enter at least one ' . $word . '.';
        }

        $allowedTypes = ['text', 'number', 'integer', 'date', 'yes_no'];
        $seen = [];
        foreach ($items as $item) {
            if (!is_array($item)) {
                return 'Each ' . $word . ' must have a key, label, and type.';
            }

            $key = trim((string) ($item['key'] ?? ''));
            $label = trim((string) ($item['label'] ?? ''));
            $type = (string) ($item['type'] ?? 'text');

            if (!preg_match('/^[A-Za-z0-9_-]{1,64}$/', $key)
                || $label === ''
                || strlen($label) > 200
                || !in_array($type, $allowedTypes, true)) {
                return 'Each ' . $word . ' needs a valid key, label, and type.';
            }

            if (isset($seen[$key])) {
                return 'Each ' . $word . ' key must be unique.';
            }
            $seen[$key] = true;
        }

        return null;
    };

    switch ($fieldType) {
        case 'relation':
            $targets = $config['target_types'] ?? null;
            if (!is_array($targets) || $targets === []) {
                return ['error' => 'Choose at least one relation target type.', 'config' => []];
            }
            $allowed = ['task', 'project', 'file', 'record'];
            $normalized = array_values(array_unique(array_map('strval', $targets)));
            foreach ($normalized as $target) {
                if (!in_array($target, $allowed, true)) {
                    return ['error' => 'That relation target type is not available.', 'config' => []];
                }
            }

            return ['error' => null, 'config' => ['target_types' => $normalized]];

        case 'task_relation':
        case 'project_relation':
        case 'file_relation':
        case 'record_relation':
            return ['error' => null, 'config' => []];

        case 'checklist':
        case 'structured_checklist':
            $steps = $config['steps'] ?? [];
            $error = is_array($steps) ? $parseStepList($steps, 'step') : 'Enter at least one step.';
            if ($error !== null) {
                return ['error' => $error, 'config' => []];
            }

            return ['error' => null, 'config' => ['steps' => array_values($steps)]];

        case 'table':
            $columns = $config['columns'] ?? [];
            $error = is_array($columns) ? $parseTypedList($columns, 'column') : 'Enter at least one column.';
            if ($error !== null) {
                return ['error' => $error, 'config' => []];
            }

            return ['error' => null, 'config' => ['columns' => array_values($columns)]];

        case 'repeater':
            $children = $config['children'] ?? [];
            $error = is_array($children) ? $parseTypedList($children, 'field') : 'Enter at least one field.';
            if ($error !== null) {
                return ['error' => $error, 'config' => []];
            }

            return ['error' => null, 'config' => ['children' => array_values($children)]];

        case 'approval':
            $approvers = $config['approver_ids'] ?? [];
            if (!is_array($approvers) || $approvers === [] || count($approvers) > 50) {
                return ['error' => 'Choose between 1 and 50 explicit approvers.', 'config' => []];
            }
            foreach ($approvers as $id) {
                if (filter_var($id, FILTER_VALIDATE_INT) === false || (int) $id <= 0) {
                    return ['error' => 'Choose valid approvers.', 'config' => []];
                }
            }
            return ['error' => null, 'config' => [
                'approver_ids' => array_values(array_unique(array_map('intval', $approvers))),
            ]];

        case 'formula':
            $formula = trim((string) ($config['formula'] ?? ''));
            if ($formula === '' || strlen($formula) > WORK_TEMPLATE_FORMULA_MAX_SOURCE) {
                return ['error' => 'Enter a formula.', 'config' => []];
            }
            $parsed = work_template_formula_parse($formula);
            if (!$parsed['ok']) {
                return ['error' => 'Formula: ' . ($parsed['error'] ?? 'invalid.'), 'config' => []];
            }

            return ['error' => null, 'config' => ['formula' => $formula]];

        case 'lookup':
            $relationKey = trim((string) ($config['relation_field_key'] ?? ''));
            if ($relationKey === '' || !preg_match('/^[A-Za-z0-9_-]{1,64}$/', $relationKey)) {
                return ['error' => 'Choose the relation field to source this field.', 'config' => []];
            }

            $target = (string) ($config['target_type'] ?? '');
            $descriptor = trim((string) ($config['descriptor'] ?? ''));
            $allowedTargets = ['task', 'project', 'file', 'record'];
            // V1 deliberately supports only the authorized target's name.
            $allowedDescriptors = ['name'];
            if (!in_array($target, $allowedTargets, true)
                || $descriptor === ''
                || !in_array($descriptor, $allowedDescriptors, true)) {
                return ['error' => 'Choose a valid lookup target and descriptor.', 'config' => []];
            }

            return ['error' => null, 'config' => [
                'relation_field_key' => $relationKey,
                'target_type' => $target,
                'descriptor' => $descriptor,
            ]];

        case 'rollup':
            $relationKey = trim((string) ($config['relation_field_key'] ?? ''));
            if ($relationKey === '' || !preg_match('/^[A-Za-z0-9_-]{1,64}$/', $relationKey)) {
                return ['error' => 'Choose the relation field to source this field.', 'config' => []];
            }

            $operation = (string) ($config['operation'] ?? '');
            if ($operation !== 'count' || !empty($config['value_field_key'])) {
                return ['error' => 'Rollup supports accessible-target count only.', 'config' => []];
            }

            $valueKey = trim((string) ($config['value_field_key'] ?? ''));
            $rollup = [
                'relation_field_key' => $relationKey,
                'operation' => $operation,
            ];
            if ($valueKey !== '') {
                if (!preg_match('/^[A-Za-z0-9_-]{1,64}$/', $valueKey)) {
                    return ['error' => 'Choose a valid rollup value field.', 'config' => []];
                }
                $rollup['value_field_key'] = $valueKey;
            }

            return ['error' => null, 'config' => $rollup];

        default:
            return ['error' => null, 'config' => []];
    }
}

/*
|--------------------------------------------------------------------------
| Queries
|--------------------------------------------------------------------------
*/

function work_template_by_id(int $workspaceId, int $templateId): ?array
{
    $statement = db()->prepare(
        'SELECT t.*
         FROM work_templates t
         WHERE t.id = ?
           AND t.workspace_id = ?
         LIMIT 1'
    );

    $statement->execute([$templateId, $workspaceId]);

    $template = $statement->fetch();

    return $template ?: null;
}

function work_templates_for_workspace(
    int $workspaceId,
    bool $includeArchived = false
): array {
    $sql = 'SELECT
                t.*,
                COUNT(v.id) AS version_count,
                SUM(CASE WHEN v.status = "draft" THEN 1 ELSE 0 END) AS draft_count,
                MAX(CASE WHEN v.status = "published" THEN v.version_number END) AS published_number
            FROM work_templates t
            LEFT JOIN work_template_versions v
                ON v.template_id = t.id
            WHERE t.workspace_id = ?';

    $parameters = [$workspaceId];

    if (!$includeArchived) {
        $sql .= ' AND t.status = "active"';
    }

    $sql .= ' GROUP BY t.id
              ORDER BY t.name COLLATE NOCASE ASC, t.id ASC';

    $statement = db()->prepare($sql);
    $statement->execute($parameters);

    return $statement->fetchAll();
}

function work_template_versions(int $workspaceId, int $templateId): array
{
    $statement = db()->prepare(
        'SELECT
            v.*,
            creator.display_name AS creator_name
         FROM work_template_versions v
         INNER JOIN work_templates t
             ON t.id = v.template_id
         LEFT JOIN users creator
             ON creator.id = v.created_by
         WHERE t.workspace_id = ?
           AND t.id = ?
         ORDER BY v.version_number DESC'
    );

    $statement->execute([$workspaceId, $templateId]);

    return $statement->fetchAll();
}

function work_template_version_by_id(int $workspaceId, int $versionId): ?array
{
    $statement = db()->prepare(
        'SELECT
            v.*,
            t.name AS template_name,
            t.status AS template_status,
            t.workspace_id
         FROM work_template_versions v
         INNER JOIN work_templates t
             ON t.id = v.template_id
         WHERE v.id = ?
           AND t.workspace_id = ?
         LIMIT 1'
    );

    $statement->execute([$versionId, $workspaceId]);

    $version = $statement->fetch();

    return $version ?: null;
}
function work_template_published_version(
    int $workspaceId,
    int $templateId
): ?array {
    $statement = db()->prepare(
        'SELECT v.*
         FROM work_template_versions v
         INNER JOIN work_templates t
             ON t.id = v.template_id
         WHERE t.workspace_id = ?
           AND t.id = ?
           AND v.status = "published"
         LIMIT 1'
    );

    $statement->execute([$workspaceId, $templateId]);

    $version = $statement->fetch();

    return $version ?: null;
}

function work_template_latest_draft(
    int $workspaceId,
    int $templateId
): ?array {
    $statement = db()->prepare(
        'SELECT v.*
         FROM work_template_versions v
         INNER JOIN work_templates t
             ON t.id = v.template_id
         WHERE t.workspace_id = ?
           AND t.id = ?
           AND v.status = "draft"
         ORDER BY v.version_number DESC
         LIMIT 1'
    );

    $statement->execute([$workspaceId, $templateId]);

    $version = $statement->fetch();

    return $version ?: null;
}

function work_template_draft_version(int $workspaceId, int $versionId): ?array
{
    $statement = db()->prepare(
        'SELECT
            v.*,
            t.id AS template_id,
            t.status AS template_status,
            t.workspace_id
         FROM work_template_versions v
         INNER JOIN work_templates t
             ON t.id = v.template_id
         WHERE v.id = ?
           AND t.workspace_id = ?
           AND v.status = "draft"
           AND t.status = "active"
         LIMIT 1'
    );

    $statement->execute([$versionId, $workspaceId]);

    $version = $statement->fetch();

    return $version ?: null;
}

function work_template_section_row(int $workspaceId, int $sectionId): ?array
{
    $statement = db()->prepare(
        'SELECT
            s.*,
            v.id AS version_id,
            v.status AS version_status,
            v.template_id
         FROM work_template_sections s
         INNER JOIN work_template_versions v
             ON v.id = s.version_id
         INNER JOIN work_templates t
             ON t.id = v.template_id
         WHERE s.id = ?
           AND t.workspace_id = ?
           AND v.status = "draft"
           AND t.status = "active"
         LIMIT 1'
    );

    $statement->execute([$sectionId, $workspaceId]);

    $section = $statement->fetch();

    return $section ?: null;
}

function work_template_field_row(int $workspaceId, int $fieldId): ?array
{
    $statement = db()->prepare(
        'SELECT
            f.*,
            s.id AS section_id,
            s.version_id,
            v.status AS version_status,
            v.template_id
         FROM work_template_fields f
         INNER JOIN work_template_sections s
             ON s.id = f.section_id
         INNER JOIN work_template_versions v
             ON v.id = s.version_id
         INNER JOIN work_templates t
             ON t.id = v.template_id
         WHERE f.id = ?
           AND t.workspace_id = ?
           AND v.status = "draft"
           AND t.status = "active"
         LIMIT 1'
    );

    $statement->execute([$fieldId, $workspaceId]);

    $field = $statement->fetch();

    return $field ?: null;
}
/*
|--------------------------------------------------------------------------
| Definition assembly (relational, authoritative for DRAFT)
|--------------------------------------------------------------------------
*/

function work_template_definition(int $versionId): array
{
    $statement = db()->prepare(
        'SELECT
            s.id AS section_id,
            s.name AS section_name,
            s.description AS section_description,
            s.sort_order AS section_sort_order,
            f.id AS field_id,
            f.name AS field_name,
            f.description AS field_description,
            f.field_type,
            f.is_required,
            f.options_json,
            f.number_unit,
            f.config_json,
            f.field_key,
            f.sort_order AS field_sort_order
         FROM work_template_sections s
         LEFT JOIN work_template_fields f
             ON f.section_id = s.id
         WHERE s.version_id = ?
         ORDER BY
             s.sort_order ASC,
             s.id ASC,
             f.sort_order ASC,
             f.id ASC'
    );

    $statement->execute([$versionId]);

    $sections = [];

    foreach ($statement->fetchAll() as $row) {
        $sectionId = (int) $row['section_id'];

        if (!isset($sections[$sectionId])) {
            $sections[$sectionId] = [
                'id' => $sectionId,
                'name' => (string) $row['section_name'],
                'description' => $row['section_description'] !== null
                    ? (string) $row['section_description']
                    : null,
                'sort_order' => (int) $row['section_sort_order'],
                'fields' => [],
            ];
        }

        if ($row['field_id'] !== null) {
            $sections[$sectionId]['fields'][] = [
                'id' => (int) $row['field_id'],
                'name' => (string) $row['field_name'],
                'description' => $row['field_description'] !== null
                    ? (string) $row['field_description']
                    : null,
                'field_type' => (string) $row['field_type'],
                'is_required' => (int) $row['is_required'] === 1,
                'options' => work_template_decode_options(
                    $row['options_json']
                ),
                'number_unit' => $row['number_unit'] !== null
                    ? (string) $row['number_unit']
                    : null,
                'config' => work_template_decode_config($row['config_json']),
                'field_key' => work_template_field_key(
                    $row['field_key'] ?? null,
                    (int) $row['field_id']
                ),
                'sort_order' => (int) $row['field_sort_order'],
            ];
        }
    }

    ksort($sections);

    return array_values($sections);
}

/*
|--------------------------------------------------------------------------
| Definition normalization + validation (used by builder and publish)
|--------------------------------------------------------------------------
*/

function work_template_parse_options(?string $raw): array
{
    if ($raw === null) {
        return [];
    }

    $options = [];

    foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
        $line = trim($line);

        if ($line === '' || strlen($line) > 200) {
            continue;
        }

        $options[] = $line;
    }

    return array_values(array_unique($options));
}

/**
 * Parse the optional "value = label" lines used by the scale field type.
 * Returns an indexed list of value/label pairs, an empty list for blank
 * input, or NULL for any line that does not follow the expected shape.
 *
 * @return list<array{value: float, label: string}>|null
 */
function work_template_parse_scale_labels(?string $raw): ?array
{
    if ($raw === null || trim($raw) === '') {
        return [];
    }

    $labels = [];

    foreach (preg_split('/\r\n|\r|\n/', $raw) ?: [] as $line) {
        $line = trim($line);

        if ($line === '') {
            continue;
        }

        $parts = explode('=', $line, 2);

        if (count($parts) !== 2 || trim($parts[0]) === '' || trim($parts[1]) === '') {
            return null;
        }

        $value = trim($parts[0]);
        $label = trim($parts[1]);

        if (!is_numeric($value) || strlen($label) > 200) {
            return null;
        }

        $labels[] = [
            'value' => (float) $value,
            'label' => $label,
        ];
    }

    return $labels;
}

/**
 * Normalize + validate a single field definition.
 *
 * @return array{options_json: ?string, number_unit: ?string, config_json: ?string, error: ?string}
 */
function work_template_normalize_field_definition(
    string $fieldType,
    ?string $optionsRaw,
    ?string $numberUnit,
    array $config
): array {
    $result = [
        'options_json' => null,
        'number_unit' => null,
        'config_json' => null,
        'error' => null,
    ];

    if (!work_template_field_type_exists($fieldType)) {
        $result['error'] = 'Choose a valid field type.';

        return $result;
    }

    $types = work_template_field_types();
    $type = $types[$fieldType];

    if (!empty($type['custom_options'])) {
        $options = work_template_parse_options($optionsRaw);

        if ($options === []) {
            $result['error'] = 'This field needs at least one option.';

            return $result;
        }

        $result['options_json'] = work_template_encode_json($options);
    }

    if ($fieldType === 'number_unit') {
        $unit = trim((string) ($numberUnit ?? ''));

        if ($unit === '' || strlen($unit) > 40) {
            $result['error'] = 'Enter a unit (up to 40 characters).';

            return $result;
        }

        $result['number_unit'] = $unit;
    }

    $configKeys = work_template_field_config_keys($fieldType);
    $defaults = work_template_field_config_defaults($fieldType);
    $configObject = [];

    $rawMin = $config['min'] ?? $defaults['min'] ?? null;
    $rawMax = $config['max'] ?? $defaults['max'] ?? null;
    $rawStep = $config['step'] ?? $defaults['step'] ?? null;
    $rawLabels = array_key_exists('labels', $config)
        ? $config['labels']
        : ($defaults['labels'] ?? '');

    if (in_array('min', $configKeys, true)) {
        $min = $rawMin !== null && trim((string) $rawMin) !== ''
            ? (string) $rawMin
            : null;

        if ($min !== null && !is_numeric($min)) {
            $result['error'] = 'Minimum must be a number.';

            return $result;
        }

        if ($min !== null) {
            $configObject['min'] = (float) $min;
        }
    }

    if (in_array('max', $configKeys, true)) {
        $max = $rawMax !== null && trim((string) $rawMax) !== ''
            ? (string) $rawMax
            : null;

        if ($max !== null && !is_numeric($max)) {
            $result['error'] = 'Maximum must be a number.';

            return $result;
        }

        if ($max !== null) {
            $configObject['max'] = (float) $max;
        }
    }

    if (
        isset($configObject['min'])
        && isset($configObject['max'])
        && $configObject['min'] > $configObject['max']
    ) {
        $result['error'] = 'Minimum cannot be greater than maximum.';

        return $result;
    }

    if (in_array('step', $configKeys, true)) {
        $step = $rawStep !== null && trim((string) $rawStep) !== ''
            ? (string) $rawStep
            : null;

        if ($step !== null && (!is_numeric($step) || (float) $step <= 0)) {
            $result['error'] = 'Step must be a positive number.';

            return $result;
        }

        if ($step !== null) {
            $configObject['step'] = (float) $step;
        }
    }

    if (in_array('labels', $configKeys, true)) {
        if (is_array($rawLabels)) {
            $labels = $rawLabels;
        } else {
            $labels = work_template_parse_scale_labels(
                is_string($rawLabels) ? $rawLabels : null
            );

            if ($labels === null) {
                $result['error'] = 'Scale labels must be formatted as "value = label", one per line.';

                return $result;
            }
        }

        if ($labels !== []) {
            $configObject['labels'] = $labels;
        }
    }

    $advanced = work_template_normalize_advanced_config($fieldType, $config);
    if ($advanced['error'] !== null) {
        $result['error'] = $advanced['error'];

        return $result;
    }

    if (in_array($fieldType, work_template_advanced_field_types(), true)) {
        $configObject = $advanced['config'];
    }

    $result['config_json'] = work_template_encode_json($configObject);

    return $result;
}
/*
|--------------------------------------------------------------------------
| Template identity mutations
|--------------------------------------------------------------------------
*/

function work_template_create(
    int $workspaceId,
    int $createdBy,
    string $name,
    ?string $description
): int {
    $connection = db();

    $connection->beginTransaction();

    try {
        $templateStatement = $connection->prepare(
            'INSERT INTO work_templates
                (workspace_id, created_by, name, description)
             VALUES (?, ?, ?, ?)'
        );

        $templateStatement->execute([
            $workspaceId,
            $createdBy,
            $name,
            $description !== '' ? $description : null,
        ]);

        $templateId = (int) $connection->lastInsertId();

        $versionStatement = $connection->prepare(
            'INSERT INTO work_template_versions
                (template_id, version_number, status, created_by)
             VALUES (?, 1, "draft", ?)'
        );

        $versionStatement->execute([$templateId, $createdBy]);

        $connection->commit();

        return $templateId;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}

function work_template_update_identity(
    int $workspaceId,
    int $templateId,
    string $name,
    ?string $description
): void {
    $statement = db()->prepare(
        'UPDATE work_templates
         SET name = ?,
             description = ?,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?
           AND workspace_id = ?'
    );

    $statement->execute([
        $name,
        $description !== '' ? $description : null,
        $templateId,
        $workspaceId,
    ]);
}

function work_template_archive(int $workspaceId, int $templateId): void
{
    $statement = db()->prepare(
        'UPDATE work_templates
         SET status = "archived",
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?
           AND workspace_id = ?'
    );

    $statement->execute([$templateId, $workspaceId]);
}

function work_template_unarchive(int $workspaceId, int $templateId): void
{
    $statement = db()->prepare(
        'UPDATE work_templates
         SET status = "active",
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?
           AND workspace_id = ?'
    );

    $statement->execute([$templateId, $workspaceId]);
}

/**
 * Delete a template that was never published and is not referenced by any
 * task. Published or referenced templates must be archived, never deleted.
 */
function work_template_delete_safe(int $workspaceId, int $templateId): ?string
{
    $connection = db();

    $publishedCount = $connection->prepare(
        'SELECT COUNT(*)
         FROM work_template_versions
         WHERE template_id = ?
           AND status != "draft"'
    );
    $publishedCount->execute([$templateId]);
    $publishedVersionCount = (int) $publishedCount->fetchColumn();

    if ($publishedVersionCount > 0) {
        return 'Published templates cannot be deleted. Archive it instead.';
    }

    $referenceCount = $connection->prepare(
        'SELECT COUNT(*)
         FROM tasks
         WHERE template_version_id IN (
             SELECT id
             FROM work_template_versions
             WHERE template_id = ?
         )'
    );
    $referenceCount->execute([$templateId]);

    if ((int) $referenceCount->fetchColumn() > 0) {
        return 'This template is in use and cannot be deleted.';
    }

    $statement = $connection->prepare(
        'DELETE FROM work_templates
         WHERE id = ?
           AND workspace_id = ?'
    );
    $statement->execute([$templateId, $workspaceId]);

    return null;
}
/*
|--------------------------------------------------------------------------
| Version lifecycle
|--------------------------------------------------------------------------
*/

function work_template_create_draft_version(
    int $workspaceId,
    int $createdBy,
    int $templateId
): int {
    $connection = db();

    $connection->beginTransaction();

    try {
        $template = work_template_by_id($workspaceId, $templateId);

        if ($template === null || $template['status'] !== 'active') {
            throw new RuntimeException('Template is not available.');
        }

        $nextVersion = (int) $connection->query(
            'SELECT COALESCE(MAX(version_number), 0) + 1
             FROM work_template_versions
             WHERE template_id = ' . (int) $templateId
        )->fetchColumn();

        $versionStatement = $connection->prepare(
            'INSERT INTO work_template_versions
                (template_id, version_number, status, created_by)
             VALUES (?, ?, "draft", ?)'
        );
        $versionStatement->execute([
            $templateId,
            $nextVersion,
            $createdBy,
        ]);

        $versionId = (int) $connection->lastInsertId();

        // Clone the most recent definition (latest version wins).
        $sourceVersion = $connection->prepare(
            'SELECT id
             FROM work_template_versions
             WHERE template_id = ?
             ORDER BY version_number DESC
             LIMIT 1'
        );
        $sourceVersion->execute([$templateId]);
        $sourceVersionId = $sourceVersion->fetchColumn();

        if ($sourceVersionId !== false && (int) $sourceVersionId !== $versionId) {
            $sections = $connection->prepare(
                'SELECT id, sort_order, name, description
                 FROM work_template_sections
                 WHERE version_id = ?
                 ORDER BY sort_order ASC, id ASC'
            );
            $sections->execute([(int) $sourceVersionId]);

            foreach ($sections->fetchAll() as $section) {
                $sectionInsert = $connection->prepare(
                    'INSERT INTO work_template_sections
                        (version_id, sort_order, name, description)
                     VALUES (?, ?, ?, ?)'
                );
                $sectionInsert->execute([
                    $versionId,
                    (int) $section['sort_order'],
                    $section['name'],
                    $section['description'],
                ]);

                $newSectionId = (int) $connection->lastInsertId();

                $fields = $connection->prepare(
                    'SELECT id, sort_order, name, description, field_type,
                            is_required, options_json, number_unit, config_json,
                            field_key
                     FROM work_template_fields
                     WHERE section_id = ?
                     ORDER BY sort_order ASC, id ASC'
                );
                $fields->execute([(int) $section['id']]);

                foreach ($fields->fetchAll() as $field) {
                    $fieldInsert = $connection->prepare(
                        'INSERT INTO work_template_fields
                            (
                                section_id,
                                sort_order,
                                name,
                                description,
                                field_type,
                                is_required,
                                options_json,
                                number_unit,
                                config_json,
                                field_key
                            )
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
                    );
                    $fieldInsert->execute([
                        $newSectionId,
                        (int) $field['sort_order'],
                        $field['name'],
                        $field['description'],
                        $field['field_type'],
                        (int) $field['is_required'],
                        $field['options_json'],
                        $field['number_unit'],
                        $field['config_json'],
                        work_template_clone_field_key($field),
                    ]);
                }
            }
        }

        $connection->commit();

        return $versionId;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}
function work_template_publish_version(int $workspaceId, int $versionId): ?string
{
    $version = work_template_draft_version($workspaceId, $versionId);

    if ($version === null) {
        return 'Only a draft version of an active template can be published.';
    }

    $templateId = (int) $version['template_id'];

    $definition = work_template_definition($versionId);

    if ($definition === []) {
        return 'Add at least one section to publish this template.';
    }

    foreach ($definition as $section) {
        if ($section['fields'] === []) {
            return 'Every section needs at least one field to publish.';
        }

        foreach ($section['fields'] as $field) {
            $normalized = work_template_normalize_field_definition(
                (string) $field['field_type'],
                $field['options'] !== []
                    ? implode("\n", $field['options'])
                    : null,
                $field['number_unit'],
                $field['config']
            );

            if ($normalized['error'] !== null) {
                return 'Field "' . $field['name'] . '": '
                    . $normalized['error'];
            }
        }
    }

    // Enforce per-version field_key uniqueness. There is intentionally no
    // global unique index on field_key, because a logical key must survive
    // draft cloning into later Template Versions.
    $seenKeys = [];
    foreach ($definition as $section) {
        foreach ($section['fields'] as $field) {
            $key = (string) $field['field_key'];
            if (isset($seenKeys[$key])) {
                return 'Field "' . $field['name'] . '" uses a duplicate key.';
            }
            $seenKeys[$key] = $field;
        }
    }

    foreach ($seenKeys as $field) {
        $type = $field['field_type'];
        if ($type === 'lookup' || $type === 'rollup') {
            $source = $seenKeys[$field['config']['relation_field_key'] ?? ''] ?? null;
            if ($source === null || !in_array($source['field_type'], ['relation', 'task_relation', 'project_relation', 'file_relation', 'record_relation'], true)) {
                return 'Calculated fields must reference a relation field in this version.';
            }
            $targets = $source['field_type'] === 'relation' ? ($source['config']['target_types'] ?? [])
                : [str_replace('_relation', '', $source['field_type'])];
            if ($type === 'lookup' && !in_array($field['config']['target_type'], $targets, true)) {
                return 'Lookup target must match its relation field.';
            }
        }
        if ($type === 'approval') {
            foreach ($field['config']['approver_ids'] as $approverId) {
                $eligible = db()->prepare('SELECT 1 FROM workspace_members wm INNER JOIN users u ON u.id = wm.user_id
                    WHERE wm.workspace_id = ? AND wm.user_id = ? AND u.account_status = \'active\'');
                $eligible->execute([$workspaceId, $approverId]);
                if (!$eligible->fetchColumn()) {
                    return 'Approvers must be active members of this workspace.';
                }
            }
        }
    }

    $snapshot = [
        'version_number' => (int) $version['version_number'],
        'sections' => array_map(
            static function (array $section): array {
                return [
                    'id' => $section['id'],
                    'name' => $section['name'],
                    'description' => $section['description'],
                    'fields' => array_map(
                        static function (array $field): array {
                            return [
                                'id' => $field['id'],
                                'field_key' => $field['field_key'],
                                'name' => $field['name'],
                                'description' => $field['description'],
                                'field_type' => $field['field_type'],
                                'is_required' => $field['is_required'],
                                'options' => $field['options'],
                                'number_unit' => $field['number_unit'],
                                'config' => $field['config'],
                            ];
                        },
                        $section['fields']
                    ),
                ];
            },
            $definition
        ),
    ];

    $connection = db();
    $connection->beginTransaction();

    try {
        $retire = $connection->prepare(
            'UPDATE work_template_versions
             SET status = "retired",
                 retired_at = CURRENT_TIMESTAMP
             WHERE template_id = ?
               AND status = "published"'
        );
        $retire->execute([$templateId]);

        $publish = $connection->prepare(
            'UPDATE work_template_versions
             SET status = "published",
                 published_at = CURRENT_TIMESTAMP,
                 definition_json = ?
             WHERE id = ?
               AND status = "draft"'
        );
        $publish->execute([
            work_template_encode_json($snapshot),
            $versionId,
        ]);

        $connection->commit();

        return null;
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}
/*
|--------------------------------------------------------------------------
| Draft section mutations
|--------------------------------------------------------------------------
*/

function work_template_add_section(
    int $workspaceId,
    int $versionId,
    string $name,
    ?string $description
): int {
    if (work_template_draft_version($workspaceId, $versionId) === null) {
        throw new RuntimeException('That draft version is not editable.');
    }

    $maxOrder = (int) db()->query(
        'SELECT COALESCE(MAX(sort_order), 0) + 1
         FROM work_template_sections
         WHERE version_id = ' . (int) $versionId
    )->fetchColumn();

    $statement = db()->prepare(
        'INSERT INTO work_template_sections
            (version_id, sort_order, name, description)
         VALUES (?, ?, ?, ?)'
    );
    $statement->execute([
        $versionId,
        $maxOrder,
        $name,
        $description !== '' ? $description : null,
    ]);

    return (int) db()->lastInsertId();
}

function work_template_update_section(
    int $workspaceId,
    int $sectionId,
    string $name,
    ?string $description
): void {
    if (work_template_section_row($workspaceId, $sectionId) === null) {
        throw new RuntimeException('That section is not editable.');
    }

    $statement = db()->prepare(
        'UPDATE work_template_sections
         SET name = ?,
             description = ?
         WHERE id = ?'
    );
    $statement->execute([
        $name,
        $description !== '' ? $description : null,
        $sectionId,
    ]);
}

function work_template_delete_section(int $workspaceId, int $sectionId): void
{
    if (work_template_section_row($workspaceId, $sectionId) === null) {
        throw new RuntimeException('That section is not editable.');
    }

    $statement = db()->prepare(
        'DELETE FROM work_template_sections WHERE id = ?'
    );
    $statement->execute([$sectionId]);
}

function work_template_move_section(
    int $workspaceId,
    int $sectionId,
    string $direction
): void {
    $section = work_template_section_row($workspaceId, $sectionId);

    if ($section === null) {
        throw new RuntimeException('That section is not editable.');
    }

    if (!in_array($direction, ['up', 'down'], true)) {
        throw new RuntimeException('Invalid move direction.');
    }

    work_template_move_ordered(
        'work_template_sections',
        'version_id',
        (int) $section['version_id'],
        $sectionId,
        (int) $section['sort_order'],
        $direction
    );
}

/**
 * Swap sort_order with the neighbouring row in either direction.
 * Table and parent column names are internal constants, never user input.
 */
function work_template_move_ordered(
    string $table,
    string $parentColumn,
    int $parentId,
    int $rowId,
    int $sortOrder,
    string $direction
): void {
    $connection = db();

    $operator = $direction === 'up' ? '<' : '>';
    $orderDirection = $direction === 'up' ? 'DESC' : 'ASC';

    $neighbour = $connection->prepare(
        'SELECT id, sort_order
         FROM ' . $table . '
         WHERE ' . $parentColumn . ' = ?
           AND sort_order ' . $operator . ' ?
         ORDER BY sort_order ' . $orderDirection . ',
                  id ' . $orderDirection . '
         LIMIT 1'
    );
    $neighbour->execute([$parentId, $sortOrder]);

    $other = $neighbour->fetch();

    if (!$other) {
        return;
    }

    $connection->beginTransaction();

    try {
        $swapA = $connection->prepare(
            'UPDATE ' . $table . ' SET sort_order = ? WHERE id = ?'
        );
        $swapA->execute([(int) $other['sort_order'], $rowId]);

        $swapB = $connection->prepare(
            'UPDATE ' . $table . ' SET sort_order = ? WHERE id = ?'
        );
        $swapB->execute([$sortOrder, (int) $other['id']]);

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}
/*
|--------------------------------------------------------------------------
| Draft field mutations
|--------------------------------------------------------------------------
*/

function work_template_add_field(
    int $workspaceId,
    int $sectionId,
    string $name,
    string $fieldType,
    ?string $optionsRaw,
    ?string $numberUnit,
    array $config
): int {
    $section = work_template_section_row($workspaceId, $sectionId);

    if ($section === null) {
        throw new RuntimeException('That section is not editable.');
    }

    $normalized = work_template_normalize_field_definition(
        $fieldType,
        $optionsRaw,
        $numberUnit,
        $config
    );

    if ($normalized['error'] !== null) {
        throw new RuntimeException($normalized['error']);
    }

    $maxOrder = (int) db()->query(
        'SELECT COALESCE(MAX(sort_order), 0) + 1
         FROM work_template_fields
         WHERE section_id = ' . (int) $sectionId
    )->fetchColumn();

    $statement = db()->prepare(
        'INSERT INTO work_template_fields
            (
                section_id,
                sort_order,
                name,
                field_type,
                is_required,
                options_json,
                number_unit,
                config_json,
                field_key
            )
         VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?)'
    );
    $statement->execute([
        $sectionId,
        $maxOrder,
        $name,
        $fieldType,
        $normalized['options_json'],
        $normalized['number_unit'],
        $normalized['config_json'],
        work_template_generate_field_key(),
    ]);

    return (int) db()->lastInsertId();
}

function work_template_update_field(
    int $workspaceId,
    int $fieldId,
    string $name,
    string $fieldType,
    bool $isRequired,
    ?string $optionsRaw,
    ?string $numberUnit,
    array $config
): void {
    if (work_template_field_row($workspaceId, $fieldId) === null) {
        throw new RuntimeException('That field is not editable.');
    }

    $normalized = work_template_normalize_field_definition(
        $fieldType,
        $optionsRaw,
        $numberUnit,
        $config
    );

    if ($normalized['error'] !== null) {
        throw new RuntimeException($normalized['error']);
    }

    $statement = db()->prepare(
        'UPDATE work_template_fields
         SET name = ?,
             field_type = ?,
             is_required = ?,
             options_json = ?,
             number_unit = ?,
             config_json = ?
         WHERE id = ?'
    );
    $statement->execute([
        $name,
        $fieldType,
        $isRequired ? 1 : 0,
        $normalized['options_json'],
        $normalized['number_unit'],
        $normalized['config_json'],
        $fieldId,
    ]);
}

function work_template_delete_field(int $workspaceId, int $fieldId): void
{
    if (work_template_field_row($workspaceId, $fieldId) === null) {
        throw new RuntimeException('That field is not editable.');
    }

    $statement = db()->prepare(
        'DELETE FROM work_template_fields WHERE id = ?'
    );
    $statement->execute([$fieldId]);
}

function work_template_move_field(
    int $workspaceId,
    int $fieldId,
    string $direction
): void {
    $field = work_template_field_row($workspaceId, $fieldId);

    if ($field === null) {
        throw new RuntimeException('That field is not editable.');
    }

    if (!in_array($direction, ['up', 'down'], true)) {
        throw new RuntimeException('Invalid move direction.');
    }

    work_template_move_ordered(
        'work_template_fields',
        'section_id',
        (int) $field['section_id'],
        $fieldId,
        (int) $field['sort_order'],
        $direction
    );
}
/*
|--------------------------------------------------------------------------
| Task-list allowed templates
|--------------------------------------------------------------------------
*/

function work_template_allowed_templates(
    int $workspaceId,
    int $taskListId
): array {
    $statement = db()->prepare(
        'SELECT
            t.id,
            t.name,
            t.description,
            t.status,
            v.id AS published_version_id,
            v.version_number AS published_version_number
         FROM task_list_allowed_templates alat
         INNER JOIN work_templates t
             ON t.id = alat.template_id
         LEFT JOIN work_template_versions v
             ON v.template_id = t.id
            AND v.status = "published"
         INNER JOIN task_lists tl
             ON tl.id = alat.task_list_id
         WHERE tl.id = ?
           AND tl.workspace_id = ?
           AND t.workspace_id = ?
           AND t.status = "active"
         ORDER BY t.name COLLATE NOCASE ASC'
    );

    $statement->execute([$taskListId, $workspaceId, $workspaceId]);

    return $statement->fetchAll();
}

function work_template_allowed_template_ids(
    int $workspaceId,
    int $taskListId
): array {
    $statement = db()->prepare(
        'SELECT alat.template_id
         FROM task_list_allowed_templates alat
         INNER JOIN task_lists tl
             ON tl.id = alat.task_list_id
         WHERE tl.id = ?
           AND tl.workspace_id = ?
         ORDER BY alat.template_id ASC'
    );

    $statement->execute([$taskListId, $workspaceId]);

    return array_map(
        'intval',
        $statement->fetchAll(PDO::FETCH_COLUMN)
    );
}

/**
 * Replace the allowed-template set and default template for a task list.
 *
 * Selecting a default implicitly allows that template, so the stored state can
 * never become inconsistent (the default always belongs to the allowed set).
 * Passing NULL keeps the Basic Task default and does not touch the allowed set.
 */
function work_template_set_task_list_templates(
    int $workspaceId,
    int $taskListId,
    array $templateIds,
    ?int $defaultTemplateId
): void {
    $templateIds = array_values(array_unique(array_map('intval', $templateIds)));
    $templateIds = array_values(array_filter(
        $templateIds,
        static fn (int $id): bool => $id > 0
    ));

    if (
        $defaultTemplateId !== null
        && !in_array($defaultTemplateId, $templateIds, true)
    ) {
        // Choosing a default automatically allows that template. This keeps
        // default_template_id and the allowed set consistent without trusting
        // client-side JavaScript. The default is still validated against the
        // workspace / active / published rules below.
        $templateIds[] = $defaultTemplateId;
    }

    $connection = db();

    if ($templateIds !== []) {
        $placeholders = implode(
            ',',
            array_fill(0, count($templateIds), '?')
        );

        $validTemplates = $connection->prepare(
            'SELECT COUNT(*)
             FROM work_templates
             WHERE workspace_id = ?
               AND id IN (' . $placeholders . ')
               AND status = "active"
               AND EXISTS (
                   SELECT 1
                   FROM work_template_versions
                   WHERE work_template_versions.template_id = work_templates.id
                     AND work_template_versions.status = "published"
               )'
        );

        $parameters = array_merge([$workspaceId], $templateIds);
        $validTemplates->execute($parameters);

        if ((int) $validTemplates->fetchColumn() !== count($templateIds)) {
            throw new RuntimeException(
                'One or more selected templates are not available.'
            );
        }
    }

    $connection->beginTransaction();

    try {
        $delete = $connection->prepare(
            'DELETE FROM task_list_allowed_templates
             WHERE task_list_id = ?'
        );
        $delete->execute([$taskListId]);

        if ($templateIds !== []) {
            $insert = $connection->prepare(
                'INSERT INTO task_list_allowed_templates
                    (task_list_id, template_id)
                 VALUES (?, ?)'
            );

            foreach ($templateIds as $templateId) {
                $insert->execute([$taskListId, $templateId]);
            }
        }

        $update = $connection->prepare(
            'UPDATE task_lists
             SET default_template_id = ?
             WHERE id = ?
               AND workspace_id = ?'
        );
        $update->execute([
            $defaultTemplateId,
            $taskListId,
            $workspaceId,
        ]);

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }
}
