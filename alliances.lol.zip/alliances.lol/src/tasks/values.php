<?php

declare(strict_types=1);

require_once __DIR__ . '/../database.php';
require_once __DIR__ . '/fields.php';
require_once __DIR__ . '/templates.php';

/*
|--------------------------------------------------------------------------
| Typed field values for template-backed tasks
|--------------------------------------------------------------------------
|
| Rendering and validation always resolve the field definition from the
| task's immutable template version (its definition_json snapshot). The
| submitted field_type is never trusted.
|
*/

function work_template_task_definition(
    int $workspaceId,
    int $taskId
): ?array {
    $statement = db()->prepare(
        'SELECT
            wtv.id AS version_id,
            wtv.version_number,
            wtv.status AS version_status,
            wtv.definition_json,
            wtw.name AS template_name,
            wtw.status AS template_status
         FROM tasks t
         INNER JOIN task_lists tl
             ON tl.id = t.task_list_id
         INNER JOIN work_template_versions wtv
             ON wtv.id = t.template_version_id
         INNER JOIN work_templates wtw
             ON wtw.id = wtv.template_id
            AND wtw.workspace_id = tl.workspace_id
         WHERE t.id = ?
           AND tl.workspace_id = ?
         LIMIT 1'
    );

    $statement->execute([$taskId, $workspaceId]);

    $row = $statement->fetch();

    if (!$row) {
        return null;
    }

    $snapshot = $row['definition_json'] !== null
        ? json_decode($row['definition_json'], true)
        : null;

    if (!is_array($snapshot) || !isset($snapshot['sections']) || !is_array($snapshot['sections'])) {
        // Fallback: reconstruct from the immutable relational rows.
        $snapshot = [
            'version_number' => (int) $row['version_number'],
            'sections' => work_template_definition((int) $row['version_id']),
        ];
    }

    $sections = isset($snapshot['sections']) && is_array($snapshot['sections'])
        ? $snapshot['sections']
        : [];

    // Legacy snapshots resolve identity locally; never consult mutable builder rows.
    foreach ($sections as &$section) {
        foreach ($section['fields'] as &$field) {
            $field['field_key'] = work_template_field_key($field['field_key'] ?? null, (int) $field['id']);
        }
        unset($field);
    }
    unset($section);

    return [
        'version_id' => (int) $row['version_id'],
        'version_number' => (int) $row['version_number'],
        'version_status' => (string) $row['version_status'],
        'template_name' => (string) $row['template_name'],
        'template_status' => (string) $row['template_status'],
        'sections' => $sections,
    ];
}

function work_template_task_values(int $taskId): array
{
    $statement = db()->prepare(
        'SELECT
            field_id,
            value_text,
            value_integer,
            value_real,
            value_json
         FROM task_values
         WHERE task_id = ?
         ORDER BY id ASC'
    );

    $statement->execute([$taskId]);

    $values = [];

    foreach ($statement->fetchAll() as $row) {
        $values[(int) $row['field_id']] = [
            'value_text' => $row['value_text'],
            'value_integer' => $row['value_integer'],
            'value_real' => $row['value_real'],
            'value_json' => $row['value_json'],
        ];
    }

    return $values;
}

function work_template_person_choices(int $workspaceId): array
{
    $statement = db()->prepare(
        'SELECT u.id, u.display_name
         FROM users u
         INNER JOIN workspace_members wm
             ON wm.user_id = u.id
         WHERE wm.workspace_id = ?
           AND u.account_status = "active"
         ORDER BY u.display_name COLLATE NOCASE ASC'
    );

    $statement->execute([$workspaceId]);

    $choices = [];

    foreach ($statement->fetchAll() as $row) {
        $choices[(int) $row['id']] = (string) $row['display_name'];
    }

    return $choices;
}

function work_template_team_choices(int $workspaceId): array
{
    $statement = db()->prepare(
        'SELECT t.id, t.name
         FROM teams t
         WHERE t.workspace_id = ?
           AND t.status = "active"
         ORDER BY t.name COLLATE NOCASE ASC'
    );

    $statement->execute([$workspaceId]);

    $choices = [];

    foreach ($statement->fetchAll() as $row) {
        $choices[(int) $row['id']] = (string) $row['name'];
    }

    return $choices;
}

function work_template_project_choices(int $workspaceId): array
{
    $statement = db()->prepare(
        'SELECT p.id, p.name
         FROM projects p
         WHERE p.workspace_id = ?
           AND p.status != "archived"
         ORDER BY p.name COLLATE NOCASE ASC'
    );
    $statement->execute([$workspaceId]);

    $choices = [];
    foreach ($statement->fetchAll() as $row) {
        $choices[(int) $row['id']] = (string) $row['name'];
    }

    return $choices;
}
function work_template_field_current_value(array $field, ?array $valueRow): mixed
{
    if ($valueRow === null) {
        return null;
    }

    $storage = work_template_field_storage((string) $field['field_type']);

    if ($storage === 'real') {
        return is_numeric($valueRow['value_real'])
            ? (float) $valueRow['value_real']
            : $valueRow['value_real'];
    }

    if ($storage === 'integer') {
        return filter_var($valueRow['value_integer'], FILTER_VALIDATE_INT) !== false
            ? (int) $valueRow['value_integer']
            : $valueRow['value_integer'];
    }

    if ($storage === 'json') {
        if ($valueRow['value_json'] === null) {
            return null;
        }
        $decoded = json_decode((string) $valueRow['value_json'], true);

        // Keep malformed historical data visible instead of silently treating it as empty.
        return is_array($decoded) ? $decoded : $valueRow['value_json'];
    }

    return $valueRow['value_text'];
}

function work_template_render_field_value(
    array $field,
    mixed $value,
    array $personChoices,
    array $teamChoices,
    array $projectChoices = []
): string {
    $type = (string) $field['field_type'];
    $escape = static fn (string $text): string =>
        htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    if (work_template_value_shape_error($field, $value) !== null) {
        return $escape(is_scalar($value) ? (string) $value : work_template_encode_json($value));
    }

    if (work_template_value_is_empty($value)) {
        return '—';
    }

    switch ($type) {
        case 'checkbox':
            return (int) $value === 1 ? 'Yes' : 'No';

        case 'multi_select':
        case 'checkbox_group':
            return is_array($value)
                ? $escape(implode(', ', array_map('strval', $value)))
                : $escape((string) $value);

        case 'person':
            return $escape(
                $personChoices[(int) $value] ?? 'Unknown person'
            );
        case 'team':
            return $escape(
                $teamChoices[(int) $value] ?? 'Unknown team'
            );

        case 'people':
            if (!is_array($value)) {
                return $escape((string) $value);
            }
            $names = [];
            foreach ($value as $id) {
                $names[] = $personChoices[(int) $id] ?? 'Unknown person';
            }

            return $escape(implode(', ', $names));

        case 'teams':
            if (!is_array($value)) {
                return $escape((string) $value);
            }
            $teamNames = [];
            foreach ($value as $id) {
                $teamNames[] = $teamChoices[(int) $id] ?? 'Unknown team';
            }

            return $escape(implode(', ', $teamNames));

        case 'project_role':
            if (!is_array($value)) {
                return $escape((string) $value);
            }
            $roleProject = $projectChoices[(int) ($value['project_id'] ?? 0)]
                ?? 'Unavailable project';
            $roleName = ucfirst((string) ($value['role'] ?? 'member'));

            return $escape($roleProject . ' - ' . $roleName);

        case 'number_unit':
            $unit = trim((string) ($field['number_unit'] ?? ''));

            return $unit !== ''
                ? $escape(work_template_format_bound((float) $value) . ' ' . $unit)
                : $escape((string) $value);

        case 'currency':
            return $escape('$' . work_template_format_bound((float) $value));

        case 'percentage':
            return $escape(work_template_format_bound((float) $value) . '%');

        case 'number':
        case 'integer':
        case 'decimal':
        case 'rating':
        case 'range':
            return $escape(work_template_format_bound((float) $value));

        case 'scale':
            $numeric = (float) $value;
            $labels = is_array($field['config']['labels'] ?? null)
                ? $field['config']['labels']
                : [];

            foreach ($labels as $label) {
                if ((float) ($label['value'] ?? 0) === $numeric) {
                    return $escape(
                        (string) ($label['label'] ?? work_template_format_bound($numeric))
                    );
                }
            }

            return $escape(work_template_format_bound($numeric));

        case 'yes_no':
        case 'pass_fail':
        case 'tri_state':
            return $escape((string) $value);

        case 'status':
            return '<span class="badge badge--warning">'
                . $escape((string) $value) . '</span>';

        case 'color':
            if (!preg_match('/^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/', (string) $value)) {
                return $escape((string) $value);
            }
            return '<span class="task-template-color-swatch" style="background:'
                . $escape((string) $value) . '"></span> '
                . $escape((string) $value);

        case 'rich_text':
            return nl2br($escape((string) $value));

        case 'code':
            return '<pre class="task-template-code">'
                . $escape((string) $value) . '</pre>';

        case 'date_range':
        case 'time_range':
            if (is_array($value)) {
                return $escape(
                    (string) ($value['start'] ?? '')
                    . ' – '
                    . (string) ($value['end'] ?? '')
                );
            }

            return $escape((string) $value);

        case 'coordinates':
            if (is_array($value)) {
                return $escape(
                    (string) ($value['lat'] ?? '') . ', ' . (string) ($value['lng'] ?? '')
                );
            }

            return $escape((string) $value);

        case 'duration':
            return $escape(work_template_format_duration((int) $value));

        default:
            return $escape((string) $value);
    }
}

function work_template_field_required_error(array $field): string
{
    return '"' . $field['name'] . '" is required.';
}
function work_template_value_is_empty(mixed $value): bool
{
    if ($value === null || $value === '') {
        return true;
    }

    if (is_array($value)) {
        foreach ($value as $item) {
            if (is_scalar($item) && trim((string) $item) !== '') {
                return false;
            }
        }

        return true;
    }

    // "" is handled above. Values such as 0, "0", "No", "Fail", and "N/A" are
    // legitimate and must never be treated as empty. A boolean false needs an
    // explicit guard because (string) false === "".
    if ($value === false) {
        return false;
    }

    return trim((string) $value) === '';
}

function work_template_format_bound(float $value): string
{
    // PHP's float string already omits fractional zeroes; trimming would turn 100 into 1.
    return (string) $value;
}

/** Reject malformed shapes before casting, validating, or rendering browser/historical data. */
function work_template_value_shape_error(array $field, mixed $value): ?string
{
    if ($value === null || $value === '') {
        return null;
    }

    $type = (string) $field['field_type'];
    if (work_template_field_storage($type) === 'json') {
        if (!is_array($value)) {
            return 'Enter a valid value.';
        }
        $keys = match ($type) {
            'date_range', 'time_range' => ['start', 'end'],
            'coordinates' => ['lat', 'lng'],
            default => null,
        };
        foreach ($value as $key => $part) {
            if (($keys !== null && !in_array($key, $keys, true))
                || (!is_scalar($part) && $part !== null)
                || (is_string($part) && str_contains($part, "\0"))) {
                return 'Enter a valid value.';
            }
        }
        return null;
    }

    return !is_scalar($value) || (is_string($value) && str_contains($value, "\0"))
        ? 'Enter a single valid value.'
        : null;
}

/**
 * Shared length guard for the new Phase 2A free-text field types. Existing
 * Phase 1 text types intentionally keep their original, unbounded behaviour.
 */
function work_template_validate_text_value(mixed $value): ?string
{
    if (strlen((string) $value) > 2000) {
        return 'Enter a value up to 2000 characters.';
    }

    return null;
}

/**
 * Validate a single submitted value against the immutable field definition.
 * The submitted field_type from the request is never consulted; the storage
 * and constraints always come from the template version definition.
 */
function work_template_validate_value(
    array $field,
    mixed $value,
    array $personChoices,
    array $teamChoices,
    array $projectChoices = []
): ?string {
    $type = (string) $field['field_type'];
    $required = (bool) ($field['is_required'] ?? false);

    if (work_template_field_is_computed($type)) {
        return work_template_value_is_empty($value)
            ? null
            : 'This field is calculated and cannot be edited.';
    }

    if (work_template_field_is_normalized($type)) {
        return null;
    }

    $shapeError = work_template_value_shape_error($field, $value);
    if ($shapeError !== null) {
        return $shapeError;
    }
    $isEmpty = work_template_value_is_empty($value);

    if ($required && $isEmpty) {
        return work_template_field_required_error($field);
    }

    if ($isEmpty) {
        return null;
    }

    $storage = work_template_field_storage($type);
    if (in_array($storage, ['real', 'integer'], true)
        && is_numeric($value) && !is_finite((float) $value)) {
        return 'Enter a finite number.';
    }

    $options = is_array($field['options'] ?? null)
        ? $field['options']
        : [];

    $config = is_array($field['config'] ?? null)
        ? $field['config']
        : [];

    switch ($type) {
        case 'checkbox':
            if (!in_array($value, [0, 1, '0', '1', false, true], true)) {
                return 'Choose a valid checkbox value.';
            }
            break;
        case 'dropdown':
            if (!in_array((string) $value, $options, true)) {
                return 'Choose a valid option.';
            }
            break;

        case 'multi_select':
            if (!is_array($value)) {
                return 'Choose a valid option.';
            }

            foreach ($value as $option) {
                if (!in_array((string) $option, $options, true)) {
                    return 'Choose a valid option.';
                }
            }
            break;

        case 'radio':
            if (!in_array((string) $value, $options, true)) {
                return 'Choose a valid option.';
            }
            break;

        case 'checkbox_group':
            if (!is_array($value)) {
                return 'Choose a valid option.';
            }

            foreach ($value as $option) {
                if (!in_array((string) $option, $options, true)) {
                    return 'Choose a valid option.';
                }
            }
            break;

        case 'status':
            if (!in_array((string) $value, $options, true)) {
                return 'Choose a valid option.';
            }
            break;

        case 'tri_state':
            if (!in_array($value, ['Yes', 'No', 'N/A'], true)) {
                return 'Choose Yes, No, or N/A.';
            }
            break;

        case 'yes_no':
            if (!in_array($value, ['Yes', 'No'], true)) {
                return 'Choose Yes or No.';
            }
            break;

        case 'pass_fail':
            if (!in_array($value, ['Pass', 'Fail'], true)) {
                return 'Choose Pass or Fail.';
            }
            break;

        case 'number':
        case 'number_unit':
        case 'currency':
        case 'decimal':
        case 'percentage':
        case 'range':
            if (!is_numeric((string) $value)) {
                return 'Enter a number.';
            }

            $number = (float) $value;

            $min = array_key_exists('min', $config)
                ? (float) $config['min']
                : null;
            $max = array_key_exists('max', $config)
                ? (float) $config['max']
                : null;

            if ($min !== null && $number < $min) {
                return 'Enter at least '
                    . work_template_format_bound($min) . '.';
            }

            if ($max !== null && $number > $max) {
                return 'Enter at most '
                    . work_template_format_bound($max) . '.';
            }
            break;

        case 'integer':
            if (!is_numeric((string) $value)) {
                return 'Enter a number.';
            }

            $number = (float) $value;

            if ((float) (int) $number !== $number) {
                return 'Enter a whole number.';
            }

            $min = array_key_exists('min', $config)
                ? (float) $config['min']
                : null;
            $max = array_key_exists('max', $config)
                ? (float) $config['max']
                : null;

            if ($min !== null && $number < $min) {
                return 'Enter at least '
                    . work_template_format_bound($min) . '.';
            }

            if ($max !== null && $number > $max) {
                return 'Enter at most '
                    . work_template_format_bound($max) . '.';
            }
            break;

        case 'rating':
            if (!is_numeric((string) $value)) {
                return 'Enter a number.';
            }

            $number = (float) $value;

            $min = array_key_exists('min', $config)
                ? (float) $config['min']
                : 1.0;
            $max = array_key_exists('max', $config)
                ? (float) $config['max']
                : 5.0;

            if ((float) (int) $number !== $number) {
                return 'Enter a whole-number rating.';
            }

            if ($number < $min) {
                return 'Enter at least '
                    . work_template_format_bound($min) . '.';
            }

            if ($number > $max) {
                return 'Enter at most '
                    . work_template_format_bound($max) . '.';
            }
            break;

        case 'scale':
            if (!is_numeric((string) $value)) {
                return 'Enter a number.';
            }

            $number = (float) $value;

            $min = array_key_exists('min', $config)
                ? (float) $config['min']
                : 1.0;
            $max = array_key_exists('max', $config)
                ? (float) $config['max']
                : 5.0;

            if ($number < $min || $number > $max) {
                return 'Enter a value between '
                    . work_template_format_bound($min) . ' and '
                    . work_template_format_bound($max) . '.';
            }

            $labels = $config['labels'] ?? [];

            if (is_array($labels) && $labels !== []) {
                $allowed = [];

                foreach ($labels as $label) {
                    $allowed[] = (float) ($label['value'] ?? 0);
                }

                if (!in_array($number, $allowed, true)) {
                    return 'Choose a valid scale value.';
                }
            }
            break;

        case 'email':
            if (filter_var(trim((string) $value), FILTER_VALIDATE_EMAIL) === false) {
                return 'Enter a valid email address.';
            }
            break;

        case 'phone':
            if (!preg_match('/^[0-9+\-().\s]{3,30}$/', (string) $value)) {
                return 'Enter a valid phone number.';
            }
            break;

        case 'ip_address':
            if (filter_var(trim((string) $value), FILTER_VALIDATE_IP) === false) {
                return 'Enter a valid IP address.';
            }
            break;

        case 'color':
            if (!preg_match('/^#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/', (string) $value)) {
                return 'Enter a valid hex color.';
            }
            break;

        case 'time':
            $time = DateTimeImmutable::createFromFormat('!H:i', (string) $value);

            if ($time === false) {
                $time = DateTimeImmutable::createFromFormat('!H:i:s', (string) $value);
            }

            if ($time === false) {
                return 'Enter a valid time.';
            }
            break;

        case 'duration':
            if (!ctype_digit((string) $value)) {
                return 'Enter a whole number of seconds.';
            }
            break;

        case 'date_range':
            if (!is_array($value)) {
                return 'Enter a valid date range.';
            }

            $start = (string) ($value['start'] ?? '');
            $end = (string) ($value['end'] ?? '');

            if (($start === '') !== ($end === '')) {
                return 'Enter both start and end dates.';
            }

            foreach ([$start, $end] as $part) {
                if ($part === '') {
                    continue;
                }

                $date = DateTimeImmutable::createFromFormat('!Y-m-d', $part);

                if ($date === false || $date->format('Y-m-d') !== $part) {
                    return 'Enter a valid date range.';
                }
            }

            if ($start !== '' && $end !== '' && $start > $end) {
                return 'Start date cannot be after end date.';
            }
            break;

        case 'time_range':
            if (!is_array($value)) {
                return 'Enter a valid time range.';
            }

            $start = (string) ($value['start'] ?? '');
            $end = (string) ($value['end'] ?? '');

            if (($start === '') !== ($end === '')) {
                return 'Enter both start and end times.';
            }

            foreach ([$start, $end] as $part) {
                if ($part === '') {
                    continue;
                }

                $time = DateTimeImmutable::createFromFormat('!H:i', $part);

                if ($time === false) {
                    $time = DateTimeImmutable::createFromFormat('!H:i:s', $part);
                }

                if ($time === false) {
                    return 'Enter a valid time range.';
                }
            }
            break;

        case 'coordinates':
            if (!is_array($value)) {
                return 'Enter valid coordinates.';
            }

            $lat = $value['lat'] ?? null;
            $lng = $value['lng'] ?? null;

            if (!is_numeric((string) $lat) || !is_numeric((string) $lng)) {
                return 'Enter valid coordinates.';
            }

            if ((float) $lat < -90 || (float) $lat > 90) {
                return 'Latitude must be between -90 and 90.';
            }

            if ((float) $lng < -180 || (float) $lng > 180) {
                return 'Longitude must be between -180 and 180.';
            }
            break;

        case 'rich_text':
        case 'code':
        case 'version':
        case 'address':
        case 'location':
        case 'barcode':
        case 'qr_code':
            $lengthError = work_template_validate_text_value($value);

            if ($lengthError !== null) {
                return $lengthError;
            }
            break;

        case 'url':
            if (filter_var(trim((string) $value), FILTER_VALIDATE_URL) === false) {
                return 'Enter a valid URL.';
            }
            break;

        case 'person':
            if (filter_var($value, FILTER_VALIDATE_INT) === false
                || !array_key_exists((int) $value, $personChoices)) {
                return 'Choose a valid person.';
            }
            break;

        case 'team':
            if (filter_var($value, FILTER_VALIDATE_INT) === false
                || !array_key_exists((int) $value, $teamChoices)) {
                return 'Choose a valid team.';
            }
            break;

        case 'people':
            if (!is_array($value)) {
                return 'Choose valid people.';
            }
            foreach ($value as $id) {
                if (!is_numeric($id) || !array_key_exists((int) $id, $personChoices)) {
                    return 'Choose valid people.';
                }
            }
            break;

        case 'teams':
            if (!is_array($value)) {
                return 'Choose valid teams.';
            }
            foreach ($value as $id) {
                if (!is_numeric($id) || !array_key_exists((int) $id, $teamChoices)) {
                    return 'Choose valid teams.';
                }
            }
            break;

        case 'project_role':
            if (!is_array($value)) {
                return 'Choose a valid project role.';
            }
            $projectId = $value['project_id'] ?? null;
            $role = $value['role'] ?? null;
            if (!is_numeric($projectId) || (int) $projectId <= 0
                || !in_array($role, ['lead', 'member'], true)) {
                return 'Choose a valid project role.';
            }
            if ($projectChoices !== []
                && !array_key_exists((int) $projectId, $projectChoices)) {
                return 'Choose a valid project.';
            }
            break;

        case 'date':
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', (string) $value);

            if ($date === false || $date->format('Y-m-d') !== (string) $value) {
                return 'Enter a valid date.';
            }
            break;

        case 'datetime':
            $dateTime = DateTimeImmutable::createFromFormat(
                '!Y-m-d\TH:i',
                (string) $value
            );

            if ($dateTime === false) {
                $dateTime = DateTimeImmutable::createFromFormat(
                    '!Y-m-d\TH:i:s',
                    (string) $value
                );
            }

            if ($dateTime === false) {
                return 'Enter a valid date and time.';
            }
            break;
    }

    return null;
}

/**
 * Canonicalize a validated value into the exact representation stored in the
 * JSON column. Multi-value fields keep a deduplicated option list, while range
 * and coordinate fields keep their named key shape so they survive round-trips.
 */
function work_template_canonical_value(array $field, mixed $value): mixed
{
    $type = (string) $field['field_type'];

    return match ($type) {
        'multi_select', 'checkbox_group' => is_array($value)
            ? array_values(array_unique(array_map('strval', $value)))
            : [],
        'people', 'teams' => is_array($value)
            ? array_values(array_unique(array_map(
                'intval',
                array_filter($value, 'is_numeric')
            )))
            : [],
        'project_role' => [
            'project_id' => is_array($value) ? (int) ($value['project_id'] ?? 0) : 0,
            'role' => is_array($value) ? (string) ($value['role'] ?? 'member') : 'member',
        ],
        'date_range', 'time_range' => [
            'start' => is_array($value) ? (string) ($value['start'] ?? '') : '',
            'end' => is_array($value) ? (string) ($value['end'] ?? '') : '',
        ],
        'coordinates' => [
            'lat' => is_array($value) && isset($value['lat'])
                ? (float) $value['lat']
                : null,
            'lng' => is_array($value) && isset($value['lng'])
                ? (float) $value['lng']
                : null,
        ],
        default => $value,
    };
}

/**
 * Render a stored duration (in seconds) as a compact human-readable string.
 */
function work_template_format_duration(int $seconds): string
{
    $hours = intdiv($seconds, 3600);
    $minutes = intdiv($seconds % 3600, 60);
    $secs = $seconds % 60;

    $parts = [];

    if ($hours > 0) {
        $parts[] = $hours . 'h';
    }

    if ($minutes > 0 || $hours > 0) {
        $parts[] = $minutes . 'm';
    }

    $parts[] = $secs . 's';

    return implode(' ', $parts);
}

/**
 * Map a validated value onto the four typed task_values columns. Empty values
 * are stored as NULL so a cleared field is reflected instead of left stale.
 */
function work_template_value_storage_values(array $field, mixed $value): array
{
    $storage = [
        'value_text' => null,
        'value_integer' => null,
        'value_real' => null,
        'value_json' => null,
    ];

    if (work_template_value_is_empty($value)) {
        return $storage;
    }

    $column = work_template_field_storage((string) $field['field_type']);

    if ($column === 'real') {
        $storage['value_real'] = (float) $value;
    } elseif ($column === 'integer') {
        $storage['value_integer'] = (int) $value;
    } elseif ($column === 'json') {
        $storage['value_json'] = work_template_encode_json(
            work_template_canonical_value($field, $value)
        );
    } else {
        $storage['value_text'] = (string) $value;
    }

    return $storage;
}

/**
 * Validate and persist every field value for a template-backed task.
 *
 * @param array               $sections        definition sections
 * @param array               $submittedValues raw values keyed by field id
 * @param array<int, string>  $personChoices
 * @param array<int, string>  $teamChoices
 *
 * @return array<int, string> validation errors keyed by field id (empty on success)
 */
function work_template_save_task_values(
    int $taskId,
    array $sections,
    array $submittedValues,
    array $personChoices,
    array $teamChoices,
    array $projectChoices = []
): array {
    $fieldsById = [];

    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            $fieldsById[(int) $field['id']] = $field;
        }
    }

    $normalized = [];

    foreach ($submittedValues as $fieldId => $raw) {
        $normalized[(int) $fieldId] = $raw;
    }

    $submittedValues = $normalized;

    $errors = [];
    $rows = [];

    foreach ($fieldsById as $fieldId => $field) {
        if (!work_template_field_uses_task_values((string) $field['field_type'])) {
            continue;
        }

        $raw = $submittedValues[$fieldId] ?? null;

        $error = work_template_validate_value(
            $field,
            $raw,
            $personChoices,
            $teamChoices,
            $projectChoices
        );

        if ($error !== null) {
            $errors[$fieldId] = $error;

            continue;
        }

        $rows[$fieldId] = work_template_value_storage_values($field, $raw);
    }

    if ($errors !== []) {
        return $errors;
    }

    $connection = db();
    $connection->beginTransaction();

    try {
        $statement = $connection->prepare(
            'INSERT INTO task_values
                (
                    task_id,
                    field_id,
                    value_text,
                    value_integer,
                    value_real,
                    value_json
                )
             VALUES (?, ?, ?, ?, ?, ?)
             ON CONFLICT(task_id, field_id)
             DO UPDATE SET
                 value_text = excluded.value_text,
                 value_integer = excluded.value_integer,
                 value_real = excluded.value_real,
                 value_json = excluded.value_json,
                 updated_at = CURRENT_TIMESTAMP'
        );

        foreach ($rows as $fieldId => $row) {
            $statement->execute([
                $taskId,
                $fieldId,
                $row['value_text'],
                $row['value_integer'],
                $row['value_real'],
                $row['value_json'],
            ]);
        }

        $connection->commit();
    } catch (Throwable $error) {
        if ($connection->inTransaction()) {
            $connection->rollBack();
        }

        throw $error;
    }

    return [];
}
/**
 * Render the input control for a single field in the task-list template form.
 */
function work_template_render_field_input(
    array $field,
    mixed $currentValue,
    array $personChoices,
    array $teamChoices,
    ?string $fieldError = null,
    array $projectChoices = []
): string {
    $type = (string) $field['field_type'];
    $fieldId = (int) $field['id'];
    $name = 'values[' . $fieldId . ']';
    $required = (bool) ($field['is_required'] ?? false);
    $options = is_array($field['options'] ?? null)
        ? $field['options']
        : [];
    $config = is_array($field['config'] ?? null)
        ? $field['config']
        : [];

    // An invalid submission still gets a usable control and its validation message.
    if (work_template_value_shape_error($field, $currentValue) !== null) {
        $currentValue = null;
    }

    $escape = static function (string $text): string {
        return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    };

    // The named numeric input preserves empty/exact values; native sliders always
    // choose a default and round to their step, even when no value was saved.
    $rangeControl = static function (string $min, string $max, string $step) use ($escape, $name, $currentValue, $required): string {
        $display = $escape((string) ($currentValue ?? ''));
        return '<div class="form-row"><input type="number" step="any" name="' . $escape($name)
            . '" min="' . $escape($min) . '" max="' . $escape($max) . '" value="' . $display . '" '
            . ($required ? 'required ' : '')
            . 'oninput="this.nextElementSibling.value = this.value">'
            . '<input type="range" min="' . $escape($min) . '" max="' . $escape($max)
            . '" step="' . $escape($step) . '" value="' . $display . '" '
            . 'oninput="this.previousElementSibling.value = this.value"></div>';
    };

    $output = '';

    switch ($type) {
        case 'checkbox':
            $output = '<input type="checkbox" name="' . $escape($name)
                . '" value="1" '
                . ((int) $currentValue === 1 ? 'checked ' : '')
                . '>';
            break;

        case 'long_text':
            $output = '<textarea name="' . $escape($name) . '" '
                . ($required ? 'required ' : '')
                . '>' . $escape((string) ($currentValue ?? '')) . '</textarea>';
            break;

        case 'number':
        case 'integer':
        case 'decimal':
        case 'number_unit':
        case 'currency':
        case 'percentage':
        case 'rating':
            if ($type === 'currency') {
                $step = '0.01';
            } elseif ($type === 'integer' || $type === 'rating') {
                $step = '1';
            } else {
                $step = 'any';
            }

            $min = array_key_exists('min', $config)
                ? (string) (float) $config['min']
                : null;
            $max = array_key_exists('max', $config)
                ? (string) (float) $config['max']
                : null;

            if ($type === 'rating') {
                $min = $min ?? '1';
                $max = $max ?? '5';
            }

            $output = '<input type="number" step="' . $escape($step) . '" '
                . ($min !== null ? 'min="' . $escape($min) . '" ' : '')
                . ($max !== null ? 'max="' . $escape($max) . '" ' : '')
                . 'name="' . $escape($name) . '" value="'
                . $escape((string) ($currentValue ?? '')) . '" '
                . ($required ? 'required ' : '')
                . '>';

            if ($type === 'number_unit') {
                $unit = trim((string) ($field['number_unit'] ?? ''));

                if ($unit !== '') {
                    $output .= ' <span class="task-template-unit">'
                        . $escape($unit) . '</span>';
                }
            }

            if ($type === 'percentage') {
                $output .= ' <span class="task-template-unit">%</span>';
            }
            break;

        case 'range':
            $min = array_key_exists('min', $config)
                ? (string) (float) $config['min']
                : '0';
            $max = array_key_exists('max', $config)
                ? (string) (float) $config['max']
                : '100';
            $step = array_key_exists('step', $config)
                ? (string) (float) $config['step']
                : '1';
            $output = $rangeControl($min, $max, $step);
            break;

        case 'scale':
            $labels = is_array($config['labels'] ?? null)
                ? $config['labels']
                : [];
            $min = array_key_exists('min', $config)
                ? (string) (float) $config['min']
                : '1';
            $max = array_key_exists('max', $config)
                ? (string) (float) $config['max']
                : '5';
            $step = array_key_exists('step', $config)
                ? (string) (float) $config['step']
                : '1';
            if ($labels !== []) {
                foreach ($labels as $label) {
                    $labelValue = (string) (float) ($label['value'] ?? 0);
                    $checked = $currentValue !== null && $currentValue !== ''
                        && (float) $currentValue === (float) $labelValue
                        ? 'checked'
                        : '';
                    $output .= '<label class="task-template-checkbox">'
                        . '<input type="radio" name="' . $escape($name) . '" '
                        . 'value="' . $escape($labelValue) . '" ' . $checked
                        . ($required ? ' required' : '') . '> '
                        . $escape((string) ($label['label'] ?? $labelValue))
                        . '</label>';
                }
            } else {
                $output = $rangeControl($min, $max, $step);
            }
            break;

        case 'dropdown':
            $output = '<select name="' . $escape($name) . '" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select…</option>';

            foreach ($options as $option) {
                $selected = (string) $currentValue === (string) $option
                    ? 'selected'
                    : '';
                $output .= '<option value="' . $escape((string) $option)
                    . '" ' . $selected . '>' . $escape((string) $option)
                    . '</option>';
            }

            $output .= '</select>';
            break;

        case 'multi_select':
            $selected = is_array($currentValue)
                ? array_map('strval', $currentValue)
                : [];

            foreach ($options as $option) {
                $checked = in_array((string) $option, $selected, true)
                    ? 'checked'
                    : '';
                $output .= '<label class="task-template-checkbox">'
                    . '<input type="checkbox" name="' . $escape($name) . '[]" '
                    . 'value="' . $escape((string) $option) . '" ' . $checked . '> '
                    . $escape((string) $option) . '</label>';
            }
            break;

        case 'yes_no':
        case 'pass_fail':
            $choices = $type === 'yes_no'
                ? ['Yes', 'No']
                : ['Pass', 'Fail'];

            $output = '<select name="' . $escape($name) . '" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select…</option>';

            foreach ($choices as $choice) {
                $selected = (string) $currentValue === $choice
                    ? 'selected'
                    : '';
                $output .= '<option value="' . $escape($choice) . '" '
                    . $selected . '>' . $escape($choice) . '</option>';
            }

            $output .= '</select>';
            break;
        case 'date':
            $output = '<input type="date" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'datetime':
            $value = is_string($currentValue) && $currentValue !== ''
                ? str_replace(' ', 'T', $currentValue)
                : '';
            $output = '<input type="datetime-local" name="' . $escape($name)
                . '" value="' . $escape($value) . '" '
                . ($required ? 'required ' : '') . '>';
            break;

        case 'url':
            $output = '<input type="url" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'person':
            $output = '<select name="' . $escape($name) . '" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select…</option>';

            foreach ($personChoices as $id => $label) {
                $selected = (int) $currentValue === (int) $id ? 'selected' : '';
                $output .= '<option value="' . (int) $id . '" ' . $selected
                    . '>' . $escape((string) $label) . '</option>';
            }

            $output .= '</select>';
            break;

        case 'team':
            $output = '<select name="' . $escape($name) . '" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select…</option>';

            foreach ($teamChoices as $id => $label) {
                $selected = (int) $currentValue === (int) $id ? 'selected' : '';
                $output .= '<option value="' . (int) $id . '" ' . $selected
                    . '>' . $escape((string) $label) . '</option>';
            }

            $output .= '</select>';
            break;

        case 'people':
        case 'teams':
            $selected = is_array($currentValue)
                ? array_map('intval', $currentValue)
                : [];
            $sourceChoices = $type === 'people' ? $personChoices : $teamChoices;
            foreach ($sourceChoices as $id => $label) {
                $checked = in_array((int) $id, $selected, true) ? 'checked' : '';
                $output .= '<label class="task-template-checkbox">'
                    . '<input type="checkbox" name="' . $escape($name) . '[]" '
                    . 'value="' . (int) $id . '" ' . $checked . '> '
                    . $escape((string) $label) . '</label>';
            }
            break;

        case 'project_role':
            $currentProject = is_array($currentValue) ? (int) ($currentValue['project_id'] ?? 0) : 0;
            $currentRole = is_array($currentValue) ? (string) ($currentValue['role'] ?? 'member') : 'member';
            $output = '<select name="' . $escape($name) . '[project_id]" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select project...</option>';
            foreach ($projectChoices as $id => $label) {
                $selected = $currentProject === (int) $id ? 'selected' : '';
                $output .= '<option value="' . (int) $id . '" ' . $selected . '>'
                    . $escape((string) $label) . '</option>';
            }
            $output .= '</select> '
                . '<select name="' . $escape($name) . '[role]" '
                . ($required ? 'required ' : '') . '>';
            foreach (['lead' => 'Lead', 'member' => 'Member'] as $roleValue => $roleLabel) {
                $selected = $currentRole === $roleValue ? 'selected' : '';
                $output .= '<option value="' . $roleValue . '" ' . $selected . '>'
                    . $roleLabel . '</option>';
            }
            $output .= '</select>';
            break;

        case 'rich_text':
            $output = '<textarea name="' . $escape($name) . '" class="task-template-rich" '
                . ($required ? 'required ' : '')
                . 'rows="5">' . $escape((string) ($currentValue ?? ''))
                . '</textarea>';
            break;

        case 'code':
            $output = '<textarea name="' . $escape($name) . '" class="task-template-code" '
                . ($required ? 'required ' : '')
                . 'rows="5" spellcheck="false">' . $escape((string) ($currentValue ?? ''))
                . '</textarea>';
            break;

        case 'email':
            $output = '<input type="email" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'phone':
            $output = '<input type="tel" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'address':
            $output = '<textarea name="' . $escape($name) . '" class="task-template-address" '
                . ($required ? 'required ' : '')
                . 'rows="3">' . $escape((string) ($currentValue ?? ''))
                . '</textarea>';
            break;

        case 'location':
            $output = '<input type="text" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'version':
            $output = '<input type="text" name="' . $escape($name)
                . '" placeholder="e.g. 1.0.0" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'ip_address':
            $output = '<input type="text" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'barcode':
        case 'qr_code':
            $output = '<input type="text" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'color':
            // A native picker alone silently replaces empty/invalid values with black.
            $color = (string) ($currentValue ?? '');
            $pickerColor = preg_match('/^#[0-9a-fA-F]{3}$/', $color)
                ? '#' . $color[1] . $color[1] . $color[2] . $color[2] . $color[3] . $color[3]
                : $color;
            $output = '<div class="form-row"><input type="text" name="' . $escape($name)
                . '" value="' . $escape($color) . '" placeholder="#rrggbb" '
                . ($required ? 'required ' : '')
                . 'oninput="this.nextElementSibling.value = this.value">'
                . '<input type="color" value="' . $escape($pickerColor)
                . '" oninput="this.previousElementSibling.value = this.value"></div>';
            break;

        case 'time':
            $output = '<input type="time" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;

        case 'duration':
            $output = '<input type="number" step="1" min="0" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '> '
                . '<span class="task-template-unit">sec</span>';
            break;

        case 'date_range':
            $start = is_array($currentValue)
                ? (string) ($currentValue['start'] ?? '')
                : '';
            $end = is_array($currentValue)
                ? (string) ($currentValue['end'] ?? '')
                : '';
            $output = '<input type="date" name="' . $escape($name) . '[start]" '
                . 'value="' . $escape($start) . '" '
                . ($required ? 'required ' : '') . '> '
                . '<span class="task-template-unit">to</span> '
                . '<input type="date" name="' . $escape($name) . '[end]" '
                . 'value="' . $escape($end) . '" '
                . ($required ? 'required ' : '') . '>';
            break;

        case 'time_range':
            $start = is_array($currentValue)
                ? (string) ($currentValue['start'] ?? '')
                : '';
            $end = is_array($currentValue)
                ? (string) ($currentValue['end'] ?? '')
                : '';
            $output = '<input type="time" name="' . $escape($name) . '[start]" '
                . 'value="' . $escape($start) . '" '
                . ($required ? 'required ' : '') . '> '
                . '<span class="task-template-unit">to</span> '
                . '<input type="time" name="' . $escape($name) . '[end]" '
                . 'value="' . $escape($end) . '" '
                . ($required ? 'required ' : '') . '>';
            break;

        case 'coordinates':
            $lat = is_array($currentValue)
                ? (string) ($currentValue['lat'] ?? '')
                : '';
            $lng = is_array($currentValue)
                ? (string) ($currentValue['lng'] ?? '')
                : '';
            $output = '<input type="number" step="any" name="' . $escape($name) . '[lat]" '
                . 'placeholder="Latitude" value="' . $escape($lat) . '" '
                . ($required ? 'required ' : '') . '> '
                . '<input type="number" step="any" name="' . $escape($name) . '[lng]" '
                . 'placeholder="Longitude" value="' . $escape($lng) . '" '
                . ($required ? 'required ' : '') . '>';
            break;

        case 'tri_state':
            $choices = ['Yes', 'No', 'N/A'];
            $output = '<select name="' . $escape($name) . '" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select…</option>';

            foreach ($choices as $choice) {
                $selected = (string) $currentValue === $choice ? 'selected' : '';
                $output .= '<option value="' . $escape($choice) . '" ' . $selected
                    . '>' . $escape($choice) . '</option>';
            }

            $output .= '</select>';
            break;

        case 'status':
            $output = '<select name="' . $escape($name) . '" '
                . ($required ? 'required ' : '') . '>'
                . '<option value="">Select…</option>';

            foreach ($options as $option) {
                $selected = (string) $currentValue === (string) $option ? 'selected' : '';
                $output .= '<option value="' . $escape((string) $option) . '" ' . $selected
                    . '>' . $escape((string) $option) . '</option>';
            }

            $output .= '</select>';
            break;

        case 'radio':
            foreach ($options as $option) {
                $checked = (string) $currentValue === (string) $option ? 'checked' : '';
                $output .= '<label class="task-template-checkbox">'
                    . '<input type="radio" name="' . $escape($name) . '" '
                    . 'value="' . $escape((string) $option) . '" ' . $checked
                    . ($required ? ' required' : '') . '> '
                    . $escape((string) $option) . '</label>';
            }
            break;

        case 'checkbox_group':
            $selected = is_array($currentValue)
                ? array_map('strval', $currentValue)
                : [];

            foreach ($options as $option) {
                $checked = in_array((string) $option, $selected, true) ? 'checked' : '';
                $output .= '<label class="task-template-checkbox">'
                    . '<input type="checkbox" name="' . $escape($name) . '[]" '
                    . 'value="' . $escape((string) $option) . '" ' . $checked . '> '
                    . $escape((string) $option) . '</label>';
            }
            break;

        case 'short_text':
        default:
            $output = '<input type="text" name="' . $escape($name)
                . '" value="' . $escape((string) ($currentValue ?? ''))
                . '" ' . ($required ? 'required ' : '') . '>';
            break;
    }

    // Name every control, including both ends of compound fields, without nested labels.
    $output = preg_replace_callback('/<(input|select|textarea)\b[^>]*>/',
        static function (array $match) use ($field, $fieldId, $fieldError, $escape): string {
            $label = $escape((string) $field['name']);
            if (!str_contains($match[0], 'name="')) {
                $label .= $field['field_type'] === 'color' ? ' — Picker' : ' — Slider';
            } elseif (preg_match('/name="[^" ]*\[(start|end|lat|lng)\]"/', $match[0], $part)) {
                $label .= ' — ' . match ($part[1]) {
                    'lat' => 'Latitude', 'lng' => 'Longitude',
                    'start' => 'Start', 'end' => 'End',
                };
            } elseif (preg_match('/type="(?:radio|checkbox)"/', $match[0])
                && $field['field_type'] !== 'checkbox'
                && preg_match('/value="([^"]*)"/', $match[0], $option)) {
                $label .= ': ' . $option[1];
            }
            $attributes = ' aria-label="' . $label . '"';
            if ($fieldError !== null) {
                $attributes .= ' aria-invalid="true" aria-describedby="work-field-error-' . $fieldId . '"';
            }
            return '<' . $match[1] . $attributes . substr($match[0], strlen($match[1]) + 1);
        }, $output) ?? $output;

    if ($fieldError !== null) {
        $output .= '<p class="task-template-field-error" id="work-field-error-' . $fieldId . '">'
            . $escape($fieldError) . '</p>';
    }

    return $output;
}

/**
 * Resolve the sections for a signed template version id. Published versions
 * read their immutable definition_json snapshot; otherwise the relational
 * rows are authoritative. Callers must already have validated the version id
 * against the workspace.
 */
function work_template_version_sections(int $versionId): array
{
    $statement = db()->prepare(
        'SELECT definition_json
         FROM work_template_versions
         WHERE id = ?
         LIMIT 1'
    );
    $statement->execute([$versionId]);
    $version = $statement->fetch();

    if ($version !== false) {
        $snapshot = $version['definition_json'] !== null
            ? json_decode($version['definition_json'], true)
            : null;

        if (
            is_array($snapshot)
            && isset($snapshot['sections'])
            && is_array($snapshot['sections'])
        ) {
            return $snapshot['sections'];
        }
    }

    return work_template_definition($versionId);
}

/**
 * Validate submitted values without writing anything. Returns errors keyed
 * by field id (empty when valid). Used before the task row is inserted so a
 * validation failure never leaves an orphan task behind.
 */
function work_template_validate_task_values(
    array $sections,
    array $submittedValues,
    array $personChoices,
    array $teamChoices,
    array $projectChoices = []
): array {
    $fieldsById = [];

    foreach ($sections as $section) {
        foreach ($section['fields'] as $field) {
            $fieldsById[(int) $field['id']] = $field;
        }
    }

    $normalized = [];

    foreach ($submittedValues as $fieldId => $raw) {
        $normalized[(int) $fieldId] = $raw;
    }

    $errors = [];

    foreach ($fieldsById as $fieldId => $field) {
        if (!work_template_field_uses_task_values((string) $field['field_type'])) {
            continue;
        }

        $error = work_template_validate_value(
            $field,
            $normalized[$fieldId] ?? null,
            $personChoices,
            $teamChoices,
            $projectChoices
        );

        if ($error !== null) {
            $errors[$fieldId] = $error;
        }
    }

    return $errors;
}
