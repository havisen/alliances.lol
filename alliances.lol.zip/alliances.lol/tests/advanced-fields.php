<?php

declare(strict_types=1);

/*
|--------------------------------------------------------------------------
| Advanced field registry + field_key + formula (pure, no database)
|--------------------------------------------------------------------------
*/

require_once dirname(__DIR__) . '/src/tasks/fields.php';
require_once dirname(__DIR__) . '/src/tasks/formula.php';
require_once dirname(__DIR__) . '/src/tasks/templates.php';

set_error_handler(static function (int $severity, string $message, string $file, int $line): never {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$checks = 0;
function advance_check(bool $condition, string $message): void
{
    global $checks;
    ++$checks;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

// --- Registry invariants -------------------------------------------------
$advanced = work_template_advanced_field_types();
advance_check(count($advanced) === 23, 'Exactly 23 advanced types');
advance_check(count(array_unique($advanced)) === 23, 'Advanced catalog has no duplicates');

$types = work_template_field_types();
foreach ($advanced as $type) {
    advance_check(isset($types[$type]), "$type is registered");
}

advance_check(!work_template_field_available('asset_relation'), 'asset_relation unavailable');
foreach (array_diff($advanced, ['asset_relation']) as $type) {
    advance_check(work_template_field_available($type), "$type available");
}

advance_check(work_template_field_uses_task_values('people'), 'people uses task_values');
advance_check(work_template_field_uses_task_values('teams'), 'teams uses task_values');
advance_check(work_template_field_uses_task_values('project_role'), 'project_role uses task_values');
advance_check(!work_template_field_uses_task_values('formula'), 'formula is computed');
advance_check(!work_template_field_uses_task_values('approval'), 'approval is normalized');
advance_check(work_template_field_creation_eligible('people'), 'people is creation-time');
advance_check(!work_template_field_creation_eligible('formula'), 'formula is not creation-time');

// --- field_key identity --------------------------------------------------
$key = work_template_generate_field_key();
advance_check((bool) preg_match('/^[0-9a-f]{16}$/', $key), 'field_key is 16 lowercase hex chars');
advance_check(work_template_field_key(null, 7) === 'f7', 'field_key falls back to f||id');
advance_check(work_template_field_key('abc123', 7) === 'abc123', 'field_key preserves a stored key');
advance_check(work_template_field_key('', 7) === 'f7', 'field_key treats empty as missing');

// --- Formula: tokenizer/parser/evaluator ---------------------------------
$evaluate = static fn (string $src, array $values = []): ?float =>
    work_template_formula_evaluate($src, static fn (string $key): ?float => $values[$key] ?? null);

advance_check($evaluate('1 + 2 * 3') === 7.0, 'operator precedence');
advance_check($evaluate('(1 + 2) * 3') === 9.0, 'parentheses override precedence');
advance_check($evaluate('-5 + 2') === -3.0, 'unary minus');
advance_check($evaluate('-(2 + 3)') === -5.0, 'unary minus over parenthesized group');
advance_check($evaluate('{x} + 1', ['x' => 4.0]) === 5.0, 'field reference resolves');
advance_check($evaluate('min(3, 1, 2)') === 1.0, 'min');
advance_check($evaluate('max(3, 1, 2)') === 3.0, 'max');
advance_check($evaluate('round(2.567, 2)') === 2.57, 'round with digits');
advance_check($evaluate('round(2.5)') === 3.0, 'round defaults to integer');
advance_check($evaluate('{missing} + 1') === null, 'NULL propagates through unknown field');
advance_check($evaluate('1 / 0') === null, 'division by zero is NULL');
advance_check($evaluate('min({missing}, 2)') === 2.0, 'min ignores NULL operands');
advance_check($evaluate('max({missing})') === null, 'max of only NULL is NULL');

advance_check(work_template_formula_parse('1 +')['ok'] === false, 'malformed syntax rejected');
advance_check(work_template_formula_parse('foo(1)')['ok'] === false, 'unknown function rejected');
advance_check(
    str_contains((string) work_template_formula_parse('foo(1)')['error'], 'Unknown function'),
    'unknown function message'
);

$refs = work_template_formula_parse('{a} + {b} * 2')['refs'];
advance_check($refs === ['a', 'b'], 'field references extracted');

// --- Formula cycles ------------------------------------------------------
advance_check(work_template_formula_find_cycles(['a' => ['a']]) === ['a'], 'self cycle detected');
$two = work_template_formula_find_cycles(['a' => ['b'], 'b' => ['a']]);
sort($two);
advance_check($two === ['a', 'b'], 'two-node cycle detected');

$transitive = work_template_formula_find_cycles(['a' => ['b'], 'b' => ['c'], 'c' => ['a']]);
sort($transitive);
advance_check($transitive === ['a', 'b', 'c'], 'transitive cycle detected');

advance_check(
    work_template_formula_find_cycles(['a' => ['b'], 'b' => ['c'], 'c' => []]) === [],
    'valid acyclic graph has no cycles'
);

$graph = work_template_formula_evaluate_all([
    'a' => '10',
    'b' => '2',
    'c' => '{a} / {b}',
    'd' => '{c} + 1',
]);
advance_check($graph['c'] === 5.0 && $graph['d'] === 6.0, 'valid non-cycle dependency graph evaluates');

$cyclic = work_template_formula_evaluate_all([
    'a' => '{b} + 1',
    'b' => '{a} + 1',
]);
advance_check($cyclic['a'] === null && $cyclic['b'] === null, 'cycles evaluate to NULL');

advance_check((new ReflectionFunction('db'))->getStaticVariables()['connection'] === null, 'No database opened');

echo "PASS: $checks advanced-field registry, field_key, and formula checks. No database opened. No eval.\n";