<?php

declare(strict_types=1);

// Pure behavior + recording probes. No PDO construction, SQL execution, or db() connection.
require_once dirname(__DIR__) . '/src/tasks/advanced.php';
require_once dirname(__DIR__) . '/src/projects/overview.php';

set_error_handler(static function (int $severity, string $message, string $file, int $line): never {
    throw new ErrorException($message, 0, $severity, $file, $line);
});
$checks = 0;
$root = dirname(__DIR__);
function verify(bool $condition, string $message): void
{
    global $checks;
    ++$checks;
    if (!$condition) { throw new RuntimeException($message); }
}
function rejects(callable $callback, string $message): void
{
    try { $callback(); } catch (InvalidArgumentException | JsonException $error) { verify(true, $message); return; }
    verify(false, $message);
}
function source_of(string $function): string
{
    $r = new ReflectionFunction($function);
    return implode('', array_slice(file($r->getFileName()), $r->getStartLine() - 1, $r->getEndLine() - $r->getStartLine() + 1));
}

$keys = ['status', 'progress', 'tasks', 'members', 'milestones', 'calendar', 'channel', 'group_chat', 'files', 'document', 'spreadsheet', 'activity', 'announcements', 'metrics', 'links', 'notes', 'custom_content'];
$registry = project_overview_module_registry();
verify(array_keys($registry) === $keys, 'Exact intended 17 modules');
foreach ($registry as $key => $meta) {
    verify($meta['available'] === true && $meta['default_span'] >= 1 && $meta['default_span'] <= 3, "$key available with valid span");
    verify(project_overview_normalize_config($key, ['unexpected' => 'discard']) === project_overview_normalize_config($key, []), "$key drops unknown config");
}
rejects(fn() => project_overview_normalize_config('tasks', ['filter' => 'private']), 'Invalid enum');
foreach ([0, 21, '1.2', [], 'bad'] as $limit) {
    rejects(fn() => project_overview_normalize_config('tasks', ['limit' => $limit]), 'Invalid bounded integer');
}
rejects(fn() => project_overview_normalize_config('notes', ['content' => str_repeat('a', 2001)]), 'Notes char limit');
rejects(fn() => project_overview_normalize_config('notes', ['content' => str_repeat('界', 2000)]), 'Encoded byte limit');
rejects(fn() => project_overview_decode_config('notes', '{'), 'Malformed JSON fails closed');
rejects(fn() => project_overview_decode_config('notes', 'null'), 'Non-object config fails closed');
rejects(fn() => project_overview_normalize_config('notes', ['v' => 2]), 'Unknown config version');
foreach (['javascript:alert(1)', 'data:text/html,x', '//example.test', 'ftp://example.test'] as $url) {
    verify(!project_overview_valid_url($url), 'Reject unsafe link');
}
verify(project_overview_valid_url('https://example.test/path'), 'Accept HTTPS');
verify(!project_overview_module_visible(['visibility' => 'leads'], false), 'Ordinary member cannot see lead module');
verify(project_overview_module_visible(['visibility' => 'leads'], true), 'Explicit lead/admin can see lead module');
verify(!project_overview_module_visible(['visibility' => 'unknown'], true), 'Unknown visibility fails closed');
verify(!project_is_writable(['status' => 'archived']), 'Archived is read-only');
verify(project_is_writable(['status' => 'active']), 'Active is writable');

$context = [
    'task_counts' => ['total' => 3, 'completed' => 1, 'overdue' => 1], 'list_count' => 1,
    'tasks' => ['open' => [['id' => 1, 'name' => '<script>task</script>', 'status' => 'pending']]],
    'members' => [['display_name' => 'Alex']], 'leads' => [],
    'milestones' => [['title' => 'First', 'status' => 'pending', 'due_date' => '2026-10-06']], 'milestones_completed' => 0,
    'calendar' => [['date' => '2026-10-06', 'title' => 'Meeting']],
    'activity' => [['activity_type' => 'resource_attached', 'summary' => 'SECRET OLD NAME', 'actor_name' => 'Alex']],
    'announcements' => [['title' => 'News', 'body' => '<img onerror=alert(1)>']],
    'links' => [['title' => 'Unsafe', 'url' => 'javascript:alert(1)']],
    'resources' => [
        ['id' => 1, 'type' => 'drive_file', 'title' => 'Private.docx', 'unavailable' => true],
        ['id' => 2, 'type' => 'drive_file', 'title' => 'Notes.docx', 'mime_type' => null, 'url' => '/drive/editor.php?file_id=2'],
        ['id' => 3, 'type' => 'drive_file', 'title' => 'Budget.xlsx', 'mime_type' => null, 'url' => '/drive/editor.php?file_id=3'],
        ['id' => 4, 'type' => 'conversation', 'title' => 'Channel', 'conversation_type' => 'channel', 'url' => '/messaging/?conversation_id=4'],
        ['id' => 5, 'type' => 'conversation', 'title' => 'Group', 'conversation_type' => 'group', 'url' => '/messaging/?conversation_id=5'],
        ['id' => 6, 'type' => 'conversation', 'title' => 'DM SECRET', 'conversation_type' => 'direct', 'url' => '/messaging/'],
    ],
];
foreach ($keys as $key) {
    $html = project_overview_render_v1(['module_key' => $key], ['status' => 'active'], $context);
    verify($html !== '', "$key renders");
    verify(!str_contains($html, 'SECRET') && !str_contains($html, 'Private.docx'), "$key does not leak inaccessible resource or saved activity names");
    verify(!str_contains($html, '<script>') && !str_contains($html, '<img ') && !str_contains($html, 'href="javascript:'), "$key escapes content");
}
$notes = project_overview_render_v1(['module_key' => 'notes', 'config' => json_encode(['content' => '<script>alert(1)</script>'])], [], []);
verify(str_contains($notes, '&lt;script&gt;'), 'Notes are plain text');
verify(!project_overview_resource_matches('document', $context['resources'][2]), 'Spreadsheet not Document');
verify(!project_overview_resource_matches('channel', $context['resources'][4]), 'Group is not Channel');
verify(project_overview_resource_matches('group_chat', $context['resources'][4]), 'Group Chat independent');
verify(!project_overview_resource_matches('group_chat', $context['resources'][5]), 'DM rejected');

$approval = ['id' => 10, 'field_key' => 'stable_approval', 'field_type' => 'approval', 'config' => ['approver_ids' => [7]]];
verify(work_template_approval_can_decide($approval, 7), 'Designated approver');
verify(!work_template_approval_can_decide($approval, 8), 'Editable non-approver not eligible');
verify(!work_template_approval_can_decide(['field_type' => 'approval', 'config' => []], 7), 'Legacy approval fails closed');
foreach (['approved', 'rejected', 'changes_requested'] as $decision) {
    verify(work_template_approval_transition_allowed('pending', $decision), 'Decision closes requested cycle');
    verify(!work_template_approval_transition_allowed('not_requested', $decision), 'Cannot decide without request');
    verify(work_template_approval_transition_allowed($decision, 'pending'), 'New cycle can be requested');
    verify(!work_template_approval_transition_allowed($decision, 'approved'), 'Cannot overwrite closed decision');
}
verify(!work_template_approval_transition_allowed('pending', 'pending'), 'Cannot request over pending cycle');
eval('namespace SecurityRenderProbe; function csrf_input() { return "<input name=csrf_token value=fixture>"; }');
eval('namespace SecurityRenderProbe; ' . source_of('work_template_advanced_render_field'));
$pending = ['approvals' => ['stable_approval' => [['id' => 1, 'cycle' => 1, 'decision' => 'pending', 'comment' => '', 'decided_by_name' => 'Requester']]]];
$approverHtml = SecurityRenderProbe\work_template_advanced_render_field($approval, 1, $pending, 9, 7, [], false, []);
verify(str_contains($approverHtml, 'value="save_approval"'), 'Read-only Task viewer who is designated approver can decide');
$editorHtml = SecurityRenderProbe\work_template_advanced_render_field($approval, 1, $pending, 9, 8, [], true, []);
verify(!str_contains($editorHtml, '<form'), 'Ordinary editor cannot decide pending request');
$requestHtml = SecurityRenderProbe\work_template_advanced_render_field($approval, 1, [], 9, 8, [], true, []);
verify(str_contains($requestHtml, 'value="request_approval"') && !str_contains($requestHtml, 'value="approved"'), 'Editor can request only');
verify(str_contains($approverHtml, 'name="field_key" value="stable_approval"'), 'Rendered POST uses stable key');
verify(work_template_clone_field_key(['id' => 90, 'field_key' => null]) === 'f90', 'Legacy clone preserves original logical identity');
verify(work_template_clone_field_key(['id' => 99, 'field_key' => 'stable']) === 'stable', 'New clone preserves stable identity');
$templatesSource = file_get_contents($root . '/src/tasks/templates.php');
$cloneSelect = preg_replace('/\s+/', ' ', (string) preg_replace('/^.*?SELECT\s+/s', 'SELECT ', (string) strstr($templatesSource, "'SELECT id, sort_order, name, description, field_type,")));
verify(str_contains($templatesSource, "'SELECT id, sort_order, name, description, field_type,"), 'Template clone selects source field id');
verify(str_contains($templatesSource, 'work_template_clone_field_key($field)'), 'Template clone derives key from selected source row');
$v1 = [['fields' => [$approval]]];
$v2 = [['fields' => [array_replace($approval, ['id' => 999])]]];
verify(work_template_advanced_field_by_key($v1, 'stable_approval')['id'] === 10, 'V1 resolves snapshot');
verify(work_template_advanced_field_by_key($v2, 'stable_approval')['id'] === 999, 'V2 resolves own snapshot using same key');
foreach (['sum', 'avg', 'min', 'max'] as $op) {
    verify(work_template_normalize_advanced_config('rollup', ['relation_field_key' => 'source', 'operation' => $op])['error'] !== null, 'Unsupported rollup rejected');
}
foreach (['status', 'assigned_to', 'deadline'] as $descriptor) {
    verify(work_template_normalize_advanced_config('lookup', ['relation_field_key' => 'source', 'target_type' => 'task', 'descriptor' => $descriptor])['error'] !== null, 'Unsupported lookup rejected');
}

// Execute the real compute function with only the target resolver replaced by a permission fixture.
eval('namespace SecurityProbe; function work_template_advanced_resolve_target($w, $u, $a, $type, $id) { return $GLOBALS["visible_targets"][$type . ":" . $id] ?? null; }');
eval('namespace SecurityProbe; ' . source_of('work_template_advanced_compute_fields'));
$sections = [['fields' => [
    ['id' => 1, 'field_key' => 'source', 'field_type' => 'relation', 'config' => ['target_types' => ['task', 'file']]],
    ['id' => 2, 'field_key' => 'total', 'field_type' => 'rollup', 'config' => ['relation_field_key' => 'source', 'operation' => 'count']],
    ['id' => 3, 'field_key' => 'name', 'field_type' => 'lookup', 'config' => ['relation_field_key' => 'source', 'target_type' => 'file', 'descriptor' => 'name']],
]]];
$state = ['relations' => ['source' => [['target_type' => 'task', 'target_id' => 1], ['target_type' => 'file', 'target_id' => 2]]]];
$visible_targets = ['task:1' => ['label' => 'Task'], 'file:2' => ['label' => 'File']];
$result = SecurityProbe\work_template_advanced_compute_fields($sections, [], $state, 1, 7, []);
verify($result['total'] === 2 && $result['name'] === 'File', 'Count works; lookup honors target type');
unset($visible_targets['file:2']);
$result = SecurityProbe\work_template_advanced_compute_fields($sections, [], $state, 1, 7, []);
verify($result['total'] === 1 && $result['name'] === null, 'Revocation removes count and name');

// Query probes record actual production SQL; they never execute SQL.
final class SecurityRecorder
{
    public string $sql = '';
    public array $parameters = [];
    public array $rows = [];
    public int $changed = 1;
    public function prepare(string $sql): self { $this->sql = preg_replace('/\s+/', ' ', $sql); return $this; }
    public function execute(array $parameters): void { $this->parameters = $parameters; }
    public function fetch(int $mode = 0): mixed { return $this->rows[0] ?? false; }
    public function fetchAll(int $mode = 0): array { return $this->rows; }
    public function rowCount(): int { return $this->changed; }
}
$securityRecorder = new SecurityRecorder();
eval('namespace SecurityQueryProbe; use \PDO; function db() { return $GLOBALS["securityRecorder"]; }');
foreach (['drive_accessible_folder', 'drive_search_metadata', 'project_resource_revalidate_drive_file', 'project_resource_picker_conversations', 'work_template_advanced_load_relations', 'work_template_advanced_load_approvals'] as $name) {
    eval('namespace SecurityQueryProbe; use \PDO; ' . source_of($name));
}
SecurityQueryProbe\drive_accessible_folder(9, 7, 3);
verify(str_contains($securityRecorder->sql, 'vf.created_by = :user_id') && $securityRecorder->parameters[':user_id'] === 7, 'Folder submitted ID requires actor ownership');
verify(str_contains($securityRecorder->sql, 'trashed_at IS NULL') && str_contains($securityRecorder->sql, 'child.workspace_id'), 'Folder valid same-workspace ancestor chain');
SecurityQueryProbe\project_resource_revalidate_drive_file(9, 7, 3);
foreach (['dfa.user_id = :access_user_id', 'dfk.user_id = :key_user_id', 'dfk.key_version = df.key_version', 'drive_effective_access dfa', 'df.workspace_id = :file_workspace_id'] as $predicate) {
    verify(str_contains($securityRecorder->sql, $predicate), 'Drive file predicate: ' . $predicate);
}
SecurityQueryProbe\project_resource_picker_conversations(9, 7, 'query');
verify(str_contains($securityRecorder->sql, "c.type IN ('channel', 'group')") && str_contains($securityRecorder->sql, 'cm.user_id = :user_id'), 'Picker requires membership and excludes DMs');
$securityRecorder->rows = [['field_key' => 'stable', 'target_type' => 'task', 'target_id' => 4, 'sort_order' => 0]];
verify(isset(SecurityQueryProbe\work_template_advanced_load_relations(1)['stable']), 'Loader indexes stable key without numeric cast');
$sql = project_overview_tasks_sql('COUNT(*)');
verify(str_contains($sql, 'member.user_id = ?') && str_contains($sql, 'tl.workspace_id = ?') && str_contains($sql, 'tl.project_id = ?'), 'Tasks and Metrics preserve all three scopes');
verify(str_contains(source_of('drive_search_metadata'), 'vf.created_by = :folder_user_id'), 'Folder search requires actor ownership');

// Actual approval persistence boundary, with Task visibility and history supplied by fixtures.
eval('namespace SecurityApprovalProbe; use \InvalidArgumentException;
    function db() { return $GLOBALS["securityRecorder"]; }
    function task_for_member($w, $u, $t) { return $GLOBALS["approval_task"]; }
    function work_template_task_definition($w, $t) { return ["sections" => $GLOBALS["v1"]]; }
    function work_template_advanced_load_approvals($t) { return $GLOBALS["approval_history"]; }');
eval('namespace SecurityApprovalProbe; use \InvalidArgumentException; ' . source_of('work_template_advanced_append_approval'));
$approval_task = ['list_created_by' => 8, 'members_can_edit' => 0];
$approval_history = [];
$decision = ['event_type' => 'requested', 'decision' => 'pending', 'decided_by' => 8, 'decided_by_name' => 'Editor', 'expected_decision_id' => 0];
SecurityApprovalProbe\work_template_advanced_append_approval(9, 1, 'stable_approval', $decision);
verify($securityRecorder->parameters[6] === 1 && $securityRecorder->parameters[7] === 'requested', 'First request creates cycle one');
$approval_history = ['stable_approval' => [['id' => 1, 'cycle' => 1, 'decision' => 'pending']]];
$decision = ['event_type' => 'decision', 'decision' => 'approved', 'decided_by' => 8, 'expected_decision_id' => 1];
rejects(fn() => SecurityApprovalProbe\work_template_advanced_append_approval(9, 1, 'stable_approval', $decision), 'Persistence rejects editor non-approver');
$decision['decided_by'] = 7;
SecurityApprovalProbe\work_template_advanced_append_approval(9, 1, 'stable_approval', $decision);
verify($securityRecorder->parameters[6] === 1 && str_contains($securityRecorder->sql, 'SELECT MAX(id)'), 'Decision belongs to requested cycle with atomic revision check');
$securityRecorder->changed = 0;
rejects(fn() => SecurityApprovalProbe\work_template_advanced_append_approval(9, 1, 'stable_approval', $decision), 'Concurrent decision fails closed');
$securityRecorder->changed = 1;
$decision['expected_decision_id'] = 0;
rejects(fn() => SecurityApprovalProbe\work_template_advanced_append_approval(9, 1, 'stable_approval', $decision), 'Stale decision rejected');
$approval_task = null;
rejects(fn() => SecurityApprovalProbe\work_template_advanced_append_approval(9, 1, 'stable_approval', $decision), 'Revoked Task access rejected');

$advancedSql = file_get_contents($root . '/database/migrations/work-templates_zadvanced.sql');
verify(!str_contains($advancedSql, 'REFERENCES work_template_fields'), 'No normalized builder-row FKs');
verify(!preg_match('/\bfield_id\b/', $advancedSql), 'No normalized field_id column');
verify(substr_count($advancedSql, 'field_key TEXT NOT NULL') === 9, 'All nine normalized tables use stable identity');
verify(str_contains($advancedSql, 'task_template_context_immutable'), 'Task version pin is immutable');
$overviewSql = file_get_contents($root . '/database/migrations/projects_zoverview.sql');
$overviewPageSchema = (string) preg_replace(
    '/\bCREATE TABLE IF NOT EXISTS project_overview_modules\b.*$/s',
    '',
    $overviewSql
);
verify(str_contains($overviewPageSchema, 'config_json TEXT'), 'Overview page schema uses canonical config_json column');
verify(!preg_match('/\bconfig TEXT\b/', $overviewPageSchema), 'Overview page schema has no stale config column');
verify(!preg_match('/UNIQUE\s*\(page_id,\s*module_key\)/', $overviewSql), 'Repeated module types allowed');
verify(str_contains($overviewSql, 'FOREIGN KEY (page_id, project_id)'), 'Cross-Project page assignment rejected in schema');
verify(str_contains($overviewSql, 'icon TEXT'), 'Projects schema includes icon');
verify(str_contains($overviewSql, 'color TEXT'), 'Projects schema includes color');
verify(str_contains($overviewSql, 'health TEXT NOT NULL DEFAULT \'unknown\''), 'Projects schema includes default health');
foreach (['unknown', 'on_track', 'at_risk', 'off_track'] as $health) {
    verify(str_contains($overviewSql, "'$health'"), "Project health supports $health");
}
verify(str_contains($overviewSql, 'is_default INTEGER NOT NULL DEFAULT 0'), 'Overview pages persist explicit default');
verify(str_contains($overviewSql, 'archived_at TEXT'), 'Overview pages support archival');
verify(str_contains($overviewSql, 'idx_overview_pages_one_active_default'), 'Overview pages enforce one default');
verify(str_contains($overviewSql, 'project_overview_pages_max_eight'), 'Overview pages enforce max eight active pages');
verify(str_contains($overviewSql, 'project_overview_pages_keep_one_active'), 'Overview pages protect the last active page');
verify(str_contains($overviewSql, "CHECK (status IN ('open', 'completed'))"), 'Milestones use open/completed semantics');
verify(str_contains($overviewSql, 'position INTEGER NOT NULL DEFAULT 0'), 'Milestones have stable position');
verify(str_contains($overviewSql, 'completed_by INTEGER'), 'Milestones record completer');
verify(str_contains($overviewSql, 'completed_at TEXT'), 'Milestones record completion time');

$projectsSource = file_get_contents($root . '/src/projects.php');
verify(str_contains($projectsSource, 'project_validate_icon'), 'Project icon validation exists');
verify(str_contains($projectsSource, 'project_validate_color'), 'Project color validation exists');
verify(str_contains($projectsSource, 'project_validate_health'), 'Project health validation exists');
verify(str_contains($projectsSource, "['unknown', 'on_track', 'at_risk', 'off_track']"), 'Project health allowlist is exact');

$pageSave = file_get_contents($root . '/public/actions/projects/overview-page-save.php');
foreach (['create', 'rename', 'move_up', 'move_down', 'set_default', 'archive'] as $action) {
    verify(str_contains($pageSave, "'$action'"), "Overview page action supports $action");
}
verify(str_contains($pageSave, "\$_POST['action']"), 'Overview page endpoint reads canonical action parameter');
$managerSource = file_get_contents($root . '/src/projects/overview-management.php');
foreach (['name="action" value="create"', 'name="action" value="rename"', 'name="action" value="move_up"', 'name="action" value="move_down"', 'name="action" value="set_default"', 'name="action" value="archive"'] as $contract) {
    verify(str_contains($managerSource, $contract), 'Overview manager uses canonical action contract: ' . $contract);
}
verify(str_contains($pageSave, '>= 8'), 'Overview page action enforces max eight');
verify(str_contains($pageSave, 'count($activePages) <= 1'), 'Overview page action protects last active page');
verify(str_contains($pageSave, 'is_default = 1'), 'Overview page action promotes a default');

foreach (['milestone-save.php', 'milestone-toggle.php', 'milestone-delete.php'] as $action) {
    $source = file_get_contents($root . '/public/actions/projects/' . $action);
    verify(str_contains($source, 'project_user_can_manage('), "$action is manager-only");
    verify(str_contains($source, 'project_assert_writable('), "$action rechecks writability in transaction");
}
verify(str_contains(file_get_contents($root . '/src/projects.php'), 'function project_assert_writable(int $projectId, ?PDO $connection = null)'), 'Writable helper accepts project id then optional connection');
foreach (glob($root . '/public/actions/projects/*.php') as $file) {
    $source = file_get_contents($file);
    verify(!preg_match('/project_assert_writable\(\s*\$(?:pdo|connection)\s*,/', $source), basename($file) . ' writable helper argument order');
}
verify(str_contains(file_get_contents($root . '/src/projects/overview.php'), 'archived_at, config_json'), 'Overview page reads canonical config_json column');
verify(str_contains(file_get_contents($root . '/public/actions/projects/overview-page-save.php'), 'config_json'), 'Overview page writes canonical config_json column');
verify(str_contains(file_get_contents($root . '/public/actions/projects/overview-module-save.php'), 'page_key'), 'Overview module mutation resolves authoritative page_key');
verify(!preg_match("/&page=' \. \$pageId|&page=' \. \(int\) \$module\['page_id'\]/", file_get_contents($root . '/public/actions/projects/overview-module-save.php')), 'Overview module redirects do not use numeric page id');
verify(str_contains(file_get_contents($root . '/public/actions/projects/overview-module-toggle.php'), "p.page_key"), 'Overview module toggle resolves page_key');
$milestoneSave = file_get_contents($root . '/public/actions/projects/milestone-save.php');
verify(str_contains($milestoneSave, 'created_by'), 'Milestone creation records creator');
$milestoneToggle = file_get_contents($root . '/public/actions/projects/milestone-toggle.php');
verify(str_contains($milestoneToggle, 'completed_by') && str_contains($milestoneToggle, 'completed_at'), 'Milestone completion records actor and time');

$calendarSource = file_get_contents($root . '/public/calendar.php');
verify(str_contains($calendarSource, 'project_milestones'), 'Global Calendar includes Project milestones');
verify(str_contains($calendarSource, 'project_user_can_view('), 'Global Calendar checks Project visibility before milestones');

$preferencesSource = file_get_contents($root . '/src/preferences.php');
verify(str_contains($preferencesSource, "'notify_projects' => '1'"), 'Project notifications default on');
verify(str_contains($preferencesSource, "'notify_projects'"), 'Project notification preference is registered');
$notificationsSource = file_get_contents($root . '/src/notifications.php');
verify(str_contains($notificationsSource, "str_starts_with(\$type, 'project_')"), 'Project notification types map to Projects category');
verify(str_contains($notificationsSource, 'function create_project_notifications_for_users'), 'Bounded Project notification helper exists');
verify(str_contains($notificationsSource, 'min($maxRecipients, 500)'), 'Project notification fan-out has a hard upper bound');

$announcementSave = file_get_contents($root . '/public/actions/projects/announcement-save.php');
verify(str_contains($announcementSave, "'project_announcement_posted'"), 'Announcement posting creates Project notification');
verify(str_contains($announcementSave, 'project_effective_members('), 'Announcement recipients come from effective Project membership');
foreach (['announcement-save.php', 'announcement-toggle-pin.php', 'announcement-archive.php'] as $action) {
    $source = file_get_contents($root . '/public/actions/projects/' . $action);
    verify(str_contains($source, 'project_user_can_manage('), "$action is manager-only");
}
verify(str_contains(file_get_contents($root . '/public/actions/projects/announcement-archive.php'), 'archived_at = CURRENT_TIMESTAMP'), 'Announcements archive instead of hard delete');

$linkSave = file_get_contents($root . '/public/actions/projects/link-save.php');
verify(str_contains($linkSave, "['http', 'https']"), 'Project Links only allow HTTP(S)');
verify(str_contains($linkSave, '(project_id, title, url, kind, added_by, created_at)'), 'Project Link insert matches schema');
verify(!str_contains($linkSave, 'javascript:'), 'Project Link action does not special-case unsafe schemes');
$linkRemove = file_get_contents($root . '/public/actions/projects/link-remove.php');
verify(str_contains($linkRemove, 'DELETE FROM project_links WHERE id = ? AND project_id = ?'), 'Project Link removal is Project-scoped');

$managerSource = file_get_contents($root . '/src/projects/overview-management.php');
foreach ([
    '/actions/projects/milestone-save.php',
    '/actions/projects/milestone-toggle.php',
    '/actions/projects/milestone-delete.php',
    '/actions/projects/announcement-save.php',
    '/actions/projects/announcement-toggle-pin.php',
    '/actions/projects/announcement-archive.php',
    '/actions/projects/link-save.php',
    '/actions/projects/link-remove.php',
] as $managerAction) {
    verify(str_contains($managerSource, $managerAction), "Overview manager exposes $managerAction");
}

$addMemberSource = file_get_contents($root . '/public/actions/projects/add-member.php');
verify(str_contains($addMemberSource, "'project_member_added'"), 'Adding a Project member creates notification');
verify(str_contains($addMemberSource, '$previousRole === null'), 'Member-added notification is transition-only');
$roleSource = file_get_contents($root . '/public/actions/projects/update-member-role.php');
verify(str_contains($roleSource, "'project_lead_assigned'"), 'Project Lead assignment creates notification');
verify(str_contains($roleSource, "\$previousRole !== 'lead'"), 'Lead notification is transition-only');

$projectPageSource = file_get_contents($root . '/public/projects/project.php');
verify(substr_count($projectPageSource, 'project_overview_manager($projectId') === 1, 'Project page has one Overview manager surface');
foreach (glob($root . '/public/actions/projects/*.php') as $file) {
    $source = file_get_contents($file);
    verify(str_contains($source, "['REQUEST_METHOD'] !== 'POST'") && str_contains($source, 'require_valid_csrf()'), basename($file) . ' POST + CSRF');
    if (basename($file) !== 'create.php') {
        verify(str_contains($source, 'project_require_writable_request($project)'), basename($file) . ' archive guard');
    }
}
verify(!str_contains(file_get_contents($root . '/public/projects/project.php'), 'project_overview_bootstrap('), 'GET never seeds');
verify(str_contains(source_of('project_overview_record_activity'), '$summary = project_overview_activity_summary($type)'), 'Persisted summaries come from allowlist');
verify((new ReflectionFunction('db'))->getStaticVariables()['connection'] === null, 'No database opened');
echo "PASS: $checks pre-migration security/contract checks. No database opened or created; no SQL executed.\n";
