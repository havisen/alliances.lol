<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/src/search.php';
require_once dirname(__DIR__) . '/src/command-palette.php';

// Capture SQL without executing it. No PDO connection or temporary database.
// Run copies of the actual function bodies in a namespace with a recording db().
final class ProjectSearchQueryRecorder
{
    public string $sql = '';
    public array $parameters = [];
    public array $rows = [];
    public int $queries = 0;

    public function prepare(string $sql): self
    {
        $this->sql = preg_replace('/\s+/', ' ', trim($sql));
        ++$this->queries;
        return $this;
    }

    public function execute(array $parameters): bool
    {
        $this->parameters = $parameters;
        return true;
    }

    public function fetchAll(): array
    {
        return $this->rows;
    }

    public function fetchColumn(): bool
    {
        return false;
    }
}

$recorder = new ProjectSearchQueryRecorder();
eval('namespace ProjectSearchProbe; function db() { return $GLOBALS["recorder"]; }');
foreach (['projects_for_workspace', 'projects_for_user', 'project_user_is_effective_member', 'alliances_search_projects'] as $name) {
    $function = new ReflectionFunction($name);
    $lines = file($function->getFileName());
    $source = implode('', array_slice($lines, $function->getStartLine() - 1, $function->getEndLine() - $function->getStartLine() + 1));
    eval('namespace ProjectSearchProbe; ' . $source);
}

$checks = 0;
function project_search_check(bool $condition, string $message): void
{
    global $checks;
    ++$checks;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

// Compare the search selector's full membership predicate with the existing
// detail-page access helper, rather than maintaining a test-only access model.
ProjectSearchProbe\project_user_is_effective_member(9, 3, 7);
preg_match('/AND \((.*)\) LIMIT 1$/', $recorder->sql, $membership);
project_search_check(isset($membership[1]), 'Existing membership predicate captured');
$predicate = 'AND (' . $membership[1] . ')';
$query = "%Workshop' OR 1=1 --%";

foreach ([['workspace_id' => 3], ['workspace_id' => 3, 'is_team_lead' => true], ['workspace_id' => 4]] as $access) {
    $before = $recorder->queries;
    ProjectSearchProbe\alliances_search_projects($access, 7, $query);
    project_search_check($recorder->queries === $before + 1, 'One query for non-admin Project search');
    project_search_check(str_contains($recorder->sql, $predicate), 'Exact existing direct/synchronized membership predicate preserved');
    project_search_check(str_contains($recorder->sql, 'p.workspace_id = ?'), 'Workspace scope remains mandatory');
    project_search_check($recorder->parameters === [$access['workspace_id'], 7, 7, $query, $query], 'Actor/workspace/query bindings are scoped');
    project_search_check(!str_contains($recorder->sql, $query), 'Query text is bound, never interpolated');
    project_search_check(str_contains($recorder->sql, 'p.status != "archived"'), 'Archived Projects excluded');
    project_search_check(str_contains($recorder->sql, 'p.name LIKE ? COLLATE NOCASE OR p.description LIKE ? COLLATE NOCASE'), 'Name and description searched');
    project_search_check(str_ends_with($recorder->sql, 'ORDER BY p.name COLLATE NOCASE ASC, p.id ASC LIMIT 20'), 'Deterministic SQL ordering and limit');
}

ProjectSearchProbe\alliances_search_projects(['workspace_id' => 3, 'is_admin' => true], 7, '%work%');
project_search_check($recorder->parameters === [3, '%work%', '%work%'], 'Admin stays scoped to own workspace');
project_search_check(!str_contains($recorder->sql, 'project_members'), 'Admin does not require Project membership');
project_search_check(str_contains($recorder->sql, 'status != "archived"'), 'Admin search also excludes archived');
project_search_check(str_ends_with($recorder->sql, 'LIMIT 20'), 'Admin search is bounded');

// Existing callers keep their unfiltered/unlimited list and Show archived behavior.
ProjectSearchProbe\projects_for_user(3, 7);
project_search_check(!str_contains($recorder->sql, 'LIKE') && !str_contains($recorder->sql, 'LIMIT'), 'Existing member list defaults preserved');
ProjectSearchProbe\projects_for_user(3, 7, true);
project_search_check(!str_contains($recorder->sql, 'archived') && str_contains($recorder->sql, $predicate), 'Archived member list retains authorization');
ProjectSearchProbe\projects_for_workspace(3, true);
project_search_check($recorder->parameters === [3] && !str_contains($recorder->sql, 'archived'), 'Admin Show archived preserved');

$recorder->rows = [
    ['id' => 9, 'name' => '<b>Workshop</b>', 'status' => 'on_hold', 'description' => "First line\nSecond line"],
    ['id' => 10, 'name' => 'Completed work', 'status' => 'completed', 'description' => str_repeat('ø', 200)],
    ['id' => 11, 'name' => 'Planning', 'status' => 'planning', 'description' => null],
];
$before = $recorder->queries;
$rows = ProjectSearchProbe\alliances_search_projects(['workspace_id' => 3], 7, '%work%');
project_search_check($recorder->queries === $before + 1, 'Mapping multiple results adds no membership queries');
project_search_check($rows[0]['type'] === 'project' && $rows[0]['url'] === '/projects/project.php?id=9', 'Project type and fixed numeric route');
project_search_check($rows[0]['subtitle'] === 'Project · On hold · First line Second line', 'Readable status and compact description');
project_search_check(mb_strlen(substr($rows[1]['subtitle'], strlen('Project · Completed · '))) === 140, 'Unicode description length bounded');
project_search_check($rows[2]['subtitle'] === 'Project · Planning', 'Missing description renders cleanly');
project_search_check(array_keys($rows[0]) === ['type', 'id', 'title', 'subtitle', 'url'], 'Only safe result metadata returned');
$before = $recorder->queries;
project_search_check(ProjectSearchProbe\alliances_search_projects([], 7, '%work%') === [], 'Missing workspace rejected');
project_search_check(ProjectSearchProbe\alliances_search_projects(['workspace_id' => 3], 0, '%work%') === [], 'Invalid actor rejected');
project_search_check($recorder->queries === $before, 'Invalid access does not query');

foreach ([null, ['workspace_id' => 3], ['workspace_id' => 3, 'is_admin' => true]] as $access) {
    ob_start();
    render_command_palette(['id' => 7], $access, !empty($access['is_admin']));
    $html = (string) ob_get_clean();
    preg_match('/id="command-palette-nav">(.*?)<\/script>/s', $html, $json);
    $commands = json_decode($json[1], true, 512, JSON_THROW_ON_ERROR);
    $projects = array_values(array_filter($commands, static fn (array $command): bool => $command['label'] === 'Projects'));
    project_search_check(count($projects) === ($access === null ? 0 : 1), 'One Projects shortcut for workspace users only');
    if ($access !== null) {
        project_search_check($projects[0]['url'] === '/projects/', 'Shortcut points to existing Project list');
    }
}

project_search_check((new ReflectionFunction('db'))->getStaticVariables()['connection'] === null, 'Real database connection never initialized');
echo "PASS: $checks Project search query/render checks. No database opened or created.\n";
