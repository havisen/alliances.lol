<?php

declare(strict_types=1);

// Pure helper regressions: this script never opens, creates, or modifies a database.
require_once dirname(__DIR__) . '/src/tasks/values.php';
require_once dirname(__DIR__) . '/src/tasks/access.php';

set_error_handler(static function (int $severity, string $message, string $file, int $line): never {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$checks = 0;
function check(bool $condition, string $message): void
{
    global $checks;
    ++$checks;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

$people = [7 => 'Alex'];
$teams = [8 => 'Operations'];
$samples = [
    'short_text' => 'A <task> & details', 'long_text' => "Line one\nLine two",
    'rich_text' => '<script>alert(1)</script>', 'code' => 'echo "hello";',
    'number' => '100', 'integer' => '10', 'decimal' => '10.25',
    'number_unit' => '100', 'currency' => '100', 'percentage' => '0',
    'range' => '50', 'rating' => '3', 'yes_no' => 'No', 'checkbox' => '0',
    'pass_fail' => 'Fail', 'tri_state' => 'N/A', 'status' => 'Ready',
    'dropdown' => 'Ready', 'multi_select' => ['Ready', 'Done'], 'radio' => 'Done',
    'checkbox_group' => ['Ready'], 'scale' => '3', 'date' => '2026-10-06',
    'datetime' => '2026-10-06T10:30', 'time' => '10:30',
    'date_range' => ['start' => '2026-10-06', 'end' => '2026-10-07'],
    'time_range' => ['start' => '10:30', 'end' => '11:30'], 'duration' => '3661',
    'email' => 'alex@example.com', 'phone' => '+47 123 45 678',
    'url' => 'https://example.com/', 'person' => '7', 'team' => '8',
    'address' => "Example Road 1\nOslo", 'location' => 'Oslo',
    'coordinates' => ['lat' => '0', 'lng' => '10.25'], 'version' => '1.2.3',
    'ip_address' => '2001:db8::1', 'color' => '#12abef',
    'barcode' => '0123456789', 'qr_code' => 'QR contents',
];

$types = work_template_field_types();
$advancedTypes = work_template_advanced_field_types();
$legacyTypes = array_diff_key($types, array_flip($advancedTypes));
check(count($advancedTypes) === 23, 'Exactly 23 advanced field types are requested.');
check(count($types) === 64, 'The catalog must contain 41 legacy + 23 advanced types.');
check(count($legacyTypes) === 41, 'The existing 41 legacy types remain intact.');
check(array_diff_key($legacyTypes, $samples) === [], 'Every legacy type has a test sample.');
check(!work_template_field_available('asset_relation'), 'asset_relation stays unavailable.');
$fields = [];
foreach ($legacyTypes as $type => $registration) {
    $field = [
        'id' => count($fields) + 1, 'name' => $registration['label'], 'field_type' => $type,
        'is_required' => false, 'options' => ['Ready', 'Done'], 'number_unit' => 'kg',
        'config' => work_template_field_config_defaults($type),
    ];
    $fields[$type] = $field;
    $sample = $samples[$type];
    check(work_template_validate_value($field, $sample, $people, $teams) === null, "$type validates");
    $row = work_template_value_storage_values($field, $sample);
    $value = work_template_field_current_value($field, $row);
    check(work_template_validate_value($field, $value, $people, $teams) === null, "$type round-trips");
    $html = work_template_render_field_input($field, $value, $people, $teams);
    check(str_contains($html, 'name="values[' . $field['id'] . ']'), "$type has a named control");
    check(str_contains($html, 'aria-label='), "$type has an accessible control name");
    $display = work_template_render_field_value($field, $value, $people, $teams);
    check($display !== '', "$type renders read-only");
    check(!str_contains($display, '<script>'), "$type escapes stored text");

    check(work_template_validate_value($field, null, $people, $teams) === null, "$type can be empty");
    check(work_template_field_current_value($field, work_template_value_storage_values($field, null)) === null, "$type clearing persists null");
    $required = array_replace($field, ['is_required' => true]);
    check(work_template_validate_value($required, null, $people, $teams) !== null, "$type required validation");

    // Attack/historical shapes must be rejected and render safely without warnings.
    foreach ([[['nested']], ['start' => ['bad']], new stdClass()] as $malformed) {
        check(work_template_validate_value($field, $malformed, $people, $teams) !== null, "$type rejects malformed shapes");
        work_template_render_field_input($field, $malformed, $people, $teams, 'Invalid value');
        work_template_render_field_value($field, $malformed, $people, $teams);
    }
}

check(work_template_render_field_value($fields['number'], 100, [], []) === '100', 'Integer zeroes survive numeric formatting');
check(work_template_render_field_value($fields['currency'], 100, [], []) === '$100', 'Currency zeroes survive formatting');
check(work_template_render_field_value($fields['number_unit'], 100, [], []) === '100 kg', 'Unit zeroes survive formatting');
check(work_template_render_field_value($fields['checkbox'], 0, [], []) === 'No', 'Unchecked is a real false value');
check(work_template_render_field_value($fields['percentage'], 0, [], []) === '0%', 'Zero is not blank');
check(work_template_validate_value($fields['number'], '1e999', [], []) !== null, 'Overflow rejected');
check(work_template_validate_value($fields['date'], "2026-10-06\0", [], []) !== null, 'Null byte dates rejected');
check(work_template_validate_value($fields['person'], 99, $people, $teams) !== null, 'Unavailable person rejected');
check(work_template_validate_value($fields['team'], 99, $people, $teams) !== null, 'Unavailable team rejected');
check(work_template_validate_value($fields['person'], '7other', $people, $teams) !== null, 'Malformed person ID rejected');
check(work_template_validate_value($fields['team'], '8other', $people, $teams) !== null, 'Malformed team ID rejected');
check(work_template_validate_value($fields['dropdown'], 'Removed option', [], []) !== null, 'Unavailable option rejected');
check(!str_contains(work_template_render_field_value($fields['color'], 'red; background:url(https://example.com)', [], []), 'style='), 'Historical invalid colors cannot inject CSS');

$corrupt = ['value_text' => null, 'value_integer' => null, 'value_real' => null, 'value_json' => '{invalid'];
check(work_template_field_current_value($fields['coordinates'], $corrupt) === '{invalid', 'Malformed historical JSON stays visible');
check(work_template_validate_value($fields['coordinates'], '{invalid', [], []) !== null, 'Malformed JSON cannot silently save as empty');
$sections = [['fields' => [$fields['number']]]];
$submitted = [$fields['number']['id'] => 'not a number', 'field_type' => 'short_text'];
check(work_template_validate_task_values($sections, $submitted, [], []) !== [], 'Submitted type never overrides the stored definition');

foreach (['range' => 'number', 'scale' => 'number', 'color' => 'text'] as $type => $controlType) {
    $blank = work_template_render_field_input($fields[$type], null, [], []);
    check((bool) preg_match('/type="' . $controlType . '"[^>]*name="values\[\d+\]"[^>]*value=""/', $blank), "$type submits an explicit blank without picker defaults");
    check(!preg_match('/type="(?:range|color)"[^>]*name=/', $blank), "$type picker itself cannot overwrite the named value");
}

// Permission helpers assume task_for_member has already established list/workspace access.
$task = ['list_created_by' => 1, 'assigned_to' => 2, 'members_can_edit' => 0];
check(task_can_edit($task, 1), 'Creator edits');
check(!task_can_edit($task, 2), 'Assignee alone cannot edit');
check(!task_can_edit($task, 3), 'Other read-only member cannot edit');
check(task_can_complete($task, 1), 'Creator completes/reopens');
check(task_can_complete($task, 2), 'Assignee completes/reopens');
check(!task_can_complete($task, 3), 'Other member cannot complete assigned task');
$task['members_can_edit'] = 1;
check(task_can_edit($task, 3), 'Editable-list member edits');
check(!task_can_complete($task, 3), 'Edit permission does not imply completion permission');
$task['assigned_to'] = null;
check(task_can_complete($task, 3), 'Everyone task can be completed by a list member');
check(!task_can_complete($task, 0), 'Invalid actor cannot complete');

check((new ReflectionFunction('db'))->getStaticVariables()['connection'] === null, 'Tests never opened the database');

echo "PASS: $checks checks across " . count($legacyTypes) . " legacy field types and Task permissions. No database opened.\n";
