<?php

declare(strict_types=1);

// Render the actual page markup with fixtures, without authentication or any database.
require __DIR__ . '/task-experience.php';

function csrf_input(): string
{
    return '<input type="hidden" name="csrf_token" value="fixture-only">';
}

function render_navigation(array $user): void
{
    // Navigation is outside this page's scope and normally requires a logged-in session.
}

$pageSource = file_get_contents(dirname(__DIR__) . '/public/tasks/task.php');
$markup = substr($pageSource, strpos($pageSource, '?>') + 2);
$fixture = [
    'user' => ['id' => 1], 'taskId' => 12, 'listId' => 4,
    'task' => ['name' => 'Inspect the workshop', 'list_name' => 'Weekly maintenance',
        'description' => "Check equipment and record the result.\nReport anything that needs attention.",
        'created_at' => '2026-10-01 09:00:00', 'completed_at' => null,
        'status' => 'pending', 'template_version_id' => null],
    'assignedLabel' => 'Alex', 'list' => ['project_id' => null], 'project' => null,
    'canViewProject' => false, 'canEdit' => true, 'canComplete' => true, 'canDelete' => true,
    'assigneeChoices' => [1 => 'Alex', 2 => 'Sam'], 'unavailableAssignee' => false,
    'formName' => 'Inspect the workshop', 'formDescription' => 'Check equipment.', 'formAssignee' => '1',
    'detailsError' => null, 'workError' => null, 'savedMessage' => null,
    'definition' => null, 'values' => [], 'projectChoices' => [], 'personChoices' => $people, 'teamChoices' => $teams,
    'templateValueErrors' => [], 'valuesSubmitted' => false, 'submittedTemplateValues' => [],
];
$render = static function (array $data) use ($markup): string {
    extract($data, EXTR_SKIP);
    $escape = static fn (string $text): string => htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    $formatDate = static fn (?string $value): string => (string) $value;
    ob_start();
    eval('?>' . $markup);
    return (string) ob_get_clean();
};
$domFor = static function (string $html): DOMXPath {
    libxml_use_internal_errors(true);
    $document = new DOMDocument();
    $document->loadHTML($html);
    libxml_clear_errors();
    return new DOMXPath($document);
};

$basic = $render($fixture);
check(!str_contains($basic, 'id="work-title"'), 'Basic task has no empty template section');
check(str_contains($basic, 'Save task details'), 'Editors can save normal details');
check(str_contains($basic, 'Complete task'), 'Pending task can be completed');
check(str_contains($basic, 'Back to Task List'), 'Task List navigation remains visible');
check(!str_contains($basic, '/projects/project.php'), 'Detached list has no project link');

$viewer = array_replace($fixture, ['canEdit' => false, 'canComplete' => false, 'canDelete' => false]);
$viewHtml = $render($viewer);
check($domFor($viewHtml)->query('//form')->length === 0, 'Read-only viewer receives no mutation forms');
$assigneeView = $render(array_replace($viewer, ['canComplete' => true]));
check($domFor($assigneeView)->query('//form')->length === 1, 'Assigned read-only member gets only status control');

$template = $fixture;
$template['task']['template_version_id'] = 20;
$template['definition'] = [
    'template_name' => 'Workshop inspection', 'version_number' => 2, 'template_status' => 'archived',
    'sections' => [['name' => 'Inspection', 'description' => 'Record observations.', 'fields' => array_values($fields)]],
];
foreach ($fields as $type => $field) {
    $template['values'][$field['id']] = work_template_value_storage_values($field, $samples[$type]);
}
$templateHtml = $render($template);
$templateDom = $domFor($templateHtml);
check(str_contains($templateHtml, 'Version 2'), 'Exact version is displayed');
check(str_contains($templateHtml, 'Archived template'), 'Archived template still renders');
check($templateDom->query('//*[@role="group"]')->length === 41, 'All 41 fields render on the actual Task page');
check($templateDom->query('//label//label')->length === 0, 'No nested field labels');
check(str_contains($templateHtml, 'Save work'), 'Template work has a distinct save action');

$templateViewer = array_replace($template, ['canEdit' => false, 'canComplete' => false, 'canDelete' => false]);
$templateViewHtml = $render($templateViewer);
check($domFor($templateViewHtml)->query('//form')->length === 0, 'Template viewer has no working edit controls');
check(str_contains($templateViewHtml, '$100'), 'Read-only stored values render accurately');

$invalid = $template;
$invalid['values'][$fields['coordinates']['id']]['value_json'] = '{broken';
$invalid['values'][$fields['person']['id']]['value_integer'] = 999;
$invalidHtml = $render($invalid);
check(str_contains($invalidHtml, '{broken'), 'Invalid historical JSON remains visible');
check(str_contains($invalidHtml, 'Saved value needs attention'), 'Invalid historical values are explained');

$failed = array_replace($template, [
    'valuesSubmitted' => true,
    'submittedTemplateValues' => [$fields['short_text']['id'] => 'Keep this new draft', $fields['checkbox']['id'] => null],
    'templateValueErrors' => [$fields['number']['id'] => 'Enter a number.'],
    'workError' => 'Work was not saved.',
]);
$failedHtml = $render($failed);
check(str_contains($failedHtml, 'Keep this new draft'), 'Failed save retains submitted text');
check(!str_contains($failedHtml, 'value="0" checked'), 'Omitted checkbox does not revert to saved state');
check(str_contains($failedHtml, 'aria-invalid="true"'), 'Invalid fields are identified accessibly');

$completed = $fixture;
$completed['task']['status'] = 'completed';
$completed['task']['completed_at'] = '2026-10-06 11:00:00';
check(str_contains($render($completed), 'Reopen task'), 'Completed task offers reopening');

$projectFixture = array_replace($fixture, [
    'list' => ['project_id' => 5], 'project' => ['id' => 5, 'name' => 'Operations refresh'],
    'canViewProject' => true,
]);
check(str_contains($render($projectFixture), '/projects/project.php?id=5'), 'Accessible Project is linked');
$projectFixture['canViewProject'] = false;
$restrictedProject = $render($projectFixture);
check(!str_contains($restrictedProject, 'Operations refresh'), 'Restricted Project name is not disclosed');
check(!str_contains($restrictedProject, '/projects/project.php'), 'Restricted Project has no link');

$unavailable = array_replace($fixture, [
    'assignedLabel' => 'Former member (inactive)', 'unavailableAssignee' => true, 'formAssignee' => 'keep',
]);
check(str_contains($render($unavailable), 'Keep: Former member (inactive)'), 'Unavailable assignee can be preserved');

// Optional static previews use only fixture HTML and a copy of the existing stylesheet.
if (isset($argv[1])) {
    $directory = $argv[1];
    if (!is_dir($directory)) {
        mkdir($directory, 0777, true);
    }
    foreach (['basic' => $basic, 'template' => $templateHtml, 'viewer' => $templateViewHtml, 'historical' => $invalidHtml] as $name => $html) {
        file_put_contents($directory . '/' . $name . '.html', str_replace('/assets/css/app.css', 'app.css', $html));
    }
    copy(dirname(__DIR__) . '/public/assets/css/app.css', $directory . '/app.css');
}

check((new ReflectionFunction('db'))->getStaticVariables()['connection'] === null, 'Page render tests never opened the database');
echo "PASS: $checks total helper/render checks; no database opened.\n";
