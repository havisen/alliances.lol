<?php

declare(strict_types=1);

/*
 * DB-free static/contract checks for multi-workspace isolation, the per-Work-
 * space Drive quota ceiling, and the new auth/signup/switch surfaces.
 * No PDO construction, SQL execution, or db() connection is performed.
 */

require_once dirname(__DIR__) . '/src/auth.php';
require_once dirname(__DIR__) . '/src/drive/quota.php';

set_error_handler(static function (int $severity, string $message, string $file, int $line): never {
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$checks = 0;
$root = dirname(__DIR__);

function verify(bool $condition, string $message): void
{
    global $checks;
    ++$checks;
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function source_of(string $function): string
{
    $r = new ReflectionFunction($function);
    return implode('', array_slice(file($r->getFileName()), $r->getStartLine() - 1, $r->getEndLine() - $r->getStartLine() + 1));
}

/* --------------------------------------------------------------------------
 * Multi-workspace auth surface
 * ------------------------------------------------------------------------ */
verify(function_exists('user_workspaces'), 'user_workspaces is defined');
verify(function_exists('workspace_is_member'), 'workspace_is_member is defined');
verify(function_exists('resolve_active_workspace_id'), 'resolve_active_workspace_id is defined');
verify(function_exists('switch_workspace'), 'switch_workspace is defined');

$accessSource = source_of('workspace_access');
verify(str_contains($accessSource, 'resolve_active_workspace_id('), 'workspace_access resolves the active Workspace');
verify(str_contains($accessSource, 'workspace_members'), 'workspace_access re-verifies membership on every request');
verify(!str_contains($accessSource, 'SELECT workspace_id, role'), 'legacy arbitrary single-workspace pick is gone');

$resolveSource = source_of('resolve_active_workspace_id');
verify(str_contains($resolveSource, 'filter_var'), 'active_workspace_id is integer-validated');
verify(str_contains($resolveSource, 'in_array'), 'active_workspace_id is checked against real membership');

$switchSource = source_of('switch_workspace');
verify(str_contains($switchSource, 'workspace_is_member('), 'switch_workspace verifies membership before selecting');

/* --------------------------------------------------------------------------
 * Quota helpers
 * ------------------------------------------------------------------------ */
verify(function_exists('workspace_storage_used'), 'workspace_storage_used is defined');
verify(function_exists('workspace_storage_limit'), 'workspace_storage_limit is defined');
verify(function_exists('workspace_quota_assert_capacity'), 'workspace_quota_assert_capacity is defined');
verify(function_exists('workspace_quota_lock_and_assert'), 'workspace_quota_lock_and_assert is defined');

$usedSource = source_of('workspace_storage_used');
foreach (['GROUP BY storage_id', 'drive_file_versions', 'drive_files', 'MAX(encrypted_size)'] as $predicate) {
    verify(str_contains($usedSource, $predicate), 'workspace_storage_used matches storage-usage accounting: ' . $predicate);
}

$limitSource = source_of('workspace_storage_limit');
verify(str_contains($limitSource, 'workspace_quotas'), 'limit reads workspace_quotas');
verify(str_contains($limitSource, 'ALLIANCES_WORKSPACE_STORAGE_LIMIT_BYTES'), 'limit falls back to the 1 GiB default');

$assertSource = source_of('workspace_quota_assert_capacity');
verify(str_contains($assertSource, 'DriveQuotaExceededException'), 'capacity assertion throws the typed quota exception');

$lockSource = source_of('workspace_quota_lock_and_assert');
verify(str_contains($lockSource, 'UPDATE workspace_quotas'), 'lock helper acquires the SQLite write lock');
verify(str_contains($lockSource, 'storage_limit_bytes = storage_limit_bytes'), 'lock is a no-op row touch');

/* --------------------------------------------------------------------------
 * Write endpoints enforce the ceiling before/inside their transactions
 * ------------------------------------------------------------------------ */
foreach (['upload.php', 'copy.php', 'save-version.php', 'restore-version.php'] as $endpoint) {
    $source = file_get_contents($root . '/public/actions/drive/' . $endpoint);
    verify(str_contains($source, 'workspace_quota_assert_capacity('), $endpoint . ' rejects before accepting storage');
    verify(str_contains($source, 'workspace_quota_lock_and_assert('), $endpoint . ' re-checks quota inside the transaction');
    verify(str_contains($source, 'DriveQuotaExceededException'), $endpoint . ' handles the quota exception');
}

/* --------------------------------------------------------------------------
 * Signup and switch surfaces
 * ------------------------------------------------------------------------ */
$signup = file_get_contents($root . '/public/signup.php');
foreach (['require_valid_csrf()', 'password_hash(', 'session_regenerate_id', 'active_workspace_id', 'workspace_members', 'workspace_quotas', '1073741824'] as $needle) {
    verify(str_contains($signup, $needle), 'signup includes ' . $needle);
}
verify(substr_count($signup, 'beginTransaction()') === 1, 'signup is atomic');

$switch = file_get_contents($root . '/public/actions/workspace/switch.php');
foreach (['require_login()', 'require_valid_csrf()', 'switch_workspace(', 'HTTP_REFERER', 'hash_equals'] as $needle) {
    verify(str_contains($switch, $needle), 'switch includes ' . $needle);
}

/* --------------------------------------------------------------------------
 * Navigation exposes a workspace switcher
 * ------------------------------------------------------------------------ */
$navigation = file_get_contents($root . '/src/navigation.php');
verify(str_contains($navigation, '/actions/workspace/switch.php'), 'navigation links to the switch action');
verify(str_contains($navigation, 'user_workspaces('), 'navigation lists the user\'s workspaces');

/* --------------------------------------------------------------------------
 * Guarantee no database was opened by this test
 * ------------------------------------------------------------------------ */
verify((new ReflectionFunction('db'))->getStaticVariables()['connection'] === null, 'No database opened');

echo "PASS: $checks workspace-isolation/quota contract checks. No database opened or created; no SQL executed.\n";